<?php

use App\Http\Middleware\EnsureIdempotency;
use App\Http\Middleware\EnsureUserIsActive;
use App\Http\Middleware\RequireRole;
use App\Support\Exceptions\ApiException;
use App\Support\Exceptions\ApiExceptionRenderer;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Sentry\Laravel\Integration;
use Symfony\Component\HttpFoundation\Response;

$app = Application::configure(basePath: dirname(__DIR__))
    ->withEvents(discover: false)
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'role' => RequireRole::class,
            'active' => EnsureUserIsActive::class,
            'idempotency' => EnsureIdempotency::class,
        ]);

        $trustedProxies = array_values(array_filter(array_map(
            'trim',
            explode(',', (string) env('TRUSTED_PROXIES', '')),
        )));

        $middleware->trustProxies(
            at: $trustedProxies === [] ? null : $trustedProxies,
            headers: Request::HEADER_X_FORWARDED_FOR |
                Request::HEADER_X_FORWARDED_HOST |
                Request::HEADER_X_FORWARDED_PORT |
                Request::HEADER_X_FORWARDED_PROTO |
                Request::HEADER_X_FORWARDED_AWS_ELB,
        );

        $middleware->throttleApi();
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        if (filled(config('sentry.dsn'))) {
            Integration::handles($exceptions);
        }
        $renderer = new ApiExceptionRenderer;

        $exceptions->render(function (Throwable $e, Request $request) use ($renderer): ?Response {
            return $renderer->render($e, $request);
        });

        $exceptions->dontReport([
            ApiException::class,
        ]);
    })->create();

$app->usePublicPath(dirname(__DIR__));

return $app;
