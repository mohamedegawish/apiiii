<?php

namespace App\Console\Commands;

use App\Jobs\SendDailyAttendanceSummary;
use App\Support\CenterClock;
use Illuminate\Console\Command;

class SendDailyAttendanceSummaryCommand extends Command
{
    protected $signature = 'automation:attendance-summary {--date= : Attendance date (Y-m-d)}';

    protected $description = 'Queue daily attendance summaries for guardians';

    public function handle(): int
    {
        $date = $this->option('date') ?: CenterClock::today()->toDateString();
        SendDailyAttendanceSummary::dispatch($date);
        $this->info("Queued attendance summaries for {$date}.");

        return self::SUCCESS;
    }
}
