<?php

namespace App\Console\Commands;

use App\Jobs\CleanupExpiredIdempotencyKeys;
use Illuminate\Console\Command;

class CleanupExpiredIdempotencyKeysCommand extends Command
{
    protected $signature = 'automation:cleanup-idempotency-keys';

    protected $description = 'Delete idempotency keys past their expiry';

    public function handle(): int
    {
        $count = (new CleanupExpiredIdempotencyKeys)->handle();
        $this->info("Deleted {$count} expired idempotency key(s).");

        return self::SUCCESS;
    }
}
