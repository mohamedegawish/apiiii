<?php

namespace App\Console\Commands;

use App\Jobs\CleanupExpiredSanctumTokens;
use Illuminate\Console\Command;

class CleanupExpiredSanctumTokensCommand extends Command
{
    protected $signature = 'automation:cleanup-sanctum-tokens';

    protected $description = 'Delete expired Sanctum personal access tokens';

    public function handle(): int
    {
        $count = (new CleanupExpiredSanctumTokens)->handle();
        $this->info("Deleted {$count} expired Sanctum token(s).");

        return self::SUCCESS;
    }
}
