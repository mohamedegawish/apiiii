<?php

namespace App\Console\Commands;

use App\Jobs\CleanupOldNotifications;
use Illuminate\Console\Command;

class CleanupOldNotificationsCommand extends Command
{
    protected $signature = 'automation:cleanup-notifications {--days=90 : Retention period in days}';

    protected $description = 'Delete notifications older than the retention period';

    public function handle(): int
    {
        $days = max(1, (int) $this->option('days'));
        $count = (new CleanupOldNotifications($days))->handle();
        $this->info("Deleted {$count} old notification(s).");

        return self::SUCCESS;
    }
}
