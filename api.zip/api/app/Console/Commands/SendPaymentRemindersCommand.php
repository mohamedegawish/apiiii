<?php

namespace App\Console\Commands;

use App\Jobs\SendPaymentReminders;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

class SendPaymentRemindersCommand extends Command
{
    protected $signature = 'automation:payment-reminders';

    protected $description = 'Queue payment reminders when payment storage is available';

    public function handle(): int
    {
        if (! Schema::hasTable('invoices')) {
            $message = 'Payment reminders skipped because the invoices table does not exist.';
            Log::info($message);
            $this->components->info($message);

            return self::SUCCESS;
        }

        SendPaymentReminders::dispatch();
        $this->info('Queued payment reminders.');

        return self::SUCCESS;
    }
}
