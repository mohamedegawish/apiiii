<?php

namespace App\Console\Commands;

use App\Jobs\SendMonthlyStudentReport;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;

class SendMonthlyStudentReportCommand extends Command
{
    protected $signature = 'automation:monthly-student-report {--month= : Report month (Y-m)}';

    protected $description = 'Queue monthly student reports for guardians';

    public function handle(): int
    {
        $month = $this->option('month') ? Carbon::createFromFormat('Y-m', $this->option('month')) : today();
        SendMonthlyStudentReport::dispatch($month->copy()->startOfMonth()->toDateString(), $month->copy()->endOfMonth()->toDateString());
        $this->info("Queued monthly student reports for {$month->format('Y-m')}.");

        return self::SUCCESS;
    }
}
