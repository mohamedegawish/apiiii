<?php

namespace App\Console\Commands;

use App\Enums\Role;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

/**
 * Creates the first super admin (or a center owner) on a fresh production
 * database.
 *
 * Production has no other way in: the demo seeders refuse to run outside
 * local/development/testing, and POST /users never creates a super admin.
 * The password is always typed at the prompt (hidden), never passed as an
 * argument, so it does not end up in shell history or process lists.
 * Every other account (teachers, students, guardians) is created from the
 * admin app, which also creates their teacher / student / guardian records.
 */
class CreateAdminUserCommand extends Command
{
    protected $signature = 'user:create-admin
        {--role=super_admin : super_admin or center_owner}
        {--name= : Display name}
        {--email= : Login e-mail}';

    protected $description = 'Create a super admin or center owner account (password prompted, hidden)';

    public function handle(): int
    {
        $role = Role::tryFrom((string) $this->option('role'));

        if (! in_array($role, [Role::SuperAdmin, Role::CenterOwner], true)) {
            $this->error('--role must be super_admin or center_owner. Other accounts are created from the admin app.');

            return self::FAILURE;
        }

        $name = (string) ($this->option('name') ?: $this->ask('Name'));
        $email = mb_strtolower(trim((string) ($this->option('email') ?: $this->ask('E-mail'))));
        $password = (string) $this->secret('Password (min 8 characters, hidden)');
        $confirmation = (string) $this->secret('Repeat password');

        $validator = Validator::make(
            ['name' => $name, 'email' => $email, 'password' => $password, 'password_confirmation' => $confirmation],
            [
                'name' => ['required', 'string', 'max:255'],
                'email' => ['required', 'email', 'max:255', 'unique:users,email'],
                'password' => ['required', 'string', 'min:8', 'max:255', 'confirmed'],
            ],
        );

        if ($validator->fails()) {
            foreach ($validator->errors()->all() as $message) {
                $this->error($message);
            }

            return self::FAILURE;
        }

        $user = new User;
        $user->forceFill([
            'name' => $name,
            'email' => $email,
            'password' => Hash::make($password),
            'role' => $role,
            'locale' => 'ar',
            'timezone' => config('itqan.timezone', 'UTC'),
            'is_active' => true,
            'email_verified_at' => now(),
        ])->save();

        $this->info("Created {$role->value} account {$email} ({$user->id}).");

        return self::SUCCESS;
    }
}
