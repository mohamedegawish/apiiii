<?php

namespace App\Console\Commands;

use App\Support\Storage\PlatformStorage;
use Illuminate\Console\Command;
use Illuminate\Contracts\Queue\Factory as QueueFactory;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schedule;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Kreait\Firebase\Contract\Messaging;
use Sentry\State\HubInterface;
use Spatie\Backup\Config\Config as BackupConfig;
use Spatie\Backup\Tasks\Monitor\BackupDestinationStatusFactory;
use Throwable;

class ProductionSmokeTestCommand extends Command
{
    protected $signature = 'operations:smoke-test {--strict}';

    protected $description = 'Verify production dependencies and operational configuration';

    /** @var array<int, string> */
    private const REQUIRED_SCHEDULES = [
        'automation:attendance-summary',
        'automation:weekly-student-report',
        'automation:monthly-student-report',
        'automation:payment-reminders',
        'automation:upcoming-session-reminders --hours=24',
        'automation:detect-inactive-students --days=30',
        'automation:cleanup-device-tokens --days=90',
        'automation:cleanup-sanctum-tokens',
        'automation:cleanup-notifications --days=90',
        'queue:health-check',
        'queue:monitor database:default --max=100',
        'queue:prune-failed --hours=168',
        'queue:prune-batches --hours=168 --unfinished=168 --cancelled=168',
        'sanctum:prune-expired --hours=24',
        'backup:run --only-db',
        'backup:run',
        'backup:clean',
        'backup:monitor',
    ];

    public function handle(PlatformStorage $storage, QueueFactory $queues, BackupConfig $backupConfig): int
    {
        $strict = (bool) $this->option('strict');
        $results = [];

        $results[] = $this->check('Database', function (): string {
            DB::select('select 1 as smoke_test');

            return 'Select succeeded on '.DB::getDefaultConnection().'.';
        });
        $results[] = $this->check('Cache', function (): string {
            $key = 'operations:smoke-test:'.Str::uuid();
            $value = Str::random(32);

            try {
                if (! Cache::put($key, $value, 60) || Cache::get($key) !== $value) {
                    throw new \RuntimeException('Cache value could not be written and read back.');
                }
            } finally {
                $deleted = Cache::forget($key);
            }

            if (! $deleted || Cache::has($key)) {
                throw new \RuntimeException('Cache value could not be deleted.');
            }

            return 'Put, get, and delete succeeded on '.config('cache.default').'.';
        });
        $results[] = $this->check('Platform storage', function () use ($storage): string {
            $path = 'smoke-tests/'.Str::uuid().'.txt';
            $contents = Str::random(32);

            try {
                if (! $storage->put($path, $contents) || $storage->get($path) !== $contents) {
                    throw new \RuntimeException('Stored value could not be written and read back.');
                }
            } finally {
                $deleted = $storage->delete($path);
            }

            if (! $deleted || $storage->exists($path)) {
                throw new \RuntimeException('Stored value could not be deleted.');
            }

            return 'Put, get, and delete succeeded.';
        });
        $results[] = $this->check('Queue', function () use ($queues): string {
            $connection = (string) config('queue.default');
            $queues->connection($connection);
            $queueConfig = config("queue.connections.{$connection}", []);
            $tables = [
                [(string) config('queue.batching.database'), (string) config('queue.batching.table', 'job_batches')],
                [(string) config('queue.failed.database'), (string) config('queue.failed.table', 'failed_jobs')],
            ];

            if (($queueConfig['driver'] ?? null) === 'database') {
                $tables[] = [
                    (string) ($queueConfig['connection'] ?: config('database.default')),
                    (string) ($queueConfig['table'] ?? 'jobs'),
                ];
            }

            $missing = collect($tables)
                ->unique(fn (array $table): string => implode(':', $table))
                ->reject(fn (array $table): bool => Schema::connection($table[0])->hasTable($table[1]))
                ->map(fn (array $table): string => "{$table[0]}.{$table[1]}")
                ->values();

            if ($missing->isNotEmpty()) {
                throw new \RuntimeException('Missing queue table(s): '.$missing->implode(', '));
            }

            return "Connection [{$connection}] resolved and queue tables exist.";
        });
        $results[] = $this->check('Scheduler', function (): string {
            $commands = collect(Schedule::events())->pluck('command')->filter();
            $missing = collect(self::REQUIRED_SCHEDULES)
                ->reject(fn (string $required): bool => $commands->contains(
                    fn (string $command): bool => str_ends_with($command, $required)
                ));

            if ($missing->isNotEmpty()) {
                throw new \RuntimeException('Missing scheduled command(s): '.$missing->implode(', '));
            }

            return count(self::REQUIRED_SCHEDULES).' required commands are scheduled.';
        });
        $results[] = $this->check('Routes', function (): string {
            $uris = collect(Route::getRoutes()->getRoutes())->map->uri();
            $required = ['api/v1/audit-logs', 'api/v1/audit-logs/{auditLog}', 'api/v1/health'];
            $missing = collect($required)->reject(fn (string $uri): bool => $uris->contains($uri));

            if ($missing->isNotEmpty()) {
                throw new \RuntimeException('Missing route(s): '.$missing->implode(', '));
            }

            return 'Audit index/detail and health routes are registered.';
        });
        $results[] = $this->externalBindingCheck(
            'Firebase Messaging',
            config('firebase.projects.'.config('firebase.default').'.credentials'),
            Messaging::class,
            $strict,
        );
        $results[] = $this->externalBindingCheck(
            'Sentry Hub',
            config('sentry.dsn'),
            HubInterface::class,
            $strict,
        );
        $results[] = $this->check('Backup', function () use ($backupConfig): string {
            $statuses = BackupDestinationStatusFactory::createForMonitorConfig($backupConfig->monitoredBackups);

            if ($statuses->isEmpty()) {
                throw new \RuntimeException('No backup destinations are monitored.');
            }

            $unhealthy = $statuses->reject->isHealthy()->map(function ($status): string {
                $destination = $status->backupDestination();

                return $destination->backupName().' on '.$destination->diskName();
            });

            if ($unhealthy->isNotEmpty()) {
                throw new \RuntimeException('Unhealthy backup destination(s): '.$unhealthy->implode(', '));
            }

            return $statuses->count().' monitored destination(s) are reachable and healthy.';
        });

        $this->table(['Check', 'Status', 'Details'], $results);

        return collect($results)->contains(fn (array $result): bool => $result[1] === 'FAIL')
            ? self::FAILURE
            : self::SUCCESS;
    }

    /** @return array{string, string, string} */
    private function check(string $name, callable $check): array
    {
        try {
            return [$name, 'PASS', $check()];
        } catch (Throwable $exception) {
            return [$name, 'FAIL', $exception->getMessage()];
        }
    }

    /** @return array{string, string, string} */
    private function externalBindingCheck(string $name, mixed $credentials, string $binding, bool $strict): array
    {
        if (blank($credentials)) {
            return $strict
                ? [$name, 'FAIL', 'Required credentials are not configured.']
                : [$name, 'SKIP', 'Credentials are not configured; external check skipped.'];
        }

        if (! $strict) {
            return [$name, 'SKIP', 'External resolution is only performed in strict mode.'];
        }

        return $this->check($name, function () use ($binding): string {
            app()->make($binding);

            return "Binding [{$binding}] resolved; no test message was sent.";
        });
    }
}
