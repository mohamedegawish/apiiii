<?php

namespace App\Console\Commands;

use App\Jobs\SendUpcomingSessionReminders;
use Illuminate\Console\Command;

class SendUpcomingSessionRemindersCommand extends Command
{
    protected $signature = 'automation:upcoming-session-reminders {--hours=24 : Reminder window in hours}';

    protected $description = 'Queue reminders for upcoming circle sessions';

    public function handle(): int
    {
        $hours = max(1, (int) $this->option('hours'));
        SendUpcomingSessionReminders::dispatch(now()->toIso8601String(), now()->addHours($hours)->toIso8601String());
        $this->info("Queued reminders for sessions in the next {$hours} hours.");

        return self::SUCCESS;
    }
}
