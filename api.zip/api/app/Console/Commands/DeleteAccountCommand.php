<?php

namespace App\Console\Commands;

use App\Features\Auth\Actions\DeleteOwnAccountAction;
use App\Models\User;
use App\Support\Exceptions\ConflictException;
use Illuminate\Console\Command;

/**
 * Executes an account-deletion request received outside the app (the public
 * deletion web page required by Google Play) for a user who cannot sign in.
 *
 * Applies exactly the same erasure as the in-app «حذف الحساب» flow. Verify the
 * requester's identity before running it — there is no password check here.
 */
class DeleteAccountCommand extends Command
{
    protected $signature = 'account:delete
        {identifier : User id (uuid), e-mail, or phone of the account}
        {--role= : Required when a phone number matches more than one account}
        {--force : Skip the interactive confirmation}';

    protected $description = 'Delete a user account on a verified request (same behaviour as in-app deletion)';

    public function handle(DeleteOwnAccountAction $action): int
    {
        $identifier = (string) $this->argument('identifier');

        $matches = User::query()
            ->where(fn ($q) => $q->where('id', $identifier)
                ->orWhere('email', $identifier)
                ->orWhere('phone', $identifier))
            ->when($this->option('role'), fn ($q, $role) => $q->where('role', $role))
            ->get();

        if ($matches->isEmpty()) {
            $this->error('No matching account.');

            return self::FAILURE;
        }

        if ($matches->count() > 1) {
            $this->error('Several accounts match; pass --role or the user id.');
            $matches->each(fn (User $u) => $this->line("  {$u->id}  {$u->roleEnum()?->value}"));

            return self::FAILURE;
        }

        /** @var User $user */
        $user = $matches->first();

        if (! $this->option('force')
            && ! $this->confirm("Permanently delete account {$user->id} ({$user->roleEnum()?->value})?")) {
            $this->warn('Aborted.');

            return self::FAILURE;
        }

        try {
            $action->erase($user, 'operator_request');
        } catch (ConflictException $e) {
            $this->error($e->getMessage());

            return self::FAILURE;
        }

        $this->info("Account {$user->id} deleted.");

        return self::SUCCESS;
    }
}
