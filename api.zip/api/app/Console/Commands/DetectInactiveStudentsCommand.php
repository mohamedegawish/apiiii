<?php

namespace App\Console\Commands;

use App\Jobs\DetectInactiveStudents;
use Illuminate\Console\Command;

class DetectInactiveStudentsCommand extends Command
{
    protected $signature = 'automation:detect-inactive-students {--days=30 : Days without attendance or learning activity}';

    protected $description = 'Queue inactive student detection without changing student statuses';

    public function handle(): int
    {
        $days = max(1, (int) $this->option('days'));
        DetectInactiveStudents::dispatch($days);
        $this->info("Queued inactive student detection using a {$days}-day threshold.");

        return self::SUCCESS;
    }
}
