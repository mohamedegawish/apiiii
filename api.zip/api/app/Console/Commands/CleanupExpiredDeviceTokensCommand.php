<?php

namespace App\Console\Commands;

use App\Jobs\CleanupExpiredDeviceTokens;
use Illuminate\Console\Command;

class CleanupExpiredDeviceTokensCommand extends Command
{
    protected $signature = 'automation:cleanup-device-tokens {--days=90 : Inactivity threshold in days}';

    protected $description = 'Delete expired or stale device tokens';

    public function handle(): int
    {
        $days = max(1, (int) $this->option('days'));
        $count = (new CleanupExpiredDeviceTokens($days))->handle();
        $this->info("Deleted {$count} expired device token(s).");

        return self::SUCCESS;
    }
}
