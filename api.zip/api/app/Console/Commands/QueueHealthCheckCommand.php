<?php

namespace App\Console\Commands;

use App\Support\Queue\QueueMonitoringService;
use Illuminate\Console\Command;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\DB;

class QueueHealthCheckCommand extends Command
{
    protected $signature = 'queue:health-check {--connection= : Queue connection to inspect}';

    protected $description = 'Check a database queue for stalled available jobs';

    public function handle(QueueMonitoringService $monitor): int
    {
        $connectionName = (string) ($this->option('connection') ?: config('queue.default'));
        $queueConfig = config("queue.connections.{$connectionName}");

        if (! is_array($queueConfig) || ($queueConfig['driver'] ?? null) !== 'database') {
            $this->components->info("Queue connection [{$connectionName}] is not database-backed; health check skipped.");

            return self::SUCCESS;
        }

        $database = $this->databaseConnection($queueConfig['connection'] ?? null);
        $table = (string) ($queueConfig['table'] ?? 'jobs');
        $queue = (string) ($queueConfig['queue'] ?? 'default');
        $now = now()->timestamp;
        $query = $database->table($table)
            ->where('queue', $queue)
            ->whereNull('reserved_at')
            ->where('available_at', '<=', $now);
        $size = (clone $query)->count();
        $oldestAvailableAt = (clone $query)->min('available_at');
        $oldestAgeSeconds = $oldestAvailableAt === null ? 0 : max(0, $now - (int) $oldestAvailableAt);
        $sizeThreshold = max(1, (int) config('operations.queue.stall_size', 1));
        $ageThreshold = max(1, (int) config('operations.queue.stall_age_seconds', 300));

        if ($size >= $sizeThreshold && $oldestAgeSeconds >= $ageThreshold) {
            $monitor->recordQueueStalled([
                'connection' => $connectionName,
                'queue' => $queue,
                'size' => $size,
                'size_threshold' => $sizeThreshold,
                'oldest_available_age_seconds' => $oldestAgeSeconds,
                'age_threshold_seconds' => $ageThreshold,
            ]);

            $this->components->error("Queue [{$queue}] appears stalled: {$size} available job(s), oldest {$oldestAgeSeconds}s.");

            return self::FAILURE;
        }

        $this->components->info("Queue [{$queue}] is healthy: {$size} available job(s), oldest {$oldestAgeSeconds}s.");

        return self::SUCCESS;
    }

    private function databaseConnection(mixed $connection): ConnectionInterface
    {
        return DB::connection(is_string($connection) && $connection !== '' ? $connection : null);
    }
}
