<?php

namespace App\Console\Commands;

use App\Features\CircleSessions\Actions\GenerateCircleSessionsAction;
use App\Support\CenterClock;
use Illuminate\Console\Command;

class GenerateCircleSessionsCommand extends Command
{
    protected $signature = 'automation:generate-circle-sessions {--days=1 : Number of days ahead to generate sessions}';

    protected $description = 'Auto-generate circle sessions from weekly schedules for today and upcoming days.';

    public function handle(GenerateCircleSessionsAction $action): int
    {
        $days = max(1, (int) $this->option('days'));
        $total = 0;

        for ($i = 0; $i < $days; $i++) {
            $date = CenterClock::now()->addDays($i);
            $created = $action->execute($date);
            $total += count($created);

            if (! empty($created)) {
                $this->info(sprintf('Generated %d session(s) for %s.', count($created), $date->toDateString()));
            }
        }

        $this->info("Total sessions generated: {$total}");

        return self::SUCCESS;
    }
}
