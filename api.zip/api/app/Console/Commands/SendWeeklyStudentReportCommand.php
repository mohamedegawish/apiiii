<?php

namespace App\Console\Commands;

use App\Jobs\SendWeeklyStudentReport;
use Illuminate\Console\Command;

class SendWeeklyStudentReportCommand extends Command
{
    protected $signature = 'automation:weekly-student-report {--end= : Period end date (Y-m-d)}';

    protected $description = 'Queue weekly student reports for guardians';

    public function handle(): int
    {
        $end = $this->option('end') ? now()->parse($this->option('end')) : today();
        $start = $end->copy()->subDays(6);
        SendWeeklyStudentReport::dispatch($start->toDateString(), $end->toDateString());
        $this->info("Queued weekly student reports through {$end->toDateString()}.");

        return self::SUCCESS;
    }
}
