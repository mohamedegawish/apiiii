<?php

namespace App\Console\Commands;

use App\Features\Reports\Actions\GenerateMonthlyProgressAction;
use App\Support\CenterClock;
use Illuminate\Console\Command;

class GenerateMonthlyProgressCommand extends Command
{
    protected $signature = 'automation:generate-monthly-progress
        {--year= : Calendar year, defaults to the current month at the center}
        {--month= : Calendar month 1-12}
        {--previous : Snapshot the month that just ended instead of the current one}
        {--circle= : Limit to a single circle}';

    protected $description = 'Snapshot monthly progress records from attendance and learning records';

    public function handle(GenerateMonthlyProgressAction $action): int
    {
        // "This month" means the center's month, not UTC's.
        $reference = CenterClock::now();

        if ($this->option('previous')) {
            $reference = $reference->subMonthNoOverflow();
        }

        $year = (int) ($this->option('year') ?: $reference->year);
        $month = (int) ($this->option('month') ?: $reference->month);

        if ($month < 1 || $month > 12) {
            $this->error('The --month option must be between 1 and 12.');

            return self::FAILURE;
        }

        $written = $action->execute($year, $month, $this->option('circle'));

        $this->info(sprintf('Wrote %d monthly progress record(s) for %04d-%02d.', $written, $year, $month));

        return self::SUCCESS;
    }
}
