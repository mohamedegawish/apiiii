<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

/**
 * Delivers the password-reset OTP to the user (via the configured mail channel).
 */
class PasswordResetCodeNotification extends Notification
{
    use Queueable;

    public function __construct(protected string $code, protected int $expiresMinutes = 10) {}

    /**
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject('رمز إعادة تعيين كلمة المرور')
            ->greeting('مرحباً')
            ->line("رمز التحقّق الخاص بك هو: {$this->code}")
            ->line("ينتهي هذا الرمز خلال {$this->expiresMinutes} دقائق.")
            ->line('إذا لم تطلب إعادة تعيين كلمة المرور، تجاهل هذه الرسالة.');
    }
}
