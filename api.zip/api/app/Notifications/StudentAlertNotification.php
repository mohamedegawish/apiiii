<?php

namespace App\Notifications;

use App\Features\Push\Channels\PushChannel;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Log;
use Sentry\State\HubInterface;
use Throwable;

class StudentAlertNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public int $tries = 3;

    public int $timeout = 30;

    /** @var list<int> */
    public array $backoff = [10, 60, 300];

    /** @param array<string, mixed> $data */
    public function __construct(private readonly string $kind, private readonly array $data) {}

    /** @return list<string> */
    public function via(object $notifiable): array
    {
        return ['database', PushChannel::class];
    }

    /** @return array<string, mixed> */
    public function toArray(object $notifiable): array
    {
        return ['kind' => $this->kind, ...$this->data];
    }

    public function eventType(): string
    {
        return $this->kind;
    }

    /** @return array<string, mixed> */
    public function payload(): array
    {
        return $this->data;
    }

    public function failed(Throwable $exception): void
    {
        Log::error('Queued platform notification failed', [
            'kind' => $this->kind,
            'exception' => $exception::class,
            'message' => $exception->getMessage(),
        ]);

        if (filled(config('sentry.dsn')) && app()->bound(HubInterface::class)) {
            app(HubInterface::class)->captureException($exception);
        }
    }
}
