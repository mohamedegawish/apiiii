<?php

namespace App\Features\StudentLifecycle\Services;

use App\Enums\StudentStatus;
use App\Features\StudentLifecycle\Actions\TransferStudentAction;
use App\Features\StudentLifecycle\Actions\TransitionStudentStatusAction;
use App\Features\StudentLifecycle\DTO\StatusTransitionData;
use App\Models\Student;
use App\Support\Services\BaseService;

class StudentLifecycleService extends BaseService
{
    public function __construct(
        protected TransitionStudentStatusAction $transitionStudentStatusAction,
        protected TransferStudentAction $transferStudentAction,
    ) {}

    public function suspend(string $studentId, string $reason, ?string $changedBy): Student
    {
        return $this->transition($studentId, StudentStatus::Suspended, $reason, $changedBy);
    }

    public function reactivate(string $studentId, string $reason, ?string $changedBy): Student
    {
        return $this->transition($studentId, StudentStatus::Active, $reason, $changedBy);
    }

    public function graduate(string $studentId, string $reason, ?string $changedBy): Student
    {
        return $this->transition($studentId, StudentStatus::Graduated, $reason, $changedBy);
    }

    public function withdraw(string $studentId, string $reason, ?string $changedBy): Student
    {
        return $this->transition($studentId, StudentStatus::Withdrawn, $reason, $changedBy);
    }

    public function transfer(string $studentId, string $targetCircleId, string $reason, ?string $changedBy): Student
    {
        return $this->transaction(fn (): Student => $this->transferStudentAction->execute(
            $studentId,
            $targetCircleId,
            $reason,
            $changedBy,
        ));
    }

    private function transition(string $studentId, StudentStatus $status, string $reason, ?string $changedBy): Student
    {
        return $this->transaction(fn (): Student => $this->transitionStudentStatusAction->execute(
            $studentId,
            new StatusTransitionData($status, $reason, $changedBy),
        ))->load(['enrollments.circle', 'statusHistory']);
    }
}
