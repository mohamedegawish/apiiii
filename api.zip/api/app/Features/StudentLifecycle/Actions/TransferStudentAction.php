<?php

namespace App\Features\StudentLifecycle\Actions;

use App\Enums\EnrollmentStatus;
use App\Enums\StudentStatus;
use App\Features\Enrollments\Actions\CloseEnrollmentAction;
use App\Features\Enrollments\DTO\EnrollmentData;
use App\Models\Circle;
use App\Models\Enrollment;
use App\Models\Student;
use App\Models\StudentStatusHistory;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;
use App\Support\Exceptions\NotFoundException;

class TransferStudentAction extends BaseAction
{
    public function __construct(protected CloseEnrollmentAction $closeEnrollmentAction) {}

    /**
     * @return Student
     */
    public function execute(mixed ...$arguments): mixed
    {
        [$studentId, $targetCircleId, $reason, $changedBy] = $arguments;

        $student = Student::query()->lockForUpdate()->find($studentId);

        if ($student === null) {
            throw new NotFoundException('Student not found.');
        }

        $targetCircle = Circle::query()->lockForUpdate()->find($targetCircleId);

        if ($targetCircle === null) {
            throw new NotFoundException('Target circle not found.');
        }

        $activeEnrollments = Enrollment::query()
            ->where('student_id', $student->id)
            ->where('status', EnrollmentStatus::Active)
            ->lockForUpdate()
            ->get();

        if (! $student->status->canTransitionTo(StudentStatus::Transferred)) {
            throw new ConflictException("A student cannot transfer from {$student->status->value}.");
        }

        if (! $targetCircle->is_active) {
            throw new ConflictException('The target circle is not active.');
        }

        if ($student->status !== StudentStatus::Active) {
            throw new ConflictException("A student cannot transfer from {$student->status->value}.");
        }

        if ($activeEnrollments->contains('circle_id', $targetCircle->id)) {
            throw new ConflictException('The student is already enrolled in the target circle.');
        }

        $targetEnrollmentCount = Enrollment::query()
            ->where('circle_id', $targetCircle->id)
            ->where('status', EnrollmentStatus::Active)
            ->count();

        if ($targetEnrollmentCount >= $targetCircle->capacity) {
            throw new ConflictException('The target circle has reached its capacity.');
        }

        foreach ($activeEnrollments as $enrollment) {
            $this->closeEnrollmentAction->execute(
                $enrollment->id,
                new EnrollmentData(status: EnrollmentStatus::Transferred, reason: $reason),
            );
        }

        $oldStatus = $student->status;
        $changedAt = now();

        $student->update(['status' => StudentStatus::Transferred]);
        StudentStatusHistory::query()->create([
            'student_id' => $student->id,
            'old_status' => $oldStatus,
            'new_status' => StudentStatus::Transferred,
            'reason' => $reason,
            'changed_by' => $changedBy,
            'changed_at' => $changedAt,
        ]);

        Enrollment::query()->create([
            'student_id' => $student->id,
            'circle_id' => $targetCircle->id,
            'joined_at' => $changedAt->toDateString(),
            'status' => EnrollmentStatus::Active,
            'reason' => $reason,
        ]);

        $student->update(['status' => StudentStatus::Active]);
        StudentStatusHistory::query()->create([
            'student_id' => $student->id,
            'old_status' => StudentStatus::Transferred,
            'new_status' => StudentStatus::Active,
            'reason' => $reason,
            'changed_by' => $changedBy,
            'changed_at' => now(),
        ]);

        return $student->fresh(['enrollments.circle', 'statusHistory']);
    }
}
