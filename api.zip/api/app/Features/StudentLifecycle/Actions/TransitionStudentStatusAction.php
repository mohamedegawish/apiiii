<?php

namespace App\Features\StudentLifecycle\Actions;

use App\Enums\EnrollmentStatus;
use App\Enums\StudentStatus;
use App\Features\Enrollments\Actions\CloseEnrollmentAction;
use App\Features\Enrollments\DTO\EnrollmentData;
use App\Features\StudentLifecycle\DTO\StatusTransitionData;
use App\Models\Enrollment;
use App\Models\Student;
use App\Models\StudentStatusHistory;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;
use App\Support\Exceptions\NotFoundException;

class TransitionStudentStatusAction extends BaseAction
{
    public function __construct(protected CloseEnrollmentAction $closeEnrollmentAction) {}

    /**
     * @return Student
     */
    public function execute(mixed ...$arguments): mixed
    {
        [$studentId, $data] = $arguments;

        if (! $data instanceof StatusTransitionData) {
            throw new \InvalidArgumentException('TransitionStudentStatusAction expects StatusTransitionData.');
        }

        $student = Student::query()->lockForUpdate()->find($studentId);

        if ($student === null) {
            throw new NotFoundException('Student not found.');
        }

        $activeEnrollments = Enrollment::query()
            ->where('student_id', $student->id)
            ->where('status', EnrollmentStatus::Active)
            ->lockForUpdate()
            ->get();

        if (! $student->status->canTransitionTo($data->status)) {
            throw new ConflictException("A student cannot transition from {$student->status->value} to {$data->status->value}.");
        }

        $enrollmentStatus = match ($data->status) {
            StudentStatus::Graduated => EnrollmentStatus::Completed,
            StudentStatus::Withdrawn => EnrollmentStatus::Withdrawn,
            default => null,
        };

        if ($enrollmentStatus !== null) {
            foreach ($activeEnrollments as $enrollment) {
                $this->closeEnrollmentAction->execute(
                    $enrollment->id,
                    new EnrollmentData(status: $enrollmentStatus, reason: $data->reason),
                );
            }
        }

        $oldStatus = $student->status;
        $attributes = ['status' => $data->status];

        if ($data->status === StudentStatus::Graduated) {
            $attributes['graduated_at'] = now()->toDateString();
        }

        if ($oldStatus === StudentStatus::Graduated && $data->status !== StudentStatus::Graduated) {
            $attributes['graduated_at'] = null;
        }

        $student->update($attributes);

        StudentStatusHistory::query()->create([
            'student_id' => $student->id,
            'old_status' => $oldStatus,
            'new_status' => $data->status,
            'reason' => $data->reason,
            'changed_by' => $data->changedBy,
            'changed_at' => now(),
        ]);

        return $student->fresh();
    }
}
