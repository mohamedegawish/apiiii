<?php

namespace App\Features\StudentLifecycle\Requests;

class TransferStudentRequest extends ChangeStudentStatusRequest
{
    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'target_circle_id' => ['required', 'uuid', 'exists:circles,id'],
            'reason' => ['required', 'string', 'max:2000'],
        ];
    }
}
