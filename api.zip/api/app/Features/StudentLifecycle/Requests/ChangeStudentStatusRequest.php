<?php

namespace App\Features\StudentLifecycle\Requests;

use App\Models\Student;
use App\Support\Http\Requests\BaseRequest;

class ChangeStudentStatusRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $student = $this->route('student');
        $student = $student instanceof Student ? $student : Student::find($student);

        return $student !== null && ($this->user()?->can('update', $student) ?? false);
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'reason' => ['required', 'string', 'max:2000'],
        ];
    }
}
