<?php

namespace App\Features\StudentLifecycle\Resources;

use App\Enums\EnrollmentStatus;
use App\Features\Enrollments\Resources\EnrollmentResource;
use App\Models\Student;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * @mixin Student
 */
class StudentLifecycleResource extends BaseResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'center_id' => null,
            'name' => $this->name,
            'status' => [
                'value' => $this->status?->value,
                'label' => $this->status?->name,
            ],
            'graduated_at' => $this->graduated_at?->toDateString(),
            'current_enrollment' => EnrollmentResource::make(
                $this->enrollments->firstWhere('status', EnrollmentStatus::Active),
            ),
            'enrollments' => EnrollmentResource::collection($this->whenLoaded('enrollments')),
            'status_history' => StudentStatusHistoryResource::collection($this->whenLoaded('statusHistory')),
        ];
    }
}
