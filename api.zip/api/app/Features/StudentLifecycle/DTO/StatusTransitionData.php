<?php

namespace App\Features\StudentLifecycle\DTO;

use App\Enums\StudentStatus;

final readonly class StatusTransitionData
{
    public function __construct(
        public StudentStatus $status,
        public string $reason,
        public ?string $changedBy,
    ) {}
}
