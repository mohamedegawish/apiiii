<?php

namespace App\Features\StudentLifecycle\Controllers;

use App\Features\StudentLifecycle\Requests\ChangeStudentStatusRequest;
use App\Features\StudentLifecycle\Requests\TransferStudentRequest;
use App\Features\StudentLifecycle\Resources\StudentLifecycleResource;
use App\Features\StudentLifecycle\Services\StudentLifecycleService;
use App\Models\Student;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;

class StudentLifecycleController extends BaseController
{
    public function __construct(protected StudentLifecycleService $studentLifecycleService) {}

    public function suspend(ChangeStudentStatusRequest $request, string $student): JsonResponse
    {
        return $this->transitionResponse(
            $this->studentLifecycleService->suspend($student, $request->validatedData()['reason'], $request->user()?->id),
            'Student suspended successfully.',
        );
    }

    public function reactivate(ChangeStudentStatusRequest $request, string $student): JsonResponse
    {
        return $this->transitionResponse(
            $this->studentLifecycleService->reactivate($student, $request->validatedData()['reason'], $request->user()?->id),
            'Student reactivated successfully.',
        );
    }

    public function graduate(ChangeStudentStatusRequest $request, string $student): JsonResponse
    {
        return $this->transitionResponse(
            $this->studentLifecycleService->graduate($student, $request->validatedData()['reason'], $request->user()?->id),
            'Student graduated successfully.',
        );
    }

    public function withdraw(ChangeStudentStatusRequest $request, string $student): JsonResponse
    {
        return $this->transitionResponse(
            $this->studentLifecycleService->withdraw($student, $request->validatedData()['reason'], $request->user()?->id),
            'Student withdrawn successfully.',
        );
    }

    public function transfer(TransferStudentRequest $request, string $student): JsonResponse
    {
        $data = $request->validatedData();

        return $this->transitionResponse(
            $this->studentLifecycleService->transfer(
                $student,
                $data['target_circle_id'],
                $data['reason'],
                $request->user()?->id,
            ),
            'Student transferred successfully.',
        );
    }

    private function transitionResponse(Student $student, string $message): JsonResponse
    {
        return $this->success(
            data: StudentLifecycleResource::make($student),
            message: $message,
        );
    }
}
