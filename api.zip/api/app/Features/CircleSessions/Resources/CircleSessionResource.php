<?php

namespace App\Features\CircleSessions\Resources;

use App\Models\CircleSession;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * @mixin CircleSession
 */
class CircleSessionResource extends BaseResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'circle_id' => $this->circle_id,
            'schedule_id' => $this->schedule_id,
            'teacher_id' => $this->teacher_id,
            'session_date' => $this->session_date?->toDateString(),
            'start_time' => $this->start_time,
            'end_time' => $this->end_time,
            'status' => [
                'value' => $this->status?->value,
                'label' => $this->status?->name,
            ],
            'notes' => $this->notes,
            'completed_at' => $this->completed_at?->toIso8601String(),
            'locked_at' => $this->locked_at?->toIso8601String(),
            'version' => $this->version,
            'circle' => $this->whenLoaded('circle', fn () => [
                'id' => $this->circle->id,
                'name' => $this->circle->name,
            ]),
            'teacher' => $this->whenLoaded('teacher', fn () => [
                'id' => $this->teacher->id,
                'name' => $this->teacher->user?->name ?? $this->teacher->title,
            ]),
            'students_count' => $this->whenLoaded(
                'circle',
                fn () => $this->circle?->enrollments_count,
            ),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
