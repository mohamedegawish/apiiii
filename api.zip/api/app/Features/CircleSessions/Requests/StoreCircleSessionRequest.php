<?php

namespace App\Features\CircleSessions\Requests;

use App\Models\CircleSession;
use App\Support\Http\Requests\BaseRequest;
use App\Support\Rules\OwnedCircle;

class StoreCircleSessionRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', CircleSession::class) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'circle_id' => ['required', 'uuid', 'exists:circles,id', new OwnedCircle],
            'schedule_id' => ['nullable', 'uuid', 'exists:circle_schedules,id'],
            'session_date' => ['required', 'date_format:Y-m-d'],
            'start_time' => ['required', 'date_format:H:i'],
            'end_time' => ['required', 'date_format:H:i', 'after:start_time'],
            'notes' => ['nullable', 'string', 'max:5000'],
        ];
    }
}
