<?php

namespace App\Features\CircleSessions\Requests;

use App\Models\CircleSession;
use App\Support\Http\Requests\BaseRequest;
use App\Support\Rules\OwnedCircle;

class UpdateCircleSessionRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $session = CircleSession::find($this->route('circleSession'));

        return $session !== null && ($this->user()?->can('update', $session) ?? false);
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'circle_id' => ['sometimes', 'required', 'uuid', 'exists:circles,id', new OwnedCircle],
            'schedule_id' => ['sometimes', 'nullable', 'uuid', 'exists:circle_schedules,id'],
            'session_date' => ['sometimes', 'required', 'date_format:Y-m-d'],
            'start_time' => ['sometimes', 'required', 'date_format:H:i'],
            'end_time' => ['sometimes', 'required', 'date_format:H:i'],
            'notes' => ['sometimes', 'nullable', 'string', 'max:5000'],
        ];
    }
}
