<?php

namespace App\Features\CircleSessions\Queries;

use App\Enums\Role;
use App\Models\CircleSession;
use App\Support\Queries\BaseQuery;
use App\Support\Queries\DateColumn;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class CircleSessionQuery extends BaseQuery
{
    protected string $defaultSort = '-session_date';

    public function __construct()
    {
        parent::__construct(CircleSession::class);

        // Always available (not opt-in via ?include) — the dashboard card
        // needs the circle name and student count on every session row, and
        // omitting them forces the client to fetch a roster per session.
        $this->builder->with(['circle' => CircleSession::circleWithStudentCount()]);
    }

    /**
     * @param  EloquentBuilder<CircleSession>  $builder
     */
    protected function applyTenantScope(EloquentBuilder $builder): void
    {
        if ($this->shouldBypassScope()) {
            return;
        }

        $user = $this->currentUser();

        if ($user?->hasRole(Role::Teacher) && $user->teacher !== null) {
            $builder->where(function (EloquentBuilder $query) use ($user) {
                $query->where('teacher_id', $user->teacher->id)
                    ->orWhereHas('circle', fn (EloquentBuilder $q) => $q->where('teacher_id', $user->teacher->id));
            });

            return;
        }

        $circleIds = $this->accessibleCircleIds();

        if ($circleIds === []) {
            $builder->whereRaw('1 = 0');

            return;
        }

        if ($circleIds !== null) {
            $builder->whereIn('circle_id', $circleIds);
        }
    }

    /**
     * @return list<AllowedFilter>
     */
    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::exact('circle_id'),
            AllowedFilter::exact('schedule_id'),
            AllowedFilter::exact('teacher_id'),
            AllowedFilter::exact('session_date'),
            AllowedFilter::callback('session_date_before', fn (EloquentBuilder $query, $value) => $query->where('session_date', '<', $value)),
            AllowedFilter::callback('session_date_after', fn (EloquentBuilder $query, $value) => $query->where('session_date', '>=', DateColumn::dayAfter($value))),
            AllowedFilter::exact('status'),
        ];
    }

    /**
     * @return list<string>
     */
    protected function allowedSorts(): array
    {
        return ['session_date', 'start_time', 'status', 'created_at', 'updated_at'];
    }

    /**
     * @return list<string>
     */
    /**
     * @return list<string>
     */
    protected function allowedIncludes(): array
    {
        return ['circle', 'schedule', 'teacher'];
    }

    /**
     * CircleSessionResource renders the teacher's name from `teacher.user`, so
     * `?include=teacher` has to bring the user along. Spatie only eager-loads
     * the relationship it was asked for, which left `user` to lazy-load once
     * per row — a page of 25 sessions cost 25 extra queries.
     */
    public function paginate(): LengthAwarePaginator
    {
        if (in_array('teacher', $this->requestedIncludes(), true)) {
            $this->getBuilder()->with('teacher.user');
        }

        return parent::paginate();
    }

    /**
     * @return list<string>
     */
    private function requestedIncludes(): array
    {
        $includes = request()->query('include');

        if (is_string($includes)) {
            return array_map(trim(...), explode(',', $includes));
        }

        return is_array($includes) ? array_map(trim(...), $includes) : [];
    }
}
