<?php

namespace App\Features\CircleSessions\Queries;

use App\Enums\AttendanceStatus;
use App\Enums\LearningRecordType;
use App\Enums\StudentStatus;
use App\Models\CircleSession;
use App\Models\Enrollment;
use DateTimeInterface;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Whether a session is allowed to complete: every roster student must have
 * attendance recorded, PRESENT students must have matn/listening results, and
 * only active memorization/revision homework creates an additional requirement.
 * Shared by the completion-status read endpoint and the transition guard.
 */
class CircleSessionCompletionQuery
{
    /**
     * @return array{
     *     missing_attendance_student_ids: list<string>,
     *     attendance_complete: bool,
     *     present_student_ids: list<string>,
     *     missing_by_type: array<string, list<string>>,
     *     evaluation_complete: bool,
     *     can_complete: bool,
     * }
     */
    public function check(CircleSession $session): array
    {
        return $this->checkMany(collect([$session]))[$session->id];
    }

    /**
     * Completion status for many sessions using a fixed number of queries.
     *
     * The per-session rules are identical to {@see check()} — which delegates
     * here so the two can never drift. The analytics dashboards evaluate every
     * session a teacher ran in a period, which as one-call-per-session cost
     * five queries per session; batching makes it five queries in total.
     *
     * @param  Collection<int, CircleSession>  $sessions
     * @return array<string, array{
     *     missing_attendance_student_ids: list<string>,
     *     attendance_complete: bool,
     *     present_student_ids: list<string>,
     *     missing_by_type: array<string, list<string>>,
     *     evaluation_complete: bool,
     *     can_complete: bool,
     * }> Keyed by session id.
     */
    public function checkMany(Collection $sessions): array
    {
        if ($sessions->isEmpty()) {
            return [];
        }

        $sessionIds = $sessions->pluck('id')->all();
        $circleIds = $sessions->pluck('circle_id')->unique()->values()->all();

        // Read as plain rows, not models: this method is called with every
        // completed session of a period, which is thousands of rows per table
        // for a busy center, and Eloquent hydration of rows we only ever read
        // scalars from dominated the cost. Enum values are still derived from
        // the enums themselves (below), never re-spelled as literals, and the
        // soft-delete predicates Eloquent would have added are explicit here.
        $presentStatuses = array_map(
            fn (AttendanceStatus $status): string => $status->value,
            array_filter(AttendanceStatus::cases(), fn (AttendanceStatus $status): bool => $status->wasPresent()),
        );
        $presentStatuses = array_flip($presentStatuses);
        $quranTypes = array_flip(array_map(
            fn (LearningRecordType $type): string => $type->value,
            LearningRecordType::quranBasedTypes(),
        ));

        // Every enrollment for the circles involved, filtered to each session's
        // own date in PHP — the date window (Enrollment::scopeCoveringDate)
        // differs per session, so it cannot be pushed into one SQL predicate.
        $enrollmentsByCircle = [];
        $enrolledStudentIds = [];
        foreach (
            DB::table('enrollments')
                ->whereIn('circle_id', $circleIds)
                ->get(['circle_id', 'student_id', 'joined_at', 'left_at']) as $enrollment
        ) {
            $enrollmentsByCircle[$enrollment->circle_id][] = $enrollment;
            $enrolledStudentIds[$enrollment->student_id] = true;
        }

        $activeStudentIds = array_flip(
            DB::table('students')
                ->whereIn('id', array_keys($enrolledStudentIds))
                ->where('status', StudentStatus::Active->value)
                ->whereNull('deleted_at')
                ->pluck('id')
                ->all()
        );

        $attendanceBySession = [];
        foreach (
            DB::table('attendances')
                ->whereIn('circle_session_id', $sessionIds)
                ->whereNull('deleted_at')
                ->get(['circle_session_id', 'student_id', 'status']) as $attendance
        ) {
            $attendanceBySession[$attendance->circle_session_id][] = $attendance;
        }

        $recordsBySession = [];
        foreach (
            DB::table('student_learning_records')
                ->whereIn('circle_session_id', $sessionIds)
                ->whereNull('deleted_at')
                ->where(function ($query): void {
                    $query->whereNotNull('score')
                        ->orWhere('is_na', true)
                        ->orWhereNotNull('result_status');
                })
                ->get(['circle_session_id', 'student_id', 'type', 'homework_id']) as $record
        ) {
            $recordsBySession[$record->circle_session_id][] = $record;
        }

        // Indexed circle -> student -> [homework], so the per-session loop is a
        // pair of array lookups rather than a scan per student.
        $homeworkByCircleStudent = [];
        foreach (
            DB::table('homework')
                ->whereIn('circle_id', $circleIds)
                ->whereIn('status', ['pending', 'submitted', 'late'])
                ->whereNull('deleted_at')
                ->get(['id', 'circle_id', 'student_id', 'circle_session_id', 'homework_type']) as $homework
        ) {
            $homeworkByCircleStudent[$homework->circle_id][$homework->student_id][] = $homework;
        }

        $results = [];

        foreach ($sessions as $session) {
            $date = $session->session_date;

            $rosterStudentIds = [];
            foreach ($enrollmentsByCircle[$session->circle_id] ?? [] as $enrollment) {
                $studentId = $enrollment->student_id;
                if (isset($rosterStudentIds[$studentId]) || ! isset($activeStudentIds[$studentId])) {
                    continue;
                }
                if ($this->covers($enrollment->joined_at, $enrollment->left_at, $date)) {
                    $rosterStudentIds[$studentId] = true;
                }
            }
            $rosterStudentIds = array_keys($rosterStudentIds);

            $attended = [];
            $presentLookup = [];
            foreach ($attendanceBySession[$session->id] ?? [] as $attendance) {
                $attended[$attendance->student_id] = true;
                if (isset($presentStatuses[$attendance->status])) {
                    $presentLookup[$attendance->student_id] = true;
                }
            }
            $presentStudentIds = array_keys($presentLookup);

            $missingAttendance = array_values(array_filter(
                $rosterStudentIds,
                fn (string $studentId): bool => ! isset($attended[$studentId]),
            ));

            // A pending assignment created in the current session is for the next
            // visit and must not make the current session incomplete.
            $activeHomework = [];
            foreach ($homeworkByCircleStudent[$session->circle_id] ?? [] as $studentId => $items) {
                if (! isset($presentLookup[$studentId])) {
                    continue;
                }
                foreach ($items as $homework) {
                    if ($homework->circle_session_id !== $session->id) {
                        $activeHomework[$studentId][] = $homework;
                    }
                }
            }

            // student => [type => true] and homework id => true, precomputed so
            // the per-type passes below are constant-time lookups.
            $homeworkTypesByStudent = [];
            $activeHomeworkIds = [];
            foreach ($activeHomework as $studentId => $items) {
                foreach ($items as $homework) {
                    $homeworkTypesByStudent[$studentId][$homework->homework_type] = true;
                    $activeHomeworkIds[$studentId][$homework->id] = true;
                }
            }

            $recordStudentIdsByType = [];
            foreach ($recordsBySession[$session->id] ?? [] as $record) {
                $studentId = $record->student_id;
                if (! isset($presentLookup[$studentId])) {
                    continue;
                }
                $type = $record->type;
                if (isset($quranTypes[$type]) && ! isset($activeHomeworkIds[$studentId][$record->homework_id])) {
                    continue;
                }
                $recordStudentIdsByType[$type][$studentId] = true;
            }

            $missingByType = [];
            foreach (LearningRecordType::values() as $type) {
                $requiredStudentIds = $presentStudentIds;
                if (isset($quranTypes[$type])) {
                    $requiredStudentIds = array_values(array_filter(
                        $presentStudentIds,
                        fn (string $studentId): bool => isset($homeworkTypesByStudent[$studentId][$type]),
                    ));
                }

                $satisfied = $recordStudentIdsByType[$type] ?? [];
                $missingByType[$type] = array_values(array_filter(
                    $requiredStudentIds,
                    fn (string $studentId): bool => ! isset($satisfied[$studentId]),
                ));
            }

            $evaluationComplete = array_reduce(
                $missingByType,
                fn (bool $carry, array $missing): bool => $carry && $missing === [],
                true,
            );

            $results[$session->id] = [
                'missing_attendance_student_ids' => $missingAttendance,
                'attendance_complete' => $missingAttendance === [],
                'present_student_ids' => $presentStudentIds,
                'missing_by_type' => $missingByType,
                'evaluation_complete' => $evaluationComplete,
                'can_complete' => $missingAttendance === [] && $evaluationComplete,
            ];
        }

        return $results;
    }

    /**
     * PHP equivalent of {@see Enrollment::scopeCoveringDate()} — joined on or
     * before the session date, and not left before it. Compared on the date
     * part alone, since a date-cast column reaches here as a bare `Y-m-d` on
     * MySQL but as a full datetime string on SQLite.
     */
    private function covers(mixed $joinedAt, mixed $leftAt, mixed $date): bool
    {
        $day = $this->datePart($date);

        if ($joinedAt !== null && $this->datePart($joinedAt) > $day) {
            return false;
        }

        return $leftAt === null || $this->datePart($leftAt) >= $day;
    }

    private function datePart(mixed $value): string
    {
        if ($value instanceof DateTimeInterface) {
            return $value->format('Y-m-d');
        }

        return substr((string) $value, 0, 10);
    }
}
