<?php

namespace App\Features\CircleSessions\Queries;

use App\Enums\LearningRecordType;
use App\Features\Circles\Services\CircleRosterService;
use App\Models\Attendance;
use App\Models\CircleSession;
use App\Models\Homework;
use App\Models\StudentLearningRecord;
use Illuminate\Support\Collection;

/**
 * Everything that actually happened in one session, as a single sheet: one
 * row per roster student, one column per evaluation type, plus the
 * attendance mark and the homework assigned out of the session.
 *
 * Deliberately one endpoint rather than the three the teacher workspace
 * already stitches together (roster + attendance + learning-records): the
 * admin reads a *finished* session and must not have to reproduce that
 * join — least of all the "who recorded this, and when" provenance, which
 * no existing list endpoint carries per cell.
 */
class CircleSessionSheetQuery
{
    public function __construct(protected CircleRosterService $circleRosterService) {}

    /**
     * @return array{rows: list<array<string, mixed>>, summary: array<string, mixed>}
     */
    public function build(CircleSession $session): array
    {
        $roster = $this->circleRosterService->asOf($session->circle, $session->session_date);
        $studentIds = array_column($roster, 'id');

        $attendance = Attendance::where('circle_session_id', $session->id)
            ->get()
            ->keyBy('student_id');

        $records = StudentLearningRecord::with('teacher.user')
            ->where('circle_session_id', $session->id)
            ->get()
            ->groupBy('student_id');

        // Assigned *out of* this session — the work the student leaves with.
        // Homework carried in from an earlier session belongs on that
        // session's sheet, not on this one.
        $homework = Homework::where('circle_session_id', $session->id)
            ->whereIn('student_id', $studentIds)
            ->get()
            ->groupBy('student_id');

        $rows = [];

        foreach ($roster as $student) {
            $studentId = $student['id'];
            $studentRecords = $records->get($studentId, new Collection)->keyBy(
                fn (StudentLearningRecord $record): string => $record->type->value,
            );

            $rows[] = [
                'student_id' => $studentId,
                'student_name' => $student['name'] ?? null,
                'student_code' => $student['student_code'] ?? null,
                'enrollment_id' => $student['enrollment_id'] ?? null,
                'attendance' => $this->attendanceCell($attendance->get($studentId)),
                'records' => $this->recordCells($studentRecords),
                'homework' => $homework->get($studentId, new Collection)
                    ->map(fn (Homework $item): array => [
                        'id' => $item->id,
                        'type' => $item->homework_type->value,
                        'title' => $item->title,
                        'surah_number' => $item->surah_number,
                        'from_ayah' => $item->from_ayah,
                        'to_ayah' => $item->to_ayah,
                        'due_date' => $item->due_date,
                        'status' => $item->status->value,
                    ])->values()->all(),
            ];
        }

        return [
            'rows' => $rows,
            'summary' => $this->summary($rows),
        ];
    }

    /** @return array<string, mixed>|null */
    private function attendanceCell(?Attendance $attendance): ?array
    {
        if (! $attendance instanceof Attendance) {
            return null;
        }

        return [
            'id' => $attendance->id,
            'status' => $attendance->status->value,
            'was_present' => $attendance->status->wasPresent(),
            'arrival_time' => $attendance->arrival_time,
            'notes' => $attendance->notes,
            'recorded_at' => $attendance->updated_at?->toIso8601String(),
        ];
    }

    /**
     * One entry per evaluation type, `null` where nothing was recorded — an
     * empty cell is itself information to the admin, so the key is always
     * present rather than omitted.
     *
     * @param  Collection<string, StudentLearningRecord>  $records
     * @return array<string, array<string, mixed>|null>
     */
    private function recordCells(Collection $records): array
    {
        $cells = [];

        foreach (LearningRecordType::values() as $type) {
            $record = $records->get($type);

            if (! $record instanceof StudentLearningRecord) {
                $cells[$type] = null;

                continue;
            }

            $cells[$type] = [
                'id' => $record->id,
                'score' => $record->score === null ? null : (float) $record->score,
                'is_na' => (bool) $record->is_na,
                'result_status' => $record->result_status?->value,
                'reference_label' => $record->reference_label,
                'surah_number' => $record->surah_number,
                'from_ayah' => $record->from_ayah,
                'to_surah_number' => $record->to_surah_number,
                'to_ayah' => $record->to_ayah,
                'topic' => $record->topic,
                'notes' => $record->notes,
                'teacher_name' => $record->teacher?->user?->name,
                'recorded_at' => $record->updated_at?->toIso8601String(),
            ];
        }

        return $cells;
    }

    /**
     * Sheet totals. Averages count only scored cells: an `is_na` or
     * `not_memorized` cell is a recorded outcome with no number behind it,
     * and folding it in as a zero would understate the circle.
     *
     * @param  list<array<string, mixed>>  $rows
     * @return array<string, mixed>
     */
    private function summary(array $rows): array
    {
        $present = 0;
        $absent = 0;
        $unmarked = 0;
        $scores = [];
        $byType = [];
        $typeScores = array_fill_keys(LearningRecordType::values(), []);

        foreach (LearningRecordType::values() as $type) {
            $byType[$type] = ['scored' => 0, 'na' => 0, 'not_memorized' => 0, 'average' => null];
        }

        foreach ($rows as $row) {
            $attendance = $row['attendance'];

            if ($attendance === null) {
                $unmarked++;
            } elseif ($attendance['was_present']) {
                $present++;
            } else {
                $absent++;
            }

            foreach ($row['records'] as $type => $record) {
                if ($record === null) {
                    continue;
                }

                if ($record['score'] !== null) {
                    $byType[$type]['scored']++;
                    $typeScores[$type][] = $record['score'];
                    $scores[] = $record['score'];

                    continue;
                }

                if ($record['is_na']) {
                    $byType[$type]['na']++;
                } elseif ($record['result_status'] !== null) {
                    $byType[$type]['not_memorized']++;
                }
            }
        }

        foreach ($typeScores as $type => $values) {
            $byType[$type]['average'] = $values === []
                ? null
                : round(array_sum($values) / count($values), 2);
        }

        return [
            'roster_count' => count($rows),
            'present_count' => $present,
            'absent_count' => $absent,
            'unmarked_count' => $unmarked,
            'scored_count' => count($scores),
            'average_score' => $scores === [] ? null : round(array_sum($scores) / count($scores), 2),
            'by_type' => $byType,
        ];
    }
}
