<?php

namespace App\Features\CircleSessions\Policies;

use App\Enums\CircleSessionStatus;
use App\Enums\Role;
use App\Models\CircleSession;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class CircleSessionPolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $user instanceof User && $user->roleEnum()?->isStaff() === true;
    }

    public function view(?User $user, CircleSession $session): bool
    {
        return $this->canManage($user, $session);
    }

    public function create(?User $user): bool
    {
        return $user instanceof User && $user->roleEnum()?->isStaff() === true;
    }

    public function update(?User $user, CircleSession $session): bool
    {
        return ! $session->isImmutable() && $this->canManage($user, $session);
    }

    public function delete(?User $user, CircleSession $session): bool
    {
        return $session->status === CircleSessionStatus::Scheduled
            && ($this->isSuperAdmin($user) || $this->hasRole($user, Role::CenterOwner));
    }

    public function start(?User $user, CircleSession $session): bool
    {
        return $this->canManage($user, $session);
    }

    public function complete(?User $user, CircleSession $session): bool
    {
        return $this->canManage($user, $session);
    }

    public function cancel(?User $user, CircleSession $session): bool
    {
        return $this->canManage($user, $session);
    }

    /**
     * Teachers may lock their own completed sessions -- a deliberate product
     * decision (see TEACHER_LOCK_AUDIT.md), not an oversight. The safety net
     * for it is unlock() below, which is administrative.
     */
    public function lock(?User $user, CircleSession $session): bool
    {
        return $this->canManage($user, $session);
    }

    /**
     * Reopening a finished session for correction, by the teacher who owns it
     * as well as by an admin — a product decision, replacing the earlier
     * admin-only rule.
     *
     * The seal is not thereby meaningless: reopening moves the session to
     * `InProgress`, so it stops reading as "مكتملة"/"مقفلة" the moment it
     * becomes writable, and the act is recorded by the model's Auditable
     * trait with the acting user. A teacher cannot edit a sealed record
     * silently — only unseal it visibly and then edit.
     */
    public function reopen(?User $user, CircleSession $session): bool
    {
        return $this->canManage($user, $session);
    }

    private function canManage(?User $user, CircleSession $session): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        return $this->hasRole($user, Role::Teacher)
            && ($session->teacher_id === $user?->teacher?->id || $session->circle?->teacher_id === $user?->teacher?->id);
    }
}
