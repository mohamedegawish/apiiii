<?php

namespace App\Features\CircleSessions\Services;

use App\Enums\CircleSessionStatus;
use App\Features\Circles\Services\CircleRosterService;
use App\Features\CircleSessions\Actions\CreateCircleSessionAction;
use App\Features\CircleSessions\Actions\DeleteCircleSessionAction;
use App\Features\CircleSessions\Actions\ReopenCircleSessionAction;
use App\Features\CircleSessions\Actions\TransitionCircleSessionAction;
use App\Features\CircleSessions\Actions\UpdateCircleSessionAction;
use App\Features\CircleSessions\Queries\CircleSessionCompletionQuery;
use App\Features\CircleSessions\Queries\CircleSessionQuery;
use App\Features\CircleSessions\Queries\CircleSessionSheetQuery;
use App\Features\CircleSessions\Requests\StoreCircleSessionRequest;
use App\Features\CircleSessions\Requests\UpdateCircleSessionRequest;
use App\Models\CircleSession;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class CircleSessionService extends BaseService
{
    public function __construct(
        protected CreateCircleSessionAction $createCircleSessionAction,
        protected UpdateCircleSessionAction $updateCircleSessionAction,
        protected DeleteCircleSessionAction $deleteCircleSessionAction,
        protected TransitionCircleSessionAction $transitionCircleSessionAction,
        protected ReopenCircleSessionAction $reopenCircleSessionAction,
        protected CircleSessionQuery $circleSessionQuery,
        protected CircleRosterService $circleRosterService,
        protected CircleSessionCompletionQuery $circleSessionCompletionQuery,
        protected CircleSessionSheetQuery $circleSessionSheetQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        // Session generation runs on the `automation:generate-circle-sessions`
        // schedule (see routes/console.php), not on every read — see
        // GenerateCircleSessionsAction's docblock for why.
        return $this->circleSessionQuery->paginate();
    }

    public function findOrFail(string $id): CircleSession
    {
        $session = CircleSession::with(['circle' => CircleSession::circleWithStudentCount(), 'schedule', 'teacher.user'])->find($id);

        if ($session === null) {
            throw new NotFoundException('Circle session not found.');
        }

        return $session;
    }

    public function create(StoreCircleSessionRequest $request): CircleSession
    {
        return $this->transaction(fn (): CircleSession => $this->createCircleSessionAction->execute($request));
    }

    public function update(CircleSession $session, UpdateCircleSessionRequest $request): CircleSession
    {
        return $this->transaction(fn (): CircleSession => $this->updateCircleSessionAction->execute($session, $request));
    }

    public function delete(CircleSession $session): bool
    {
        return $this->transaction(fn (): bool => $this->deleteCircleSessionAction->execute($session));
    }

    public function start(CircleSession $session): CircleSession
    {
        return $this->transition($session, CircleSessionStatus::InProgress);
    }

    public function complete(CircleSession $session): CircleSession
    {
        return $this->transition($session, CircleSessionStatus::Completed);
    }

    public function cancel(CircleSession $session): CircleSession
    {
        return $this->transition($session, CircleSessionStatus::Cancelled);
    }

    public function lock(CircleSession $session): CircleSession
    {
        return $this->transition($session, CircleSessionStatus::Locked);
    }

    /**
     * Reopen a completed or locked session for editing. Not routed through
     * transition(), because Locked is deliberately a sink in the status
     * graph -- see ReopenCircleSessionAction.
     */
    public function reopen(CircleSession $session): CircleSession
    {
        return $this->transaction(fn (): CircleSession => $this->reopenCircleSessionAction->execute($session));
    }

    /**
     * Students enrolled in the session's circle as of the session's own date —
     * correct for historical sessions, unlike `GET /circles/{id}/students`
     * which only ever answers "enrolled today".
     *
     * @return list<array<string, mixed>>
     */
    public function roster(CircleSession $session): array
    {
        return $this->circleRosterService->asOf($session->circle, $session->session_date);
    }

    /**
     * Live completion-readiness data (attendance/evaluation gaps) — the
     * same check TransitionCircleSessionAction enforces before allowing
     * `Completed`, exposed for the Summary tab's warnings and Complete-
     * button gating so the client never has to re-derive it independently.
     *
     * @return array<string, mixed>
     */
    public function completionStatus(CircleSession $session): array
    {
        return $this->circleSessionCompletionQuery->check($session);
    }

    /**
     * The whole session as one sheet — roster × evaluation types, with the
     * attendance mark, the homework it assigned, and who recorded each cell.
     * Answers "what happened in this session" in a single read, for the
     * administrative review screen.
     *
     * @return array{rows: list<array<string, mixed>>, summary: array<string, mixed>}
     */
    public function sheet(CircleSession $session): array
    {
        return $this->circleSessionSheetQuery->build($session);
    }

    private function transition(CircleSession $session, CircleSessionStatus $status): CircleSession
    {
        return $this->transaction(fn (): CircleSession => $this->transitionCircleSessionAction->execute($session, $status));
    }
}
