<?php

namespace App\Features\CircleSessions\Controllers;

use App\Features\CircleSessions\Requests\StoreCircleSessionRequest;
use App\Features\CircleSessions\Requests\UpdateCircleSessionRequest;
use App\Features\CircleSessions\Resources\CircleSessionResource;
use App\Features\CircleSessions\Services\CircleSessionService;
use App\Models\CircleSession;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CircleSessionController extends BaseController
{
    public function __construct(protected CircleSessionService $circleSessionService) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', CircleSession::class);

        return $this->paginate(
            CircleSessionResource::collection($this->circleSessionService->paginate()),
            'Circle sessions retrieved successfully.',
        );
    }

    public function show(string $circleSession): JsonResponse
    {
        $session = $this->circleSessionService->findOrFail($circleSession);
        $this->authorize('view', $session);

        return $this->success(CircleSessionResource::make($session), 'Circle session retrieved successfully.');
    }

    public function roster(string $circleSession): JsonResponse
    {
        $session = $this->circleSessionService->findOrFail($circleSession);
        $this->authorize('view', $session);

        return $this->success(
            $this->circleSessionService->roster($session),
            'Session roster retrieved successfully.',
        );
    }

    /**
     * The full session sheet: every roster student against every evaluation
     * type, plus attendance and assigned homework. Gated by the same `view`
     * ability as the session itself, so an admin sees any session and a
     * teacher only their own.
     */
    public function sheet(string $circleSession): JsonResponse
    {
        $session = $this->circleSessionService->findOrFail($circleSession);
        $this->authorize('view', $session);

        return $this->success(
            [
                'session' => CircleSessionResource::make($session)->resolve(),
                ...$this->circleSessionService->sheet($session),
            ],
            'Session sheet retrieved successfully.',
        );
    }

    public function completionStatus(string $circleSession): JsonResponse
    {
        $session = $this->circleSessionService->findOrFail($circleSession);
        $this->authorize('view', $session);

        return $this->success(
            $this->circleSessionService->completionStatus($session),
            'Session completion status retrieved successfully.',
        );
    }

    public function store(StoreCircleSessionRequest $request): JsonResponse
    {
        return $this->created(
            CircleSessionResource::make($this->circleSessionService->create($request)),
            'Circle session created successfully.',
        );
    }

    public function update(UpdateCircleSessionRequest $request, string $circleSession): JsonResponse
    {
        $session = $this->circleSessionService->findOrFail($circleSession);
        $this->authorize('update', $session);

        return $this->success(
            CircleSessionResource::make($this->circleSessionService->update($session, $request)),
            'Circle session updated successfully.',
        );
    }

    public function destroy(string $circleSession): JsonResponse
    {
        $session = $this->circleSessionService->findOrFail($circleSession);
        $this->authorize('delete', $session);
        $this->circleSessionService->delete($session);

        return $this->success(null, 'Circle session deleted successfully.');
    }

    public function start(string $circleSession): JsonResponse
    {
        return $this->transition($circleSession, 'start', 'started');
    }

    public function complete(string $circleSession): JsonResponse
    {
        return $this->transition($circleSession, 'complete', 'completed');
    }

    public function cancel(string $circleSession): JsonResponse
    {
        return $this->transition($circleSession, 'cancel', 'cancelled');
    }

    public function lock(string $circleSession): JsonResponse
    {
        return $this->transition($circleSession, 'lock', 'locked');
    }

    /**
     * Reopen a completed or locked session so its attendance and evaluations
     * can be corrected. Served at both `/reopen` and the older `/unlock`
     * path, which named the same recourse.
     */
    public function reopen(string $circleSession): JsonResponse
    {
        return $this->transition($circleSession, 'reopen', 'reopened');
    }

    private function transition(string $id, string $ability, string $pastTense): JsonResponse
    {
        $session = $this->circleSessionService->findOrFail($id);
        $this->authorize($ability, $session);
        $updated = $this->circleSessionService->{$ability}($session);

        return $this->success(
            CircleSessionResource::make($updated),
            "Circle session {$pastTense} successfully.",
        );
    }
}
