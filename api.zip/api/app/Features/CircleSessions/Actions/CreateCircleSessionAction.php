<?php

namespace App\Features\CircleSessions\Actions;

use App\Enums\CircleSessionStatus;
use App\Enums\Role;
use App\Features\CircleSessions\Requests\StoreCircleSessionRequest;
use App\Models\Circle;
use App\Models\CircleSchedule;
use App\Models\CircleSession;
use App\Models\User;
use App\Support\Actions\BaseAction;
use App\Support\Services\GuardianNotificationService;
use Illuminate\Validation\ValidationException;

class CreateCircleSessionAction extends BaseAction
{
    public function __construct(protected GuardianNotificationService $guardianNotificationService) {}

    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreCircleSessionRequest) {
            throw new \InvalidArgumentException('CreateCircleSessionAction expects a StoreCircleSessionRequest.');
        }

        $data = $request->validatedData();
        $circle = Circle::lockForUpdate()->find($data['circle_id']);

        if ($circle === null || ! $circle->is_active) {
            throw ValidationException::withMessages(['circle_id' => ['The selected circle must be active.']]);
        }

        $user = $request->user();
        $this->ensureCircleAccess($user, $circle);
        $this->ensureScheduleBelongsToCircle($data['schedule_id'] ?? null, $circle->id);

        if ($circle->teacher_id === null) {
            throw ValidationException::withMessages(['circle_id' => ['The selected circle does not have an assigned teacher.']]);
        }

        $data['teacher_id'] = $user?->hasRole(Role::Teacher) ? $user->teacher?->id : $circle->teacher_id;
        $data['status'] = CircleSessionStatus::Scheduled;
        $data['version'] = 1;

        $session = CircleSession::create($data)->load(['circle' => CircleSession::circleWithStudentCount(), 'schedule', 'teacher']);
        if ($session->session_date->isTomorrow()) {
            $this->guardianNotificationService->notifyCircleGuardians($session, 'session_reminder');
        }

        return $session;
    }

    private function ensureCircleAccess(?User $user, Circle $circle): void
    {
        $allowed = $user?->isSuperAdmin()
            || ($user?->hasRole(Role::Teacher) && $user->teacher?->id === $circle->teacher_id);

        if (! $allowed) {
            throw ValidationException::withMessages(['circle_id' => ['The selected circle does not belong to your tenant.']]);
        }
    }

    private function ensureScheduleBelongsToCircle(?string $scheduleId, string $circleId): void
    {
        if ($scheduleId !== null && ! CircleSchedule::whereKey($scheduleId)->where('circle_id', $circleId)->exists()) {
            throw ValidationException::withMessages(['schedule_id' => ['The selected schedule does not belong to the circle.']]);
        }
    }
}
