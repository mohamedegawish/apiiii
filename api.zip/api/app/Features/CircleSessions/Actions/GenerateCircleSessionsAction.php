<?php

namespace App\Features\CircleSessions\Actions;

use App\Enums\CircleSessionStatus;
use App\Models\CircleSchedule;
use App\Models\CircleSession;
use App\Support\Actions\BaseAction;
use App\Support\CenterClock;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;

/**
 * Auto-generates circle sessions from weekly schedules for a given date.
 *
 * For every active schedule whose day_of_week matches the target date, a
 * session is created (if one does not already exist) so that teachers and
 * admins see sessions ready for the day when they open the app.
 *
 * Called only from the scheduled `automation:generate-circle-sessions`
 * command — never from a read path — so it never runs concurrently with
 * itself in practice; the try/catch below is the actual safety net against
 * duplicate sessions (two overlapping cron runs, manual + scheduled overlap)
 * and is enforced by the `circle_sessions_schedule_occurrence_unique` index.
 */
class GenerateCircleSessionsAction extends BaseAction
{
    /**
     * Generate missing sessions for the given date.
     *
     * @param  Carbon  $date  The date to generate sessions for (defaults to today in the center's timezone).
     * @return list<CircleSession> The sessions created (empty if all already exist).
     */
    public function execute(mixed ...$arguments): mixed
    {
        $date = $arguments[0] ?? CenterClock::now();

        if (! $date instanceof Carbon) {
            $date = Carbon::parse($date);
        }

        $dateString = $date->toDateString();
        $dayOfWeek = (int) $date->format('N');

        $schedules = CircleSchedule::with('circle')
            ->where('day_of_week', $dayOfWeek)
            ->whereHas('circle', fn ($q) => $q->where('is_active', true)->whereNotNull('teacher_id'))
            ->get();

        $created = [];

        foreach ($schedules as $schedule) {
            $exists = CircleSession::where('circle_id', $schedule->circle_id)
                ->where('schedule_id', $schedule->id)
                ->where('session_date', $dateString)
                ->exists();

            if ($exists) {
                continue;
            }

            try {
                $created[] = CircleSession::create([
                    'circle_id' => $schedule->circle_id,
                    'schedule_id' => $schedule->id,
                    'teacher_id' => $schedule->circle->teacher_id,
                    'session_date' => $dateString,
                    'start_time' => $schedule->start_time,
                    'end_time' => $schedule->end_time,
                    'status' => CircleSessionStatus::Scheduled,
                    'version' => 1,
                ]);
            } catch (UniqueConstraintViolationException) {
                // A concurrent run already created this occurrence — not an error.
            }
        }

        if (! empty($created)) {
            Log::info('Generated {count} circle session(s) for {date}.', [
                'count' => count($created),
                'date' => $dateString,
            ]);
        }

        return $created;
    }
}
