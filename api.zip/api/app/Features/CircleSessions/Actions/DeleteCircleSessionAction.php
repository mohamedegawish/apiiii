<?php

namespace App\Features\CircleSessions\Actions;

use App\Enums\CircleSessionStatus;
use App\Models\CircleSession;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;

class DeleteCircleSessionAction extends BaseAction
{
    public function execute(mixed ...$arguments): mixed
    {
        $session = $arguments[0] ?? null;

        if (! $session instanceof CircleSession) {
            throw new \InvalidArgumentException('DeleteCircleSessionAction expects a CircleSession.');
        }

        $session = CircleSession::lockForUpdate()->findOrFail($session->id);

        if ($session->status !== CircleSessionStatus::Scheduled) {
            throw new ConflictException('Only scheduled sessions can be deleted.');
        }

        return $session->delete();
    }
}
