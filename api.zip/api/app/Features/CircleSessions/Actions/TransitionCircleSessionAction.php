<?php

namespace App\Features\CircleSessions\Actions;

use App\Enums\CircleSessionStatus;
use App\Features\CircleSessions\Queries\CircleSessionCompletionQuery;
use App\Models\CircleSession;
use App\Support\Actions\BaseAction;
use App\Support\CenterClock;
use App\Support\Exceptions\ConflictException;
use App\Support\Services\GuardianNotificationService;

class TransitionCircleSessionAction extends BaseAction
{
    public function __construct(
        protected GuardianNotificationService $guardianNotificationService,
        protected CircleSessionCompletionQuery $circleSessionCompletionQuery,
    ) {}

    public function execute(mixed ...$arguments): mixed
    {
        $session = $arguments[0] ?? null;
        $target = $arguments[1] ?? null;

        if (! $session instanceof CircleSession || ! $target instanceof CircleSessionStatus) {
            throw new \InvalidArgumentException('TransitionCircleSessionAction expects a CircleSession and CircleSessionStatus.');
        }

        $session = CircleSession::with('circle')->lockForUpdate()->findOrFail($session->id);

        if (! $session->status->canTransitionTo($target)) {
            throw new ConflictException("The session cannot transition from {$session->status->value} to {$target->value}.");
        }

        if ($target === CircleSessionStatus::InProgress) {
            $scheduledStart = CenterClock::moment($session->session_date->toDateString(), $session->start_time);

            if ($scheduledStart->isFuture()) {
                throw new ConflictException('A session cannot be started before its scheduled start time.');
            }
        }

        if ($target === CircleSessionStatus::Completed) {
            $completion = $this->circleSessionCompletionQuery->check($session);

            if (! $completion['can_complete']) {
                throw new ConflictException('The session cannot be completed until attendance is recorded for every student and every present student has a score or N/A for each evaluation type.');
            }
        }

        $attributes = [
            'status' => $target,
            'version' => $session->version + 1,
        ];

        if ($target === CircleSessionStatus::Completed) {
            $attributes['completed_at'] = now();
        }

        if ($target === CircleSessionStatus::Locked) {
            $attributes['locked_at'] = now();
        }

        $session->update($attributes);

        if ($target === CircleSessionStatus::Completed) {
            $this->guardianNotificationService->notifyCircleGuardians($session->refresh(), 'parent_evaluation_reminder');
        }

        return $session->fresh(['circle' => CircleSession::circleWithStudentCount(), 'schedule', 'teacher']);
    }
}
