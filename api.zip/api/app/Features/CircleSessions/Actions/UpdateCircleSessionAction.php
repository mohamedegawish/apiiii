<?php

namespace App\Features\CircleSessions\Actions;

use App\Enums\Role;
use App\Features\CircleSessions\Requests\UpdateCircleSessionRequest;
use App\Models\Circle;
use App\Models\CircleSchedule;
use App\Models\CircleSession;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;
use Illuminate\Validation\ValidationException;

class UpdateCircleSessionAction extends BaseAction
{
    public function execute(mixed ...$arguments): mixed
    {
        $session = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $session instanceof CircleSession || ! $request instanceof UpdateCircleSessionRequest) {
            throw new \InvalidArgumentException('UpdateCircleSessionAction expects a CircleSession and UpdateCircleSessionRequest.');
        }

        $session = CircleSession::lockForUpdate()->findOrFail($session->id);

        if ($session->isImmutable()) {
            throw new ConflictException('Completed, cancelled, and locked sessions cannot be updated.');
        }

        $data = $request->validatedData();
        $circleId = $data['circle_id'] ?? $session->circle_id;
        $circle = Circle::lockForUpdate()->find($circleId);

        if ($circle === null || ! $circle->is_active) {
            throw ValidationException::withMessages(['circle_id' => ['The selected circle must be active.']]);
        }

        $user = $request->user();
        $allowed = $user?->isSuperAdmin()
            || ($user?->hasRole(Role::Teacher) && $user->teacher?->id === $circle->teacher_id);

        if (! $allowed) {
            throw ValidationException::withMessages(['circle_id' => ['The selected circle does not belong to your tenant.']]);
        }

        $scheduleId = array_key_exists('schedule_id', $data) ? $data['schedule_id'] : $session->schedule_id;

        if ($scheduleId !== null && ! CircleSchedule::whereKey($scheduleId)->where('circle_id', $circle->id)->exists()) {
            throw ValidationException::withMessages(['schedule_id' => ['The selected schedule does not belong to the circle.']]);
        }

        $startTime = $data['start_time'] ?? $session->start_time;
        $endTime = $data['end_time'] ?? $session->end_time;

        if ($startTime === null || $endTime === null || $endTime <= $startTime) {
            throw ValidationException::withMessages(['end_time' => ['The end time must be after the start time.']]);
        }

        if ($circle->teacher_id === null) {
            throw ValidationException::withMessages(['circle_id' => ['The selected circle does not have an assigned teacher.']]);
        }

        $data['teacher_id'] = $user?->hasRole(Role::Teacher) ? $user->teacher?->id : $circle->teacher_id;
        $session->update($data);

        return $session->fresh(['circle' => CircleSession::circleWithStudentCount(), 'schedule', 'teacher']);
    }
}
