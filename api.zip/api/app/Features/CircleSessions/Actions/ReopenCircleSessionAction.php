<?php

namespace App\Features\CircleSessions\Actions;

use App\Enums\CircleSessionStatus;
use App\Models\CircleSession;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;

/**
 * Reopen a finished session for editing: `Completed` or `Locked` back to
 * `InProgress`, with `completed_at` and `locked_at` cleared.
 *
 * `InProgress` is the target, not `Completed`, because every write guard in
 * the system — AttendanceService::assertWritable, ValidatesLearningRecord,
 * AcademicSessionGuard, LearningRecordPolicy — admits only a `Scheduled` or
 * `InProgress` session with a null `locked_at`. The previous unlock action
 * moved a locked session to `Completed`, which is itself immutable, so it
 * never delivered the recourse its own docblock claimed: a session locked by
 * mistake stayed permanently unwritable either way.
 *
 * Deliberately a separate action rather than edges in
 * CircleSessionStatus::allowedTransitions(). Adding `Locked => [InProgress]`
 * or `Completed => [InProgress]` to that graph would let anyone who can call
 * `start` reopen a finished session as an ordinary lifecycle step. Keeping
 * `Locked => []` intact and routing reopening through its own ability means
 * the graph still says what it means: a finished session is finished, and
 * only an explicit, separately-authorized, audited act reopens it.
 */
class ReopenCircleSessionAction extends BaseAction
{
    public function execute(mixed ...$arguments): mixed
    {
        $session = $arguments[0] ?? null;

        if (! $session instanceof CircleSession) {
            throw new \InvalidArgumentException('ReopenCircleSessionAction expects a CircleSession.');
        }

        $session = CircleSession::with('circle')->lockForUpdate()->findOrFail($session->id);

        // Cancelled is excluded on purpose: it records that the session did
        // not happen, and reopening it would invent attendance for a meeting
        // nobody held. Rescheduling is the correct answer there.
        if (! in_array($session->status, [CircleSessionStatus::Completed, CircleSessionStatus::Locked], true)) {
            throw new ConflictException(
                'Only a completed or locked session can be reopened.',
                'session_not_reopenable',
            );
        }

        $session->update([
            'status' => CircleSessionStatus::InProgress,
            'completed_at' => null,
            'locked_at' => null,
            'version' => $session->version + 1,
        ]);

        return $session->fresh(['circle' => CircleSession::circleWithStudentCount(), 'schedule', 'teacher']);
    }
}
