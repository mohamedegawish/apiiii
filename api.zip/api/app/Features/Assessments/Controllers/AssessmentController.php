<?php

namespace App\Features\Assessments\Controllers;

use App\Features\Assessments\Requests\StoreAssessmentRequest;
use App\Features\Assessments\Requests\UpdateAssessmentRequest;
use App\Features\Assessments\Resources\AssessmentResource;
use App\Features\Assessments\Services\AssessmentService;
use App\Models\Assessment;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AssessmentController extends BaseController
{
    public function __construct(protected AssessmentService $assessmentService) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Assessment::class);

        $paginator = $this->assessmentService->paginate();

        return $this->paginate(AssessmentResource::collection($paginator), 'Assessments retrieved successfully.');
    }

    public function show(string $assessment): JsonResponse
    {
        $model = $this->assessmentService->findOrFail($assessment);

        $this->authorize('view', $model);

        return $this->success(
            data: AssessmentResource::make($model),
            message: 'Assessment retrieved successfully.',
        );
    }

    public function store(StoreAssessmentRequest $request): JsonResponse
    {
        $assessment = $this->assessmentService->create($request);

        return $this->created(
            data: AssessmentResource::make($assessment),
            message: 'Assessment created successfully.',
        );
    }

    public function update(UpdateAssessmentRequest $request, string $assessment): JsonResponse
    {
        $model = $this->assessmentService->findOrFail($assessment);
        $updated = $this->assessmentService->update($model, $request);

        return $this->success(
            data: AssessmentResource::make($updated),
            message: 'Assessment updated successfully.',
        );
    }

    public function destroy(string $assessment): JsonResponse
    {
        $model = $this->assessmentService->findOrFail($assessment);

        $this->authorize('delete', $model);

        $this->assessmentService->delete($model);

        return $this->success(
            data: null,
            message: 'Assessment deleted successfully.',
        );
    }
}
