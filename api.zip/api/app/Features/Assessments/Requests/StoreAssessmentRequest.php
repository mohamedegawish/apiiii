<?php

namespace App\Features\Assessments\Requests;

use App\Enums\AssessmentType;
use App\Models\Assessment;
use App\Support\Http\Requests\BaseRequest;
use App\Support\Rules\OwnedCircle;
use Illuminate\Validation\Rule;

class StoreAssessmentRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', Assessment::class) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'student_id' => ['required', 'uuid', 'exists:students,id'],
            'teacher_id' => ['prohibited'],
            'circle_session_id' => ['required', 'uuid', 'exists:circle_sessions,id'],
            'circle_id' => ['nullable', 'uuid', 'exists:circles,id', new OwnedCircle],
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:2000'],
            'assessment_type' => ['nullable', 'string', Rule::in(AssessmentType::values())],
            'surah_number' => ['nullable', 'integer', 'min:1', 'max:114'],
            'from_ayah' => ['nullable', 'integer', 'min:1'],
            'to_ayah' => ['nullable', 'integer', 'min:1'],
            'grade' => ['nullable', 'numeric', 'min:0', 'lte:max_grade'],
            'max_grade' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'assessment_date' => ['prohibited'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
