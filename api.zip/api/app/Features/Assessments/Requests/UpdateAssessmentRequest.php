<?php

namespace App\Features\Assessments\Requests;

use App\Enums\AssessmentType;
use App\Models\Assessment;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class UpdateAssessmentRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $assessment = Assessment::find($this->route('assessment'));

        return $this->user()?->can('update', $assessment) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'student_id' => ['prohibited'],
            'teacher_id' => ['prohibited'],
            'circle_id' => ['prohibited'],
            'circle_session_id' => ['prohibited'],
            'title' => ['sometimes', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:2000'],
            'assessment_type' => ['nullable', 'string', Rule::in(AssessmentType::values())],
            'surah_number' => ['nullable', 'integer', 'min:1', 'max:114'],
            'from_ayah' => ['nullable', 'integer', 'min:1'],
            'to_ayah' => ['nullable', 'integer', 'min:1'],
            'grade' => ['nullable', 'numeric', 'min:0', 'lte:max_grade'],
            'max_grade' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'assessment_date' => ['prohibited'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
