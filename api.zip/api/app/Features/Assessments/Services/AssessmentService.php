<?php

namespace App\Features\Assessments\Services;

use App\Features\Assessments\Actions\CreateAssessmentAction;
use App\Features\Assessments\Actions\DeleteAssessmentAction;
use App\Features\Assessments\Actions\UpdateAssessmentAction;
use App\Features\Assessments\Queries\AssessmentQuery;
use App\Features\Assessments\Requests\StoreAssessmentRequest;
use App\Features\Assessments\Requests\UpdateAssessmentRequest;
use App\Models\Assessment;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class AssessmentService extends BaseService
{
    public function __construct(
        protected CreateAssessmentAction $createAssessmentAction,
        protected UpdateAssessmentAction $updateAssessmentAction,
        protected DeleteAssessmentAction $deleteAssessmentAction,
        protected AssessmentQuery $assessmentQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->assessmentQuery->paginate();
    }

    public function findOrFail(string $id): Assessment
    {
        $assessment = Assessment::with(['student', 'teacher'])->find($id);

        if ($assessment === null) {
            throw new NotFoundException('Assessment not found.');
        }

        return $assessment;
    }

    public function create(StoreAssessmentRequest $request): Assessment
    {
        return $this->transaction(fn (): Assessment => $this->createAssessmentAction->execute($request));
    }

    public function update(Assessment $assessment, UpdateAssessmentRequest $request): Assessment
    {
        return $this->transaction(fn (): Assessment => $this->updateAssessmentAction->execute($assessment, $request));
    }

    public function delete(Assessment $assessment): bool
    {
        return $this->transaction(fn (): bool => $this->deleteAssessmentAction->execute($assessment));
    }
}
