<?php

namespace App\Features\Assessments\Resources;

use App\Models\Assessment;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * @mixin Assessment
 */
class AssessmentResource extends BaseResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'student_id' => $this->student_id,
            'teacher_id' => $this->teacher_id,
            'circle_id' => $this->circle_id,
            'circle_session_id' => $this->circle_session_id,
            'title' => $this->title,
            'description' => $this->description,
            'assessment_type' => [
                'value' => $this->assessment_type?->value,
                'label' => $this->assessment_type?->name,
            ],
            'surah_number' => $this->surah_number,
            'from_ayah' => $this->from_ayah,
            'to_ayah' => $this->to_ayah,
            'grade' => $this->grade,
            'max_grade' => $this->max_grade,
            'assessment_date' => $this->assessment_date?->toIso8601String(),
            'notes' => $this->notes,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
