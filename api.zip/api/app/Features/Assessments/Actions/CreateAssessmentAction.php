<?php

namespace App\Features\Assessments\Actions;

use App\Events\AssessmentCreated;
use App\Features\Assessments\Requests\StoreAssessmentRequest;
use App\Models\Assessment;
use App\Models\CircleSession;
use App\Models\User;
use App\Support\Actions\BaseAction;
use App\Support\Services\AcademicSessionGuard;

class CreateAssessmentAction extends BaseAction
{
    public function __construct(protected AcademicSessionGuard $academicSessionGuard) {}

    /**
     * @return Assessment
     */
    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreAssessmentRequest) {
            throw new \InvalidArgumentException('CreateAssessmentAction expects a StoreAssessmentRequest.');
        }

        $data = $request->validatedData();
        $session = CircleSession::with(['circle', 'teacher'])->lockForUpdate()->findOrFail($data['circle_session_id']);
        $user = $request->user();
        if (! $user instanceof User) {
            throw new \InvalidArgumentException('An authenticated user is required.');
        }
        $this->academicSessionGuard->assertWritable($user, $session, $data['student_id']);
        $data['teacher_id'] = $session->teacher_id;
        $data['circle_id'] = $session->circle_id;
        $data['assessment_date'] = $session->session_date->toDateString();
        $assessment = Assessment::create($data);

        event(new AssessmentCreated($assessment));

        return $assessment;
    }
}
