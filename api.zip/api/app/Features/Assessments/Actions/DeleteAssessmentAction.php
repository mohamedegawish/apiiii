<?php

namespace App\Features\Assessments\Actions;

use App\Models\Assessment;
use App\Support\Actions\BaseAction;

class DeleteAssessmentAction extends BaseAction
{
    /**
     * @return bool
     */
    public function execute(mixed ...$arguments): mixed
    {
        $assessment = $arguments[0] ?? null;

        if (! $assessment instanceof Assessment) {
            throw new \InvalidArgumentException('DeleteAssessmentAction expects an Assessment.');
        }

        return $assessment->delete();
    }
}
