<?php

namespace App\Features\Assessments\Actions;

use App\Features\Assessments\Requests\UpdateAssessmentRequest;
use App\Models\Assessment;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;

class UpdateAssessmentAction extends BaseAction
{
    /**
     * @return Assessment
     */
    public function execute(mixed ...$arguments): mixed
    {
        $assessment = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $assessment instanceof Assessment) {
            throw new \InvalidArgumentException('UpdateAssessmentAction expects an Assessment as the first argument.');
        }

        if (! $request instanceof UpdateAssessmentRequest) {
            throw new \InvalidArgumentException('UpdateAssessmentAction expects an UpdateAssessmentRequest as the second argument.');
        }

        $assessment->loadMissing('circleSession');
        if ($assessment->circleSession?->isImmutable() || $assessment->circleSession?->locked_at !== null) {
            throw new ConflictException('Records in completed or locked sessions are immutable.');
        }

        $assessment->update($request->validatedData());

        return $assessment->fresh();
    }
}
