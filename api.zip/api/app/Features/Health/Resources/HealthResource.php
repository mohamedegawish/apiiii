<?php

namespace App\Features\Health\Resources;

use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

class HealthResource extends BaseResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'status' => $this->resource['status'],
            'checks' => $this->resource['checks'],
            'version' => $this->resource['version'],
            'environment' => $this->resource['environment'],
            'uptime' => $this->resource['uptime'],
            'response_time_ms' => $this->resource['response_time_ms'],
        ];
    }
}
