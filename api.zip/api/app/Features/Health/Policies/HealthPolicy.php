<?php

namespace App\Features\Health\Policies;

use App\Enums\Role;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class HealthPolicy extends BasePolicy
{
    public function view(?User $user): bool
    {
        return $this->hasRole($user, Role::SuperAdmin, Role::CenterOwner);
    }
}
