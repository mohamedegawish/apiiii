<?php

namespace App\Features\Health\Controllers;

use App\Features\Health\Policies\HealthPolicy;
use App\Features\Health\Resources\HealthResource;
use App\Features\Health\Services\HealthService;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class HealthController extends BaseController
{
    public function __construct(
        private readonly HealthService $healthService,
        private readonly HealthPolicy $healthPolicy,
    ) {}

    /**
     * @throws AuthorizationException
     */
    public function __invoke(Request $request): JsonResponse
    {
        if (! $this->healthPolicy->view($request->user())) {
            throw new AuthorizationException;
        }

        $health = $this->healthService->check();
        $status = $health['status'] === 'unhealthy'
            ? Response::HTTP_SERVICE_UNAVAILABLE
            : Response::HTTP_OK;

        return $this->success(
            data: HealthResource::make($health),
            message: 'Health check completed.',
            status: $status,
        );
    }
}
