<?php

namespace App\Features\Health\Services;

use App\Support\Storage\PlatformStorage;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

class HealthService
{
    private readonly float $startedAt;

    public function __construct(private readonly PlatformStorage $storage)
    {
        $this->startedAt = defined('LARAVEL_START') ? LARAVEL_START : microtime(true);
    }

    /**
     * @return array<string, mixed>
     */
    public function check(): array
    {
        $startedAt = microtime(true);
        $checks = [
            'database' => $this->measure(fn () => DB::select('select 1')),
            'cache' => $this->measure(fn () => $this->checkCache()),
            'queue' => $this->measure(fn () => $this->checkQueue()),
            'storage' => $this->measure(fn () => $this->checkStorage()),
        ];

        $status = $this->overallStatus($checks);

        return [
            'status' => $status,
            'checks' => $checks,
            'version' => (string) config('platform.version', 'unknown'),
            'environment' => app()->environment(),
            'uptime' => round(max(0, microtime(true) - $this->startedAt), 3),
            'response_time_ms' => round((microtime(true) - $startedAt) * 1000, 2),
        ];
    }

    private function checkCache(): void
    {
        $key = 'health:'.Str::uuid();
        $value = Str::random(32);
        $created = false;

        try {
            Cache::put($key, $value, 10);
            $created = true;

            if (Cache::get($key) !== $value) {
                throw new RuntimeException('Cache read verification failed.');
            }
        } finally {
            if ($created) {
                Cache::forget($key);
            }
        }
    }

    private function checkQueue(): void
    {
        $connection = (string) config('queue.default');
        $driver = config("queue.connections.{$connection}.driver");

        if ($driver === 'database') {
            $queueDatabase = config("queue.connections.{$connection}.connection");
            $jobsTable = (string) config("queue.connections.{$connection}.table", 'jobs');
            $failedDatabase = config('queue.failed.database');
            $failedTable = (string) config('queue.failed.table', 'failed_jobs');

            DB::connection($queueDatabase)->table($jobsTable)->limit(1)->exists();
            DB::connection($failedDatabase)->table($failedTable)->limit(1)->exists();

            return;
        }

        Queue::connection($connection)->size();
    }

    private function checkStorage(): void
    {
        $path = 'health/'.Str::uuid().'.tmp';
        $value = Str::random(32);
        $created = false;

        try {
            if (! $this->storage->put($path, $value)) {
                throw new RuntimeException('Storage write verification failed.');
            }

            $created = true;

            if (! $this->storage->exists($path) || $this->storage->get($path) !== $value) {
                throw new RuntimeException('Storage read verification failed.');
            }
        } finally {
            if ($created) {
                $this->storage->delete($path);
            }
        }
    }

    /**
     * @param  callable(): mixed  $check
     * @return array<string, mixed>
     */
    private function measure(callable $check): array
    {
        $startedAt = microtime(true);

        try {
            $check();

            return [
                'status' => 'healthy',
                'response_time_ms' => round((microtime(true) - $startedAt) * 1000, 2),
            ];
        } catch (Throwable $exception) {
            $result = [
                'status' => 'unhealthy',
                'response_time_ms' => round((microtime(true) - $startedAt) * 1000, 2),
            ];

            if (! app()->isProduction()) {
                $result['error'] = Str::limit(preg_replace('/\s+/', ' ', $exception->getMessage()) ?: 'Check failed.', 200);
            }

            return $result;
        }
    }

    /**
     * @param  array<string, array<string, mixed>>  $checks
     */
    private function overallStatus(array $checks): string
    {
        if ($checks['database']['status'] !== 'healthy') {
            return 'unhealthy';
        }

        foreach ($checks as $check) {
            if ($check['status'] !== 'healthy') {
                return 'degraded';
            }
        }

        return 'healthy';
    }
}
