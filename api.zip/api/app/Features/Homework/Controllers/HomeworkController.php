<?php

namespace App\Features\Homework\Controllers;

use App\Features\Homework\Requests\BulkStoreHomeworkRequest;
use App\Features\Homework\Requests\StoreHomeworkRequest;
use App\Features\Homework\Requests\UpdateHomeworkRequest;
use App\Features\Homework\Resources\HomeworkResource;
use App\Features\Homework\Services\HomeworkService;
use App\Models\Homework;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class HomeworkController extends BaseController
{
    public function __construct(protected HomeworkService $homeworkService) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Homework::class);

        $paginator = $this->homeworkService->paginate();

        return $this->paginate(HomeworkResource::collection($paginator), 'Homework retrieved successfully.');
    }

    public function bulkStore(BulkStoreHomeworkRequest $request): JsonResponse
    {
        return $this->created(
            data: HomeworkResource::collection($this->homeworkService->bulkCreate($request)),
            message: 'Homework assigned successfully.',
        );
    }

    public function show(string $homework): JsonResponse
    {
        $model = $this->homeworkService->findOrFail($homework);

        $this->authorize('view', $model);

        return $this->success(
            data: HomeworkResource::make($model),
            message: 'Homework retrieved successfully.',
        );
    }

    public function store(StoreHomeworkRequest $request): JsonResponse
    {
        $homework = $this->homeworkService->create($request);

        return $this->created(
            data: HomeworkResource::make($homework),
            message: 'Homework created successfully.',
        );
    }

    public function update(UpdateHomeworkRequest $request, string $homework): JsonResponse
    {
        $model = $this->homeworkService->findOrFail($homework);
        $updated = $this->homeworkService->update($model, $request);

        return $this->success(
            data: HomeworkResource::make($updated),
            message: 'Homework updated successfully.',
        );
    }

    public function destroy(string $homework): JsonResponse
    {
        $model = $this->homeworkService->findOrFail($homework);

        $this->authorize('delete', $model);

        $this->homeworkService->delete($model);

        return $this->success(
            data: null,
            message: 'Homework deleted successfully.',
        );
    }
}
