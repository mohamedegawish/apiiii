<?php

namespace App\Features\Homework\Actions;

use App\Enums\HomeworkStatus;
use App\Enums\HomeworkType;
use App\Features\Homework\Requests\BulkStoreHomeworkRequest;
use App\Models\CircleSession;
use App\Models\Homework;
use App\Models\Student;
use App\Models\User;
use App\Support\Actions\BaseAction;
use App\Support\Services\AcademicSessionGuard;
use App\Support\Services\GuardianNotificationService;
use Illuminate\Support\Collection;

class BulkCreateHomeworkAction extends BaseAction
{
    public function __construct(
        protected GuardianNotificationService $guardianNotificationService,
        protected AcademicSessionGuard $academicSessionGuard,
    ) {}

    /**
     * @return Collection<int, Homework>
     */
    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof BulkStoreHomeworkRequest) {
            throw new \InvalidArgumentException('BulkCreateHomeworkAction expects a BulkStoreHomeworkRequest.');
        }

        $data = $request->validatedData();
        $user = $request->user();

        if (! $user instanceof User) {
            throw new \InvalidArgumentException('An authenticated user is required.');
        }

        $session = CircleSession::with(['circle', 'teacher'])->lockForUpdate()->findOrFail($data['circle_session_id']);

        $shared = [
            'circle_session_id' => $session->id,
            'homework_type' => $data['homework_type'] ?? HomeworkType::Memorization->value,
            'teacher_id' => $session->teacher_id,
            'circle_id' => $session->circle_id,
            'title' => $data['title'],
            'description' => $data['description'] ?? null,
            'surah_number' => $data['surah_number'] ?? null,
            'from_ayah' => $data['from_ayah'] ?? null,
            'to_ayah' => $data['to_ayah'] ?? null,
            'due_date' => $data['due_date'],
            'status' => HomeworkStatus::Pending->value,
        ];

        $created = collect();

        foreach ($data['student_ids'] as $studentId) {
            $this->academicSessionGuard->assertWritable($user, $session, $studentId);

            $homework = Homework::create([...$shared, 'student_id' => $studentId]);
            $created->push($homework);

            $student = Student::find($studentId);
            if ($student !== null) {
                $this->guardianNotificationService->notifyStudentGuardians($student, 'new_homework', [
                    'homework_id' => $homework->id,
                    'due_date' => $homework->due_date->toDateString(),
                ]);
            }
        }

        return $created;
    }
}
