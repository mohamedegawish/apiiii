<?php

namespace App\Features\Homework\Actions;

use App\Enums\HomeworkStatus;
use App\Features\Homework\Requests\StoreHomeworkRequest;
use App\Models\CircleSession;
use App\Models\Homework;
use App\Models\Student;
use App\Models\User;
use App\Support\Actions\BaseAction;
use App\Support\Services\AcademicSessionGuard;
use App\Support\Services\GuardianNotificationService;

class CreateHomeworkAction extends BaseAction
{
    public function __construct(
        protected GuardianNotificationService $guardianNotificationService,
        protected AcademicSessionGuard $academicSessionGuard,
    ) {}

    /**
     * @return Homework
     */
    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreHomeworkRequest) {
            throw new \InvalidArgumentException('CreateHomeworkAction expects a StoreHomeworkRequest.');
        }

        $data = $request->validatedData();
        $session = CircleSession::with(['circle', 'teacher'])->lockForUpdate()->findOrFail($data['circle_session_id']);
        $user = $request->user();
        if (! $user instanceof User) {
            throw new \InvalidArgumentException('An authenticated user is required.');
        }
        $this->academicSessionGuard->assertWritable($user, $session, $data['student_id']);
        $data['teacher_id'] = $session->teacher_id;
        $data['circle_id'] = $session->circle_id;

        if (! isset($data['status'])) {
            $data['status'] = HomeworkStatus::Pending->value;
        }

        $homework = Homework::create($data);
        $student = Student::find($homework->student_id);
        if ($student !== null) {
            $this->guardianNotificationService->notifyStudentGuardians($student, 'new_homework', [
                'homework_id' => $homework->id,
                'due_date' => $homework->due_date->toDateString(),
            ]);
        }

        return $homework;
    }
}
