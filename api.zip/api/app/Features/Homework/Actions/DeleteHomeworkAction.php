<?php

namespace App\Features\Homework\Actions;

use App\Models\Homework;
use App\Support\Actions\BaseAction;

class DeleteHomeworkAction extends BaseAction
{
    /**
     * @return bool
     */
    public function execute(mixed ...$arguments): mixed
    {
        $homework = $arguments[0] ?? null;

        if (! $homework instanceof Homework) {
            throw new \InvalidArgumentException('DeleteHomeworkAction expects a Homework.');
        }

        return $homework->delete();
    }
}
