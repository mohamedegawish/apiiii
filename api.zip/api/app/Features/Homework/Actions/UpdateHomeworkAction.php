<?php

namespace App\Features\Homework\Actions;

use App\Events\HomeworkGraded;
use App\Features\Homework\Requests\UpdateHomeworkRequest;
use App\Models\Homework;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;

class UpdateHomeworkAction extends BaseAction
{
    /**
     * Fields describing the assignment itself — frozen once the origin
     * session closes, since they are part of that session's academic record.
     * `status`, `submitted_at`, `grade` and `feedback` stay writable, because
     * homework is graded on its own timeline (often after the class that
     * assigned it has ended) and freezing them would make homework
     * permanently unmarkable the moment the teacher completes the session.
     *
     * @var list<string>
     */
    private const CONTENT_FIELDS = ['homework_type', 'title', 'description', 'surah_number', 'from_ayah', 'to_ayah', 'due_date'];

    /**
     * @return Homework
     */
    public function execute(mixed ...$arguments): mixed
    {
        $homework = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $homework instanceof Homework) {
            throw new \InvalidArgumentException('UpdateHomeworkAction expects a Homework as the first argument.');
        }

        if (! $request instanceof UpdateHomeworkRequest) {
            throw new \InvalidArgumentException('UpdateHomeworkAction expects an UpdateHomeworkRequest as the second argument.');
        }

        $homework->loadMissing('circleSession');
        $data = $request->validatedData();
        $sessionClosed = $homework->circleSession?->isImmutable() || $homework->circleSession?->locked_at !== null;

        if ($sessionClosed && array_intersect_key($data, array_flip(self::CONTENT_FIELDS)) !== []) {
            throw new ConflictException('The assignment details are frozen once its session is completed or locked; only status, grade, and feedback remain editable.');
        }

        $gradeBefore = $homework->grade;

        $homework->update($data);

        $homework = $homework->fresh();

        if (blank($gradeBefore) && ! blank($homework->grade)) {
            event(new HomeworkGraded($homework));
        }

        return $homework;
    }
}
