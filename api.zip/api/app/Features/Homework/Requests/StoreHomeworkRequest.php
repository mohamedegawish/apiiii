<?php

namespace App\Features\Homework\Requests;

use App\Enums\HomeworkStatus;
use App\Enums\HomeworkType;
use App\Models\Homework;
use App\Support\Http\Requests\BaseRequest;
use App\Support\Rules\OwnedCircle;
use Illuminate\Validation\Rule;

class StoreHomeworkRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', Homework::class) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'student_id' => ['required', 'uuid', 'exists:students,id'],
            'teacher_id' => ['prohibited'],
            'circle_session_id' => ['required', 'uuid', 'exists:circle_sessions,id'],
            'homework_type' => ['sometimes', 'string', Rule::in(HomeworkType::values())],
            'circle_id' => ['nullable', 'uuid', 'exists:circles,id', new OwnedCircle],
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:2000'],
            'surah_number' => ['nullable', 'integer', 'min:1', 'max:114'],
            'from_ayah' => ['nullable', 'integer', 'min:1'],
            'to_ayah' => ['nullable', 'integer', 'min:1'],
            'due_date' => ['required', 'date', 'after_or_equal:today'],
            'submitted_at' => ['nullable', 'date'],
            'status' => ['nullable', 'string', Rule::in(HomeworkStatus::values())],
            'grade' => ['nullable', 'numeric', 'min:0'],
            'feedback' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
