<?php

namespace App\Features\Homework\Requests;

use App\Enums\HomeworkStatus;
use App\Enums\HomeworkType;
use App\Models\Homework;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class UpdateHomeworkRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $homework = Homework::find($this->route('homework'));

        return $this->user()?->can('update', $homework) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'student_id' => ['prohibited'],
            'teacher_id' => ['prohibited'],
            'circle_id' => ['prohibited'],
            'circle_session_id' => ['prohibited'],
            'homework_type' => ['sometimes', 'string', Rule::in(HomeworkType::values())],
            'title' => ['sometimes', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:2000'],
            'surah_number' => ['nullable', 'integer', 'min:1', 'max:114'],
            'from_ayah' => ['nullable', 'integer', 'min:1'],
            'to_ayah' => ['nullable', 'integer', 'min:1'],
            'due_date' => ['sometimes', 'date'],
            'submitted_at' => ['nullable', 'date'],
            'status' => ['nullable', 'string', Rule::in(HomeworkStatus::values())],
            'grade' => ['nullable', 'numeric', 'min:0'],
            'feedback' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
