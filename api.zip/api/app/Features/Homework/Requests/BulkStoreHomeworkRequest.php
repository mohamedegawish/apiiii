<?php

namespace App\Features\Homework\Requests;

use App\Enums\HomeworkType;
use App\Models\Homework;
use App\Support\Http\Requests\BaseRequest;
use App\Support\Rules\OwnedCircle;
use Illuminate\Validation\Rule;

/**
 * Assigns the same homework to every listed student in one session-bound
 * transaction — assigning to a whole circle one student at a time would be
 * N requests against the 30/min sensitive-write throttle.
 */
class BulkStoreHomeworkRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', Homework::class) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'circle_session_id' => ['required', 'uuid', 'exists:circle_sessions,id'],
            'homework_type' => ['sometimes', 'string', Rule::in(HomeworkType::values())],
            'circle_id' => ['nullable', 'uuid', 'exists:circles,id', new OwnedCircle],
            'student_ids' => ['required', 'array', 'min:1', 'max:200'],
            'student_ids.*' => ['required', 'uuid', 'distinct:strict', 'exists:students,id'],
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:2000'],
            'surah_number' => ['nullable', 'integer', 'min:1', 'max:114'],
            'from_ayah' => ['nullable', 'integer', 'min:1'],
            'to_ayah' => ['nullable', 'integer', 'min:1'],
            'due_date' => ['required', 'date', 'after_or_equal:today'],
        ];
    }
}
