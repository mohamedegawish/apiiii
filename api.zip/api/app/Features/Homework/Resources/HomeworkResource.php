<?php

namespace App\Features\Homework\Resources;

use App\Models\Homework;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * @mixin Homework
 */
class HomeworkResource extends BaseResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'student_id' => $this->student_id,
            'teacher_id' => $this->teacher_id,
            'circle_id' => $this->circle_id,
            'circle_session_id' => $this->circle_session_id,
            'homework_type' => [
                'value' => $this->homework_type?->value,
                'label' => $this->homework_type?->label(),
            ],
            'title' => $this->title,
            'description' => $this->description,
            'surah_number' => $this->surah_number,
            'from_ayah' => $this->from_ayah,
            'to_ayah' => $this->to_ayah,
            'due_date' => $this->due_date?->toIso8601String(),
            'submitted_at' => $this->submitted_at?->toIso8601String(),
            'status' => [
                'value' => $this->status?->value,
                'label' => $this->status?->name,
            ],
            'grade' => $this->grade,
            'feedback' => $this->feedback,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
