<?php

namespace App\Features\Homework\Services;

use App\Features\Homework\Actions\BulkCreateHomeworkAction;
use App\Features\Homework\Actions\CreateHomeworkAction;
use App\Features\Homework\Actions\DeleteHomeworkAction;
use App\Features\Homework\Actions\UpdateHomeworkAction;
use App\Features\Homework\Queries\HomeworkQuery;
use App\Features\Homework\Requests\BulkStoreHomeworkRequest;
use App\Features\Homework\Requests\StoreHomeworkRequest;
use App\Features\Homework\Requests\UpdateHomeworkRequest;
use App\Models\Homework;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

class HomeworkService extends BaseService
{
    public function __construct(
        protected CreateHomeworkAction $createHomeworkAction,
        protected UpdateHomeworkAction $updateHomeworkAction,
        protected DeleteHomeworkAction $deleteHomeworkAction,
        protected BulkCreateHomeworkAction $bulkCreateHomeworkAction,
        protected HomeworkQuery $homeworkQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->homeworkQuery->paginate();
    }

    public function findOrFail(string $id): Homework
    {
        $homework = Homework::with(['student', 'teacher'])->find($id);

        if ($homework === null) {
            throw new NotFoundException('Homework not found.');
        }

        return $homework;
    }

    public function create(StoreHomeworkRequest $request): Homework
    {
        return $this->transaction(fn (): Homework => $this->createHomeworkAction->execute($request));
    }

    /**
     * @return Collection<int, Homework>
     */
    public function bulkCreate(BulkStoreHomeworkRequest $request): Collection
    {
        return $this->transaction(fn (): Collection => $this->bulkCreateHomeworkAction->execute($request));
    }

    public function update(Homework $homework, UpdateHomeworkRequest $request): Homework
    {
        return $this->transaction(fn (): Homework => $this->updateHomeworkAction->execute($homework, $request));
    }

    public function delete(Homework $homework): bool
    {
        return $this->transaction(fn (): bool => $this->deleteHomeworkAction->execute($homework));
    }
}
