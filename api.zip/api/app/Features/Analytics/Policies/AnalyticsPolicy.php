<?php

namespace App\Features\Analytics\Policies;

use App\Enums\Role;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class AnalyticsPolicy extends BasePolicy
{
    public function viewExecutiveDashboard(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }
}
