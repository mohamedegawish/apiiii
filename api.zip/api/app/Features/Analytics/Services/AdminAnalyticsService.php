<?php

namespace App\Features\Analytics\Services;

use App\Enums\CircleSessionStatus;
use App\Enums\StudentStatus;
use App\Features\Finance\Services\FinanceReportService;
use App\Models\Attendance;
use App\Models\CircleSession;
use App\Models\ParentEvaluation;
use App\Models\Student;
use App\Models\StudentLearningRecord;
use App\Models\Teacher;
use App\Support\CenterClock;
use App\Support\Queries\DateColumn;
use Illuminate\Support\Carbon;

/**
 * The executive dashboard's finance widget delegates to
 * {@see FinanceReportService::monthlySummary()} rather than recomputing
 * revenue/expense totals — one source of truth for "this month's numbers"
 * shared with the dedicated finance reports.
 */
class AdminAnalyticsService
{
    private const LEARNING_TYPES = ['memorization', 'revision', 'matn', 'listening'];

    public function __construct(
        protected TeacherAnalyticsService $teacherAnalyticsService,
        protected FinanceReportService $financeReportService,
    ) {}

    /** @return array<string, mixed> */
    public function executiveDashboard(): array
    {
        // The center's calendar day, not UTC's -- Cairo is 2-3h ahead, so a
        // UTC "today" reports yesterday's figures during the center's morning.
        $today = CenterClock::today();
        $start = $today->copy()->startOfMonth();
        $end = $today->copy()->endOfMonth();
        $prevStart = $start->copy()->subMonthNoOverflow();
        $prevEnd = $prevStart->copy()->endOfMonth();

        return [
            'period' => ['start' => $start->toDateString(), 'end' => $end->toDateString()],
            'students' => $this->studentsWidget($start, $end),
            'teachers' => $this->teachersWidget($start, $end),
            'sessions' => $this->sessionsWidget($start, $end),
            'learning_growth' => $this->learningGrowthWidget($start, $end, $prevStart, $prevEnd),
            'parent_engagement' => $this->parentEngagementWidget($start, $end),
            'finance' => $this->financeWidget($today),
        ];
    }

    /** @return array<string, mixed> */
    private function studentsWidget(Carbon $start, Carbon $end): array
    {
        return [
            'total' => Student::count(),
            'active' => Student::where('status', StudentStatus::Active->value)->count(),
            'inactive' => Student::where('status', '!=', StudentStatus::Active->value)->count(),
            'new_this_period' => Student::where('enrolled_at', '>=', $start->toDateString())
                ->where('enrolled_at', '<', DateColumn::dayAfter($end))->count(),
        ];
    }

    /** @return array<string, mixed> */
    private function teachersWidget(Carbon $start, Carbon $end): array
    {
        $teachers = Teacher::where('is_active', true)->with('user')->get();

        // One batched metrics pass for the whole faculty. Scoring them one at a
        // time meant a full metric query set per teacher — the dominant cost of
        // this dashboard — for a widget that only shows the top five.
        $metrics = $this->teacherAnalyticsService->metricsForTeachers(
            $teachers->pluck('id')->all(),
            $start,
            $end,
        );

        $topPerformers = $teachers
            ->map(fn (Teacher $teacher): array => [
                'teacher_id' => $teacher->id,
                'teacher_name' => $teacher->user?->name,
                'performance_score' => $metrics[$teacher->id]['performance_score'] ?? 0.0,
            ])
            ->sortByDesc('performance_score')
            ->take(5)
            ->values();

        return [
            'total' => Teacher::count(),
            'active' => $teachers->count(),
            'top_performers' => $topPerformers,
        ];
    }

    /** @return array<string, mixed> */
    private function sessionsWidget(Carbon $start, Carbon $end): array
    {
        $counts = CircleSession::where('session_date', '>=', $start->toDateString())
            ->where('session_date', '<', DateColumn::dayAfter($end))
            ->selectRaw('status, COUNT(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        return [
            'scheduled' => (int) ($counts[CircleSessionStatus::Scheduled->value] ?? 0),
            'in_progress' => (int) ($counts[CircleSessionStatus::InProgress->value] ?? 0),
            'completed' => (int) ($counts[CircleSessionStatus::Completed->value] ?? 0),
            'locked' => (int) ($counts[CircleSessionStatus::Locked->value] ?? 0),
            'cancelled' => (int) ($counts[CircleSessionStatus::Cancelled->value] ?? 0),
        ];
    }

    /** @return array<string, mixed> */
    private function learningGrowthWidget(Carbon $start, Carbon $end, Carbon $prevStart, Carbon $prevEnd): array
    {
        $current = $this->averageScoresByType($start, $end);
        $previous = $this->averageScoresByType($prevStart, $prevEnd);

        $growth = [];
        foreach (self::LEARNING_TYPES as $type) {
            $growth[$type] = [
                'current_average' => $current[$type],
                'previous_average' => $previous[$type],
                'growth' => ($current[$type] !== null && $previous[$type] !== null)
                    ? round($current[$type] - $previous[$type], 2)
                    : null,
            ];
        }

        return $growth;
    }

    /**
     * Averaged in SQL rather than by hydrating every learning record of the
     * period — the figures are identical, but the row set never leaves MySQL.
     * This runs twice per dashboard (current and previous period).
     *
     * @return array<string, float|null>
     */
    private function averageScoresByType(Carbon $start, Carbon $end): array
    {
        $averages = StudentLearningRecord::whereBetween('created_at', [$start->copy()->startOfDay(), $end->copy()->endOfDay()])
            ->whereNotNull('score')
            ->selectRaw('type, AVG(score) as aggregate')
            ->groupBy('type')
            ->pluck('aggregate', 'type');

        $result = [];
        foreach (self::LEARNING_TYPES as $type) {
            $average = $averages[$type] ?? null;
            $result[$type] = $average === null ? null : round((float) $average, 2);
        }

        return $result;
    }

    /**
     * The attended-session set stays inside MySQL as a subquery. Pulling every
     * attendance row's session id into PHP first, then sending the de-duplicated
     * list back as a `whereIn` of thousands of UUIDs, was the same answer at a
     * far higher cost in both directions of the wire.
     *
     * @return array<string, mixed>
     */
    private function parentEngagementWidget(Carbon $start, Carbon $end): array
    {
        $attendedSessions = Attendance::query()
            ->where('attendance_date', '>=', $start->toDateString())
            ->where('attendance_date', '<', DateColumn::dayAfter($end))
            ->whereIn('status', ['present', 'late'])
            ->whereNotNull('circle_session_id');

        $expected = (int) $attendedSessions->clone()->distinct()->count('circle_session_id');

        $submitted = (int) ParentEvaluation::whereIn(
            'circle_session_id',
            $attendedSessions->clone()->select('circle_session_id'),
        )->count();

        return [
            'expected_evaluations' => $expected,
            'submitted_evaluations' => $submitted,
            'engagement_rate' => $expected > 0 ? round($submitted / $expected * 100, 2) : 0.0,
        ];
    }

    /** @return array<string, mixed> */
    private function financeWidget(Carbon $today): array
    {
        $summary = $this->financeReportService
            ->monthlySummary(['year' => $today->year, 'month' => $today->month])
            ->items()[0] ?? null;

        return [
            'revenue' => $summary['total_revenue'] ?? 0.0,
            'expenses' => $summary['total_expenses'] ?? 0.0,
            'profit' => $summary['net_profit'] ?? 0.0,
            'outstanding_receivables' => $summary['outstanding_receivables'] ?? 0.0,
        ];
    }
}
