<?php

namespace App\Features\Analytics\Services;

use App\Enums\AttendanceStatus;
use App\Enums\CircleSessionStatus;
use App\Enums\HomeworkStatus;
use App\Features\CircleSessions\Queries\CircleSessionCompletionQuery;
use App\Models\Circle;
use App\Models\CircleSession;
use App\Models\Enrollment;
use App\Models\Homework;
use App\Models\ParentEvaluation;
use App\Models\StudentLearningRecord;
use App\Models\Teacher;
use App\Support\CenterClock;
use App\Support\Queries\DateColumn;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/**
 * All numbers here come straight from circle_sessions/attendances/
 * student_learning_records/homework/parent_evaluations — the same tables
 * PayrollCalculator and StudentTrackingService read, so a teacher's
 * dashboard, payroll, and their students' tracking profiles never disagree
 * about what happened in a given period.
 *
 * Every metric is computed by {@see metricsForTeachers()}, which answers for
 * a whole set of teachers in a fixed number of queries. The single-teacher
 * {@see performanceMetrics()} delegates to it, so the ranking board (which
 * needs every active teacher's score) costs the same handful of queries as
 * one teacher's card rather than one full metric pass per teacher.
 */
class TeacherAnalyticsService
{
    private const LEARNING_TYPES = ['memorization', 'revision', 'matn', 'listening'];

    public function __construct(protected CircleSessionCompletionQuery $completionQuery) {}

    /** @return array<string, mixed> */
    public function dashboard(Teacher $teacher, string $granularity = 'monthly'): array
    {
        // The center's calendar day, not UTC's -- Cairo is 2-3h ahead, so a
        // UTC "today" reports yesterday's figures during the center's morning.
        $today = CenterClock::today();
        [$start, $end] = $this->periodRange($granularity, $today);
        [$prevStart, $prevEnd] = $this->periodRange($granularity, $this->shiftBack($granularity, $today));

        $todaySessions = CircleSession::where('teacher_id', $teacher->id)
            ->where('session_date', '>=', DateColumn::day($today))
            ->where('session_date', '<', DateColumn::dayAfter($today))
            ->with('circle')
            ->orderBy('start_time')
            ->get()
            ->map(fn (CircleSession $session): array => $this->summarizeSession($session))
            ->values();

        $upcoming = CircleSession::where('teacher_id', $teacher->id)
            ->where('session_date', '>=', DateColumn::dayAfter($today))
            ->where('status', CircleSessionStatus::Scheduled->value)
            ->orderBy('session_date')
            ->orderBy('start_time')
            ->limit(10)
            ->with('circle')
            ->get()
            ->map(fn (CircleSession $session): array => $this->summarizeSession($session))
            ->values();

        $completedThisPeriod = CircleSession::where('teacher_id', $teacher->id)
            ->where('status', CircleSessionStatus::Completed->value)
            ->where('session_date', '>=', $start->toDateString())
            ->where('session_date', '<', DateColumn::dayAfter($end))
            ->count();

        // One metrics pass covers both this teacher's own card and the ranking
        // board it is placed on. The board itself stays limited to active
        // teachers; an inactive teacher still sees their own card, and (as
        // before) ranks nowhere on it.
        $rankedTeacherIds = Teacher::where('is_active', true)->pluck('id')->all();
        $metricTeacherIds = in_array($teacher->id, $rankedTeacherIds, true)
            ? $rankedTeacherIds
            : [...$rankedTeacherIds, $teacher->id];

        $allMetrics = $this->metricsForTeachers($metricTeacherIds, $start, $end);
        $performance = $allMetrics[$teacher->id] ?? $this->emptyMetrics();

        return [
            'period' => ['granularity' => $granularity, 'start' => $start->toDateString(), 'end' => $end->toDateString()],
            'sessions' => [
                'today' => $todaySessions,
                'upcoming' => $upcoming,
                'completed_count_this_period' => $completedThisPeriod,
            ],
            'performance' => $performance,
            'learning_growth' => $this->learningGrowth($teacher, $start, $end, $prevStart, $prevEnd),
            'ranking' => $this->rankingFrom($teacher, $performance['performance_score'], $allMetrics, $rankedTeacherIds),
        ];
    }

    /** @return array<string, mixed> */
    public function performanceMetrics(Teacher $teacher, Carbon $start, Carbon $end): array
    {
        return $this->metricsForTeachers([$teacher->id], $start, $end)[$teacher->id] ?? $this->emptyMetrics();
    }

    /**
     * Performance metrics for many teachers at once, in a fixed number of
     * queries regardless of how many teachers or sessions are involved.
     *
     * @param  list<string>  $teacherIds
     * @return array<string, array<string, mixed>> Keyed by teacher id.
     */
    public function metricsForTeachers(array $teacherIds, Carbon $start, Carbon $end): array
    {
        if ($teacherIds === []) {
            return [];
        }

        $startDate = $start->toDateString();
        $endExclusive = DateColumn::dayAfter($end);
        $startAt = $start->copy()->startOfDay();
        $endAt = $end->copy()->endOfDay();

        $sessionsByTeacher = CircleSession::whereIn('teacher_id', $teacherIds)
            ->where('session_date', '>=', $startDate)
            ->where('session_date', '<', $endExclusive)
            ->get()
            ->groupBy('teacher_id');

        // Plain rows rather than models: a month of attendance for a whole
        // faculty is thousands of rows and only four scalars per row are read,
        // so Eloquent hydration was pure overhead here. The "present" statuses
        // still come from the enum rather than being re-spelled as literals.
        $presentStatuses = array_map(
            fn (AttendanceStatus $status): string => $status->value,
            array_filter(AttendanceStatus::cases(), fn (AttendanceStatus $status): bool => $status->wasPresent()),
        );

        $attendanceByTeacher = [];
        foreach (
            DB::table('attendances')
                ->whereIn('teacher_id', $teacherIds)
                ->where('attendance_date', '>=', $startDate)
                ->where('attendance_date', '<', $endExclusive)
                ->whereNull('deleted_at')
                ->get(['teacher_id', 'student_id', 'circle_session_id', 'status']) as $attendance
        ) {
            $attendanceByTeacher[$attendance->teacher_id][] = $attendance;
        }

        // Completion status for every completed session across every teacher,
        // resolved in one batch rather than one check per session.
        $completedSessions = $sessionsByTeacher
            ->flatten(1)
            ->filter(fn (CircleSession $session): bool => $session->status === CircleSessionStatus::Completed)
            ->values();
        $completion = $this->completionQuery->checkMany($completedSessions);

        // Currently-enrolled roster per teacher, via their circles.
        $circleTeacher = Circle::whereIn('teacher_id', $teacherIds)->pluck('teacher_id', 'id');
        $enrolledByTeacher = Enrollment::whereIn('circle_id', $circleTeacher->keys())
            ->where('status', 'active')
            ->get(['id', 'circle_id', 'student_id'])
            ->groupBy(fn (Enrollment $enrollment): string => (string) $circleTeacher[$enrollment->circle_id]);

        $homeworkTotals = Homework::whereIn('teacher_id', $teacherIds)
            ->whereBetween('created_at', [$startAt, $endAt])
            ->selectRaw('teacher_id, COUNT(*) as aggregate')
            ->groupBy('teacher_id')
            ->pluck('aggregate', 'teacher_id');

        $homeworkGraded = Homework::whereIn('teacher_id', $teacherIds)
            ->where('status', HomeworkStatus::Graded->value)
            ->whereBetween('updated_at', [$startAt, $endAt])
            ->selectRaw('teacher_id, COUNT(*) as aggregate')
            ->groupBy('teacher_id')
            ->pluck('aggregate', 'teacher_id');

        // Per-teacher present-attendance rollups in one pass over the rows.
        $presentLookup = array_flip($presentStatuses);
        $presentByTeacher = [];
        $allAttendedSessionIds = [];
        foreach ($attendanceByTeacher as $teacherId => $rows) {
            $students = [];
            $sessionsSeen = [];
            $presentCount = 0;
            foreach ($rows as $row) {
                if (! isset($presentLookup[$row->status])) {
                    continue;
                }
                $presentCount++;
                $students[$row->student_id] = true;
                if ($row->circle_session_id !== null) {
                    $sessionsSeen[$row->circle_session_id] = true;
                    $allAttendedSessionIds[$row->circle_session_id] = true;
                }
            }
            $presentByTeacher[$teacherId] = [
                'count' => $presentCount,
                'students' => $students,
                'sessions' => $sessionsSeen,
            ];
        }

        // Evaluations per session, so each teacher's total is a sum over the
        // sessions their present students attended.
        $evaluationsBySession = $allAttendedSessionIds === []
            ? collect()
            : ParentEvaluation::whereIn('circle_session_id', array_keys($allAttendedSessionIds))
                ->selectRaw('circle_session_id, COUNT(*) as aggregate')
                ->groupBy('circle_session_id')
                ->pluck('aggregate', 'circle_session_id');

        $results = [];

        foreach ($teacherIds as $teacherId) {
            $sessions = $sessionsByTeacher->get($teacherId, collect());
            $completedForTeacher = $sessions->where('status', CircleSessionStatus::Completed);

            $attendanceTotal = count($attendanceByTeacher[$teacherId] ?? []);
            $present = $presentByTeacher[$teacherId] ?? ['count' => 0, 'students' => [], 'sessions' => []];
            $attendanceRate = $attendanceTotal > 0
                ? round($present['count'] / $attendanceTotal * 100, 2)
                : 0.0;

            $evaluationCompleteCount = $completedForTeacher->filter(
                fn (CircleSession $session): bool => ($completion[$session->id]['evaluation_complete'] ?? false)
            )->count();
            $evaluationCompletionRate = $completedForTeacher->count() > 0
                ? round($evaluationCompleteCount / $completedForTeacher->count() * 100, 2)
                : 0.0;

            // The share of this teacher's currently-enrolled roster that actually
            // showed up at least once this period — distinct from attendance_rate,
            // which measures presence per attendance *record* rather than per student.
            $enrolledStudentIds = $enrolledByTeacher->get($teacherId, collect())
                ->pluck('student_id')->unique()->flip()->all();
            $enrolledCount = count($enrolledStudentIds);
            $studentCompletionRate = $enrolledCount > 0
                ? round(count(array_intersect_key($present['students'], $enrolledStudentIds)) / $enrolledCount * 100, 2)
                : 0.0;

            $homeworkTotal = (int) ($homeworkTotals[$teacherId] ?? 0);
            $graded = (int) ($homeworkGraded[$teacherId] ?? 0);
            $homeworkCompletionRate = $homeworkTotal > 0 ? round($graded / $homeworkTotal * 100, 2) : 0.0;

            $expectedEvaluations = count($present['sessions']);
            $submittedEvaluations = 0;
            foreach (array_keys($present['sessions']) as $sessionId) {
                $submittedEvaluations += (int) ($evaluationsBySession[$sessionId] ?? 0);
            }
            $parentEngagementRate = $expectedEvaluations > 0
                ? round($submittedEvaluations / $expectedEvaluations * 100, 2)
                : 0.0;

            $results[$teacherId] = [
                'sessions_count' => $sessions->count(),
                'completed_sessions_count' => $completedForTeacher->count(),
                'attendance_rate' => $attendanceRate,
                'evaluation_completion_rate' => $evaluationCompletionRate,
                'student_completion_rate' => $studentCompletionRate,
                'homework_completion_rate' => $homeworkCompletionRate,
                'parent_engagement_rate' => $parentEngagementRate,
                'performance_score' => round(
                    $attendanceRate * 0.3 + $evaluationCompletionRate * 0.3
                    + $homeworkCompletionRate * 0.2 + $parentEngagementRate * 0.2,
                    2
                ),
            ];
        }

        return $results;
    }

    /** @return array<string, mixed> */
    private function emptyMetrics(): array
    {
        return [
            'sessions_count' => 0,
            'completed_sessions_count' => 0,
            'attendance_rate' => 0.0,
            'evaluation_completion_rate' => 0.0,
            'student_completion_rate' => 0.0,
            'homework_completion_rate' => 0.0,
            'parent_engagement_rate' => 0.0,
            'performance_score' => 0.0,
        ];
    }

    /** @return array<string, mixed> */
    private function learningGrowth(Teacher $teacher, Carbon $start, Carbon $end, Carbon $prevStart, Carbon $prevEnd): array
    {
        $current = $this->averageScoresByType($teacher, $start, $end);
        $previous = $this->averageScoresByType($teacher, $prevStart, $prevEnd);

        $growth = [];
        foreach (self::LEARNING_TYPES as $type) {
            $growth[$type] = [
                'current_average' => $current[$type],
                'previous_average' => $previous[$type],
                'growth' => ($current[$type] !== null && $previous[$type] !== null)
                    ? round($current[$type] - $previous[$type], 2)
                    : null,
            ];
        }

        return $growth;
    }

    /**
     * Averaged in SQL rather than by hydrating every learning record of the
     * period — the figures are identical, but the row set never leaves MySQL.
     *
     * @return array<string, float|null>
     */
    private function averageScoresByType(Teacher $teacher, Carbon $start, Carbon $end): array
    {
        $averages = StudentLearningRecord::where('teacher_id', $teacher->id)
            ->whereBetween('created_at', [$start->copy()->startOfDay(), $end->copy()->endOfDay()])
            ->whereNotNull('score')
            ->selectRaw('type, AVG(score) as aggregate')
            ->groupBy('type')
            ->pluck('aggregate', 'type');

        $result = [];
        foreach (self::LEARNING_TYPES as $type) {
            $average = $averages[$type] ?? null;
            $result[$type] = $average === null ? null : round((float) $average, 2);
        }

        return $result;
    }

    /**
     * @param  array<string, array<string, mixed>>  $allMetrics
     * @param  list<string>  $rankedTeacherIds
     * @return array<string, mixed>
     */
    private function rankingFrom(Teacher $teacher, float $performanceScore, array $allMetrics, array $rankedTeacherIds): array
    {
        $scores = collect($rankedTeacherIds)
            ->map(fn (string $teacherId): array => [
                'teacher_id' => $teacherId,
                'score' => $teacherId === $teacher->id
                    ? $performanceScore
                    : ($allMetrics[$teacherId]['performance_score'] ?? 0.0),
            ])
            ->sortByDesc('score')
            ->values();

        $position = $scores->search(fn (array $row): bool => $row['teacher_id'] === $teacher->id);

        return [
            'position' => $position !== false ? $position + 1 : null,
            'out_of' => $scores->count(),
            'performance_score' => $performanceScore,
        ];
    }

    /** @return array<string, mixed> */
    private function summarizeSession(CircleSession $session): array
    {
        return [
            'id' => $session->id,
            'circle_id' => $session->circle_id,
            'circle_name' => $session->circle?->name,
            'session_date' => $session->session_date?->toDateString(),
            'start_time' => $session->start_time,
            'end_time' => $session->end_time,
            'status' => $session->status->value,
        ];
    }

    /** @return array{0: Carbon, 1: Carbon} */
    private function periodRange(string $granularity, Carbon $reference): array
    {
        return match ($granularity) {
            'weekly' => [$reference->copy()->startOfWeek(), $reference->copy()->endOfWeek()],
            'quarterly' => [$reference->copy()->startOfQuarter(), $reference->copy()->endOfQuarter()],
            'yearly' => [$reference->copy()->startOfYear(), $reference->copy()->endOfYear()],
            default => [$reference->copy()->startOfMonth(), $reference->copy()->endOfMonth()],
        };
    }

    private function shiftBack(string $granularity, Carbon $reference): Carbon
    {
        return match ($granularity) {
            'weekly' => $reference->copy()->subWeek(),
            'quarterly' => $reference->copy()->subQuarterNoOverflow(),
            'yearly' => $reference->copy()->subYearNoOverflow(),
            default => $reference->copy()->subMonthNoOverflow(),
        };
    }
}
