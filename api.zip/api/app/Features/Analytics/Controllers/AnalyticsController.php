<?php

namespace App\Features\Analytics\Controllers;

use App\Features\Analytics\Policies\AnalyticsPolicy;
use App\Features\Analytics\Services\AdminAnalyticsService;
use App\Features\Analytics\Services\TeacherAnalyticsService;
use App\Models\Teacher;
use App\Support\Exceptions\NotFoundException;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AnalyticsController extends BaseController
{
    private const GRANULARITIES = ['weekly', 'monthly', 'quarterly', 'yearly'];

    public function __construct(
        protected TeacherAnalyticsService $teacherAnalyticsService,
        protected AdminAnalyticsService $adminAnalyticsService,
        protected AnalyticsPolicy $policy,
    ) {}

    public function teacherDashboard(Request $request): JsonResponse
    {
        $teacher = Teacher::where('user_id', $request->user()->id)->first();

        if ($teacher === null) {
            throw new NotFoundException('No teacher profile is linked to this account.');
        }

        $granularity = $request->query('granularity', 'monthly');
        $granularity = in_array($granularity, self::GRANULARITIES, true) ? $granularity : 'monthly';

        return $this->success(
            $this->teacherAnalyticsService->dashboard($teacher, $granularity),
            'Teacher dashboard retrieved successfully.',
        );
    }

    public function executiveDashboard(Request $request): JsonResponse
    {
        if (! $this->policy->viewExecutiveDashboard($request->user())) {
            throw new AuthorizationException;
        }

        return $this->success(
            $this->adminAnalyticsService->executiveDashboard(),
            'Executive dashboard retrieved successfully.',
        );
    }
}
