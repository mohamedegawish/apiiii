<?php

namespace App\Features\AuditLogs\Policies;

use App\Enums\Role;
use App\Features\AuditLogs\Queries\AuditLogQuery;
use App\Models\AuditLog;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class AuditLogPolicy extends BasePolicy
{
    public function __construct(private readonly AuditLogQuery $query) {}

    public function viewAny(?User $user): bool
    {
        return $this->hasRole($user, Role::SuperAdmin, Role::CenterOwner);
    }

    public function view(?User $user, AuditLog $auditLog): bool
    {
        if (! $this->viewAny($user)) {
            return false;
        }

        if ($user->isSuperAdmin()) {
            return true;
        }

        $query = AuditLog::query()->whereKey($auditLog->getKey());
        $this->query->scopeVisibleTo($query, $user);

        return $query->exists();
    }
}
