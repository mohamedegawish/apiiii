<?php

namespace App\Features\AuditLogs\Services;

use App\Features\AuditLogs\Queries\AuditLogQuery;
use App\Models\AuditLog;
use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class AuditLogService
{
    public function __construct(private readonly AuditLogQuery $query) {}

    /** @param array<string, mixed> $filters */
    public function paginate(User $user, array $filters): LengthAwarePaginator
    {
        return $this->query->build($user, $filters)->paginate((int) ($filters['per_page'] ?? 25));
    }

    public function findOrFail(string $id): AuditLog
    {
        return AuditLog::query()->with('user')->findOrFail($id);
    }
}
