<?php

namespace App\Features\AuditLogs\Controllers;

use App\Features\AuditLogs\Policies\AuditLogPolicy;
use App\Features\AuditLogs\Requests\IndexRequest;
use App\Features\AuditLogs\Resources\AuditLogResource;
use App\Features\AuditLogs\Services\AuditLogService;
use App\Models\User;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AuditLogController extends BaseController
{
    public function __construct(
        private readonly AuditLogService $service,
        private readonly AuditLogPolicy $policy,
    ) {}

    public function index(IndexRequest $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        abort_unless($this->policy->viewAny($user), 403);

        return $this->paginate(
            AuditLogResource::collection($this->service->paginate($user, $request->validated())),
            'Audit logs retrieved successfully.',
        );
    }

    public function show(Request $request, string $auditLog): JsonResponse
    {
        abort_unless($this->policy->viewAny($request->user()), 403);

        $log = $this->service->findOrFail($auditLog);
        abort_unless($this->policy->view($request->user(), $log), 403);

        return $this->success(AuditLogResource::make($log), 'Audit log retrieved successfully.');
    }
}
