<?php

namespace App\Features\AuditLogs\Requests;

use App\Enums\Role;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class IndexRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasRole(Role::SuperAdmin, Role::CenterOwner) === true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'search' => ['nullable', 'string', 'max:255'],
            'date_from' => ['nullable', 'date'],
            'date_to' => ['nullable', 'date', 'after_or_equal:date_from'],
            'user_id' => ['nullable', 'uuid'],
            'auditable_type' => ['nullable', 'string', 'max:255'],
            'auditable_id' => ['nullable', 'uuid'],
            'action' => ['nullable', 'string', 'max:50'],
            'sort' => ['nullable', Rule::in(['created_at', '-created_at', 'action', '-action'])],
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
        ];
    }
}
