<?php

namespace App\Features\AuditLogs\Queries;

use App\Models\AuditLog;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Carbon;

class AuditLogQuery
{
    /**
     * @param  array<string, mixed>  $filters
     * @return Builder<AuditLog>
     */
    public function build(User $user, array $filters): Builder
    {
        $query = AuditLog::query()->with('user');

        $this->scopeVisibleTo($query, $user);

        $query
            ->when($filters['search'] ?? null, function (Builder $query, string $search): void {
                $query->where(function (Builder $query) use ($search): void {
                    $query->where('action', 'like', "%{$search}%")
                        ->orWhere('auditable_type', 'like', "%{$search}%")
                        ->orWhere('auditable_id', 'like', "%{$search}%")
                        ->orWhere('route', 'like', "%{$search}%")
                        ->orWhereHas('user', function (Builder $query) use ($search): void {
                            $query->where('name', 'like', "%{$search}%")
                                ->orWhere('email', 'like', "%{$search}%");
                        });
                });
            })
            // Half-open range on the bare timestamp: DATE(created_at) selects
            // the same rows but cannot use an index on created_at.
            ->when($filters['date_from'] ?? null, fn (Builder $query, string $date) => $query->where('audit_logs.created_at', '>=', $date))
            ->when($filters['date_to'] ?? null, fn (Builder $query, string $date) => $query->where('audit_logs.created_at', '<', Carbon::parse($date)->addDay()->toDateString()))
            ->when($filters['user_id'] ?? null, fn (Builder $query, string $id) => $query->where('user_id', $id))
            ->when($filters['auditable_type'] ?? null, fn (Builder $query, string $type) => $query->where('auditable_type', $type))
            ->when($filters['auditable_id'] ?? null, fn (Builder $query, string $id) => $query->where('auditable_id', $id))
            ->when($filters['action'] ?? null, fn (Builder $query, string $action) => $query->where('action', $action));

        $sort = (string) ($filters['sort'] ?? '-created_at');
        $direction = str_starts_with($sort, '-') ? 'desc' : 'asc';

        return $query->orderBy(ltrim($sort, '-'), $direction);
    }

    /** @param Builder<AuditLog> $query */
    public function scopeVisibleTo(Builder $query, User $user): void
    {
        if ($user->isSuperAdmin()) {
            return;
        }

        $query->where('user_id', $user->id);
    }
}
