<?php

namespace App\Features\AuditLogs\Resources;

use App\Models\AuditLog;
use App\Support\Http\Resources\BaseResource;
use App\Support\Services\AuditSanitizer;
use Illuminate\Http\Request;

/** @mixin AuditLog */
class AuditLogResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        $sanitizer = app(AuditSanitizer::class);

        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'actor' => $this->whenLoaded('user', fn () => $this->user === null ? null : [
                'id' => $this->user->id,
                'name' => $this->user->name,
                'email' => $this->user->email,
            ]),
            'action' => $this->action,
            'auditable_type' => $this->auditable_type,
            'auditable_id' => $this->auditable_id,
            'old_values' => $sanitizer->sanitize($this->old_values),
            'new_values' => $sanitizer->sanitize($this->new_values),
            'ip_address' => $this->ip_address,
            'user_agent' => $this->user_agent,
            'route' => $this->route,
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
