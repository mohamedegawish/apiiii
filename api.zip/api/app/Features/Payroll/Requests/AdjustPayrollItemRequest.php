<?php

namespace App\Features\Payroll\Requests;

use App\Features\Payroll\Policies\PayrollPolicy;
use App\Support\Http\Requests\BaseRequest;

/**
 * The only two components PayrollCalculator cannot derive automatically —
 * see its class docblock for why.
 */
class AdjustPayrollItemRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return app(PayrollPolicy::class)->manage($this->user());
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'deduction_amount' => ['sometimes', 'numeric', 'min:0'],
            'overtime_amount' => ['sometimes', 'numeric', 'min:0'],
            'notes' => ['sometimes', 'nullable', 'string', 'max:2000'],
        ];
    }
}
