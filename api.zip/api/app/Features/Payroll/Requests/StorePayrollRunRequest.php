<?php

namespace App\Features\Payroll\Requests;

use App\Features\Payroll\Policies\PayrollPolicy;
use App\Support\Http\Requests\BaseRequest;

class StorePayrollRunRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return app(PayrollPolicy::class)->manage($this->user());
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'period_start' => ['required', 'date'],
            'period_end' => ['required', 'date', 'after_or_equal:period_start'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
