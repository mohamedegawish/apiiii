<?php

namespace App\Features\Payroll\Resources;

use App\Models\PayrollRun;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/** @mixin PayrollRun */
class PayrollRunResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'period_start' => $this->period_start?->toDateString(),
            'period_end' => $this->period_end?->toDateString(),
            'status' => $this->status,
            'generated_at' => $this->generated_at?->toIso8601String(),
            'approved_at' => $this->approved_at?->toIso8601String(),
            'notes' => $this->notes,
            'teachers_count' => $this->whenCounted('items'),
            'total_payout' => $this->whenLoaded('items', fn () => (float) $this->items->sum('total_amount')),
            'items' => PayrollItemResource::collection($this->whenLoaded('items')),
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
