<?php

namespace App\Features\Payroll\Resources;

use App\Models\PayrollItem;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/** @mixin PayrollItem */
class PayrollItemResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'payroll_run_id' => $this->payroll_run_id,
            'teacher_id' => $this->teacher_id,
            'teacher_name' => $this->whenLoaded('teacher', fn () => $this->teacher?->user?->name),
            'salary_type' => $this->salary_type,
            'sessions_count' => $this->sessions_count,
            'completed_sessions_count' => $this->completed_sessions_count,
            'session_completion_percent' => $this->sessions_count > 0
                ? round($this->completed_sessions_count / $this->sessions_count * 100, 2)
                : 0.0,
            'students_count' => $this->students_count,
            'attendance_rate' => $this->attendance_rate,
            'evaluation_completion_rate' => $this->evaluation_completion_rate,
            'homework_reviews_count' => $this->homework_reviews_count,
            'base_amount' => $this->base_amount,
            'bonus_amount' => $this->bonus_amount,
            'deduction_amount' => $this->deduction_amount,
            'penalty_amount' => $this->penalty_amount,
            'overtime_amount' => $this->overtime_amount,
            'total_amount' => $this->total_amount,
            'status' => $this->status,
            'notes' => $this->notes,
            'expense_id' => $this->expense_id,
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
