<?php

namespace App\Features\Payroll\Queries;

use App\Models\PayrollRun;
use App\Support\Queries\BaseQuery;
use Spatie\QueryBuilder\AllowedFilter;

class PayrollRunQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(PayrollRun::class);
    }

    protected string $defaultSort = '-period_start';

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::exact('status'),
        ];
    }

    protected function allowedSorts(): array
    {
        return ['period_start', 'period_end', 'created_at'];
    }

    protected function allowedIncludes(): array
    {
        return ['items', 'items.teacher', 'items.teacher.user'];
    }
}
