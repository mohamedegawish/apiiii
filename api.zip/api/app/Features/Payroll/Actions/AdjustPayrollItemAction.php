<?php

namespace App\Features\Payroll\Actions;

use App\Features\Payroll\Requests\AdjustPayrollItemRequest;
use App\Models\PayrollItem;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;

class AdjustPayrollItemAction extends BaseAction
{
    public function execute(mixed ...$arguments): mixed
    {
        $item = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $item instanceof PayrollItem || ! $request instanceof AdjustPayrollItemRequest) {
            throw new \InvalidArgumentException('AdjustPayrollItemAction expects a PayrollItem and AdjustPayrollItemRequest.');
        }

        if ($item->status !== 'pending') {
            throw new ConflictException('Only a pending payroll item can be adjusted.');
        }

        $data = $request->validatedData();
        $deduction = (float) ($data['deduction_amount'] ?? $item->deduction_amount);
        $overtime = (float) ($data['overtime_amount'] ?? $item->overtime_amount);

        $totalAmount = max(0.0, round(
            (float) $item->base_amount + (float) $item->bonus_amount + $overtime - $deduction - (float) $item->penalty_amount,
            2
        ));

        $item->update([
            ...$data,
            'total_amount' => $totalAmount,
        ]);

        return $item->fresh(['teacher.user']);
    }
}
