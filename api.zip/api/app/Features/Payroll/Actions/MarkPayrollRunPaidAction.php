<?php

namespace App\Features\Payroll\Actions;

use App\Features\Finance\Actions\ApproveExpenseAction;
use App\Features\Finance\Actions\MarkExpensePaidAction;
use App\Models\Expense;
use App\Models\ExpenseCategory;
use App\Models\PayrollItem;
use App\Models\PayrollRun;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;

/**
 * Settling payroll routes every teacher's pay through the exact same
 * Expense -> Transaction pipeline as any other expense (see
 * MarkExpensePaidAction) — so payroll payouts automatically show up in
 * Accounts Payable, Cash Flow, and P&L without any separate bookkeeping.
 */
class MarkPayrollRunPaidAction extends BaseAction
{
    public function __construct(
        protected ApproveExpenseAction $approveExpenseAction,
        protected MarkExpensePaidAction $markExpensePaidAction,
    ) {}

    public function execute(mixed ...$arguments): mixed
    {
        $run = $arguments[0] ?? null;

        if (! $run instanceof PayrollRun) {
            throw new \InvalidArgumentException('MarkPayrollRunPaidAction expects a PayrollRun.');
        }

        if ($run->status !== 'approved') {
            throw new ConflictException('Only an approved payroll run can be marked as paid.');
        }

        $expenseCategoryId = ExpenseCategory::where('code', 'teacher_salaries')->value('id');
        $paidAt = $run->period_end->toDateString();

        $run->items()->with('teacher.user')->get()->each(function (PayrollItem $item) use ($expenseCategoryId, $run, $paidAt): void {
            $teacherName = $item->teacher->user?->name ?? $item->teacher->title ?? 'معلّم';

            $expense = Expense::create([
                'expense_category_id' => $expenseCategoryId,
                'description' => "راتب {$teacherName} - {$run->period_start->format('Y-m')}",
                'payee' => $teacherName,
                'amount' => $item->total_amount,
                'expense_date' => $paidAt,
                'status' => 'pending',
            ]);

            $expense = $this->approveExpenseAction->execute($expense);
            $expense = $this->markExpensePaidAction->execute($expense, $paidAt);

            $item->update(['status' => 'paid', 'expense_id' => $expense->id]);
        });

        $run->update(['status' => 'paid']);

        return $run->fresh(['items.teacher.user']);
    }
}
