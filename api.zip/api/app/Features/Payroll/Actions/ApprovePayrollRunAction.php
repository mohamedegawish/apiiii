<?php

namespace App\Features\Payroll\Actions;

use App\Models\PayrollRun;
use App\Models\User;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;

class ApprovePayrollRunAction extends BaseAction
{
    public function execute(mixed ...$arguments): mixed
    {
        $run = $arguments[0] ?? null;
        $user = $arguments[1] ?? null;

        if (! $run instanceof PayrollRun || ! $user instanceof User) {
            throw new \InvalidArgumentException('ApprovePayrollRunAction expects a PayrollRun and a User.');
        }

        if ($run->status !== 'generated') {
            throw new ConflictException('Only a generated payroll run can be approved.');
        }

        $run->update([
            'status' => 'approved',
            'approved_at' => now(),
            'approved_by' => $user->id,
        ]);
        $run->items()->update(['status' => 'approved']);

        return $run->fresh(['items.teacher.user']);
    }
}
