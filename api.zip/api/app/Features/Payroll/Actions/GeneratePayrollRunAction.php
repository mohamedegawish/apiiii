<?php

namespace App\Features\Payroll\Actions;

use App\Features\Payroll\Requests\StorePayrollRunRequest;
use App\Features\Payroll\Services\PayrollCalculator;
use App\Models\PayrollItem;
use App\Models\PayrollRun;
use App\Models\Teacher;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;
use Illuminate\Support\Carbon;

class GeneratePayrollRunAction extends BaseAction
{
    public function __construct(protected PayrollCalculator $calculator) {}

    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StorePayrollRunRequest) {
            throw new \InvalidArgumentException('GeneratePayrollRunAction expects a StorePayrollRunRequest.');
        }

        $data = $request->validatedData();
        $start = Carbon::parse($data['period_start'])->startOfDay();
        $end = Carbon::parse($data['period_end'])->endOfDay();

        if (PayrollRun::where('period_start', $start->toDateString())->where('period_end', $end->toDateString())->exists()) {
            throw new ConflictException('A payroll run already exists for this exact period.');
        }

        $run = PayrollRun::create([
            'period_start' => $start->toDateString(),
            'period_end' => $end->toDateString(),
            'status' => 'generated',
            'generated_at' => now(),
            'notes' => $data['notes'] ?? null,
        ]);

        Teacher::where('is_active', true)->get()->each(function (Teacher $teacher) use ($run, $start, $end): void {
            $metrics = $this->calculator->calculate($teacher, $start, $end);

            PayrollItem::create([
                'payroll_run_id' => $run->id,
                'teacher_id' => $teacher->id,
                'status' => 'pending',
                ...$metrics,
            ]);
        });

        return $run->load('items.teacher.user');
    }
}
