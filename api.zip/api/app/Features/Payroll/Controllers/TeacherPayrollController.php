<?php

namespace App\Features\Payroll\Controllers;

use App\Features\Payroll\Resources\PayrollItemResource;
use App\Features\Payroll\Services\PayrollService;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TeacherPayrollController extends BaseController
{
    public function __construct(protected PayrollService $payrollService) {}

    public function mine(Request $request): JsonResponse
    {
        $teacher = $this->payrollService->teacherForUser($request->user());
        $payroll = $this->payrollService->myPayroll($teacher);

        return $this->success([
            'current' => $payroll['current'] !== null ? PayrollItemResource::make($payroll['current']) : null,
            'summary' => $payroll['summary'],
            'history' => PayrollItemResource::collection($payroll['history']),
        ], 'Payroll summary retrieved successfully.');
    }
}
