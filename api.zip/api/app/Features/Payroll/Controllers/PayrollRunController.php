<?php

namespace App\Features\Payroll\Controllers;

use App\Features\Payroll\Policies\PayrollPolicy;
use App\Features\Payroll\Requests\AdjustPayrollItemRequest;
use App\Features\Payroll\Requests\StorePayrollRunRequest;
use App\Features\Payroll\Resources\PayrollItemResource;
use App\Features\Payroll\Resources\PayrollRunResource;
use App\Features\Payroll\Services\PayrollService;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PayrollRunController extends BaseController
{
    public function __construct(
        protected PayrollService $payrollService,
        protected PayrollPolicy $policy,
    ) {}

    public function index(Request $request): JsonResponse
    {
        if (! $this->policy->viewAny($request->user())) {
            throw new AuthorizationException;
        }

        return $this->paginate(
            PayrollRunResource::collection($this->payrollService->paginate()),
            'Payroll runs retrieved successfully.',
        );
    }

    public function show(Request $request, string $payrollRun): JsonResponse
    {
        if (! $this->policy->viewAny($request->user())) {
            throw new AuthorizationException;
        }

        return $this->success(
            PayrollRunResource::make($this->payrollService->findOrFail($payrollRun)),
            'Payroll run retrieved successfully.',
        );
    }

    public function store(StorePayrollRunRequest $request): JsonResponse
    {
        return $this->created(
            PayrollRunResource::make($this->payrollService->generate($request)),
            'Payroll run generated successfully.',
        );
    }

    public function approve(Request $request, string $payrollRun): JsonResponse
    {
        if (! $this->policy->manage($request->user())) {
            throw new AuthorizationException;
        }

        $run = $this->payrollService->findOrFail($payrollRun);

        return $this->success(
            PayrollRunResource::make($this->payrollService->approve($run, $request->user())),
            'Payroll run approved successfully.',
        );
    }

    public function markPaid(Request $request, string $payrollRun): JsonResponse
    {
        if (! $this->policy->manage($request->user())) {
            throw new AuthorizationException;
        }

        $run = $this->payrollService->findOrFail($payrollRun);

        return $this->success(
            PayrollRunResource::make($this->payrollService->markPaid($run)),
            'Payroll run marked as paid successfully.',
        );
    }

    public function adjustItem(AdjustPayrollItemRequest $request, string $payrollItem): JsonResponse
    {
        $item = $this->payrollService->findItemOrFail($payrollItem);

        return $this->success(
            PayrollItemResource::make($this->payrollService->adjustItem($item, $request)),
            'Payroll item adjusted successfully.',
        );
    }
}
