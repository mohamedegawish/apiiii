<?php

namespace App\Features\Payroll\Policies;

use App\Enums\Role;
use App\Models\PayrollItem;
use App\Models\User;
use App\Support\Policies\BasePolicy;

/**
 * Generating/approving/paying payroll is center_owner+ only. A teacher may
 * only ever read their own {@see PayrollItem} rows — never anyone else's
 * pay, and never the write actions.
 */
class PayrollPolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }

    public function manage(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }

    public function viewOwn(?User $user, PayrollItem $item): bool
    {
        if ($this->isAtLeast($user, Role::CenterOwner)) {
            return true;
        }

        return $user !== null && $item->teacher->user_id === $user->id;
    }
}
