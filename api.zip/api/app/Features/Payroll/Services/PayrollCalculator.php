<?php

namespace App\Features\Payroll\Services;

use App\Enums\CircleSessionStatus;
use App\Enums\HomeworkStatus;
use App\Enums\SalaryType;
use App\Features\CircleSessions\Queries\CircleSessionCompletionQuery;
use App\Features\Payroll\Actions\AdjustPayrollItemAction;
use App\Models\Attendance;
use App\Models\CircleSession;
use App\Models\Homework;
use App\Models\Teacher;
use App\Support\Queries\DateColumn;
use Illuminate\Support\Carbon;

/**
 * Computes one teacher's pay for a period from real session/attendance/
 * evaluation/homework data — nothing here is a placeholder or fabricated
 * number. Two components are deliberately left at 0 and reserved for manual
 * admin adjustment via {@see AdjustPayrollItemAction}:
 * `deduction_amount` (e.g. unpaid leave — no such concept exists elsewhere
 * in the schema to derive it from) and `overtime_amount` (the schema has no
 * concept of a contracted-hours baseline to compare actual hours against).
 */
class PayrollCalculator
{
    public function __construct(protected CircleSessionCompletionQuery $completionQuery) {}

    /** @return array<string, mixed> */
    public function calculate(Teacher $teacher, Carbon $start, Carbon $end): array
    {
        $sessions = CircleSession::where('teacher_id', $teacher->id)
            ->where('session_date', '>=', $start->toDateString())
            ->where('session_date', '<', DateColumn::dayAfter($end))
            ->with('circle')
            ->get();

        $sessionsCount = $sessions->count();
        $completedSessions = $sessions->where('status', CircleSessionStatus::Completed);
        $completedSessionsCount = $completedSessions->count();

        $attendanceRows = Attendance::where('teacher_id', $teacher->id)
            ->where('attendance_date', '>=', $start->toDateString())
            ->where('attendance_date', '<', DateColumn::dayAfter($end))
            ->get();
        $attendanceTotal = $attendanceRows->count();
        $presentCount = $attendanceRows->filter(fn (Attendance $attendance): bool => $attendance->status->wasPresent())->count();
        $attendanceRate = $attendanceTotal > 0 ? round($presentCount / $attendanceTotal * 100, 2) : 0.0;
        $studentsCount = $attendanceRows->pluck('student_id')->unique()->count();

        // Batched: a payroll run walks every teacher's whole period, and one
        // completion check per session made that grow with the session count.
        $completion = $this->completionQuery->checkMany($completedSessions->values());
        $evaluationCompleteCount = $completedSessions->filter(
            fn (CircleSession $session): bool => $completion[$session->id]['evaluation_complete'] ?? false
        )->count();
        $evaluationCompletionRate = $completedSessionsCount > 0
            ? round($evaluationCompleteCount / $completedSessionsCount * 100, 2)
            : 0.0;

        $homeworkReviewsCount = Homework::where('teacher_id', $teacher->id)
            ->where('status', HomeworkStatus::Graded->value)
            ->whereBetween('updated_at', [$start, $end])
            ->count();

        $hoursWorked = $completedSessions->sum(function (CircleSession $session): float {
            if (! $session->start_time || ! $session->end_time) {
                return 0.0;
            }

            return Carbon::parse($session->start_time)->diffInMinutes(Carbon::parse($session->end_time)) / 60;
        });

        $baseAmount = match ($teacher->salary_type) {
            SalaryType::Fixed => (float) $teacher->salary_amount,
            SalaryType::PerSession => $completedSessionsCount * (float) $teacher->per_session_rate,
            SalaryType::PerStudent => $studentsCount * (float) $teacher->per_student_rate,
            SalaryType::Hourly => round($hoursWorked, 2) * (float) $teacher->hourly_rate,
        };

        // Performance bonus for teachers with strong attendance and evaluation completion.
        $bonusAmount = ($attendanceRate >= 90.0 && $evaluationCompletionRate >= 90.0)
            ? round($baseAmount * 0.05, 2)
            : 0.0;

        // Automatic penalty proportional to the evaluation-completion gap.
        $penaltyAmount = round($baseAmount * (1 - $evaluationCompletionRate / 100) * 0.1, 2);

        $deductionAmount = 0.0;
        $overtimeAmount = 0.0;

        $totalAmount = max(0.0, round($baseAmount + $bonusAmount + $overtimeAmount - $deductionAmount - $penaltyAmount, 2));

        return [
            'salary_type' => $teacher->salary_type->value,
            'sessions_count' => $sessionsCount,
            'completed_sessions_count' => $completedSessionsCount,
            'students_count' => $studentsCount,
            'attendance_rate' => $attendanceRate,
            'evaluation_completion_rate' => $evaluationCompletionRate,
            'homework_reviews_count' => $homeworkReviewsCount,
            'base_amount' => round($baseAmount, 2),
            'bonus_amount' => $bonusAmount,
            'deduction_amount' => $deductionAmount,
            'penalty_amount' => max($penaltyAmount, 0.0),
            'overtime_amount' => $overtimeAmount,
            'total_amount' => $totalAmount,
        ];
    }
}
