<?php

namespace App\Features\Payroll\Services;

use App\Features\Payroll\Actions\AdjustPayrollItemAction;
use App\Features\Payroll\Actions\ApprovePayrollRunAction;
use App\Features\Payroll\Actions\GeneratePayrollRunAction;
use App\Features\Payroll\Actions\MarkPayrollRunPaidAction;
use App\Features\Payroll\Queries\PayrollRunQuery;
use App\Features\Payroll\Requests\AdjustPayrollItemRequest;
use App\Features\Payroll\Requests\StorePayrollRunRequest;
use App\Models\PayrollItem;
use App\Models\PayrollRun;
use App\Models\Teacher;
use App\Models\User;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class PayrollService extends BaseService
{
    public function __construct(
        protected GeneratePayrollRunAction $generatePayrollRunAction,
        protected ApprovePayrollRunAction $approvePayrollRunAction,
        protected MarkPayrollRunPaidAction $markPayrollRunPaidAction,
        protected AdjustPayrollItemAction $adjustPayrollItemAction,
        protected PayrollRunQuery $payrollRunQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->payrollRunQuery->paginate();
    }

    public function findOrFail(string $id): PayrollRun
    {
        $run = PayrollRun::withCount('items')->with(['items.teacher.user'])->find($id);

        if ($run === null) {
            throw new NotFoundException('Payroll run not found.');
        }

        return $run;
    }

    public function findItemOrFail(string $id): PayrollItem
    {
        $item = PayrollItem::with(['teacher.user', 'payrollRun'])->find($id);

        if ($item === null) {
            throw new NotFoundException('Payroll item not found.');
        }

        return $item;
    }

    public function generate(StorePayrollRunRequest $request): PayrollRun
    {
        return $this->transaction(fn (): PayrollRun => $this->generatePayrollRunAction->execute($request));
    }

    public function approve(PayrollRun $run, User $user): PayrollRun
    {
        return $this->transaction(fn (): PayrollRun => $this->approvePayrollRunAction->execute($run, $user));
    }

    public function markPaid(PayrollRun $run): PayrollRun
    {
        return $this->transaction(fn (): PayrollRun => $this->markPayrollRunPaidAction->execute($run));
    }

    public function adjustItem(PayrollItem $item, AdjustPayrollItemRequest $request): PayrollItem
    {
        return $this->transaction(fn (): PayrollItem => $this->adjustPayrollItemAction->execute($item, $request));
    }

    public function teacherForUser(User $user): Teacher
    {
        $teacher = Teacher::where('user_id', $user->id)->first();

        if ($teacher === null) {
            throw new NotFoundException('No teacher profile is linked to this account.');
        }

        return $teacher;
    }

    /** @return array<string, mixed> */
    public function myPayroll(Teacher $teacher): array
    {
        $forTeacher = fn () => PayrollItem::query()->where('teacher_id', $teacher->id);

        $current = $forTeacher()->where('status', 'pending')->with('payrollRun')->latest('created_at')->first()
            ?? $forTeacher()->where('status', 'approved')->with('payrollRun')->latest('created_at')->first();

        $paid = $forTeacher()->where('status', 'paid');
        $firstPaid = (clone $paid)->with('payrollRun')->latest('created_at')->first();
        $lifetimePaidTotal = round((float) (clone $paid)->sum('total_amount'), 2);
        $runsPaidCount = (clone $paid)->count();

        // History is bounded to the last 12 runs; totals are SQL aggregates so
        // the payload and memory stay flat no matter how many years of runs a
        // teacher has on record.
        $history = $forTeacher()->with('payrollRun')->latest('created_at')->limit(12)->get();

        return [
            'current' => $current,
            'summary' => [
                'pending_amount' => (float) ($current?->total_amount ?? 0),
                'last_paid_amount' => (float) ($firstPaid?->total_amount ?? 0),
                'lifetime_paid_total' => $lifetimePaidTotal,
                'runs_paid_count' => $runsPaidCount,
            ],
            'history' => $history->values(),
        ];
    }
}
