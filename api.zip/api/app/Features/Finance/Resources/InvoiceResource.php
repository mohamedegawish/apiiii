<?php

namespace App\Features\Finance\Resources;

use App\Models\Invoice;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/** @mixin Invoice */
class InvoiceResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'invoice_number' => $this->invoice_number,
            'student_id' => $this->student_id,
            'student_name' => $this->whenLoaded('student', fn () => $this->student?->name),
            'revenue_category_id' => $this->revenue_category_id,
            'revenue_category_name' => $this->whenLoaded('revenueCategory', fn () => $this->revenueCategory?->name),
            'issue_date' => $this->issue_date?->toDateString(),
            'due_date' => $this->due_date?->toDateString(),
            'subtotal' => $this->subtotal,
            'tax_amount' => $this->tax_amount,
            'total' => $this->total,
            'amount_paid' => $this->amount_paid,
            'balance_due' => $this->balanceDue(),
            'status' => $this->status,
            'notes' => $this->notes,
            'items' => InvoiceItemResource::collection($this->whenLoaded('items')),
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
