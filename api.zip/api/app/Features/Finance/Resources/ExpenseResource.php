<?php

namespace App\Features\Finance\Resources;

use App\Models\Expense;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/** @mixin Expense */
class ExpenseResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'expense_category_id' => $this->expense_category_id,
            'expense_category_name' => $this->whenLoaded('expenseCategory', fn () => $this->expenseCategory?->name),
            'teacher_id' => $this->teacher_id,
            'teacher_name' => $this->whenLoaded('teacher', fn () => $this->teacher?->user?->name),
            'financial_account_id' => $this->financial_account_id,
            'financial_account_name' => $this->whenLoaded('financialAccount', fn () => $this->financialAccount?->name),
            'description' => $this->description,
            'payee' => $this->payee,
            'amount' => $this->amount,
            'expense_date' => $this->expense_date?->toDateString(),
            'period_month' => $this->period_month?->toDateString(),
            'status' => $this->status,
            'paid_at' => $this->paid_at?->toDateString(),
            'notes' => $this->notes,
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
