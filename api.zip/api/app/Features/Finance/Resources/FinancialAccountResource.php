<?php

namespace App\Features\Finance\Resources;

use App\Models\FinancialAccount;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/** @mixin FinancialAccount */
class FinancialAccountResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'code' => $this->code,
            'type' => $this->type,
            'opening_balance' => $this->opening_balance,
            'is_active' => $this->is_active,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
