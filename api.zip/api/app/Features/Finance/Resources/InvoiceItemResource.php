<?php

namespace App\Features\Finance\Resources;

use App\Models\InvoiceItem;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/** @mixin InvoiceItem */
class InvoiceItemResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'description' => $this->description,
            'quantity' => $this->quantity,
            'unit_price' => $this->unit_price,
            'amount' => $this->amount,
        ];
    }
}
