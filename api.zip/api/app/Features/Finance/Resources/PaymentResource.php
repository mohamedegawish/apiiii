<?php

namespace App\Features\Finance\Resources;

use App\Models\Payment;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/** @mixin Payment */
class PaymentResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'invoice_id' => $this->invoice_id,
            'student_id' => $this->student_id,
            'student_name' => $this->whenLoaded('student', fn () => $this->student?->name),
            'revenue_category_id' => $this->revenue_category_id,
            'revenue_category_name' => $this->whenLoaded('revenueCategory', fn () => $this->revenueCategory?->name),
            'payer_name' => $this->payer_name,
            'method' => $this->method,
            'amount' => $this->amount,
            'paid_at' => $this->paid_at?->toDateString(),
            'period_month' => $this->period_month?->toDateString(),
            'reference_number' => $this->reference_number,
            'notes' => $this->notes,
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
