<?php

namespace App\Features\Finance\Resources;

use App\Models\RevenueCategory;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/** @mixin RevenueCategory */
class RevenueCategoryResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'code' => $this->code,
            'is_active' => $this->is_active,
        ];
    }
}
