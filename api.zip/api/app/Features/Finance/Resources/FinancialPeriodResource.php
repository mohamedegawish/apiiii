<?php

namespace App\Features\Finance\Resources;

use App\Models\FinancialPeriod;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/** @mixin FinancialPeriod */
class FinancialPeriodResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'start_date' => $this->start_date?->toDateString(),
            'end_date' => $this->end_date?->toDateString(),
            'status' => $this->status,
            'closed_at' => $this->closed_at?->toIso8601String(),
        ];
    }
}
