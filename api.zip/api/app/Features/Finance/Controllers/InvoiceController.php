<?php

namespace App\Features\Finance\Controllers;

use App\Features\Finance\Policies\FinancePolicy;
use App\Features\Finance\Requests\StoreInvoiceRequest;
use App\Features\Finance\Requests\UpdateInvoiceRequest;
use App\Features\Finance\Resources\InvoiceResource;
use App\Features\Finance\Services\InvoiceService;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class InvoiceController extends BaseController
{
    public function __construct(
        protected InvoiceService $invoiceService,
        protected FinancePolicy $policy,
    ) {}

    public function index(Request $request): JsonResponse
    {
        if (! $this->policy->viewAny($request->user())) {
            throw new AuthorizationException;
        }

        return $this->paginate(
            InvoiceResource::collection($this->invoiceService->paginate()),
            'Invoices retrieved successfully.',
        );
    }

    public function show(Request $request, string $invoice): JsonResponse
    {
        if (! $this->policy->viewAny($request->user())) {
            throw new AuthorizationException;
        }

        return $this->success(
            InvoiceResource::make($this->invoiceService->findOrFail($invoice)),
            'Invoice retrieved successfully.',
        );
    }

    public function store(StoreInvoiceRequest $request): JsonResponse
    {
        return $this->created(
            InvoiceResource::make($this->invoiceService->create($request)),
            'Invoice created successfully.',
        );
    }

    public function update(UpdateInvoiceRequest $request, string $invoice): JsonResponse
    {
        $model = $this->invoiceService->findOrFail($invoice);

        return $this->success(
            InvoiceResource::make($this->invoiceService->update($model, $request)),
            'Invoice updated successfully.',
        );
    }
}
