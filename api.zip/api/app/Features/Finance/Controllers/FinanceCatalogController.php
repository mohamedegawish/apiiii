<?php

namespace App\Features\Finance\Controllers;

use App\Features\Finance\Policies\FinancePolicy;
use App\Features\Finance\Requests\StoreExpenseCategoryRequest;
use App\Features\Finance\Requests\StoreFinancialAccountRequest;
use App\Features\Finance\Requests\StoreFinancialPeriodRequest;
use App\Features\Finance\Requests\StoreRevenueCategoryRequest;
use App\Features\Finance\Requests\UpdateExpenseCategoryRequest;
use App\Features\Finance\Requests\UpdateFinancialAccountRequest;
use App\Features\Finance\Requests\UpdateRevenueCategoryRequest;
use App\Features\Finance\Resources\ExpenseCategoryResource;
use App\Features\Finance\Resources\FinancialAccountResource;
use App\Features\Finance\Resources\FinancialPeriodResource;
use App\Features\Finance\Resources\RevenueCategoryResource;
use App\Features\Finance\Services\FinanceCatalogService;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class FinanceCatalogController extends BaseController
{
    public function __construct(
        protected FinanceCatalogService $service,
        protected FinancePolicy $policy,
    ) {}

    private function ensureCanView(Request $request): void
    {
        if (! $this->policy->viewAny($request->user())) {
            throw new AuthorizationException;
        }
    }

    // ------------------------------------------------------------ Accounts
    public function indexAccounts(Request $request): JsonResponse
    {
        $this->ensureCanView($request);

        return $this->paginate(
            FinancialAccountResource::collection($this->service->paginateAccounts()),
            'Financial accounts retrieved successfully.',
        );
    }

    public function storeAccount(StoreFinancialAccountRequest $request): JsonResponse
    {
        return $this->created(
            FinancialAccountResource::make($this->service->createAccount($request->validatedData())),
            'Financial account created successfully.',
        );
    }

    public function updateAccount(UpdateFinancialAccountRequest $request, string $financialAccount): JsonResponse
    {
        $account = $this->service->findAccount($financialAccount);

        return $this->success(
            FinancialAccountResource::make($this->service->updateAccount($account, $request->validatedData())),
            'Financial account updated successfully.',
        );
    }

    public function destroyAccount(Request $request, string $financialAccount): JsonResponse
    {
        if (! $this->policy->manage($request->user())) {
            throw new AuthorizationException;
        }
        $this->service->deleteAccount($this->service->findAccount($financialAccount));

        return $this->success(null, 'Financial account deleted successfully.');
    }

    // --------------------------------------------------- Revenue categories
    public function indexRevenueCategories(Request $request): JsonResponse
    {
        $this->ensureCanView($request);

        return $this->paginate(
            RevenueCategoryResource::collection($this->service->paginateRevenueCategories()),
            'Revenue categories retrieved successfully.',
        );
    }

    public function storeRevenueCategory(StoreRevenueCategoryRequest $request): JsonResponse
    {
        return $this->created(
            RevenueCategoryResource::make($this->service->createRevenueCategory($request->validatedData())),
            'Revenue category created successfully.',
        );
    }

    public function updateRevenueCategory(UpdateRevenueCategoryRequest $request, string $revenueCategory): JsonResponse
    {
        $category = $this->service->findRevenueCategory($revenueCategory);

        return $this->success(
            RevenueCategoryResource::make($this->service->updateRevenueCategory($category, $request->validatedData())),
            'Revenue category updated successfully.',
        );
    }

    public function destroyRevenueCategory(Request $request, string $revenueCategory): JsonResponse
    {
        if (! $this->policy->manage($request->user())) {
            throw new AuthorizationException;
        }
        $this->service->deleteRevenueCategory($this->service->findRevenueCategory($revenueCategory));

        return $this->success(null, 'Revenue category deleted successfully.');
    }

    // --------------------------------------------------- Expense categories
    public function indexExpenseCategories(Request $request): JsonResponse
    {
        $this->ensureCanView($request);

        return $this->paginate(
            ExpenseCategoryResource::collection($this->service->paginateExpenseCategories()),
            'Expense categories retrieved successfully.',
        );
    }

    public function storeExpenseCategory(StoreExpenseCategoryRequest $request): JsonResponse
    {
        return $this->created(
            ExpenseCategoryResource::make($this->service->createExpenseCategory($request->validatedData())),
            'Expense category created successfully.',
        );
    }

    public function updateExpenseCategory(UpdateExpenseCategoryRequest $request, string $expenseCategory): JsonResponse
    {
        $category = $this->service->findExpenseCategory($expenseCategory);

        return $this->success(
            ExpenseCategoryResource::make($this->service->updateExpenseCategory($category, $request->validatedData())),
            'Expense category updated successfully.',
        );
    }

    public function destroyExpenseCategory(Request $request, string $expenseCategory): JsonResponse
    {
        if (! $this->policy->manage($request->user())) {
            throw new AuthorizationException;
        }
        $this->service->deleteExpenseCategory($this->service->findExpenseCategory($expenseCategory));

        return $this->success(null, 'Expense category deleted successfully.');
    }

    // ------------------------------------------------------------- Periods
    public function indexPeriods(Request $request): JsonResponse
    {
        $this->ensureCanView($request);

        return $this->paginate(
            FinancialPeriodResource::collection($this->service->paginatePeriods()),
            'Financial periods retrieved successfully.',
        );
    }

    public function storePeriod(StoreFinancialPeriodRequest $request): JsonResponse
    {
        return $this->created(
            FinancialPeriodResource::make($this->service->createPeriod($request->validatedData())),
            'Financial period created successfully.',
        );
    }

    public function closePeriod(Request $request, string $financialPeriod): JsonResponse
    {
        if (! $this->policy->manage($request->user())) {
            throw new AuthorizationException;
        }

        return $this->success(
            FinancialPeriodResource::make($this->service->closePeriod($this->service->findPeriod($financialPeriod))),
            'Financial period closed successfully.',
        );
    }
}
