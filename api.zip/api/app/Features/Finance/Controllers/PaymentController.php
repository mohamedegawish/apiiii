<?php

namespace App\Features\Finance\Controllers;

use App\Features\Finance\Policies\FinancePolicy;
use App\Features\Finance\Requests\StorePaymentRequest;
use App\Features\Finance\Resources\PaymentResource;
use App\Features\Finance\Services\PaymentService;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PaymentController extends BaseController
{
    public function __construct(
        protected PaymentService $paymentService,
        protected FinancePolicy $policy,
    ) {}

    public function index(Request $request): JsonResponse
    {
        if (! $this->policy->viewAny($request->user())) {
            throw new AuthorizationException;
        }

        return $this->paginate(
            PaymentResource::collection($this->paymentService->paginate()),
            'Payments retrieved successfully.',
        );
    }

    public function show(Request $request, string $payment): JsonResponse
    {
        if (! $this->policy->viewAny($request->user())) {
            throw new AuthorizationException;
        }

        return $this->success(
            PaymentResource::make($this->paymentService->findOrFail($payment)),
            'Payment retrieved successfully.',
        );
    }

    public function store(StorePaymentRequest $request): JsonResponse
    {
        return $this->created(
            PaymentResource::make($this->paymentService->record($request)),
            'Payment recorded successfully.',
        );
    }
}
