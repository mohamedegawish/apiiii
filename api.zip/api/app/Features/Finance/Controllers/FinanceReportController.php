<?php

namespace App\Features\Finance\Controllers;

use App\Features\Finance\Requests\FinanceReportRequest;
use App\Features\Finance\Services\FinanceReportService;
use App\Support\Http\Controllers\BaseController;
use App\Support\Http\Controllers\Concerns\RespondsWithReport;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\StreamedResponse;

class FinanceReportController extends BaseController
{
    use RespondsWithReport;

    public function __construct(protected FinanceReportService $reportService) {}

    public function accountsReceivable(FinanceReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'accounts-receivable', fn (array $filters) => $this->reportService->accountsReceivable($filters));
    }

    public function accountsPayable(FinanceReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'accounts-payable', fn (array $filters) => $this->reportService->accountsPayable($filters));
    }

    public function cashFlow(FinanceReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'cash-flow', fn (array $filters) => $this->reportService->cashFlow($filters));
    }

    public function profitAndLoss(FinanceReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'profit-and-loss', fn (array $filters) => $this->reportService->profitAndLoss($filters));
    }

    public function revenue(FinanceReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'revenue', fn (array $filters) => $this->reportService->revenueReport($filters));
    }

    public function expenses(FinanceReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'expenses', fn (array $filters) => $this->reportService->expenseReport($filters));
    }

    public function monthlySummary(FinanceReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'monthly-summary', fn (array $filters) => $this->reportService->monthlySummary($filters));
    }

    public function yearlySummary(FinanceReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'yearly-summary', fn (array $filters) => $this->reportService->yearlySummary($filters));
    }
}
