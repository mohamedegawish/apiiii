<?php

namespace App\Features\Finance\Controllers;

use App\Features\Finance\Policies\FinancePolicy;
use App\Features\Finance\Requests\StoreExpenseRequest;
use App\Features\Finance\Requests\UpdateExpenseRequest;
use App\Features\Finance\Resources\ExpenseResource;
use App\Features\Finance\Services\ExpenseService;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ExpenseController extends BaseController
{
    public function __construct(
        protected ExpenseService $expenseService,
        protected FinancePolicy $policy,
    ) {}

    public function index(Request $request): JsonResponse
    {
        if (! $this->policy->viewAny($request->user())) {
            throw new AuthorizationException;
        }

        return $this->paginate(
            ExpenseResource::collection($this->expenseService->paginate()),
            'Expenses retrieved successfully.',
        );
    }

    public function show(Request $request, string $expense): JsonResponse
    {
        if (! $this->policy->viewAny($request->user())) {
            throw new AuthorizationException;
        }

        return $this->success(
            ExpenseResource::make($this->expenseService->findOrFail($expense)),
            'Expense retrieved successfully.',
        );
    }

    public function store(StoreExpenseRequest $request): JsonResponse
    {
        return $this->created(
            ExpenseResource::make($this->expenseService->create($request)),
            'Expense created successfully.',
        );
    }

    public function update(UpdateExpenseRequest $request, string $expense): JsonResponse
    {
        $model = $this->expenseService->findOrFail($expense);

        return $this->success(
            ExpenseResource::make($this->expenseService->update($model, $request)),
            'Expense updated successfully.',
        );
    }

    public function approve(Request $request, string $expense): JsonResponse
    {
        if (! $this->policy->manage($request->user())) {
            throw new AuthorizationException;
        }

        $model = $this->expenseService->findOrFail($expense);

        return $this->success(
            ExpenseResource::make($this->expenseService->approve($model)),
            'Expense approved successfully.',
        );
    }

    public function markPaid(Request $request, string $expense): JsonResponse
    {
        if (! $this->policy->manage($request->user())) {
            throw new AuthorizationException;
        }

        $model = $this->expenseService->findOrFail($expense);
        $paidAt = $request->query('paid_at');

        return $this->success(
            ExpenseResource::make($this->expenseService->markPaid($model, is_string($paidAt) ? $paidAt : null)),
            'Expense marked as paid successfully.',
        );
    }
}
