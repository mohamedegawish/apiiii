<?php

namespace App\Features\Finance\Policies;

use App\Enums\Role;
use App\Models\User;
use App\Support\Policies\BasePolicy;

/**
 * Shared policy for every Finance entity (accounts, categories, periods,
 * invoices, payments, expenses) — financial data is center_owner+ only.
 * Teachers have no visibility into the school's finances at all (their own
 * pay is a separate, teacher-scoped concern — see Payroll\Policies).
 */
class FinancePolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }

    public function manage(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }
}
