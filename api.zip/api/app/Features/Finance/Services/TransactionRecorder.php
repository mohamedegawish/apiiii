<?php

namespace App\Features\Finance\Services;

use App\Models\FinancialPeriod;
use App\Models\Transaction;
use App\Support\Queries\DateColumn;

/**
 * Creates the single immutable ledger entry for a real money movement.
 * Shared by payment recording (income) and expense settlement (expense) —
 * this is the only place either of those two callers construct a
 * Transaction, so Cash Flow / P&L always have exactly one row per real
 * movement regardless of which side triggered it.
 */
class TransactionRecorder
{
    /** @param array<string, mixed> $attributes */
    public function record(array $attributes): Transaction
    {
        $occurredOn = $attributes['occurred_on'];
        $period = FinancialPeriod::query()
            ->where('start_date', '<', DateColumn::dayAfter($occurredOn))
            ->where('end_date', '>=', DateColumn::day($occurredOn))
            ->first();

        return Transaction::create([
            ...$attributes,
            'financial_period_id' => $attributes['financial_period_id'] ?? $period?->id,
        ]);
    }
}
