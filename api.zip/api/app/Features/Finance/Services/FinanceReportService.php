<?php

namespace App\Features\Finance\Services;

use App\Models\Expense;
use App\Models\Invoice;
use App\Models\Transaction;
use App\Support\CenterClock;
use App\Support\Queries\DateColumn;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Pagination\LengthAwarePaginator as ConcreteLengthAwarePaginator;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Every report here reads only from invoices/payments/expenses/transactions
 * — the lightweight ledger described in FINANCE_ARCHITECTURE.md — never
 * from a separate double-entry ledger, since none exists in this system.
 */
class FinanceReportService
{
    /** @param array<string, mixed> $filters */
    public function accountsReceivable(array $filters): LengthAwarePaginator
    {
        $today = CenterClock::today();

        $paginator = Invoice::query()
            ->whereIn('status', ['sent', 'partial', 'overdue'])
            ->with('student')
            ->orderBy('due_date')
            ->paginate($this->perPage($filters));

        return $paginator->through(function (Invoice $invoice) use ($today): array {
            $daysOverdue = $invoice->due_date->lt($today) ? (int) $invoice->due_date->diffInDays($today) : 0;

            return [
                'invoice_id' => $invoice->id,
                'invoice_number' => $invoice->invoice_number,
                'student_id' => $invoice->student_id,
                'student_name' => $invoice->student?->name,
                'issue_date' => $invoice->issue_date?->toDateString(),
                'due_date' => $invoice->due_date?->toDateString(),
                'total' => (float) $invoice->total,
                'amount_paid' => (float) $invoice->amount_paid,
                'balance_due' => $invoice->balanceDue(),
                'days_overdue' => $daysOverdue,
                'aging_bucket' => $this->agingBucket($daysOverdue),
            ];
        });
    }

    /** @param array<string, mixed> $filters */
    public function accountsPayable(array $filters): LengthAwarePaginator
    {
        $today = CenterClock::today();

        $paginator = Expense::query()
            ->whereIn('status', ['pending', 'approved'])
            ->with('expenseCategory')
            ->orderBy('expense_date')
            ->paginate($this->perPage($filters));

        return $paginator->through(function (Expense $expense) use ($today): array {
            $daysPending = $expense->expense_date->lt($today) ? (int) $expense->expense_date->diffInDays($today) : 0;

            return [
                'expense_id' => $expense->id,
                'expense_category' => $expense->expenseCategory?->name,
                'description' => $expense->description,
                'payee' => $expense->payee,
                'amount' => (float) $expense->amount,
                'expense_date' => $expense->expense_date?->toDateString(),
                'status' => $expense->status,
                'days_pending' => $daysPending,
                'aging_bucket' => $this->agingBucket($daysPending),
            ];
        });
    }

    /** @param array<string, mixed> $filters */
    public function revenueReport(array $filters): LengthAwarePaginator
    {
        $query = DB::table('transactions')
            ->join('revenue_categories', 'revenue_categories.id', '=', 'transactions.revenue_category_id')
            ->where('transactions.type', Transaction::TYPE_INCOME)
            ->select(['revenue_categories.id as category_id', 'revenue_categories.name as category_name'])
            ->selectRaw('COUNT(transactions.id) as transaction_count')
            ->selectRaw('SUM(transactions.amount) as total_amount')
            ->groupBy('revenue_categories.id', 'revenue_categories.name')
            ->orderByDesc('total_amount');

        $this->applyDateRange($query, $filters, 'transactions.occurred_on');

        return $query->paginate($this->perPage($filters));
    }

    /** @param array<string, mixed> $filters */
    public function expenseReport(array $filters): LengthAwarePaginator
    {
        $query = DB::table('transactions')
            ->join('expense_categories', 'expense_categories.id', '=', 'transactions.expense_category_id')
            ->where('transactions.type', Transaction::TYPE_EXPENSE)
            ->select(['expense_categories.id as category_id', 'expense_categories.name as category_name'])
            ->selectRaw('COUNT(transactions.id) as transaction_count')
            ->selectRaw('SUM(transactions.amount) as total_amount')
            ->groupBy('expense_categories.id', 'expense_categories.name')
            ->orderByDesc('total_amount');

        $this->applyDateRange($query, $filters, 'transactions.occurred_on');

        return $query->paginate($this->perPage($filters));
    }

    /** @param array<string, mixed> $filters */
    public function cashFlow(array $filters): LengthAwarePaginator
    {
        // Aggregated in SQL rather than hydrating every transaction in the
        // range into Eloquent models and summing in PHP: a year of activity
        // scans the indexed date range once instead of materializing
        // thousands of rows. The month key is driver-aware so the grouping
        // stays in the database under both MariaDB and the tests' SQLite.
        $monthKey = $this->monthKey('occurred_on');

        $query = DB::table('transactions')
            ->selectRaw("$monthKey as period")
            ->selectRaw("COALESCE(SUM(CASE WHEN type = '".Transaction::TYPE_INCOME."' THEN amount ELSE 0 END), 0) as income")
            ->selectRaw("COALESCE(SUM(CASE WHEN type = '".Transaction::TYPE_EXPENSE."' THEN amount ELSE 0 END), 0) as expense")
            ->groupBy(DB::raw($monthKey))
            ->orderBy('period');

        $this->applyDateRange($query, $filters, 'occurred_on');

        $byMonth = $query->get()->map(function ($row): array {
            $income = (float) $row->income;
            $expense = (float) $row->expense;

            return [
                'period' => (string) $row->period,
                'income' => round($income, 2),
                'expense' => round($expense, 2),
                'net_cash_flow' => round($income - $expense, 2),
            ];
        });

        return $this->paginateCollection($byMonth, $filters);
    }

    /**
     * Doubles as the Income Statement — the same computation under the
     * traditional accounting name required by the spec alongside "Profit
     * & Loss".
     *
     * @param  array<string, mixed>  $filters
     */
    public function profitAndLoss(array $filters): LengthAwarePaginator
    {
        $revenueQuery = DB::table('transactions')
            ->leftJoin('revenue_categories', 'revenue_categories.id', '=', 'transactions.revenue_category_id')
            ->where('transactions.type', Transaction::TYPE_INCOME)
            ->select(DB::raw("COALESCE(revenue_categories.name, 'غير مصنف') as label"))
            ->selectRaw('SUM(transactions.amount) as total')
            ->groupBy('label');
        $this->applyDateRange($revenueQuery, $filters, 'transactions.occurred_on');

        $expenseQuery = DB::table('transactions')
            ->leftJoin('expense_categories', 'expense_categories.id', '=', 'transactions.expense_category_id')
            ->where('transactions.type', Transaction::TYPE_EXPENSE)
            ->select(DB::raw("COALESCE(expense_categories.name, 'غير مصنف') as label"))
            ->selectRaw('SUM(transactions.amount) as total')
            ->groupBy('label');
        $this->applyDateRange($expenseQuery, $filters, 'transactions.occurred_on');

        $revenue = $revenueQuery->get()->map(fn ($row): array => ['section' => 'revenue', 'label' => $row->label, 'total' => round((float) $row->total, 2)]);
        $expense = $expenseQuery->get()->map(fn ($row): array => ['section' => 'expense', 'label' => $row->label, 'total' => round((float) $row->total, 2)]);

        $totalRevenue = $revenue->sum('total');
        $totalExpense = $expense->sum('total');

        $rows = $revenue->concat($expense)
            ->push(['section' => 'summary', 'label' => 'صافي الربح', 'total' => round($totalRevenue - $totalExpense, 2)])
            ->values();

        return $this->paginateCollection($rows, $filters);
    }

    /** @param array<string, mixed> $filters */
    public function monthlySummary(array $filters): LengthAwarePaginator
    {
        $year = (int) ($filters['year'] ?? now()->year);
        $month = (int) ($filters['month'] ?? now()->month);
        $start = Carbon::create($year, $month, 1)->startOfMonth();
        $end = $start->copy()->endOfMonth();

        return $this->paginateCollection(collect([$this->summaryFor($start, $end)]), $filters);
    }

    /** @param array<string, mixed> $filters */
    public function yearlySummary(array $filters): LengthAwarePaginator
    {
        $year = (int) ($filters['year'] ?? now()->year);

        $start = Carbon::create($year, 1, 1)->startOfMonth();
        $end = Carbon::create($year, 12, 1)->startOfMonth()->endOfMonth();
        $yearDayAfter = DateColumn::dayAfter($end);

        // Five batched reads serve the whole year instead of 5 queries per
        // month (60): sums/counts grouped by month plus a single fetch of the
        // unpaid invoices the per-month outstanding figures are derived from.
        $incomeByMonth = $this->sumByMonth(Transaction::query()->where('type', Transaction::TYPE_INCOME), 'occurred_on', $start, $end);
        $expenseByMonth = $this->sumByMonth(Transaction::query()->where('type', Transaction::TYPE_EXPENSE), 'occurred_on', $start, $end);
        $issuedByMonth = $this->countByMonth(Invoice::query()->whereNotNull('issue_date'), 'issue_date', $start, $end);
        $paidByMonth = $this->countByMonth(Invoice::query()->where('status', 'paid'), 'updated_at', $start, $end);

        $outstandingInvoices = Invoice::query()
            ->whereIn('status', ['sent', 'partial', 'overdue'])
            ->where('due_date', '<', $yearDayAfter)
            ->get(['total', 'amount_paid', 'due_date']);

        $rows = collect(range(1, 12))->map(function (int $month) use ($year, $incomeByMonth, $expenseByMonth, $issuedByMonth, $paidByMonth, $outstandingInvoices): array {
            $monthStart = Carbon::create($year, $month, 1)->startOfMonth();
            $monthEnd = $monthStart->copy()->endOfMonth();
            $period = $monthStart->format('Y-m');
            $monthEndAfter = Carbon::create($year, $month, 1)->addMonth()->startOfDay();

            $income = (float) ($incomeByMonth[$period] ?? 0);
            $expense = (float) ($expenseByMonth[$period] ?? 0);

            $outstanding = (float) $outstandingInvoices
                // Strictly before the next month is the same half-open rule
                // summaryFor() applies to a single month.
                ->filter(fn (Invoice $invoice): bool => $invoice->due_date->lt($monthEndAfter))
                ->sum(fn (Invoice $invoice): float => (float) $invoice->total - (float) $invoice->amount_paid);

            return [
                'period' => $period,
                'total_revenue' => round($income, 2),
                'total_expenses' => round($expense, 2),
                'net_profit' => round($income - $expense, 2),
                'invoices_issued' => (int) ($issuedByMonth[$period] ?? 0),
                'invoices_paid' => (int) ($paidByMonth[$period] ?? 0),
                'outstanding_receivables' => round($outstanding, 2),
            ];
        });

        return $this->paginateCollection($rows, $filters);
    }

    /**
     * Sum a decimal column grouped by calendar month.
     *
     * @param  Builder<Transaction>  $query
     * @return array<string, string> period => sum (raw decimal strings, keyed by `Y-m`)
     */
    private function sumByMonth($query, string $column, Carbon $start, Carbon $end): array
    {
        return $query->selectRaw($this->monthKey($column).' as period')
            ->selectRaw('SUM(amount) as total')
            ->where($column, '>=', $start->toDateString())
            ->where($column, '<', DateColumn::dayAfter($end))
            ->groupBy(DB::raw($this->monthKey($column)))
            ->pluck('total', 'period')
            ->all();
    }

    /**
     * Count rows grouped by calendar month.
     *
     * @param  Builder<Invoice>  $query
     * @return array<string, int> period => count, keyed by `Y-m`
     */
    private function countByMonth($query, string $column, Carbon $start, Carbon $end): array
    {
        return $query->selectRaw($this->monthKey($column).' as period')
            ->selectRaw('COUNT(*) as total')
            ->where($column, '>=', $start->toDateString())
            ->where($column, '<', DateColumn::dayAfter($end))
            ->groupBy(DB::raw($this->monthKey($column)))
            ->pluck('total', 'period')
            ->map(fn ($count): int => (int) $count)
            ->all();
    }

    /**
     * A monotonic `Y-m` month key for a date column, expressed in the SQL
     * dialect of the active connection: DATE_FORMAT on MySQL-family drivers,
     * strftime on SQLite (the in-memory database the test suite runs on).
     */
    private function monthKey(string $column): string
    {
        return DB::connection()->getDriverName() === 'sqlite'
            ? "strftime('%Y-%m', $column)"
            : "DATE_FORMAT($column, '%Y-%m')";
    }

    /** @return array<string, mixed> */
    private function summaryFor(Carbon $start, Carbon $end): array
    {
        $income = (float) Transaction::query()->where('type', Transaction::TYPE_INCOME)
            ->where('occurred_on', '>=', $start->toDateString())
            ->where('occurred_on', '<', DateColumn::dayAfter($end))->sum('amount');
        $expense = (float) Transaction::query()->where('type', Transaction::TYPE_EXPENSE)
            ->where('occurred_on', '>=', $start->toDateString())
            ->where('occurred_on', '<', DateColumn::dayAfter($end))->sum('amount');

        $invoicesIssued = Invoice::query()
            ->where('issue_date', '>=', $start->toDateString())
            ->where('issue_date', '<', DateColumn::dayAfter($end))->count();
        $invoicesPaid = Invoice::query()->where('status', 'paid')
            ->whereBetween('updated_at', [$start, $end])->count();
        $outstandingReceivables = (float) Invoice::query()
            ->whereIn('status', ['sent', 'partial', 'overdue'])
            ->where('due_date', '<', DateColumn::dayAfter($end))
            ->sum(DB::raw('COALESCE(total, 0) - COALESCE(amount_paid, 0)'));

        return [
            'period' => $start->format('Y-m'),
            'total_revenue' => round($income, 2),
            'total_expenses' => round($expense, 2),
            'net_profit' => round($income - $expense, 2),
            'invoices_issued' => $invoicesIssued,
            'invoices_paid' => $invoicesPaid,
            'outstanding_receivables' => round($outstandingReceivables, 2),
        ];
    }

    private function agingBucket(int $days): string
    {
        return match (true) {
            $days <= 0 => 'current',
            $days <= 30 => '1-30',
            $days <= 60 => '31-60',
            $days <= 90 => '61-90',
            default => '90+',
        };
    }

    /**
     * Half-open range on the bare column — see {@see ReportService::applyDates()}
     * for why `whereDate()` cannot use the index on these columns.
     *
     * @param  array<string, mixed>  $filters
     */
    private function applyDateRange(mixed $query, array $filters, string $column): void
    {
        $query->when($filters['date_from'] ?? null, fn ($q, string $date) => $q->where($column, '>=', $date));
        $query->when(
            $filters['date_to'] ?? null,
            fn ($q, string $date) => $q->where($column, '<', Carbon::parse($date)->addDay()->toDateString()),
        );
    }

    /** @param array<string, mixed> $filters */
    private function perPage(array $filters): int
    {
        return max(1, min((int) ($filters['per_page'] ?? 25), 100));
    }

    /**
     * @param  Collection<int, array<string, mixed>>  $items
     * @param  array<string, mixed>  $filters
     */
    private function paginateCollection(Collection $items, array $filters): LengthAwarePaginator
    {
        $perPage = $this->perPage($filters);
        $page = max(1, (int) ($filters['page'] ?? 1));

        return new ConcreteLengthAwarePaginator(
            $items->forPage($page, $perPage)->values(),
            $items->count(),
            $perPage,
            $page,
            ['path' => ConcreteLengthAwarePaginator::resolveCurrentPath()],
        );
    }
}
