<?php

namespace App\Features\Finance\Services;

use App\Features\Finance\Actions\CreateInvoiceAction;
use App\Features\Finance\Actions\UpdateInvoiceAction;
use App\Features\Finance\Queries\InvoiceQuery;
use App\Features\Finance\Requests\StoreInvoiceRequest;
use App\Features\Finance\Requests\UpdateInvoiceRequest;
use App\Models\Invoice;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class InvoiceService extends BaseService
{
    public function __construct(
        protected CreateInvoiceAction $createInvoiceAction,
        protected UpdateInvoiceAction $updateInvoiceAction,
        protected InvoiceQuery $invoiceQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->invoiceQuery->paginate();
    }

    public function findOrFail(string $id): Invoice
    {
        $invoice = Invoice::with(['items', 'student', 'revenueCategory'])->find($id);

        if ($invoice === null) {
            throw new NotFoundException('Invoice not found.');
        }

        return $invoice;
    }

    public function create(StoreInvoiceRequest $request): Invoice
    {
        return $this->transaction(fn (): Invoice => $this->createInvoiceAction->execute($request));
    }

    public function update(Invoice $invoice, UpdateInvoiceRequest $request): Invoice
    {
        return $this->transaction(fn (): Invoice => $this->updateInvoiceAction->execute($invoice, $request));
    }
}
