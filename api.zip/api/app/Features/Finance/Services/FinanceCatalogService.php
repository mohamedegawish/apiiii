<?php

namespace App\Features\Finance\Services;

use App\Features\Finance\Queries\ExpenseCategoryQuery;
use App\Features\Finance\Queries\FinancialAccountQuery;
use App\Features\Finance\Queries\FinancialPeriodQuery;
use App\Features\Finance\Queries\RevenueCategoryQuery;
use App\Models\ExpenseCategory;
use App\Models\FinancialAccount;
use App\Models\FinancialPeriod;
use App\Models\RevenueCategory;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * CRUD for the four Finance reference-data entities (accounts, revenue
 * categories, expense categories, periods). Deliberately has no separate
 * Actions layer — unlike Invoice/Payment/Expense, create/update/delete here
 * is genuinely trivial (no derived fields, no side effects), so the extra
 * indirection would add files without adding safety or clarity.
 */
class FinanceCatalogService extends BaseService
{
    public function __construct(
        protected FinancialAccountQuery $financialAccountQuery,
        protected RevenueCategoryQuery $revenueCategoryQuery,
        protected ExpenseCategoryQuery $expenseCategoryQuery,
        protected FinancialPeriodQuery $financialPeriodQuery,
    ) {}

    // ------------------------------------------------------------ Accounts
    public function paginateAccounts(): LengthAwarePaginator
    {
        return $this->financialAccountQuery->paginate();
    }

    public function findAccount(string $id): FinancialAccount
    {
        return FinancialAccount::find($id) ?? throw new NotFoundException('Financial account not found.');
    }

    public function createAccount(array $data): FinancialAccount
    {
        return $this->transaction(fn () => FinancialAccount::create($data));
    }

    public function updateAccount(FinancialAccount $account, array $data): FinancialAccount
    {
        return $this->transaction(function () use ($account, $data) {
            $account->update($data);

            return $account->fresh();
        });
    }

    public function deleteAccount(FinancialAccount $account): bool
    {
        return $this->transaction(fn () => $account->delete());
    }

    // --------------------------------------------------- Revenue categories
    public function paginateRevenueCategories(): LengthAwarePaginator
    {
        return $this->revenueCategoryQuery->paginate();
    }

    public function findRevenueCategory(string $id): RevenueCategory
    {
        return RevenueCategory::find($id) ?? throw new NotFoundException('Revenue category not found.');
    }

    public function createRevenueCategory(array $data): RevenueCategory
    {
        return $this->transaction(fn () => RevenueCategory::create($data));
    }

    public function updateRevenueCategory(RevenueCategory $category, array $data): RevenueCategory
    {
        return $this->transaction(function () use ($category, $data) {
            $category->update($data);

            return $category->fresh();
        });
    }

    public function deleteRevenueCategory(RevenueCategory $category): bool
    {
        return $this->transaction(fn () => $category->delete());
    }

    // --------------------------------------------------- Expense categories
    public function paginateExpenseCategories(): LengthAwarePaginator
    {
        return $this->expenseCategoryQuery->paginate();
    }

    public function findExpenseCategory(string $id): ExpenseCategory
    {
        return ExpenseCategory::find($id) ?? throw new NotFoundException('Expense category not found.');
    }

    public function createExpenseCategory(array $data): ExpenseCategory
    {
        return $this->transaction(fn () => ExpenseCategory::create($data));
    }

    public function updateExpenseCategory(ExpenseCategory $category, array $data): ExpenseCategory
    {
        return $this->transaction(function () use ($category, $data) {
            $category->update($data);

            return $category->fresh();
        });
    }

    public function deleteExpenseCategory(ExpenseCategory $category): bool
    {
        return $this->transaction(fn () => $category->delete());
    }

    // ------------------------------------------------------------- Periods
    public function paginatePeriods(): LengthAwarePaginator
    {
        return $this->financialPeriodQuery->paginate();
    }

    public function findPeriod(string $id): FinancialPeriod
    {
        return FinancialPeriod::find($id) ?? throw new NotFoundException('Financial period not found.');
    }

    public function createPeriod(array $data): FinancialPeriod
    {
        return $this->transaction(fn () => FinancialPeriod::create($data));
    }

    public function closePeriod(FinancialPeriod $period): FinancialPeriod
    {
        return $this->transaction(function () use ($period) {
            $period->update(['status' => 'closed', 'closed_at' => now()]);

            return $period->fresh();
        });
    }
}
