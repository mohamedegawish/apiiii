<?php

namespace App\Features\Finance\Services;

use App\Features\Finance\Actions\ApproveExpenseAction;
use App\Features\Finance\Actions\CreateExpenseAction;
use App\Features\Finance\Actions\MarkExpensePaidAction;
use App\Features\Finance\Actions\UpdateExpenseAction;
use App\Features\Finance\Queries\ExpenseQuery;
use App\Features\Finance\Requests\StoreExpenseRequest;
use App\Features\Finance\Requests\UpdateExpenseRequest;
use App\Models\Expense;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class ExpenseService extends BaseService
{
    public function __construct(
        protected CreateExpenseAction $createExpenseAction,
        protected UpdateExpenseAction $updateExpenseAction,
        protected ApproveExpenseAction $approveExpenseAction,
        protected MarkExpensePaidAction $markExpensePaidAction,
        protected ExpenseQuery $expenseQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->expenseQuery->paginate();
    }

    public function findOrFail(string $id): Expense
    {
        $expense = Expense::with(['expenseCategory', 'financialAccount'])->find($id);

        if ($expense === null) {
            throw new NotFoundException('Expense not found.');
        }

        return $expense;
    }

    public function create(StoreExpenseRequest $request): Expense
    {
        return $this->transaction(fn (): Expense => $this->createExpenseAction->execute($request));
    }

    public function update(Expense $expense, UpdateExpenseRequest $request): Expense
    {
        return $this->transaction(fn (): Expense => $this->updateExpenseAction->execute($expense, $request));
    }

    public function approve(Expense $expense): Expense
    {
        return $this->transaction(fn (): Expense => $this->approveExpenseAction->execute($expense));
    }

    public function markPaid(Expense $expense, ?string $paidAt = null): Expense
    {
        return $this->transaction(
            fn (): Expense => $this->markExpensePaidAction->execute($expense, $paidAt ?? now()->toDateString())
        );
    }
}
