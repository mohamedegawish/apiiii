<?php

namespace App\Features\Finance\Services;

use App\Features\Finance\Actions\RecordPaymentAction;
use App\Features\Finance\Queries\PaymentQuery;
use App\Features\Finance\Requests\StorePaymentRequest;
use App\Models\Payment;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class PaymentService extends BaseService
{
    public function __construct(
        protected RecordPaymentAction $recordPaymentAction,
        protected PaymentQuery $paymentQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->paymentQuery->paginate();
    }

    public function findOrFail(string $id): Payment
    {
        $payment = Payment::with(['student', 'revenueCategory', 'invoice'])->find($id);

        if ($payment === null) {
            throw new NotFoundException('Payment not found.');
        }

        return $payment;
    }

    public function record(StorePaymentRequest $request): Payment
    {
        return $this->transaction(fn (): Payment => $this->recordPaymentAction->execute($request));
    }
}
