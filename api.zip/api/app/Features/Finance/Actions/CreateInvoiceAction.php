<?php

namespace App\Features\Finance\Actions;

use App\Features\Finance\Requests\StoreInvoiceRequest;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Support\Actions\BaseAction;
use Illuminate\Support\Str;

class CreateInvoiceAction extends BaseAction
{
    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreInvoiceRequest) {
            throw new \InvalidArgumentException('CreateInvoiceAction expects a StoreInvoiceRequest.');
        }

        $data = $request->validatedData();
        $items = $data['items'];
        unset($data['items']);

        $subtotal = 0.0;
        foreach ($items as $item) {
            $subtotal += ((float) $item['unit_price']) * ((int) $item['quantity']);
        }
        $tax = (float) ($data['tax_amount'] ?? 0);

        $invoice = Invoice::create([
            ...$data,
            'invoice_number' => $this->generateInvoiceNumber(),
            'subtotal' => round($subtotal, 2),
            'tax_amount' => round($tax, 2),
            'total' => round($subtotal + $tax, 2),
            'amount_paid' => 0,
            'status' => 'sent',
        ]);

        foreach ($items as $item) {
            InvoiceItem::create([
                'invoice_id' => $invoice->id,
                'description' => $item['description'],
                'quantity' => $item['quantity'],
                'unit_price' => $item['unit_price'],
                'amount' => round(((float) $item['unit_price']) * ((int) $item['quantity']), 2),
            ]);
        }

        return $invoice->load(['items', 'student', 'revenueCategory']);
    }

    private function generateInvoiceNumber(): string
    {
        do {
            $number = 'INV-'.now()->format('Ym').'-'.strtoupper(Str::random(6));
        } while (Invoice::withTrashed()->where('invoice_number', $number)->exists());

        return $number;
    }
}
