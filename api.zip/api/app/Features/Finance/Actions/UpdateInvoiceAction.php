<?php

namespace App\Features\Finance\Actions;

use App\Features\Finance\Requests\UpdateInvoiceRequest;
use App\Models\Invoice;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;

class UpdateInvoiceAction extends BaseAction
{
    public function execute(mixed ...$arguments): mixed
    {
        $invoice = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $invoice instanceof Invoice || ! $request instanceof UpdateInvoiceRequest) {
            throw new \InvalidArgumentException('UpdateInvoiceAction expects an Invoice and UpdateInvoiceRequest.');
        }

        $data = $request->validatedData();

        if (($data['status'] ?? null) === 'void') {
            if ((float) $invoice->amount_paid > 0) {
                throw new ConflictException('An invoice with payments already recorded cannot be voided.');
            }
        }

        $invoice->update($data);

        return $invoice->fresh(['items', 'student', 'revenueCategory']);
    }
}
