<?php

namespace App\Features\Finance\Actions;

use App\Features\Finance\Services\TransactionRecorder;
use App\Models\Expense;
use App\Models\Transaction;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;

/**
 * Settling an expense (pending or approved -> paid) is the moment its money
 * actually leaves the center — this is the expense-side counterpart to
 * RecordPaymentAction, and the only place an Expense causes a Transaction
 * to be created.
 */
class MarkExpensePaidAction extends BaseAction
{
    public function __construct(protected TransactionRecorder $transactionRecorder) {}

    public function execute(mixed ...$arguments): mixed
    {
        $expense = $arguments[0] ?? null;
        $paidAt = $arguments[1] ?? now()->toDateString();

        if (! $expense instanceof Expense) {
            throw new \InvalidArgumentException('MarkExpensePaidAction expects an Expense.');
        }

        if ($expense->status === 'paid') {
            throw new ConflictException('This expense has already been paid.');
        }

        $expense->update([
            'status' => 'paid',
            'paid_at' => $paidAt,
        ]);

        $this->transactionRecorder->record([
            'type' => Transaction::TYPE_EXPENSE,
            'amount' => $expense->amount,
            'occurred_on' => $paidAt,
            'financial_account_id' => $expense->financial_account_id,
            'expense_category_id' => $expense->expense_category_id,
            'source_type' => 'expense',
            'source_id' => $expense->id,
            'description' => $expense->description,
        ]);

        return $expense->fresh(['expenseCategory', 'financialAccount']);
    }
}
