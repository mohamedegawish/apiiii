<?php

namespace App\Features\Finance\Actions;

use App\Features\Finance\Requests\UpdateExpenseRequest;
use App\Models\Expense;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;

class UpdateExpenseAction extends BaseAction
{
    public function execute(mixed ...$arguments): mixed
    {
        $expense = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $expense instanceof Expense || ! $request instanceof UpdateExpenseRequest) {
            throw new \InvalidArgumentException('UpdateExpenseAction expects an Expense and UpdateExpenseRequest.');
        }

        if ($expense->status !== 'pending') {
            throw new ConflictException('Only a pending expense can be edited.');
        }

        $expense->update($request->validatedData());

        return $expense->fresh(['expenseCategory', 'financialAccount', 'teacher.user']);
    }
}
