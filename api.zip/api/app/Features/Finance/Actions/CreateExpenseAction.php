<?php

namespace App\Features\Finance\Actions;

use App\Features\Finance\Requests\StoreExpenseRequest;
use App\Models\Expense;
use App\Support\Actions\BaseAction;

class CreateExpenseAction extends BaseAction
{
    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreExpenseRequest) {
            throw new \InvalidArgumentException('CreateExpenseAction expects a StoreExpenseRequest.');
        }

        $expense = Expense::create([
            ...$request->validatedData(),
            'status' => 'pending',
        ]);

        return $expense->load(['expenseCategory', 'financialAccount', 'teacher.user']);
    }
}
