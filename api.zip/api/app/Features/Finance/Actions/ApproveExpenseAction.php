<?php

namespace App\Features\Finance\Actions;

use App\Models\Expense;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;

class ApproveExpenseAction extends BaseAction
{
    public function execute(mixed ...$arguments): mixed
    {
        $expense = $arguments[0] ?? null;

        if (! $expense instanceof Expense) {
            throw new \InvalidArgumentException('ApproveExpenseAction expects an Expense.');
        }

        if ($expense->status !== 'pending') {
            throw new ConflictException('Only a pending expense can be approved.');
        }

        $expense->update(['status' => 'approved']);

        return $expense->fresh(['expenseCategory', 'financialAccount']);
    }
}
