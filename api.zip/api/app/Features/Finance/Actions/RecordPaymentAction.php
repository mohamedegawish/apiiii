<?php

namespace App\Features\Finance\Actions;

use App\Features\Finance\Requests\StorePaymentRequest;
use App\Features\Finance\Services\TransactionRecorder;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Transaction;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;

class RecordPaymentAction extends BaseAction
{
    public function __construct(protected TransactionRecorder $transactionRecorder) {}

    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StorePaymentRequest) {
            throw new \InvalidArgumentException('RecordPaymentAction expects a StorePaymentRequest.');
        }

        $data = $request->validatedData();
        $invoice = null;

        if (! empty($data['invoice_id'])) {
            $invoice = Invoice::lockForUpdate()->find($data['invoice_id']);

            if ($invoice === null) {
                throw new ConflictException('The selected invoice is invalid.');
            }

            if ($invoice->status === 'void') {
                throw new ConflictException('A voided invoice cannot receive payments.');
            }

            $newAmountPaid = round((float) $invoice->amount_paid + (float) $data['amount'], 2);

            if ($newAmountPaid > (float) $invoice->total + 0.01) {
                throw new ConflictException('This payment would exceed the invoice total.');
            }

            $data['student_id'] ??= $invoice->student_id;
        }

        $payment = Payment::create($data);

        if ($invoice !== null) {
            $newAmountPaid = round((float) $invoice->amount_paid + (float) $payment->amount, 2);
            $invoice->update([
                'amount_paid' => $newAmountPaid,
                'status' => $newAmountPaid >= (float) $invoice->total ? 'paid' : 'partial',
            ]);
        }

        $this->transactionRecorder->record([
            'type' => Transaction::TYPE_INCOME,
            'amount' => $payment->amount,
            'occurred_on' => $payment->paid_at,
            'financial_account_id' => $payment->financial_account_id,
            'revenue_category_id' => $payment->revenue_category_id,
            'source_type' => 'payment',
            'source_id' => $payment->id,
            'description' => $invoice !== null
                ? "Payment for invoice {$invoice->invoice_number}"
                : ($payment->payer_name ?? 'Payment'),
        ]);

        return $payment->load(['student', 'revenueCategory', 'invoice']);
    }
}
