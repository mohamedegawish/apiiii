<?php

namespace App\Features\Finance\Queries;

use App\Models\FinancialAccount;
use App\Support\Queries\BaseQuery;
use Spatie\QueryBuilder\AllowedFilter;

class FinancialAccountQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(FinancialAccount::class);
    }

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::partial('name'),
            AllowedFilter::exact('type'),
            AllowedFilter::exact('is_active'),
        ];
    }

    protected function allowedSorts(): array
    {
        return ['name', 'code', 'created_at'];
    }
}
