<?php

namespace App\Features\Finance\Queries;

use App\Models\Payment;
use App\Support\Queries\BaseQuery;
use Spatie\QueryBuilder\AllowedFilter;

class PaymentQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(Payment::class);
    }

    protected string $defaultSort = '-paid_at';

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::exact('student_id'),
            AllowedFilter::exact('invoice_id'),
            AllowedFilter::exact('method'),
            AllowedFilter::exact('revenue_category_id'),
        ];
    }

    protected function allowedSorts(): array
    {
        return ['paid_at', 'amount', 'created_at'];
    }

    protected function allowedIncludes(): array
    {
        return ['student', 'revenueCategory', 'invoice'];
    }
}
