<?php

namespace App\Features\Finance\Queries;

use App\Models\Expense;
use App\Support\Queries\BaseQuery;
use Spatie\QueryBuilder\AllowedFilter;

class ExpenseQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(Expense::class);
    }

    protected string $defaultSort = '-expense_date';

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::exact('status'),
            AllowedFilter::exact('expense_category_id'),
            AllowedFilter::exact('teacher_id'),
            AllowedFilter::exact('financial_account_id'),
            AllowedFilter::partial('payee'),
        ];
    }

    protected function allowedSorts(): array
    {
        return ['expense_date', 'amount', 'created_at'];
    }

    protected function allowedIncludes(): array
    {
        return ['expenseCategory', 'financialAccount', 'teacher', 'teacher.user'];
    }
}
