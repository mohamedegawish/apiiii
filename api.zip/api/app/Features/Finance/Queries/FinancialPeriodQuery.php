<?php

namespace App\Features\Finance\Queries;

use App\Models\FinancialPeriod;
use App\Support\Queries\BaseQuery;
use Spatie\QueryBuilder\AllowedFilter;

class FinancialPeriodQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(FinancialPeriod::class);
    }

    protected string $defaultSort = '-start_date';

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::partial('name'),
            AllowedFilter::exact('status'),
        ];
    }

    protected function allowedSorts(): array
    {
        return ['start_date', 'end_date', 'created_at'];
    }
}
