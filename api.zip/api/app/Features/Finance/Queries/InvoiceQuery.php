<?php

namespace App\Features\Finance\Queries;

use App\Models\Invoice;
use App\Support\Queries\BaseQuery;
use Spatie\QueryBuilder\AllowedFilter;

class InvoiceQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(Invoice::class);
    }

    protected string $defaultSort = '-issue_date';

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::exact('student_id'),
            AllowedFilter::exact('status'),
            AllowedFilter::exact('revenue_category_id'),
            AllowedFilter::partial('invoice_number'),
        ];
    }

    protected function allowedSorts(): array
    {
        return ['issue_date', 'due_date', 'total', 'created_at'];
    }

    protected function allowedIncludes(): array
    {
        return ['student', 'revenueCategory', 'items'];
    }
}
