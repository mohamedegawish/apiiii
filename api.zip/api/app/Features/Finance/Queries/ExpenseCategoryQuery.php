<?php

namespace App\Features\Finance\Queries;

use App\Models\ExpenseCategory;
use App\Support\Queries\BaseQuery;
use Spatie\QueryBuilder\AllowedFilter;

class ExpenseCategoryQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(ExpenseCategory::class);
    }

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::partial('name'),
            AllowedFilter::exact('is_active'),
        ];
    }

    protected function allowedSorts(): array
    {
        return ['name', 'created_at'];
    }
}
