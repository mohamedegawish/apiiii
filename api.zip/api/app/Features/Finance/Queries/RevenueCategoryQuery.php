<?php

namespace App\Features\Finance\Queries;

use App\Models\RevenueCategory;
use App\Support\Queries\BaseQuery;
use Spatie\QueryBuilder\AllowedFilter;

class RevenueCategoryQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(RevenueCategory::class);
    }

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::partial('name'),
            AllowedFilter::exact('is_active'),
        ];
    }

    protected function allowedSorts(): array
    {
        return ['name', 'created_at'];
    }
}
