<?php

namespace App\Features\Finance\Requests;

use App\Features\Finance\Policies\FinancePolicy;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class UpdateExpenseCategoryRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return app(FinancePolicy::class)->manage($this->user());
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'name' => ['sometimes', 'string', 'max:255'],
            'code' => ['sometimes', 'string', 'max:50', Rule::unique('expense_categories', 'code')->ignore($this->route('expenseCategory'))],
            'is_active' => ['sometimes', 'boolean'],
        ];
    }
}
