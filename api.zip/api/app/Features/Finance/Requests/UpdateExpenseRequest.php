<?php

namespace App\Features\Finance\Requests;

use App\Features\Finance\Policies\FinancePolicy;
use App\Support\Http\Requests\BaseRequest;

/**
 * Only pending expenses may have their details edited (enforced in
 * UpdateExpenseAction) — an approved/paid expense's category, amount, or
 * date is locked to keep it consistent with any transaction already
 * recorded against it.
 */
class UpdateExpenseRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return app(FinancePolicy::class)->manage($this->user());
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'expense_category_id' => ['sometimes', 'uuid', 'exists:expense_categories,id'],
            'teacher_id' => ['sometimes', 'nullable', 'uuid', 'exists:teachers,id'],
            'financial_account_id' => ['sometimes', 'nullable', 'uuid', 'exists:financial_accounts,id'],
            'description' => ['sometimes', 'string', 'max:255'],
            'payee' => ['sometimes', 'nullable', 'string', 'max:255'],
            'amount' => ['sometimes', 'numeric', 'min:0.01'],
            'expense_date' => ['sometimes', 'date'],
            'period_month' => ['sometimes', 'nullable', 'date'],
            'notes' => ['sometimes', 'nullable', 'string', 'max:2000'],
        ];
    }
}
