<?php

namespace App\Features\Finance\Requests;

use App\Features\Finance\Policies\FinancePolicy;
use App\Support\Http\Requests\BaseRequest;

class StoreFinancialPeriodRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return app(FinancePolicy::class)->manage($this->user());
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:100'],
            'start_date' => ['required', 'date'],
            'end_date' => ['required', 'date', 'after_or_equal:start_date'],
        ];
    }
}
