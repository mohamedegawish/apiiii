<?php

namespace App\Features\Finance\Requests;

use App\Features\Finance\Policies\FinancePolicy;
use App\Support\Http\Requests\BaseRequest;

class StoreInvoiceRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return app(FinancePolicy::class)->manage($this->user());
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'student_id' => ['required', 'uuid', 'exists:students,id'],
            'revenue_category_id' => ['required', 'uuid', 'exists:revenue_categories,id'],
            'issue_date' => ['required', 'date'],
            'due_date' => ['required', 'date', 'after_or_equal:issue_date'],
            'tax_amount' => ['nullable', 'numeric', 'min:0'],
            'notes' => ['nullable', 'string', 'max:2000'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.description' => ['required', 'string', 'max:255'],
            'items.*.quantity' => ['required', 'integer', 'min:1'],
            'items.*.unit_price' => ['required', 'numeric', 'min:0'],
        ];
    }
}
