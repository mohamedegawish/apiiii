<?php

namespace App\Features\Finance\Requests;

use App\Features\Finance\Policies\FinancePolicy;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class StorePaymentRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return app(FinancePolicy::class)->manage($this->user());
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'invoice_id' => ['nullable', 'uuid', 'exists:invoices,id'],
            'student_id' => ['nullable', 'uuid', 'exists:students,id'],
            'revenue_category_id' => ['required', 'uuid', 'exists:revenue_categories,id'],
            'financial_account_id' => ['nullable', 'uuid', 'exists:financial_accounts,id'],
            'payer_name' => ['nullable', 'string', 'max:255'],
            'method' => ['required', 'string', Rule::in(['cash', 'bank_transfer', 'card', 'other'])],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'paid_at' => ['required', 'date'],
            'period_month' => ['nullable', 'date'],
            'reference_number' => ['nullable', 'string', 'max:100'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
