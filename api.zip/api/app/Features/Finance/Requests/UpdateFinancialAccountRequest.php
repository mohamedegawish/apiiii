<?php

namespace App\Features\Finance\Requests;

use App\Features\Finance\Policies\FinancePolicy;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class UpdateFinancialAccountRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return app(FinancePolicy::class)->manage($this->user());
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'name' => ['sometimes', 'string', 'max:255'],
            'code' => ['sometimes', 'string', 'max:50', Rule::unique('financial_accounts', 'code')->ignore($this->route('financialAccount'))],
            'type' => ['sometimes', 'string', Rule::in(['asset', 'liability', 'income', 'expense', 'equity'])],
            'opening_balance' => ['sometimes', 'numeric', 'min:0'],
            'is_active' => ['sometimes', 'boolean'],
        ];
    }
}
