<?php

namespace App\Features\Finance\Requests;

use App\Features\Finance\Policies\FinancePolicy;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

/**
 * Line items are fixed at creation — an invoice already partially paid
 * cannot silently change what it billed for. Only administrative fields
 * (due date, notes) and voiding an unpaid invoice are editable afterwards.
 */
class UpdateInvoiceRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return app(FinancePolicy::class)->manage($this->user());
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'due_date' => ['sometimes', 'date'],
            'notes' => ['sometimes', 'nullable', 'string', 'max:2000'],
            'status' => ['sometimes', 'string', Rule::in(['void'])],
        ];
    }
}
