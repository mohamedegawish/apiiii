<?php

namespace App\Features\Circles\Requests;

use App\Models\Circle;
use App\Support\Http\Requests\BaseRequest;
use App\Support\Rules\OwnedTeacher;

class StoreCircleRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', Circle::class) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'teacher_id' => ['nullable', 'uuid', 'exists:teachers,id', new OwnedTeacher],
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:500'],
            'capacity' => ['nullable', 'integer', 'min:1', 'max:100'],
            'is_active' => ['nullable', 'boolean'],
            'starts_at' => ['nullable', 'date'],
        ];
    }
}
