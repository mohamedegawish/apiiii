<?php

namespace App\Features\Circles\Controllers;

use App\Features\Circles\Requests\StoreCircleRequest;
use App\Features\Circles\Requests\UpdateCircleRequest;
use App\Features\Circles\Resources\CircleResource;
use App\Features\Circles\Services\CircleRosterService;
use App\Features\Circles\Services\CircleService;
use App\Features\Students\Resources\StudentResource;
use App\Models\Circle;
use App\Support\CenterClock;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class CircleController extends BaseController
{
    public function __construct(
        protected CircleService $circleService,
        protected CircleRosterService $circleRosterService,
    ) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Circle::class);

        $paginator = $this->circleService->paginate();

        return $this->paginate(CircleResource::collection($paginator), 'Circles retrieved successfully.');
    }

    public function show(string $circle): JsonResponse
    {
        $model = $this->circleService->findOrFail($circle);

        $this->authorize('view', $model);

        return $this->success(
            data: CircleResource::make($model),
            message: 'Circle retrieved successfully.',
        );
    }

    public function store(StoreCircleRequest $request): JsonResponse
    {
        $circle = $this->circleService->create($request);

        return $this->created(
            data: CircleResource::make($circle),
            message: 'Circle created successfully.',
        );
    }

    public function update(UpdateCircleRequest $request, string $circle): JsonResponse
    {
        $model = $this->circleService->findOrFail($circle);
        $updated = $this->circleService->update($model, $request);

        return $this->success(
            data: CircleResource::make($updated),
            message: 'Circle updated successfully.',
        );
    }

    public function destroy(string $circle): JsonResponse
    {
        $model = $this->circleService->findOrFail($circle);

        $this->authorize('delete', $model);

        $this->circleService->delete($model);

        return $this->success(
            data: null,
            message: 'Circle deleted successfully.',
        );
    }

    /**
     * List the students currently enrolled in a circle.
     *
     * Reads from `enrollments` (the same source AttendanceService,
     * ValidatesLearningRecord and AcademicSessionGuard validate against),
     * not the legacy `circle_student` pivot, so a student who appears here
     * is guaranteed to be writable on today's session. For a roster as of a
     * specific past session date, see CircleSessionController::roster().
     */
    public function students(string $circle): JsonResponse
    {
        $model = $this->circleService->findOrFail($circle);

        $this->authorize('view', $model);

        $data = $this->circleRosterService->asOf($model, CenterClock::today());

        return $this->success(
            data: $data,
            message: 'Enrolled students retrieved successfully.',
        );
    }

    /**
     * Enroll a student into a circle (idempotent).
     */
    public function enrollStudent(Request $request, string $circle): JsonResponse
    {
        $model = $this->circleService->findOrFail($circle);

        $this->authorize('update', $model);

        $validated = $request->validate([
            'student_id' => ['required', 'uuid', 'exists:students,id'],
            'status' => ['nullable', 'string', Rule::in(['active', 'inactive'])],
        ]);

        $model->students()->syncWithoutDetaching([
            $validated['student_id'] => [
                'id' => (string) Str::uuid(),
                'enrolled_at' => now(),
                'status' => $validated['status'] ?? 'active',
            ],
        ]);

        return $this->created(
            data: StudentResource::collection($model->students()->get())->resolve(),
            message: 'Student enrolled successfully.',
        );
    }

    /**
     * Remove a student from a circle.
     */
    public function unenrollStudent(string $circle, string $student): JsonResponse
    {
        $model = $this->circleService->findOrFail($circle);

        $this->authorize('update', $model);

        $model->students()->detach($student);

        return $this->success(
            data: null,
            message: 'Student removed from circle.',
        );
    }
}
