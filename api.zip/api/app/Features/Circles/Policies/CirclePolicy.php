<?php

namespace App\Features\Circles\Policies;

use App\Enums\Role;
use App\Models\Circle;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class CirclePolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $user instanceof User;
    }

    public function view(?User $user, Circle $circle): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        if ($this->hasRole($user, Role::Teacher)) {
            return $circle->teacher?->user_id === $user->id;
        }

        return false;
    }

    public function create(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }

    public function update(?User $user, Circle $circle): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        return false;
    }

    public function delete(?User $user, Circle $circle): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        return $this->hasRole($user, Role::CenterOwner);
    }

    public function restore(?User $user, Circle $circle): bool
    {
        return $this->isSuperAdmin($user);
    }

    public function forceDelete(?User $user, Circle $circle): bool
    {
        return $this->isSuperAdmin($user);
    }
}
