<?php

namespace App\Features\Circles\Actions;

use App\Features\Circles\Requests\UpdateCircleRequest;
use App\Models\Circle;
use App\Support\Actions\BaseAction;

class UpdateCircleAction extends BaseAction
{
    /**
     * @return Circle
     */
    public function execute(mixed ...$arguments): mixed
    {
        $circle = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $circle instanceof Circle) {
            throw new \InvalidArgumentException('UpdateCircleAction expects a Circle as the first argument.');
        }

        if (! $request instanceof UpdateCircleRequest) {
            throw new \InvalidArgumentException('UpdateCircleAction expects an UpdateCircleRequest as the second argument.');
        }

        $circle->update($request->validatedData());

        return $circle->fresh();
    }
}
