<?php

namespace App\Features\Circles\Actions;

use App\Features\Circles\Requests\StoreCircleRequest;
use App\Models\Circle;
use App\Support\Actions\BaseAction;

class CreateCircleAction extends BaseAction
{
    /**
     * @return Circle
     */
    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreCircleRequest) {
            throw new \InvalidArgumentException('CreateCircleAction expects a StoreCircleRequest.');
        }

        $data = $request->validatedData();
        $active = $data['is_active'] ?? true;
        unset($data['is_active']);

        $circle = Circle::create($data);
        $circle->forceFill(['is_active' => $active])->save();

        return $circle;
    }
}
