<?php

namespace App\Features\Circles\Actions;

use App\Models\Circle;
use App\Support\Actions\BaseAction;

class DeleteCircleAction extends BaseAction
{
    /**
     * @return bool
     */
    public function execute(mixed ...$arguments): mixed
    {
        $circle = $arguments[0] ?? null;

        if (! $circle instanceof Circle) {
            throw new \InvalidArgumentException('DeleteCircleAction expects a Circle.');
        }

        return $circle->delete();
    }
}
