<?php

namespace App\Features\Circles\Queries;

use App\Enums\Role;
use App\Models\Circle;
use App\Support\Queries\BaseQuery;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class CircleQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(Circle::class);
    }

    protected function applyTenantScope(EloquentBuilder $builder): void
    {
        if ($this->shouldBypassScope()) {
            return;
        }

        $user = $this->currentUser();

        if ($user?->hasRole(Role::Teacher) && $user->teacher !== null) {
            $builder->where('teacher_id', $user->teacher->id);

            return;
        }

        // Fail closed for every other role (guardian/student) rather than
        // silently falling through unscoped — mirrors HomeworkQuery/
        // AssessmentQuery's already-fail-closed shape.
        $circleIds = $this->accessibleCircleIds();

        if ($circleIds === []) {
            $builder->whereRaw('1 = 0');

            return;
        }

        if ($circleIds !== null) {
            $builder->whereIn('id', $circleIds);
        }
    }

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::partial('name'),
            AllowedFilter::exact('teacher_id'),
            AllowedFilter::exact('is_active'),
            AllowedFilter::scope('search'),
        ];
    }

    protected function allowedSorts(): array
    {
        return [
            'name',
            'capacity',
            'created_at',
            'updated_at',
            'starts_at',
        ];
    }

    protected function allowedIncludes(): array
    {
        return ['teacher', 'students', 'schedules'];
    }
}
