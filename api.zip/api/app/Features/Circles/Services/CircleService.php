<?php

namespace App\Features\Circles\Services;

use App\Features\Circles\Actions\CreateCircleAction;
use App\Features\Circles\Actions\DeleteCircleAction;
use App\Features\Circles\Actions\UpdateCircleAction;
use App\Features\Circles\Queries\CircleQuery;
use App\Features\Circles\Requests\StoreCircleRequest;
use App\Features\Circles\Requests\UpdateCircleRequest;
use App\Models\Circle;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class CircleService extends BaseService
{
    public function __construct(
        protected CreateCircleAction $createCircleAction,
        protected UpdateCircleAction $updateCircleAction,
        protected DeleteCircleAction $deleteCircleAction,
        protected CircleQuery $circleQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->circleQuery->paginate();
    }

    public function findOrFail(string $id): Circle
    {
        $circle = Circle::with(['teacher'])->find($id);

        if ($circle === null) {
            throw new NotFoundException('Circle not found.');
        }

        return $circle;
    }

    public function create(StoreCircleRequest $request): Circle
    {
        return $this->transaction(fn (): Circle => $this->createCircleAction->execute($request));
    }

    public function update(Circle $circle, UpdateCircleRequest $request): Circle
    {
        return $this->transaction(fn (): Circle => $this->updateCircleAction->execute($circle, $request));
    }

    public function delete(Circle $circle): bool
    {
        return $this->transaction(fn (): bool => $this->deleteCircleAction->execute($circle));
    }
}
