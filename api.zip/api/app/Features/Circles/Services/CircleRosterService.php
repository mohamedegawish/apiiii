<?php

namespace App\Features\Circles\Services;

use App\Enums\StudentStatus;
use App\Features\Students\Resources\StudentResource;
use App\Models\Circle;
use App\Models\Enrollment;
use App\Models\Student;
use Carbon\CarbonInterface;

/**
 * Deliberately independent of CircleService/CircleSessionService: both need
 * "who is enrolled as of a date" (one for the current-day roster, the other
 * for a specific session's date), and neither should have to pull in the
 * other's Spatie QueryBuilder-backed dependency graph just to reuse it —
 * QueryBuilder validates the *current* request's `?filter[]` params as soon
 * as an unrelated query object is constructed, so a `CircleSessionService`
 * that transitively constructed a `CircleQuery` would 400 on any session
 * request whose filters aren't also valid Circle filters.
 */
class CircleRosterService
{
    /**
     * Students enrolled in the circle as of a given date, with the active
     * enrollment id attached. Shares Enrollment::scopeCoveringDate with the
     * write-side validators, so a student listed here is guaranteed writable
     * for a session on that date.
     *
     * @return list<array<string, mixed>>
     */
    public function asOf(Circle $circle, CarbonInterface|string $date): array
    {
        $enrollments = Enrollment::where('circle_id', $circle->id)
            ->coveringDate($date)
            ->get()
            ->keyBy('student_id');

        $students = Student::query()
            ->whereKey($enrollments->keys())
            ->where('status', StudentStatus::Active)
            ->get();

        return $students->map(fn (Student $student): array => [
            ...StudentResource::make($student)->resolve(),
            'enrollment_id' => $enrollments->get($student->id)?->id,
        ])->all();
    }
}
