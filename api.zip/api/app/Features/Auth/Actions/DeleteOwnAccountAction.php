<?php

namespace App\Features\Auth\Actions;

use App\Enums\Role;
use App\Models\AuditLog;
use App\Models\User;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;
use App\Support\Services\AuditService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Deletes the authenticated user's own account (Google Play account-deletion
 * requirement) without destroying records the center is obliged to keep.
 *
 * What is removed for every role:
 *  - every API token, registered push device, in-app notification, push
 *    delivery log, pending password-reset code and stored idempotent response;
 *  - the login identifiers: email is replaced by a unique non-routable
 *    placeholder, phone is cleared, the password is replaced by a random hash;
 *  - those same identifiers inside the audit trail of the account itself.
 *
 * Student and guardian accounts are then soft-deleted and anonymised (name
 * becomes "حساب محذوف"), unlinked from their student / guardian record, and
 * the email mirrored onto that record is cleared. The record itself —
 * enrollment, attendance, learning, homework, evaluations, invoices and
 * payments — belongs to the center and is retained; removing it is a
 * separate request to the center administration.
 *
 * Staff accounts (teacher, center owner, super admin) keep their name because
 * payroll, expenses and session history resolve the staff member through the
 * user row; the account is deactivated and its identifiers erased. The last
 * active super admin cannot delete itself, as that would orphan the platform.
 */
class DeleteOwnAccountAction extends BaseAction
{
    public const DELETED_NAME = 'حساب محذوف';

    /** Identifiers erased from the account's own audit entries. */
    private const ERASED_ACCOUNT_KEYS = ['name', 'email', 'phone', 'email_verified_at', 'remember_token'];

    public function __construct(private readonly AuditService $auditService) {}

    public function execute(mixed ...$arguments): bool
    {
        $user = $arguments[0] ?? null;
        $password = $arguments[1] ?? null;

        if (! $user instanceof User || ! is_string($password)) {
            throw new \InvalidArgumentException('DeleteOwnAccountAction expects a user and their password.');
        }

        if (! Hash::check($password, $user->password)) {
            throw ValidationException::withMessages([
                'password' => ['كلمة المرور غير صحيحة.'],
            ]);
        }

        return $this->erase($user, 'self');
    }

    /**
     * Perform the deletion without a password check.
     *
     * Only for callers that have verified the request out of band: the
     * `account:delete` console command used for deletion requests received
     * through the public web page from users who can no longer sign in.
     */
    public function erase(User $user, string $initiatedBy): bool
    {
        return DB::transaction(function () use ($user, $initiatedBy): bool {
            /** @var User $user */
            $user = User::query()->whereKey($user->getKey())->lockForUpdate()->firstOrFail();

            if ($user->isSuperAdmin() && ! $this->anotherActiveSuperAdminExists($user)) {
                throw new ConflictException(
                    'لا يمكن حذف آخر حساب مدير عام نشط. أنشئ أو فعّل مديراً عاماً آخر أولاً.',
                    'last_super_admin',
                );
            }

            $role = $user->roleEnum();
            $selfService = $user->hasRole(Role::Student, Role::Parent);
            $originalEmail = $user->email;

            $this->eraseAccountArtifacts($user, $originalEmail);

            if ($selfService) {
                $this->unlinkProfileRecord($user, $role);
            }

            $user->forceFill([
                'name' => $selfService ? self::DELETED_NAME : $user->name,
                'email' => 'deleted-'.$user->getKey().'@deleted.invalid',
                'phone' => null,
                'email_verified_at' => null,
                'password' => Hash::make(Str::random(64)),
                'remember_token' => null,
                'is_active' => false,
            ]);
            // Quietly: the regular observer would copy the erased identifiers
            // into a fresh audit entry as "old values".
            $user->saveQuietly();

            $this->scrubAuditTrail($user, $selfService);

            $this->auditService->record(
                model: $user,
                action: 'account_deleted',
                new: ['role' => $role?->value, 'initiated_by' => $initiatedBy],
            );

            if ($selfService) {
                $user->deleteQuietly();
            }

            return true;
        });
    }

    private function anotherActiveSuperAdminExists(User $user): bool
    {
        return User::query()
            ->where('role', Role::SuperAdmin->value)
            ->where('is_active', true)
            ->whereKeyNot($user->getKey())
            ->exists();
    }

    private function eraseAccountArtifacts(User $user, ?string $originalEmail): void
    {
        $user->tokens()->delete();
        $user->deviceTokens()->delete();
        $user->notifications()->delete();

        DB::table('push_deliveries')->where('user_id', $user->getKey())->delete();
        DB::table('idempotency_keys')->where('user_id', $user->getKey())->delete();
        DB::table('sessions')->where('user_id', $user->getKey())->delete();

        if ($originalEmail !== null && $originalEmail !== '') {
            DB::table('password_reset_codes')->where('email', $originalEmail)->delete();
            DB::table('password_reset_tokens')->where('email', $originalEmail)->delete();
        }
    }

    /**
     * Detach the login from the center-owned student / guardian record and
     * clear the email the profile endpoint mirrors onto it.
     */
    private function unlinkProfileRecord(User $user, ?Role $role): void
    {
        $record = $role === Role::Student ? $user->student : $user->guardian;

        if ($record === null) {
            return;
        }

        $record->forceFill(['user_id' => null, 'email' => null])->saveQuietly();

        AuditLog::query()
            ->where('auditable_type', $record->getMorphClass())
            ->where('auditable_id', (string) $record->getKey())
            ->get()
            ->each(fn (AuditLog $log) => $this->eraseKeys($log, ['email', 'user_id']));
    }

    private function scrubAuditTrail(User $user, bool $selfService): void
    {
        $keys = $selfService
            ? self::ERASED_ACCOUNT_KEYS
            : array_values(array_diff(self::ERASED_ACCOUNT_KEYS, ['name']));

        AuditLog::query()
            ->where('auditable_type', $user->getMorphClass())
            ->where('auditable_id', (string) $user->getKey())
            ->get()
            ->each(fn (AuditLog $log) => $this->eraseKeys($log, $keys));
    }

    /**
     * @param  list<string>  $keys
     */
    private function eraseKeys(AuditLog $log, array $keys): void
    {
        $strip = static fn (?array $values): ?array => $values === null
            ? null
            : array_diff_key($values, array_flip($keys));

        DB::table($log->getTable())->where('id', $log->getKey())->update([
            'old_values' => $this->encode($strip($log->old_values)),
            'new_values' => $this->encode($strip($log->new_values)),
        ]);
    }

    private function encode(?array $values): ?string
    {
        return $values === null ? null : json_encode($values, JSON_UNESCAPED_UNICODE);
    }
}
