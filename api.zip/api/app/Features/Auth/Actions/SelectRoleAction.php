<?php

namespace App\Features\Auth\Actions;

use App\Enums\Role;
use App\Features\Auth\Requests\SelectRoleRequest;
use App\Models\User;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\UnauthenticatedException;
use Illuminate\Support\Facades\Hash;

/**
 * Issues a token for a specific role when a mobile number is shared between
 * multiple accounts (student / parent).
 */
class SelectRoleAction extends BaseAction
{
    /**
     * Execute the role-selection login.
     *
     * @return array{0: User, 1: string}
     *
     * @throws UnauthenticatedException
     */
    public function execute(mixed ...$arguments): array
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof SelectRoleRequest) {
            throw new \InvalidArgumentException('SelectRoleAction expects a SelectRoleRequest.');
        }

        $data = $request->validatedData();

        /** @var User|null $user */
        $user = User::where('phone', $data['mobile'])
            ->where('role', $data['role'])
            // Backstop: validation is not the only thing keeping a staff
            // account out of this endpoint.
            ->whereIn('role', Role::selfServiceValues())
            ->first();

        if ($user === null || ! $user->is_active || ! Hash::check($data['password'], $user->password)) {
            throw new UnauthenticatedException('The provided credentials are incorrect.');
        }

        $deviceName = trim($request->string('device_name')->toString()) ?: 'api';
        $token = $user->createToken($deviceName);

        $user->load(['teacher', 'student']);

        return [$user, $token->plainTextToken];
    }
}
