<?php

namespace App\Features\Auth\Actions;

use App\Models\User;
use App\Support\Actions\BaseAction;
use Illuminate\Http\Request;

/**
 * Revokes the current Sanctum token for the authenticated user.
 */
class LogoutAction extends BaseAction
{
    /**
     * Execute the logout action.
     */
    public function execute(mixed ...$arguments): bool
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof Request) {
            throw new \InvalidArgumentException('LogoutAction expects an Illuminate Http Request.');
        }

        /** @var User|null $user */
        $user = $request->user();

        if ($user === null) {
            return false;
        }

        $user->currentAccessToken()?->delete();

        return true;
    }
}
