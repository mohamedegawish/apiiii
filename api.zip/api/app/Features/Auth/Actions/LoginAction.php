<?php

namespace App\Features\Auth\Actions;

use App\Enums\Role;
use App\Features\Auth\Requests\LoginRequest;
use App\Models\Student;
use App\Models\User;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\UnauthenticatedException;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Hash;

/**
 * Authenticates a user with email (staff), mobile (student/parent),
 * or student_code (student only) and issues a Sanctum token.
 *
 * When a mobile number is shared by multiple active accounts (e.g. a student
 * and their guardian), the action signals that role selection is required
 * instead of issuing a token.
 */
class LoginAction extends BaseAction
{
    /**
     * Roles that can share a mobile number and require role selection.
     *
     * @var list<Role>
     */
    private const SELF_SERVICE_ROLES = [Role::Student, Role::Parent];

    /**
     * Execute the login action.
     *
     * @return array{user: User|null, token: string|null, requires_role_selection: bool, available_roles: list<string>}
     *
     * @throws UnauthenticatedException
     */
    public function execute(mixed ...$arguments): array
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof LoginRequest) {
            throw new \InvalidArgumentException('LoginAction expects a LoginRequest.');
        }

        $data = $request->validatedData();

        if (! empty($data['student_code'])) {
            return $this->loginWithStudentCode($data['student_code'], $data['password'], $request);
        }

        if (! empty($data['mobile'])) {
            return $this->loginWithMobile($data['mobile'], $data['password'], $request);
        }

        return $this->loginWithEmail($data['email'], $data['password'], $request);
    }

    /**
     * Staff login: a single account is identified by its unique email.
     *
     * @return array{user: User, token: string, requires_role_selection: false, available_roles: list<string>}
     */
    private function loginWithEmail(string $email, string $password, LoginRequest $request): array
    {
        /** @var User|null $user */
        $user = User::where('email', $email)->first();

        if ($user === null || ! Hash::check($password, $user->password) || ! $user->is_active) {
            throw new UnauthenticatedException('The provided credentials are incorrect.');
        }

        return [
            'user' => $user,
            'token' => $this->issueToken($user, $request),
            'requires_role_selection' => false,
            'available_roles' => [],
        ];
    }

    /**
     * Student/parent login: the mobile may identify one or more accounts.
     *
     * @return array{user: User|null, token: string|null, requires_role_selection: bool, available_roles: list<string>}
     */
    private function loginWithMobile(string $mobile, string $password, LoginRequest $request): array
    {
        /** @var Collection<int, User> $users */
        $users = User::where('phone', $mobile)
            ->whereIn('role', array_map(fn (Role $role) => $role->value, self::SELF_SERVICE_ROLES))
            ->get();

        /** @var Collection<int, User> $authenticatedUsers */
        $authenticatedUsers = $users->filter(
            fn (User $user) => $user->is_active && Hash::check($password, $user->password)
        )->values();

        if ($authenticatedUsers->isEmpty()) {
            throw new UnauthenticatedException('The provided credentials are incorrect.');
        }

        if ($authenticatedUsers->count() === 1) {
            /** @var User $user */
            $user = $authenticatedUsers->first();

            return [
                'user' => $user,
                'token' => $this->issueToken($user, $request),
                'requires_role_selection' => false,
                'available_roles' => [],
            ];
        }

        return [
            'user' => null,
            'token' => null,
            'requires_role_selection' => true,
            'available_roles' => array_values(array_filter(
                array_map(fn (Role $role): ?string => $authenticatedUsers->contains(
                    fn (User $user): bool => $user->roleEnum() === $role
                ) ? $role->value : null, self::SELF_SERVICE_ROLES)
            )),
        ];
    }

    /**
     * Student-only login: resolve via the student_code on the students table.
     *
     * The student_code identifies a single Student record. The linked User
     * (via user_id) must exist, be active, and hold the Student role.
     * This path never triggers role selection and cannot authenticate
     * teachers, admins, or guardians.
     *
     * @return array{user: User, token: string, requires_role_selection: false, available_roles: list<string>}
     */
    private function loginWithStudentCode(string $studentCode, string $password, LoginRequest $request): array
    {
        $student = Student::where('student_code', $studentCode)->first();

        if ($student === null || $student->user_id === null) {
            throw new UnauthenticatedException('The provided credentials are incorrect.');
        }

        /** @var User|null $user */
        $user = User::where('id', $student->user_id)
            ->where('role', Role::Student->value)
            ->first();

        if ($user === null || ! $user->is_active || ! Hash::check($password, $user->password)) {
            throw new UnauthenticatedException('The provided credentials are incorrect.');
        }

        return [
            'user' => $user,
            'token' => $this->issueToken($user, $request),
            'requires_role_selection' => false,
            'available_roles' => [],
        ];
    }

    /**
     * Issue a Sanctum token for the authenticated user.
     */
    private function issueToken(User $user, LoginRequest $request): string
    {
        $deviceName = trim($request->string('device_name')->toString()) ?: 'api';
        $token = $user->createToken($deviceName);

        // Load scope relations so the login response carries teacher_id.
        $user->load(['teacher', 'student']);

        return $token->plainTextToken;
    }
}
