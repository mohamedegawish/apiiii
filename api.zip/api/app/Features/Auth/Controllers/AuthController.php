<?php

namespace App\Features\Auth\Controllers;

use App\Features\Auth\Actions\DeleteOwnAccountAction;
use App\Features\Auth\Requests\DeleteAccountRequest;
use App\Features\Auth\Requests\ForgotPasswordRequest;
use App\Features\Auth\Requests\LoginRequest;
use App\Features\Auth\Requests\ResetPasswordRequest;
use App\Features\Auth\Requests\SelectRoleRequest;
use App\Features\Auth\Requests\UpdateProfileRequest;
use App\Features\Auth\Requests\VerifyOtpRequest;
use App\Features\Auth\Resources\TokenDeviceResource;
use App\Features\Auth\Resources\TokenResource;
use App\Features\Auth\Resources\UserResource;
use App\Features\Auth\Services\AuthService;
use App\Features\Auth\Services\PasswordResetService;
use App\Models\User;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AuthController extends BaseController
{
    public function __construct(
        protected AuthService $authService,
        protected PasswordResetService $passwordResetService,
    ) {}

    /**
     * Authenticate the user and issue an API token.
     *
     * When a mobile number is shared by multiple accounts, the response asks
     * the client to select a role instead of returning a token.
     */
    public function login(LoginRequest $request): JsonResponse
    {
        $result = $this->authService->login($request);

        if ($result['requires_role_selection']) {
            return $this->success(
                data: [
                    'requires_role_selection' => true,
                    'available_roles' => $result['available_roles'],
                ],
                message: 'Multiple accounts found. Please select a role.',
                status: 200,
            );
        }

        /** @var User $user */
        $user = $result['user'];

        $user->loadMissing(['teacher', 'student']);

        return $this->success(
            data: [
                'user' => UserResource::make($user)->resolve(),
                'token' => TokenResource::make($result['token'], 'api', $this->tokenExpiry())->resolve(),
                'permissions' => $user->roleEnum()?->permissions() ?? [],
                'requires_role_selection' => false,
            ],
            message: 'Login successful.',
            status: 200,
        );
    }

    /**
     * Issue a token for a specific role when the mobile number is shared
     * between multiple accounts (student / parent).
     */
    public function selectRole(SelectRoleRequest $request): JsonResponse
    {
        [$user, $plainTextToken] = $this->authService->selectRole($request);
        $user->loadMissing(['teacher', 'student']);

        return $this->success(
            data: [
                'user' => UserResource::make($user)->resolve(),
                'token' => TokenResource::make($plainTextToken, 'api', $this->tokenExpiry())->resolve(),
                'permissions' => $user->roleEnum()?->permissions() ?? [],
                'requires_role_selection' => false,
            ],
            message: 'Login successful.',
            status: 200,
        );
    }

    /**
     * Revoke the current access token.
     */
    public function logout(Request $request): JsonResponse
    {
        $this->authService->logout($request);

        return $this->success(
            data: null,
            message: 'Logged out successfully.',
        );
    }

    public function logoutAll(Request $request): JsonResponse
    {
        $this->authService->logoutAll($request);

        return $this->success(data: null, message: 'Logged out from all devices successfully.');
    }

    public function tokenDevices(Request $request): JsonResponse
    {
        return $this->success(
            data: TokenDeviceResource::collection($this->authService->tokenDevices($request)),
            message: 'Token devices retrieved successfully.',
        );
    }

    public function revokeToken(Request $request, string $token): JsonResponse
    {
        $this->authService->revokeToken($request, $token);

        return $this->success(data: null, message: 'Token revoked successfully.');
    }

    public function updateDeviceName(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'device_name' => ['required', 'string', 'max:120'],
        ]);

        $this->authService->updateDeviceName($request, $validated['device_name']);

        return $this->success(data: null, message: 'Device name updated successfully.');
    }

    /**
     * Return the authenticated user's profile.
     */
    public function me(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $user->loadMissing(['teacher', 'student']);

        return $this->success(
            data: UserResource::make($user),
            message: 'Profile retrieved successfully.',
        );
    }

    /**
     * Update the authenticated user's profile.
     */
    public function updateProfile(UpdateProfileRequest $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        $user = $this->authService->updateProfile($user, $request->validatedData());
        $user->loadMissing(['teacher', 'student']);

        return $this->success(
            data: UserResource::make($user),
            message: 'Profile updated successfully.',
        );
    }

    /**
     * Delete the authenticated user's own account.
     *
     * Requires the current password and an explicit confirmation. See
     * DeleteOwnAccountAction for exactly what is erased and what the center
     * retains.
     */
    public function deleteAccount(DeleteAccountRequest $request, DeleteOwnAccountAction $action): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $action->execute($user, $request->string('password')->toString());

        return $this->success(
            data: ['deleted' => true],
            message: 'تم حذف الحساب.',
        );
    }

    /**
     * Request a password-reset OTP for the given email.
     *
     * Always responds 200 without exposing account existence or the OTP.
     */
    public function forgotPassword(ForgotPasswordRequest $request): JsonResponse
    {
        $this->passwordResetService->sendCode($request->string('email')->toString());

        return $this->success(
            data: null,
            message: 'إن كان الحساب مسجّلاً لدينا، فقد أُرسل رمز التحقّق.',
        );
    }

    /**
     * Verify a password-reset OTP and issue a short-lived reset token.
     */
    public function verifyOtp(VerifyOtpRequest $request): JsonResponse
    {
        $token = $this->passwordResetService->verifyCode(
            $request->string('email')->toString(),
            $request->string('code')->toString(),
        );

        return $this->success(
            data: ['reset_token' => $token],
            message: 'تم التحقّق من الرمز بنجاح.',
        );
    }

    /**
     * Reset the password using a verified reset token.
     */
    public function resetPassword(ResetPasswordRequest $request): JsonResponse
    {
        $this->passwordResetService->resetPassword(
            $request->string('email')->toString(),
            $request->string('token')->toString(),
            $request->string('password')->toString(),
        );

        return $this->success(
            data: null,
            message: 'تم تحديث كلمة المرور بنجاح. يمكنك تسجيل الدخول الآن.',
        );
    }

    /**
     * When the token just issued expires, or null when tokens never expire.
     *
     * Sanctum enforces `sanctum.expiration` server-side, but this was never
     * passed to TokenResource -- so the API reported `expires_at: null` while
     * silently invalidating the token 30 days later, leaving clients no way to
     * refresh ahead of a surprise 401.
     */
    private function tokenExpiry(): ?string
    {
        $minutes = config('sanctum.expiration');

        return $minutes === null ? null : now()->addMinutes((int) $minutes)->toIso8601String();
    }
}
