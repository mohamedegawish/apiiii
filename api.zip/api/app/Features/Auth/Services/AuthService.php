<?php

namespace App\Features\Auth\Services;

use App\Enums\Role;
use App\Features\Auth\Actions\LoginAction;
use App\Features\Auth\Actions\LogoutAction;
use App\Features\Auth\Actions\SelectRoleAction;
use App\Features\Auth\Requests\LoginRequest;
use App\Features\Auth\Requests\SelectRoleRequest;
use App\Models\User;
use App\Support\Services\BaseService;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Validation\ValidationException;
use Laravel\Sanctum\PersonalAccessToken;

/**
 * Application service coordinating authentication flows.
 */
class AuthService extends BaseService
{
    public function __construct(
        protected LoginAction $loginAction,
        protected SelectRoleAction $selectRoleAction,
        protected LogoutAction $logoutAction,
    ) {}

    /**
     * Authenticate a user and issue a Sanctum token.
     *
     * @return array{user: User|null, token: string|null, requires_role_selection: bool, available_roles: list<string>}
     */
    public function login(LoginRequest $request): array
    {
        return $this->transaction(fn (): array => $this->loginAction->execute($request));
    }

    /**
     * Issue a token for a specific role on a shared mobile number.
     *
     * @return array{0: User, 1: string}
     */
    public function selectRole(SelectRoleRequest $request): array
    {
        return $this->transaction(fn (): array => $this->selectRoleAction->execute($request));
    }

    /**
     * Revoke the current access token.
     */
    public function logout(Request $request): bool
    {
        return $this->transaction(fn (): bool => $this->logoutAction->execute($request));
    }

    /**
     * Revoke every access token belonging to the authenticated user.
     */
    public function logoutAll(Request $request): bool
    {
        return $this->transaction(function () use ($request): bool {
            $user = $request->user();

            if (! $user instanceof User) {
                return false;
            }

            $user->tokens()->delete();

            return true;
        });
    }

    /**
     * List only the authenticated user's access tokens.
     *
     * @return Collection<int, PersonalAccessToken>
     */
    public function tokenDevices(Request $request): Collection
    {
        $user = $request->user();

        if (! $user instanceof User) {
            return new Collection;
        }

        return $user->tokens()
            ->latest('last_used_at')
            ->latest('created_at')
            ->get(['id', 'tokenable_id', 'tokenable_type', 'name', 'last_used_at', 'created_at', 'expires_at']);
    }

    /**
     * Revoke one access token, constrained to the authenticated user.
     */
    public function revokeToken(Request $request, string|int $tokenId): bool
    {
        return $this->transaction(function () use ($request, $tokenId): bool {
            $user = $request->user();

            if (! $user instanceof User || $user->tokens()->whereKey($tokenId)->delete() === 0) {
                throw ValidationException::withMessages([
                    'token_id' => ['The selected token is invalid.'],
                ]);
            }

            return true;
        });
    }

    /**
     * Update the authenticated user's profile fields.
     *
     * Student and guardian accounts mirror a domain record (students /
     * guardians) that staff screens and the student profile read their name
     * and email from. Their name and email are written to both rows in the
     * same transaction, as UpdateStudentAction does from the admin side, so
     * the login account and the record never drift apart.
     *
     * Their phone is the mobile login identifier and is managed by the
     * center: it is never written here (UpdateProfileRequest rejects a
     * different value), so a profile edit cannot change or clear how they
     * sign in.
     *
     * @param  array<string, mixed>  $data
     */
    public function updateProfile(User $user, array $data): User
    {
        return $this->transaction(function () use ($user, $data): User {
            $selfService = $user->hasRole(Role::Student, Role::Parent);
            $fields = $selfService
                ? ['name', 'email', 'locale', 'timezone']
                : ['name', 'email', 'phone', 'locale', 'timezone'];

            $user->update(Arr::only($data, $fields));

            if ($selfService) {
                $record = $user->hasRole(Role::Student) ? $user->student : $user->guardian;
                $record?->update(Arr::only($data, ['name', 'email']));
            }

            return $user;
        });
    }

    /**
     * Rename the current access token's device label.
     */
    public function updateDeviceName(Request $request, string $deviceName): bool
    {
        return $this->transaction(function () use ($request, $deviceName): bool {
            $token = $request->user()?->currentAccessToken();

            if (! $token instanceof PersonalAccessToken) {
                return false;
            }

            $token->forceFill(['name' => trim($deviceName)])->save();

            return true;
        });
    }
}
