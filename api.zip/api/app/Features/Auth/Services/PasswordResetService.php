<?php

namespace App\Features\Auth\Services;

use App\Models\PasswordResetCode;
use App\Models\User;
use App\Notifications\PasswordResetCodeNotification;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Coordinates the OTP-based password-reset flow:
 * request code → verify code → reset password.
 */
class PasswordResetService
{
    private const CODE_TTL_MINUTES = 10;

    private const MAX_ATTEMPTS = 5;

    /**
     * Issue an OTP for the given email and deliver it.
     *
     * Returns the plaintext code internally for delivery. Callers must never
     * include it in an HTTP response.
     */
    public function sendCode(string $email): ?string
    {
        $user = User::where('email', $email)->first();

        if ($user === null) {
            return null;
        }

        $code = str_pad((string) random_int(0, 9999), 4, '0', STR_PAD_LEFT);

        DB::transaction(function () use ($email, $code): void {
            PasswordResetCode::where('email', $email)->delete();

            PasswordResetCode::create([
                'email' => $email,
                'code_hash' => Hash::make($code),
                'expires_at' => now()->addMinutes(self::CODE_TTL_MINUTES),
            ]);
        });

        $user->notify(new PasswordResetCodeNotification($code, self::CODE_TTL_MINUTES));

        return $code;
    }

    /**
     * Verify an OTP and issue a short-lived reset token.
     *
     * @throws ValidationException
     */
    public function verifyCode(string $email, string $code): string
    {
        $token = DB::transaction(function () use ($email, $code): ?string {
            $record = PasswordResetCode::where('email', $email)->latest('created_at')->lockForUpdate()->first();

            if ($record === null || $record->isExpired() || $record->reset_token_hash !== null) {
                throw ValidationException::withMessages(['code' => ['رمز التحقّق غير صحيح أو منتهٍ.']]);
            }

            if ($record->attempts >= self::MAX_ATTEMPTS) {
                throw ValidationException::withMessages(['code' => ['تجاوزت عدد المحاولات المسموحة. اطلب رمزاً جديداً.']]);
            }

            if (! Hash::check($code, $record->code_hash)) {
                $record->increment('attempts');

                return null;
            }

            $token = Str::random(64);

            $record->forceFill([
                'code_hash' => Hash::make(Str::random(64)),
                'reset_token_hash' => Hash::make($token),
                'attempts' => 0,
                'expires_at' => now()->addMinutes(self::CODE_TTL_MINUTES),
            ])->save();

            return $token;
        });

        if ($token === null) {
            throw ValidationException::withMessages(['code' => ['رمز التحقّق غير صحيح.']]);
        }

        return $token;
    }

    /**
     * Set a new password using a verified reset token.
     *
     * @throws ValidationException
     */
    public function resetPassword(string $email, string $token, string $password): void
    {
        DB::transaction(function () use ($email, $token, $password): void {
            $record = PasswordResetCode::where('email', $email)
                ->whereNotNull('reset_token_hash')
                ->latest('created_at')
                ->lockForUpdate()
                ->first();

            if ($record === null || $record->isExpired() || ! Hash::check($token, $record->reset_token_hash)) {
                throw ValidationException::withMessages(['token' => ['جلسة إعادة التعيين غير صالحة أو منتهية. أعد المحاولة.']]);
            }

            $user = User::where('email', $email)->lockForUpdate()->first();

            if ($user === null) {
                throw ValidationException::withMessages(['email' => ['الحساب غير موجود.']]);
            }

            $user->forceFill(['password' => Hash::make($password)])->save();
            $user->tokens()->delete();
            PasswordResetCode::where('email', $email)->delete();
        });
    }
}
