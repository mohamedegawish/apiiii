<?php

namespace App\Features\Auth\Requests;

use App\Support\Http\Requests\BaseRequest;

/**
 * Self-service account deletion.
 *
 * The current password is required even though the caller already holds a
 * token: a token left on an unlocked or shared phone must not be enough to
 * erase an account. `confirm` is the explicit, non-default acknowledgement
 * the client collects after showing what will and will not be removed.
 */
class DeleteAccountRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'password' => ['required', 'string', 'max:255'],
            'confirm' => ['required', 'accepted'],
        ];
    }
}
