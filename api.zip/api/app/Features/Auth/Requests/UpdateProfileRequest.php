<?php

namespace App\Features\Auth\Requests;

use App\Enums\Role;
use App\Models\User;
use App\Support\Http\Requests\BaseRequest;
use Closure;
use Illuminate\Validation\Rule;

class UpdateProfileRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => [
                'nullable',
                'string',
                'email',
                'max:255',
                Rule::unique('users', 'email')->ignore($this->user()),
            ],
            'phone' => ['nullable', 'string', 'max:30', $this->phoneIsNotLoginIdentifier(...)],
            'locale' => ['sometimes', 'string', 'max:10'],
            'timezone' => ['sometimes', 'string', 'max:50'],
        ];
    }

    /**
     * A student's or guardian's phone is their mobile login identifier (and
     * may be shared between a student and their guardian), so it is managed
     * by the center rather than self-service. Re-sending the current value is
     * accepted so a client can round-trip the profile form unchanged.
     */
    private function phoneIsNotLoginIdentifier(string $attribute, mixed $value, Closure $fail): void
    {
        $user = $this->user();

        if (! $user instanceof User || ! $user->hasRole(Role::Student, Role::Parent)) {
            return;
        }

        if ((string) $value !== (string) $user->phone) {
            $fail('The mobile number is used to sign in and can only be changed by the center.');
        }
    }
}
