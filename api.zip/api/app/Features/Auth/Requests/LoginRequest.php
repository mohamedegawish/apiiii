<?php

namespace App\Features\Auth\Requests;

use App\Support\Http\Requests\BaseRequest;

class LoginRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'email' => ['required_without_all:mobile,student_code', 'nullable', 'string', 'email', 'max:255'],
            'mobile' => ['required_without_all:email,student_code', 'nullable', 'string', 'max:30'],
            'student_code' => ['required_without_all:email,mobile', 'nullable', 'string', 'max:20'],
            'password' => ['required', 'string', 'min:1', 'max:255'],
            'device_name' => ['nullable', 'string', 'max:120'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'email.required_without_all' => 'The email, mobile, or student code field is required.',
            'email.email' => 'Please provide a valid email address.',
            'mobile.required_without_all' => 'The email, mobile, or student code field is required.',
            'student_code.required_without_all' => 'The email, mobile, or student code field is required.',
            'password.required' => 'The password field is required.',
        ];
    }
}
