<?php

namespace App\Features\Auth\Requests;

use App\Support\Http\Requests\BaseRequest;

class VerifyOtpRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'email' => ['required', 'string', 'email', 'max:255'],
            'code' => ['required', 'string', 'digits:4'],
        ];
    }
}
