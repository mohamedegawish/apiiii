<?php

namespace App\Features\Auth\Requests;

use App\Enums\Role;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class SelectRoleRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'mobile' => ['required', 'string', 'max:30'],
            'password' => ['required', 'string', 'min:1', 'max:255'],
            'role' => ['required', 'string', Rule::in(Role::selfServiceValues())],
            'device_name' => ['nullable', 'string', 'max:120'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'mobile.required' => 'The mobile field is required.',
            'password.required' => 'The password field is required.',
            'role.required' => 'The role field is required.',
            'role.in' => 'The selected role is invalid.',
        ];
    }
}
