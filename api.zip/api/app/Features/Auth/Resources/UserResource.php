<?php

namespace App\Features\Auth\Resources;

use App\Models\User;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * @mixin User
 */
class UserResource extends BaseResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'phone' => $this->phone,
            'role' => [
                'value' => $this->roleEnum()?->value,
                'label' => $this->roleEnum()?->name,
            ],
            // Teacher profile id (present only when the user is a teacher). Lets
            // the client default the "teacher" field in field-operation forms.
            'teacher_id' => $this->teacher?->id,
            'student_id' => $this->student?->id,
            'student_code' => $this->student?->student_code,
            'locale' => $this->locale,
            'timezone' => $this->timezone,
            'is_active' => $this->is_active,
            'email_verified_at' => $this->email_verified_at?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
