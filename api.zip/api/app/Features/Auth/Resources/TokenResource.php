<?php

namespace App\Features\Auth\Resources;

use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * Represents a freshly issued Sanctum token response. The plaintext token
 * is only ever returned once, at the moment of creation.
 */
class TokenResource extends BaseResource
{
    public function __construct(
        protected string $plainTextToken,
        protected string $tokenName,
        protected ?string $expiresAt = null,
    ) {
        parent::__construct(null);
    }

    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'token' => $this->plainTextToken,
            'type' => 'Bearer',
            'name' => $this->tokenName,
            'expires_at' => $this->expiresAt,
        ];
    }
}
