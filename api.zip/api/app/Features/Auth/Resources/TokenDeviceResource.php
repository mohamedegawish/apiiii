<?php

namespace App\Features\Auth\Resources;

use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;
use Laravel\Sanctum\PersonalAccessToken;

/** @mixin PersonalAccessToken */
class TokenDeviceResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'last_used_at' => $this->last_used_at?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
            'expires_at' => $this->expires_at?->toIso8601String(),
            'is_current' => (string) $this->id === (string) $request->user()?->currentAccessToken()?->getKey(),
        ];
    }
}
