<?php

namespace App\Features\Reports\Requests;

use App\Support\Http\Requests\BaseRequest;

/**
 * The teacher-editable half of a monthly progress row.
 *
 * Only the free-text references and notes are writable. The numeric
 * aggregates (attendance counts and percentages) are derived from attendance
 * and learning records by GenerateMonthlyProgressAction and are deliberately
 * not accepted here -- letting them be typed in would create a second,
 * divergent source of truth for figures the canonical tables already answer.
 */
class UpdateMonthlyProgressRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'memorization_start_ref' => ['sometimes', 'nullable', 'string', 'max:500'],
            'memorization_end_ref' => ['sometimes', 'nullable', 'string', 'max:500'],
            'revision_start_ref' => ['sometimes', 'nullable', 'string', 'max:500'],
            'revision_end_ref' => ['sometimes', 'nullable', 'string', 'max:500'],
            'matn_start_ref' => ['sometimes', 'nullable', 'string', 'max:500'],
            'matn_end_ref' => ['sometimes', 'nullable', 'string', 'max:500'],
            'notes' => ['sometimes', 'nullable', 'string', 'max:2000'],

            'sessions_count' => ['prohibited'],
            'attended_sessions' => ['prohibited'],
            'missed_sessions' => ['prohibited'],
            'attendance_percentage' => ['prohibited'],
            'absence_percentage' => ['prohibited'],
            'student_id' => ['prohibited'],
            'circle_id' => ['prohibited'],
            'year' => ['prohibited'],
            'month' => ['prohibited'],
        ];
    }
}
