<?php

namespace App\Features\Reports\Requests;

use App\Support\Http\Requests\BaseRequest;

class GenerateMonthlyProgressRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'year' => ['required', 'integer', 'min:2000', 'max:2200'],
            'month' => ['required', 'integer', 'min:1', 'max:12'],
            'circle_id' => ['nullable', 'uuid', 'exists:circles,id'],
        ];
    }
}
