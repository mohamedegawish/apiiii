<?php

namespace App\Features\Reports\Requests;

use App\Enums\Role;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class ReportRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasRole(Role::SuperAdmin, Role::CenterOwner, Role::Teacher) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'date_from' => ['nullable', 'date'],
            'date_to' => ['nullable', 'date', 'after_or_equal:date_from'],
            'circle_id' => ['nullable', 'uuid', 'exists:circles,id'],
            'student_id' => ['nullable', 'uuid', 'exists:students,id'],
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
            'format' => ['nullable', Rule::in(['json', 'csv'])],
        ];
    }
}
