<?php

namespace App\Features\Reports\Services;

use App\Enums\Role;
use App\Models\User;
use App\Support\Exceptions\ForbiddenException;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class ReportService
{
    /** @param array<string, mixed> $filters */
    public function studentProgress(User $user, array $filters): LengthAwarePaginator
    {
        // Grouped by type: memorization and revision are different competencies,
        // so blending their scores/counts into one row would average two
        // unrelated things together and double-count "learning_records".
        $query = DB::table('student_learning_records as records')
            ->join('students', 'students.id', '=', 'records.student_id')
            ->join('circle_sessions as sessions', 'sessions.id', '=', 'records.circle_session_id')
            ->join('circles', 'circles.id', '=', 'sessions.circle_id')
            ->select([
                'students.id as student_id',
                'students.name as student_name',
                'circles.id as circle_id',
                'circles.name as circle_name',
                'records.type as type',
            ])
            ->selectRaw('COUNT(records.id) as learning_records')
            ->selectRaw('ROUND(AVG(records.score), 2) as average_score')
            // Global ayah numbers make this correct for ranges that cross a
            // surah boundary; COALESCE covers rows written before that column
            // existed (or via factories that don't set it).
            ->selectRaw('SUM(COALESCE(records.to_global_ayah, records.to_ayah) - COALESCE(records.from_global_ayah, records.from_ayah) + 1) as ayahs_covered')
            ->whereNull('records.deleted_at')
            ->whereNull('students.deleted_at')
            ->whereNull('sessions.deleted_at')
            ->whereNull('circles.deleted_at')
            ->groupBy('students.id', 'students.name', 'circles.id', 'circles.name', 'records.type')
            ->orderBy('students.name');

        $this->applyDates($query, $filters, 'records.created_at');
        $this->applyFilters($query, $filters, 'circles.id', 'students.id');
        $this->applyScope($query, $user, 'circles.teacher_id');

        return $this->paginate($query, $filters);
    }

    /** @param array<string, mixed> $filters */
    public function monthlyProgress(User $user, array $filters): LengthAwarePaginator
    {
        $query = DB::table('monthly_progress_records as records')
            ->join('students', 'students.id', '=', 'records.student_id')
            ->join('circles', 'circles.id', '=', 'records.circle_id')
            ->select([
                'records.id as record_id',
                'students.id as student_id',
                'students.name as student_name',
                'students.student_code as student_code',
                'circles.id as circle_id',
                'circles.name as circle_name',
                'records.year as year',
                'records.month as month',
                'records.memorization_start_ref',
                'records.memorization_end_ref',
                'records.revision_start_ref',
                'records.revision_end_ref',
                'records.matn_start_ref',
                'records.matn_end_ref',
                'records.listening_score',
                'records.attendance_percentage',
                'records.absence_percentage',
                'records.sessions_count',
                'records.attended_sessions',
                'records.missed_sessions',
                'records.notes',
            ])
            ->whereNull('students.deleted_at')
            ->whereNull('circles.deleted_at')
            ->orderBy('records.year', 'desc')
            ->orderBy('records.month', 'desc')
            ->orderBy('students.name')
            // Student names repeat; without a unique last key a client walking
            // the pages could skip or repeat a row at a page boundary.
            ->orderBy('records.id');

        if (isset($filters['year'])) {
            $query->where('records.year', $filters['year']);
        }
        if (isset($filters['month'])) {
            $query->where('records.month', $filters['month']);
        }

        $this->applyFilters($query, $filters, 'circles.id', 'students.id');
        $this->applyScope($query, $user, 'circles.teacher_id');

        return $this->paginate($query, $filters);
    }

    /** @param array<string, mixed> $filters */
    public function attendance(User $user, array $filters): LengthAwarePaginator
    {
        $query = DB::table('attendances')
            ->join('students', 'students.id', '=', 'attendances.student_id')
            ->leftJoin('circles', 'circles.id', '=', 'attendances.circle_id')
            ->select([
                'students.id as student_id',
                'students.student_code as student_code',
                'students.name as student_name',
                'circles.id as circle_id',
                'circles.name as circle_name',
            ])
            ->selectRaw('COUNT(attendances.id) as attendance_records')
            ->selectRaw("SUM(CASE WHEN attendances.status = 'present' THEN 1 ELSE 0 END) as present_count")
            ->selectRaw("SUM(CASE WHEN attendances.status = 'absent' THEN 1 ELSE 0 END) as absent_count")
            ->selectRaw("SUM(CASE WHEN attendances.status = 'late' THEN 1 ELSE 0 END) as late_count")
            ->selectRaw("ROUND(100.0 * SUM(CASE WHEN attendances.status IN ('present', 'late') THEN 1 ELSE 0 END) / NULLIF(COUNT(attendances.id), 0), 2) as attendance_rate")
            ->whereNull('attendances.deleted_at')
            ->whereNull('students.deleted_at')
            ->groupBy('students.id', 'students.student_code', 'students.name', 'circles.id', 'circles.name')
            ->orderBy('students.name');

        $this->applyDates($query, $filters, 'attendances.attendance_date');
        $this->applyFilters($query, $filters, 'attendances.circle_id', 'students.id');
        $this->applyScope($query, $user, 'circles.teacher_id');

        return $this->paginate($query, $filters);
    }

    /** @param array<string, mixed> $filters */
    public function monthlyAttendance(User $user, array $filters): LengthAwarePaginator
    {
        // A detailed report showing individual attendance records grouped by student and session date.
        $query = DB::table('attendances')
            ->join('students', 'students.id', '=', 'attendances.student_id')
            ->leftJoin('circles', 'circles.id', '=', 'attendances.circle_id')
            ->select([
                'students.id as student_id',
                'students.student_code as student_code',
                'students.name as student_name',
                'circles.id as circle_id',
                'circles.name as circle_name',
                'attendances.attendance_date as attendance_date',
                'attendances.status as status',
                'attendances.notes as notes',
            ])
            ->whereNull('attendances.deleted_at')
            ->whereNull('students.deleted_at')
            ->orderBy('students.name')
            ->orderBy('attendances.attendance_date');

        $this->applyDates($query, $filters, 'attendances.attendance_date');
        $this->applyFilters($query, $filters, 'attendances.circle_id', 'students.id');
        $this->applyScope($query, $user, 'circles.teacher_id');

        return $this->paginate($query, $filters);
    }

    /** @param array<string, mixed> $filters */
    public function teacherPerformance(User $user, array $filters): LengthAwarePaginator
    {
        // Grouped by type — see studentProgress() for why.
        $query = DB::table('student_learning_records as records')
            ->join('teachers', 'teachers.id', '=', 'records.teacher_id')
            ->join('users', 'users.id', '=', 'teachers.user_id')
            ->join('students', 'students.id', '=', 'records.student_id')
            ->join('circle_sessions as sessions', 'sessions.id', '=', 'records.circle_session_id')
            ->select(['teachers.id as teacher_id', 'users.name as teacher_name', 'records.type as type'])
            ->selectRaw('COUNT(records.id) as learning_records')
            ->selectRaw('COUNT(DISTINCT records.student_id) as students_taught')
            ->selectRaw('ROUND(AVG(records.score), 2) as average_score')
            ->selectRaw('SUM(COALESCE(records.to_global_ayah, records.to_ayah) - COALESCE(records.from_global_ayah, records.from_ayah) + 1) as ayahs_covered')
            ->whereNull('records.deleted_at')
            ->whereNull('teachers.deleted_at')
            ->whereNull('students.deleted_at')
            ->whereNull('sessions.deleted_at')
            ->groupBy('teachers.id', 'users.name', 'records.type')
            ->orderBy('users.name');

        $this->applyDates($query, $filters, 'records.created_at');
        $this->applyFilters($query, $filters, 'sessions.circle_id', 'records.student_id');
        $this->applyScope($query, $user, 'teachers.id');

        return $this->paginate($query, $filters);
    }

    /** @param array<string, mixed> $filters */
    public function parentEngagement(User $user, array $filters): LengthAwarePaginator
    {
        $query = DB::table('parent_evaluations as evaluations')
            ->join('guardians', 'guardians.id', '=', 'evaluations.guardian_id')
            ->leftJoin('users', 'users.id', '=', 'guardians.user_id')
            ->join('students', 'students.id', '=', 'evaluations.student_id')
            ->join('circle_sessions as sessions', 'sessions.id', '=', 'evaluations.circle_session_id')
            ->join('circles', 'circles.id', '=', 'sessions.circle_id')
            ->select([
                'guardians.id as guardian_id',
                DB::raw('COALESCE(users.name, guardians.name) as guardian_name'),
            ])
            ->selectRaw('COUNT(evaluations.id) as evaluations_submitted')
            ->selectRaw('COUNT(DISTINCT evaluations.student_id) as students_evaluated')
            ->selectRaw('ROUND(AVG((evaluations.behavior_score + evaluations.prayer_score + evaluations.homework_followup_score) / 3.0), 2) as average_score')
            ->whereNull('evaluations.deleted_at')
            ->whereNull('guardians.deleted_at')
            ->whereNull('students.deleted_at')
            ->whereNull('sessions.deleted_at')
            ->whereNull('circles.deleted_at')
            ->groupBy('guardians.id', 'users.name', 'guardians.name')
            ->orderBy('guardian_name');

        $this->applyDates($query, $filters, 'evaluations.created_at');
        $this->applyFilters($query, $filters, 'circles.id', 'students.id');
        $this->applyScope($query, $user, 'circles.teacher_id');

        return $this->paginate($query, $filters);
    }

    /** @param array<string, mixed> $filters */
    public function circlePerformance(User $user, array $filters): LengthAwarePaginator
    {
        $query = DB::table('attendances')
            ->join('circles', 'circles.id', '=', 'attendances.circle_id')
            ->select(['circles.id as circle_id', 'circles.name as circle_name'])
            ->selectRaw('COUNT(attendances.id) as attendance_records')
            ->selectRaw('COUNT(DISTINCT attendances.student_id) as active_students')
            ->selectRaw("ROUND(100.0 * SUM(CASE WHEN attendances.status IN ('present', 'late') THEN 1 ELSE 0 END) / NULLIF(COUNT(attendances.id), 0), 2) as attendance_rate")
            ->whereNull('attendances.deleted_at')
            ->whereNull('circles.deleted_at')
            ->groupBy('circles.id', 'circles.name')
            ->orderBy('circles.name');

        $this->applyDates($query, $filters, 'attendances.attendance_date');
        $this->applyFilters($query, $filters, 'circles.id', 'attendances.student_id');
        $this->applyScope($query, $user, 'circles.teacher_id');

        return $this->paginate($query, $filters);
    }

    /** @param array<string, mixed> $filters */
    public function centerDashboard(User $user, array $filters): LengthAwarePaginator
    {
        return $this->dashboard($user, $filters);
    }

    /** @param array<string, mixed> $filters */
    public function adminDashboard(User $user, array $filters): LengthAwarePaginator
    {
        return $this->dashboard($user, $filters);
    }

    /** @param array<string, mixed> $filters */
    private function dashboard(User $user, array $filters): LengthAwarePaginator
    {
        $query = DB::table('attendances')
            ->join('students', 'students.id', '=', 'attendances.student_id')
            ->join('circles', 'circles.id', '=', 'attendances.circle_id')
            ->select([
                DB::raw('1 as id'),
                DB::raw("'All' as name"),
            ])
            ->selectRaw('COUNT(attendances.id) as attendance_records')
            ->selectRaw('COUNT(DISTINCT attendances.student_id) as active_students')
            ->selectRaw('COUNT(DISTINCT circles.id) as active_circles')
            ->selectRaw('COUNT(DISTINCT attendances.teacher_id) as active_teachers')
            ->selectRaw("ROUND(100.0 * SUM(CASE WHEN attendances.status IN ('present', 'late') THEN 1 ELSE 0 END) / NULLIF(COUNT(attendances.id), 0), 2) as attendance_rate")
            ->whereNull('attendances.deleted_at')
            ->whereNull('students.deleted_at')
            ->whereNull('circles.deleted_at')
            ->groupBy(DB::raw('1'))
            ->orderBy('name');

        $this->applyDates($query, $filters, 'attendances.attendance_date');
        $this->applyFilters($query, $filters, 'circles.id', 'students.id');
        $this->applyScope($query, $user, 'circles.teacher_id');

        return $this->paginate($query, $filters);
    }

    private function applyScope(Builder $query, User $user, string $teacherColumn): void
    {
        if ($user->isSuperAdmin() || $user->hasRole(Role::CenterOwner)) {
            return;
        }

        if ($user->hasRole(Role::Teacher)) {
            $teacherId = DB::table('teachers')->where('user_id', $user->id)->whereNull('deleted_at')->value('id');
            $query->where($teacherColumn, $teacherId ?? '');

            return;
        }

        throw new ForbiddenException('You do not have permission to access reports.');
    }

    /**
     * Bounded as a half-open range on the bare column rather than with
     * `whereDate()`. Wrapping the column in `DATE()` makes it unusable as an
     * index key, so a date-filtered report scanned every row of the table
     * instead of seeking the period. `col >= $from` and `col < $to + 1 day`
     * select exactly the same rows for both DATE columns (attendance_date)
     * and DATETIME ones (created_at), which this helper is called with.
     *
     * @param  array<string, mixed>  $filters
     */
    private function applyDates(Builder $query, array $filters, string $column): void
    {
        $query->when($filters['date_from'] ?? null, fn (Builder $query, string $date) => $query->where($column, '>=', $date));
        $query->when(
            $filters['date_to'] ?? null,
            fn (Builder $query, string $date) => $query->where($column, '<', Carbon::parse($date)->addDay()->toDateString()),
        );
    }

    /** @param array<string, mixed> $filters */
    private function applyFilters(Builder $query, array $filters, string $circleColumn, string $studentColumn): void
    {
        $query->when($filters['circle_id'] ?? null, fn (Builder $query, string $id) => $query->where($circleColumn, $id));
        $query->when($filters['student_id'] ?? null, fn (Builder $query, string $id) => $query->where($studentColumn, $id));
    }

    /** @param array<string, mixed> $filters */
    private function paginate(Builder $query, array $filters): LengthAwarePaginator
    {
        $perPage = max(1, min((int) ($filters['per_page'] ?? 25), 100));

        return $query->paginate($perPage);
    }
}
