<?php

namespace App\Features\Reports\Actions;

use App\Enums\AttendanceStatus;
use App\Enums\CircleSessionStatus;
use App\Enums\LearningRecordType;
use App\Models\MonthlyProgressRecord;
use App\Models\StudentLearningRecord;
use App\Models\Surah;
use App\Support\Actions\BaseAction;
use App\Support\CenterClock;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Materializes `monthly_progress_records` for a given month.
 *
 * This table, its model and the `reports/monthly-progress` endpoint all
 * existed, but nothing in the codebase ever wrote a row -- so that report
 * could only ever return an empty page. This is the missing write side.
 *
 * Snapshot, not live view: the row is computed from the canonical sources
 * (`attendances` and `student_learning_records`) and stored, so a month's
 * figures survive later edits to the sessions behind them. Re-running is safe
 * and idempotent -- rows are upserted on
 * (student_id, circle_id, year, month), which the table already constrains.
 *
 * The free-text refs are teacher-editable, so a row flagged
 * `manually_edited_at` keeps its text; its numeric aggregates are still
 * refreshed, because those are facts about the month rather than commentary.
 */
class GenerateMonthlyProgressAction extends BaseAction
{
    /**
     * @return int The number of rows written.
     */
    public function execute(mixed ...$arguments): mixed
    {
        $year = $arguments[0] ?? null;
        $month = $arguments[1] ?? null;
        $circleId = $arguments[2] ?? null;

        if (! is_int($year) || ! is_int($month)) {
            throw new \InvalidArgumentException('GenerateMonthlyProgressAction expects a year and month.');
        }

        // Month boundaries are the center's calendar month.
        $start = Carbon::create($year, $month, 1, 0, 0, 0, CenterClock::timezone());

        if ($start === false) {
            throw new \InvalidArgumentException('The given year and month are not a valid date.');
        }

        $from = $start->toDateString();
        $to = $start->copy()->endOfMonth()->toDateString();

        $pairs = $this->studentCirclePairs($from, $to, $circleId);
        $written = 0;

        foreach ($pairs as $pair) {
            DB::transaction(function () use ($pair, $year, $month, $from, $to, &$written): void {
                $existing = MonthlyProgressRecord::query()
                    ->where('student_id', $pair->student_id)
                    ->where('circle_id', $pair->circle_id)
                    ->where('year', $year)
                    ->where('month', $month)
                    ->lockForUpdate()
                    ->first();

                $attributes = $this->attendanceMetrics($pair->student_id, $pair->circle_id, $from, $to);

                if ($existing === null || $existing->manually_edited_at === null) {
                    $attributes += $this->learningRefs($pair->student_id, $pair->circle_id, $from, $to);
                }

                if ($existing === null) {
                    MonthlyProgressRecord::create([
                        'student_id' => $pair->student_id,
                        'circle_id' => $pair->circle_id,
                        'year' => $year,
                        'month' => $month,
                        ...$attributes,
                    ]);
                } else {
                    $existing->fill($attributes)->save();
                }

                $written++;
            });
        }

        return $written;
    }

    /**
     * Every (student, circle) that has any attendance or any learning record in
     * the window. Driven by activity rather than by enrollment so a student who
     * moved circles mid-month gets a row per circle they actually attended.
     *
     * @return Collection<int, object>
     */
    private function studentCirclePairs(string $from, string $to, ?string $circleId): Collection
    {
        $attendance = DB::table('attendances')
            ->select(['student_id', 'circle_id'])
            ->whereNull('deleted_at')
            ->whereNotNull('circle_id')
            ->whereBetween('attendance_date', [$from, $to])
            ->when($circleId !== null, fn ($query) => $query->where('circle_id', $circleId));

        $records = DB::table('student_learning_records as records')
            ->join('circle_sessions as sessions', 'sessions.id', '=', 'records.circle_session_id')
            ->select(['records.student_id as student_id', 'sessions.circle_id as circle_id'])
            ->whereNull('records.deleted_at')
            ->whereNull('sessions.deleted_at')
            ->whereBetween('sessions.session_date', [$from, $to])
            ->when($circleId !== null, fn ($query) => $query->where('sessions.circle_id', $circleId));

        return $attendance->union($records)->get()->unique(
            fn (object $row): string => $row->student_id.'|'.$row->circle_id
        )->values();
    }

    /**
     * @return array<string, mixed>
     */
    private function attendanceMetrics(string $studentId, string $circleId, string $from, string $to): array
    {
        // Cancelled sessions are not opportunities to attend, so they are
        // excluded from the denominator -- counting them would depress every
        // student's rate for a month the center closed a day.
        $sessionsCount = DB::table('circle_sessions')
            ->where('circle_id', $circleId)
            ->whereNull('deleted_at')
            ->whereBetween('session_date', [$from, $to])
            ->where('session_date', '<=', CenterClock::today()->toDateString())
            ->where('status', '!=', CircleSessionStatus::Cancelled->value)
            ->count();

        $rows = DB::table('attendances')
            ->select('status', DB::raw('COUNT(*) as total'))
            ->where('student_id', $studentId)
            ->where('circle_id', $circleId)
            ->whereNull('deleted_at')
            ->whereBetween('attendance_date', [$from, $to])
            ->groupBy('status')
            ->pluck('total', 'status');

        // Late still means the student was there.
        $attended = (int) ($rows[AttendanceStatus::Present->value] ?? 0)
            + (int) ($rows[AttendanceStatus::Late->value] ?? 0);
        $missed = (int) ($rows[AttendanceStatus::Absent->value] ?? 0);

        $denominator = $sessionsCount > 0 ? $sessionsCount : ($attended + $missed);

        return [
            'sessions_count' => $sessionsCount,
            'attended_sessions' => $attended,
            'missed_sessions' => $missed,
            'attendance_percentage' => $denominator > 0 ? round($attended * 100 / $denominator, 2) : null,
            'absence_percentage' => $denominator > 0 ? round($missed * 100 / $denominator, 2) : null,
        ];
    }

    /**
     * The first and last reference of each type in the month, plus the mean
     * listening score.
     *
     * @return array<string, mixed>
     */
    private function learningRefs(string $studentId, string $circleId, string $from, string $to): array
    {
        $records = StudentLearningRecord::query()
            ->select('student_learning_records.*')
            ->join('circle_sessions as sessions', 'sessions.id', '=', 'student_learning_records.circle_session_id')
            ->where('student_learning_records.student_id', $studentId)
            ->where('sessions.circle_id', $circleId)
            ->whereNull('sessions.deleted_at')
            ->whereBetween('sessions.session_date', [$from, $to])
            ->with(['matnType', 'fromMatnSection', 'toMatnSection'])
            ->orderBy('sessions.session_date')
            ->orderBy('student_learning_records.created_at')
            ->get();

        $byType = $records->groupBy(fn (StudentLearningRecord $record): string => $record->type->value);

        $refsFor = function (LearningRecordType $type) use ($byType): array {
            $group = ($byType[$type->value] ?? collect())->reject(fn (StudentLearningRecord $r): bool => $r->is_na);

            return [
                $group->isEmpty() ? null : $this->describe($group->first()),
                $group->isEmpty() ? null : $this->describe($group->last()),
            ];
        };

        [$memoStart, $memoEnd] = $refsFor(LearningRecordType::Memorization);
        [$revStart, $revEnd] = $refsFor(LearningRecordType::Revision);
        [$matnStart, $matnEnd] = $refsFor(LearningRecordType::Matn);

        $listening = ($byType[LearningRecordType::Listening->value] ?? collect())
            ->reject(fn (StudentLearningRecord $r): bool => $r->is_na || $r->score === null);

        return [
            'memorization_start_ref' => $memoStart,
            'memorization_end_ref' => $memoEnd,
            'revision_start_ref' => $revStart,
            'revision_end_ref' => $revEnd,
            'matn_start_ref' => $matnStart,
            'matn_end_ref' => $matnEnd,
            'listening_score' => $listening->isEmpty() ? null : round($listening->avg('score'), 2),
        ];
    }

    /**
     * A human-readable position for one record.
     *
     * The teacher's own free-text label wins when present -- that is the whole
     * point of `reference_label`, which carries references the structured
     * columns cannot express ("آخر الحديد", "ثاني مراجعة", "التحفة 40").
     * Otherwise a label is derived from whichever structured fields the record
     * type carries.
     */
    private function describe(StudentLearningRecord $record): ?string
    {
        if (filled($record->reference_label)) {
            return $record->reference_label;
        }

        if ($record->surah_number !== null) {
            $from = $this->surahName((int) $record->surah_number);
            $toSurah = (int) ($record->to_surah_number ?? $record->surah_number);

            return $toSurah === (int) $record->surah_number
                ? sprintf('%s %s-%s', $from, $record->from_ayah, $record->to_ayah)
                : sprintf('%s %s - %s %s', $from, $record->from_ayah, $this->surahName($toSurah), $record->to_ayah);
        }

        if ($record->matn_type_id !== null) {
            return trim(sprintf(
                '%s %s',
                $record->matnType?->name ?? '',
                $record->toMatnSection?->name ?? $record->fromMatnSection?->name ?? '',
            )) ?: null;
        }

        return $record->topic;
    }

    /** @var array<int, string> */
    private array $surahNames = [];

    private function surahName(int $number): string
    {
        if ($this->surahNames === []) {
            $this->surahNames = Surah::query()->pluck('name_arabic', 'surah_number')->all();
        }

        return $this->surahNames[$number] ?? ('سورة '.$number);
    }
}
