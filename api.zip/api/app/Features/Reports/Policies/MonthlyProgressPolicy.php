<?php

namespace App\Features\Reports\Policies;

use App\Enums\Role;
use App\Models\MonthlyProgressRecord;
use App\Models\User;
use App\Support\Policies\BasePolicy;

/**
 * Who may curate a monthly progress row.
 *
 * Reading monthly progress goes through ReportService, which applies its own
 * teacher scoping. This policy covers the write side only.
 */
class MonthlyProgressPolicy extends BasePolicy
{
    public function view(?User $user, MonthlyProgressRecord $record): bool
    {
        return $this->update($user, $record);
    }

    public function update(?User $user, MonthlyProgressRecord $record): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        // A teacher may write up the months of circles they actually teach.
        return $this->hasRole($user, Role::Teacher)
            && $user?->teacher !== null
            && $record->circle?->teacher_id === $user->teacher->id;
    }

    public function delete(?User $user, MonthlyProgressRecord $record): bool
    {
        return $this->isSuperAdmin($user) || $this->hasRole($user, Role::CenterOwner);
    }
}
