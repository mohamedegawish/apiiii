<?php

namespace App\Features\Reports\Controllers;

use App\Features\Reports\Actions\GenerateMonthlyProgressAction;
use App\Features\Reports\Requests\GenerateMonthlyProgressRequest;
use App\Features\Reports\Requests\ReportRequest;
use App\Features\Reports\Requests\UpdateMonthlyProgressRequest;
use App\Features\Reports\Services\ReportService;
use App\Models\MonthlyProgressRecord;
use App\Support\Http\Controllers\BaseController;
use App\Support\Http\Controllers\Concerns\RespondsWithReport;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ReportController extends BaseController
{
    use RespondsWithReport;

    public function __construct(protected ReportService $reportService) {}

    public function studentProgress(ReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'student-progress', fn (array $filters) => $this->reportService->studentProgress($request->user(), $filters));
    }

    public function monthlyProgress(ReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'monthly-progress', fn (array $filters) => $this->reportService->monthlyProgress($request->user(), $filters));
    }

    /**
     * Rebuild the monthly snapshot on demand.
     *
     * Runs synchronously and is safe to repeat: the action upserts on
     * (student, circle, year, month).
     */
    public function generateMonthlyProgress(GenerateMonthlyProgressRequest $request, GenerateMonthlyProgressAction $action): JsonResponse
    {
        $data = $request->validatedData();

        $written = $action->execute((int) $data['year'], (int) $data['month'], $data['circle_id'] ?? null);

        return $this->success(
            ['records_written' => $written, 'year' => (int) $data['year'], 'month' => (int) $data['month']],
            'Monthly progress generated successfully.',
        );
    }

    /**
     * Curate the free-text half of one monthly row.
     *
     * Flags the row so the generator stops overwriting the teacher's wording
     * on its next run; the numeric aggregates keep refreshing either way.
     */
    public function updateMonthlyProgress(UpdateMonthlyProgressRequest $request, MonthlyProgressRecord $monthlyProgress): JsonResponse
    {
        $this->authorize('update', $monthlyProgress);

        $monthlyProgress->fill($request->validatedData());
        $monthlyProgress->manually_edited_at = now();
        $monthlyProgress->save();

        return $this->success($monthlyProgress->fresh()?->toArray() ?? [], 'Monthly progress updated successfully.');
    }

    public function attendance(ReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'attendance', fn (array $filters) => $this->reportService->attendance($request->user(), $filters));
    }

    public function monthlyAttendance(ReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'monthly-attendance', fn (array $filters) => $this->reportService->monthlyAttendance($request->user(), $filters));
    }

    public function teacherPerformance(ReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'teacher-performance', fn (array $filters) => $this->reportService->teacherPerformance($request->user(), $filters));
    }

    public function parentEngagement(ReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'parent-engagement', fn (array $filters) => $this->reportService->parentEngagement($request->user(), $filters));
    }

    public function circlePerformance(ReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'circle-performance', fn (array $filters) => $this->reportService->circlePerformance($request->user(), $filters));
    }

    public function centerDashboard(ReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'center-dashboard', fn (array $filters) => $this->reportService->adminDashboard($request->user(), $filters));
    }

    public function adminDashboard(ReportRequest $request): JsonResponse|StreamedResponse
    {
        return $this->respondWithReport($request->validatedData(), 'admin-dashboard', fn (array $filters) => $this->reportService->adminDashboard($request->user(), $filters));
    }
}
