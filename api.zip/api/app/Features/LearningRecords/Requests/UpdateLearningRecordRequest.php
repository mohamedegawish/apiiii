<?php

namespace App\Features\LearningRecords\Requests;

use App\Enums\LearningRecordResult;
use App\Enums\LearningRecordType;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class UpdateLearningRecordRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'circle_session_id' => ['prohibited'],
            'homework_id' => ['sometimes', 'uuid', 'exists:homework,id'],
            'student_id' => ['prohibited'],
            'teacher_id' => ['prohibited'],
            'type' => ['sometimes', 'string', Rule::in(LearningRecordType::values())],
            'reference_label' => ['sometimes', 'nullable', 'string', 'max:255'],
            'is_na' => ['sometimes', 'nullable', 'boolean'],
            'score_only' => ['sometimes', 'nullable', 'boolean'],
            'result_status' => ['sometimes', 'nullable', 'string', Rule::in(LearningRecordResult::values())],
            'surah_number' => ['sometimes', 'nullable', 'integer', 'min:1'],
            'from_ayah' => ['sometimes', 'nullable', 'integer', 'min:1'],
            'to_surah_number' => ['sometimes', 'nullable', 'integer', 'min:1'],
            'to_ayah' => ['sometimes', 'nullable', 'integer', 'min:1'],
            'matn_type_id' => ['sometimes', 'nullable', 'uuid', 'exists:matn_types,id'],
            'from_matn_section_id' => ['sometimes', 'nullable', 'uuid', 'exists:matn_sections,id'],
            'to_matn_section_id' => ['sometimes', 'nullable', 'uuid', 'exists:matn_sections,id'],
            'topic' => ['sometimes', 'nullable', 'string', 'max:255'],
            'score' => ['sometimes', 'nullable', 'numeric', 'between:0,100'],
            'notes' => ['sometimes', 'nullable', 'string', 'max:2000'],
        ];
    }
}
