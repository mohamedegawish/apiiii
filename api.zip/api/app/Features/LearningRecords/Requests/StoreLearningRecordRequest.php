<?php

namespace App\Features\LearningRecords\Requests;

use App\Enums\LearningRecordResult;
use App\Enums\LearningRecordType;
use App\Features\LearningRecords\Policies\LearningRecordPolicy;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class StoreLearningRecordRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return app(LearningRecordPolicy::class)->create($this->user());
    }

    /**
     * Field-level rules stay type-agnostic and nullable — which fields are
     * actually required for a given `type` (or waived entirely for
     * `is_na=true`) is business logic, validated in the Action layer, same
     * as this feature already does for Quran-range ordering.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'circle_session_id' => ['required', 'uuid', 'exists:circle_sessions,id'],
            'homework_id' => ['nullable', 'uuid', 'exists:homework,id'],
            'student_id' => ['required', 'uuid', 'exists:students,id'],
            'teacher_id' => ['prohibited'],
            'type' => ['required', 'string', Rule::in(LearningRecordType::values())],
            'reference_label' => ['nullable', 'string', 'max:255'],
            'is_na' => ['nullable', 'boolean'],
            'score_only' => ['nullable', 'boolean'],
            'result_status' => ['nullable', 'string', Rule::in(LearningRecordResult::values())],
            // Quran-based (memorization/revision)
            'surah_number' => ['nullable', 'integer', 'min:1'],
            'from_ayah' => ['nullable', 'integer', 'min:1'],
            'to_surah_number' => ['nullable', 'integer', 'min:1'],
            'to_ayah' => ['nullable', 'integer', 'min:1'],
            // Matn
            'matn_type_id' => ['nullable', 'uuid', 'exists:matn_types,id'],
            'from_matn_section_id' => ['nullable', 'uuid', 'exists:matn_sections,id'],
            'to_matn_section_id' => ['nullable', 'uuid', 'exists:matn_sections,id'],
            // Listening
            'topic' => ['nullable', 'string', 'max:255'],
            'score' => ['nullable', 'numeric', 'between:0,100'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
