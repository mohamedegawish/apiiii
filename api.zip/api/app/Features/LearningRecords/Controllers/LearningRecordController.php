<?php

namespace App\Features\LearningRecords\Controllers;

use App\Features\LearningRecords\Policies\LearningRecordPolicy;
use App\Features\LearningRecords\Requests\StoreLearningRecordRequest;
use App\Features\LearningRecords\Requests\UpdateLearningRecordRequest;
use App\Features\LearningRecords\Resources\LearningRecordResource;
use App\Features\LearningRecords\Services\LearningRecordService;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class LearningRecordController extends BaseController
{
    public function __construct(
        protected LearningRecordService $learningRecordService,
        protected LearningRecordPolicy $learningRecordPolicy,
    ) {}

    public function index(Request $request): JsonResponse
    {
        $this->ensureAuthorized($this->learningRecordPolicy->viewAny($request->user()));

        return $this->paginate(
            LearningRecordResource::collection($this->learningRecordService->paginate()),
            'Learning records retrieved successfully.',
        );
    }

    public function show(Request $request, string $learningRecord): JsonResponse
    {
        $record = $this->learningRecordService->findOrFail($learningRecord);
        $this->ensureAuthorized($this->learningRecordPolicy->view($request->user(), $record));

        return $this->success(LearningRecordResource::make($record), 'Learning record retrieved successfully.');
    }

    public function store(StoreLearningRecordRequest $request): JsonResponse
    {
        return $this->created(
            LearningRecordResource::make($this->learningRecordService->create($request)),
            'Learning record created successfully.',
        );
    }

    public function update(UpdateLearningRecordRequest $request, string $learningRecord): JsonResponse
    {
        $record = $this->learningRecordService->findOrFail($learningRecord);
        $this->ensureAuthorized($this->learningRecordPolicy->update($request->user(), $record));

        return $this->success(
            LearningRecordResource::make($this->learningRecordService->update($record, $request)),
            'Learning record updated successfully.',
        );
    }

    public function destroy(Request $request, string $learningRecord): JsonResponse
    {
        $record = $this->learningRecordService->findOrFail($learningRecord);
        $this->ensureAuthorized($this->learningRecordPolicy->delete($request->user(), $record));
        $this->learningRecordService->delete($record);

        return $this->success(null, 'Learning record deleted successfully.');
    }

    private function ensureAuthorized(bool $authorized): void
    {
        if (! $authorized) {
            throw new AuthorizationException;
        }
    }
}
