<?php

namespace App\Features\LearningRecords\Services;

use App\Features\LearningRecords\Actions\CreateLearningRecordAction;
use App\Features\LearningRecords\Actions\DeleteLearningRecordAction;
use App\Features\LearningRecords\Actions\UpdateLearningRecordAction;
use App\Features\LearningRecords\Queries\LearningRecordQuery;
use App\Features\LearningRecords\Requests\StoreLearningRecordRequest;
use App\Features\LearningRecords\Requests\UpdateLearningRecordRequest;
use App\Models\StudentLearningRecord;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class LearningRecordService extends BaseService
{
    public function __construct(
        protected CreateLearningRecordAction $createLearningRecordAction,
        protected UpdateLearningRecordAction $updateLearningRecordAction,
        protected DeleteLearningRecordAction $deleteLearningRecordAction,
        protected LearningRecordQuery $learningRecordQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->learningRecordQuery->paginate();
    }

    public function findOrFail(string $id): StudentLearningRecord
    {
        return $this->learningRecordQuery->findOrFail($id);
    }

    public function create(StoreLearningRecordRequest $request): StudentLearningRecord
    {
        return $this->transaction(fn (): StudentLearningRecord => $this->createLearningRecordAction->execute($request));
    }

    public function update(StudentLearningRecord $record, UpdateLearningRecordRequest $request): StudentLearningRecord
    {
        return $this->transaction(fn (): StudentLearningRecord => $this->updateLearningRecordAction->execute($record, $request));
    }

    public function delete(StudentLearningRecord $record): bool
    {
        return $this->transaction(fn (): bool => $this->deleteLearningRecordAction->execute($record));
    }
}
