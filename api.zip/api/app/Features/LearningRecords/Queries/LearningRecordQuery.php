<?php

namespace App\Features\LearningRecords\Queries;

use App\Enums\Role;
use App\Models\StudentLearningRecord;
use App\Support\Exceptions\NotFoundException;
use App\Support\Queries\BaseQuery;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class LearningRecordQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(StudentLearningRecord::class);
    }

    public function findOrFail(string $id): StudentLearningRecord
    {
        $record = $this->builder
            ->with([
                'circleSession.circle',
                'student',
                'teacher.user',
                'matnType',
                'fromMatnSection',
                'toMatnSection',
            ])
            ->whereKey($id)
            ->first();

        if (! $record instanceof StudentLearningRecord) {
            throw new NotFoundException('Learning record not found.');
        }

        return $record;
    }

    /** @param EloquentBuilder<StudentLearningRecord> $builder */
    protected function applyTenantScope(EloquentBuilder $builder): void
    {
        if ($this->shouldBypassScope()) {
            return;
        }

        $user = $this->currentUser();

        if ($user?->hasRole(Role::Teacher) && $user->teacher !== null) {
            $builder->where('teacher_id', $user->teacher->id)
                ->whereHas('circleSession', fn (EloquentBuilder $query) => $query->where('teacher_id', $user->teacher->id));

            return;
        }

        $builder->whereRaw('1 = 0');
    }

    /** @return list<AllowedFilter> */
    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::exact('circle_session_id'),
            AllowedFilter::exact('student_id'),
            AllowedFilter::exact('teacher_id'),
            AllowedFilter::exact('type'),
            AllowedFilter::exact('surah_number'),
            AllowedFilter::exact('matn_type_id'),
        ];
    }

    /** @return list<string> */
    protected function allowedSorts(): array
    {
        return ['score', 'created_at', 'updated_at'];
    }

    /** @return list<string> */
    protected function allowedIncludes(): array
    {
        // The resource composes teacher_name (`teacher.user`) and circle_name
        // (`circleSession.circle`) from nested relations, so those must be
        // includable together with their parents: including `teacher` without
        // `teacher.user` would otherwise lazy-load the user per row.
        return [
            'circleSession',
            'circleSession.circle',
            'student',
            'teacher',
            'teacher.user',
            'matnType',
            'fromMatnSection',
            'toMatnSection',
        ];
    }
}
