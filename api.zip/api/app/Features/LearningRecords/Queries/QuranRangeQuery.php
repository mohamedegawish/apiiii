<?php

namespace App\Features\LearningRecords\Queries;

use App\Models\Ayah;

/**
 * Resolves a Quran range's global ayah endpoints so ranges can be compared
 * and ordered across surah boundaries (e.g. النبأ 1 → النازعات 20, common
 * in جزء عم assignments) — global_ayah_number increases monotonically
 * through the whole Quran regardless of surah, so it is the only reliable
 * way to validate that "to" comes after "from" once a range may cross a
 * surah, and it is what gets stored so ayah-coverage reporting stays
 * arithmetically correct for cross-surah ranges.
 */
class QuranRangeQuery
{
    /**
     * @return array{from: int, to: int}|null Null if either endpoint does not
     *                                        exist or the range runs backwards.
     */
    public function resolve(int $fromSurah, int $fromAyah, int $toSurah, int $toAyah): ?array
    {
        $from = Ayah::where('surah_number', $fromSurah)->where('ayah_number', $fromAyah)->value('global_ayah_number');
        $to = Ayah::where('surah_number', $toSurah)->where('ayah_number', $toAyah)->value('global_ayah_number');

        if ($from === null || $to === null || $to < $from) {
            return null;
        }

        return ['from' => $from, 'to' => $to];
    }
}
