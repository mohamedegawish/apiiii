<?php

namespace App\Features\LearningRecords\Resources;

use App\Models\StudentLearningRecord;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/** @mixin StudentLearningRecord */
class LearningRecordResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'circle_session_id' => $this->circle_session_id,
            'homework_id' => $this->homework_id,
            'student_id' => $this->student_id,
            'teacher_id' => $this->teacher_id,
            'teacher_name' => $this->whenLoaded('teacher', fn () => $this->teacher?->user?->name),
            'circle_name' => $this->whenLoaded('circleSession', fn () => $this->circleSession?->circle?->name),
            'session_date' => $this->whenLoaded('circleSession', fn () => $this->circleSession?->session_date?->toDateString()),
            'type' => [
                'value' => $this->type->value,
                'label' => $this->type->label(),
            ],
            // Both apps render this as the leading label of a record; it was
            // stored but never emitted, so it always arrived as null.
            'reference_label' => $this->reference_label,
            'surah_number' => $this->surah_number,
            'from_ayah' => $this->from_ayah,
            'to_surah_number' => $this->to_surah_number,
            'to_ayah' => $this->to_ayah,
            'from_global_ayah' => $this->from_global_ayah,
            'to_global_ayah' => $this->to_global_ayah,
            'matn_type_id' => $this->matn_type_id,
            'matn_type_name' => $this->whenLoaded('matnType', fn () => $this->matnType?->name),
            'from_matn_section_id' => $this->from_matn_section_id,
            'from_matn_section_name' => $this->whenLoaded('fromMatnSection', fn () => $this->fromMatnSection?->name),
            'to_matn_section_id' => $this->to_matn_section_id,
            'to_matn_section_name' => $this->whenLoaded('toMatnSection', fn () => $this->toMatnSection?->name),
            'topic' => $this->topic,
            'is_na' => $this->is_na,
            'result_status' => $this->result_status?->value,
            'score' => $this->score,
            'notes' => $this->notes,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
