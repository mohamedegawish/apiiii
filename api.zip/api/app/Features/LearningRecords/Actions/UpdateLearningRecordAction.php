<?php

namespace App\Features\LearningRecords\Actions;

use App\Enums\HomeworkStatus;
use App\Features\LearningRecords\Queries\QuranRangeQuery;
use App\Features\LearningRecords\Requests\UpdateLearningRecordRequest;
use App\Models\CircleSession;
use App\Models\StudentLearningRecord;
use App\Models\User;
use App\Support\Actions\BaseAction;
use Illuminate\Validation\ValidationException;

class UpdateLearningRecordAction extends BaseAction
{
    use ValidatesLearningRecord;

    public function __construct(protected QuranRangeQuery $quranRangeQuery) {}

    public function execute(mixed ...$arguments): mixed
    {
        $record = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $record instanceof StudentLearningRecord || ! $request instanceof UpdateLearningRecordRequest) {
            throw new \InvalidArgumentException('UpdateLearningRecordAction expects a record and update request.');
        }

        $lockedRecord = StudentLearningRecord::lockForUpdate()->find($record->id);
        $user = $request->user();

        if ($lockedRecord === null || ! $user instanceof User) {
            throw new \InvalidArgumentException('A persisted record and authenticated user are required.');
        }

        $session = CircleSession::with('circle')->lockForUpdate()->find($lockedRecord->circle_session_id);

        if ($session === null) {
            throw ValidationException::withMessages(['circle_session_id' => ['The record session is invalid.']]);
        }

        $this->validateSession($user, $session);

        $data = $request->validatedData();

        // Partial updates re-resolve the record's *whole* type-specific
        // shape (not just the submitted fields), so e.g. patching only
        // `score` on an existing matn record still re-validates against its
        // already-stored matn_type_id/section range rather than skipping
        // validation entirely.
        $merged = [
            'type' => $data['type'] ?? $lockedRecord->type->value,
            'circle_id' => $session->circle_id,
            // Identity is immutable on update (the request marks these
            // `prohibited`), but validateHomeworkResult() still needs them to
            // find the linked assignment -- omitting them made every
            // score_only re-save of a memorization/revision evaluation, the
            // session workspace's most frequent write, fail with a 500.
            'student_id' => $lockedRecord->student_id,
            'circle_session_id' => $lockedRecord->circle_session_id,
            'reference_label' => array_key_exists('reference_label', $data) ? $data['reference_label'] : $lockedRecord->reference_label,
            'homework_id' => $data['homework_id'] ?? $lockedRecord->homework_id,
            'is_na' => array_key_exists('is_na', $data) ? $data['is_na'] : $lockedRecord->is_na,
            'score_only' => array_key_exists('score_only', $data) ? $data['score_only'] : false,
            'result_status' => array_key_exists('result_status', $data) ? $data['result_status'] : $lockedRecord->result_status?->value,
            'score' => array_key_exists('score', $data) ? $data['score'] : $lockedRecord->score,
            'notes' => array_key_exists('notes', $data) ? $data['notes'] : $lockedRecord->notes,
            'surah_number' => $data['surah_number'] ?? $lockedRecord->surah_number,
            'from_ayah' => $data['from_ayah'] ?? $lockedRecord->from_ayah,
            'to_surah_number' => $data['to_surah_number'] ?? $lockedRecord->to_surah_number,
            'to_ayah' => $data['to_ayah'] ?? $lockedRecord->to_ayah,
            'matn_type_id' => $data['matn_type_id'] ?? $lockedRecord->matn_type_id,
            'from_matn_section_id' => $data['from_matn_section_id'] ?? $lockedRecord->from_matn_section_id,
            'to_matn_section_id' => $data['to_matn_section_id'] ?? $lockedRecord->to_matn_section_id,
            'topic' => array_key_exists('topic', $data) ? $data['topic'] : $lockedRecord->topic,
        ];

        $homework = $this->validateHomeworkResult($merged, $lockedRecord->homework_id);
        $lockedRecord->update($this->resolveTypeAttributes($merged));

        if ($homework !== null) {
            $homework->update([
                'status' => HomeworkStatus::Graded,
                'grade' => $lockedRecord->score,
            ]);
        }

        return $lockedRecord->fresh()->load(['circleSession.circle', 'student', 'teacher', 'matnType', 'fromMatnSection', 'toMatnSection']);
    }
}
