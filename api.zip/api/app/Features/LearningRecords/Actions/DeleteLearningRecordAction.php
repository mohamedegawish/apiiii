<?php

namespace App\Features\LearningRecords\Actions;

use App\Models\CircleSession;
use App\Models\StudentLearningRecord;
use App\Models\User;
use App\Support\Actions\BaseAction;
use Illuminate\Validation\ValidationException;

class DeleteLearningRecordAction extends BaseAction
{
    use ValidatesLearningRecord;

    public function execute(mixed ...$arguments): mixed
    {
        $record = $arguments[0] ?? null;

        if (! $record instanceof StudentLearningRecord) {
            throw new \InvalidArgumentException('DeleteLearningRecordAction expects a StudentLearningRecord.');
        }

        $lockedRecord = StudentLearningRecord::lockForUpdate()->find($record->id);
        $user = auth()->user();

        if ($lockedRecord === null || ! $user instanceof User) {
            throw new \InvalidArgumentException('A persisted record and authenticated user are required.');
        }

        $session = CircleSession::with('circle')->lockForUpdate()->find($lockedRecord->circle_session_id);

        if ($session === null) {
            throw ValidationException::withMessages(['circle_session_id' => ['The record session is invalid.']]);
        }

        $this->validateSession($user, $session);

        return (bool) $lockedRecord->delete();
    }
}
