<?php

namespace App\Features\LearningRecords\Actions;

use App\Enums\CircleSessionStatus;
use App\Enums\HomeworkStatus;
use App\Enums\HomeworkType;
use App\Enums\LearningRecordResult;
use App\Enums\LearningRecordType;
use App\Enums\Role;
use App\Enums\StudentStatus;
use App\Features\LearningRecords\Queries\QuranRangeQuery;
use App\Models\CircleSession;
use App\Models\Enrollment;
use App\Models\Homework;
use App\Models\MatnSection;
use App\Models\Student;
use App\Models\User;
use App\Support\CenterClock;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Validation\ValidationException;

trait ValidatesLearningRecord
{
    private function validateHomeworkResult(array $data, ?string $existingHomeworkId = null): ?Homework
    {
        $type = LearningRecordType::from($data['type']);
        $homeworkId = $data['homework_id'] ?? $existingHomeworkId;
        $scoreOnly = (bool) ($data['score_only'] ?? false);
        $resultStatus = $data['result_status'] ?? null;

        if (! $scoreOnly) {
            return null;
        }

        if (! $type->isQuranBased()) {
            if ($homeworkId !== null || $resultStatus !== null) {
                throw ValidationException::withMessages([
                    'homework_id' => ['Homework is only valid for memorization and revision.'],
                ]);
            }

            return null;
        }

        if ($homeworkId === null) {
            throw ValidationException::withMessages([
                'homework_id' => ['An active homework assignment is required for this evaluation.'],
            ]);
        }

        if (($data['score'] ?? null) === null && $resultStatus !== LearningRecordResult::NotMemorized->value) {
            throw ValidationException::withMessages([
                'score' => ['Enter a score or mark the assignment as not memorized.'],
            ]);
        }

        $homework = Homework::query()
            ->whereKey($homeworkId)
            ->where('student_id', $data['student_id'])
            ->when(isset($data['circle_id']), fn ($query) => $query->where('circle_id', $data['circle_id']))
            ->where('homework_type', $type === LearningRecordType::Memorization
                ? HomeworkType::Memorization->value
                : HomeworkType::Revision->value)
            ->where(function ($query) use ($data): void {
                $query->whereNull('circle_session_id')
                    ->orWhere('circle_session_id', '!=', $data['circle_session_id']);
            })
            ->where(function ($query) use ($existingHomeworkId): void {
                $query->whereIn('status', [
                    HomeworkStatus::Pending->value,
                    HomeworkStatus::Submitted->value,
                    HomeworkStatus::Late->value,
                ]);
                if ($existingHomeworkId !== null) {
                    // orWhereKey() does not exist on Eloquent's builder (only
                    // whereKey/whereKeyNot), so this threw a BadMethodCallException
                    // on every update of an already-linked score_only record.
                    $query->orWhere('id', $existingHomeworkId);
                }
            })
            ->first();

        if ($homework === null) {
            throw ValidationException::withMessages([
                'homework_id' => ['The selected homework is not active for this student.'],
            ]);
        }

        return $homework;
    }

    private function validateSession(User $user, CircleSession $session): void
    {
        $allowed = $user->isSuperAdmin()
            || $user->hasRole(Role::CenterOwner)
            || ($user->hasRole(Role::Teacher) && $user->teacher?->id === $session->teacher_id);

        if (! $allowed) {
            throw new AuthorizationException;
        }

        if (CenterClock::isFutureDate($session->session_date)) {
            throw ValidationException::withMessages([
                'circle_session_id' => ['The selected session must not be in the future.'],
            ]);
        }

        if (! in_array($session->status, [CircleSessionStatus::Scheduled, CircleSessionStatus::InProgress], true)) {
            throw ValidationException::withMessages([
                'circle_session_id' => ['The selected session does not accept learning record changes.'],
            ]);
        }
    }

    private function validateStudent(CircleSession $session, string $studentId): Student
    {
        $student = Student::lockForUpdate()->find($studentId);

        if ($student === null || $student->status !== StudentStatus::Active) {
            throw ValidationException::withMessages(['student_id' => ['The selected student must be active.']]);
        }

        $hasEnrollment = Enrollment::where('student_id', $student->id)
            ->where('circle_id', $session->circle_id)
            ->coveringDate($session->session_date)
            ->lockForUpdate()
            ->exists();

        if (! $hasEnrollment) {
            throw ValidationException::withMessages([
                'student_id' => ['The selected student must have an enrollment covering the session date.'],
            ]);
        }

        return $student;
    }

    /**
     * @return array{from: int, to: int} The resolved global ayah endpoints.
     */
    private function validateQuranRange(QuranRangeQuery $query, int $fromSurah, int $fromAyah, int $toSurah, int $toAyah): array
    {
        $resolved = $query->resolve($fromSurah, $fromAyah, $toSurah, $toAyah);

        if ($resolved === null) {
            throw ValidationException::withMessages([
                'surah_number' => ['The selected surah and ayah range must exist.'],
            ]);
        }

        return $resolved;
    }

    /**
     * Confirms both matn sections belong to the given matn type and that the
     * range runs forward (mirrors validateQuranRange's ordering guarantee,
     * using each section's admin-defined `order` instead of a global ayah
     * position).
     *
     * @return array{from: MatnSection, to: MatnSection}
     */
    private function validateMatnRange(string $matnTypeId, string $fromSectionId, string $toSectionId): array
    {
        $from = MatnSection::where('matn_type_id', $matnTypeId)->find($fromSectionId);
        $to = MatnSection::where('matn_type_id', $matnTypeId)->find($toSectionId);

        if ($from === null || $to === null || $to->order < $from->order) {
            throw ValidationException::withMessages([
                'from_matn_section_id' => ['The selected matn section range must belong to the chosen matn type and run forward.'],
            ]);
        }

        return ['from' => $from, 'to' => $to];
    }

    /**
     * Branches on `type`/`is_na` to resolve exactly the fields that type
     * carries, nulling out every field that belongs to a different type so a
     * record can never carry, say, both a Quran range and a matn range.
     * Shared by create and update — a partial update to an existing
     * record's type-specific fields still re-validates the full range for
     * whichever type the record ends up as.
     *
     * @param  array<string, mixed>  $data  Already merged with the existing
     *                                      record's current values where the
     *                                      caller allows partial updates.
     * @return array<string, mixed>
     */
    private function resolveTypeAttributes(array $data): array
    {
        $isNa = (bool) ($data['is_na'] ?? false);
        $scoreOnly = (bool) ($data['score_only'] ?? false);
        $base = [
            'type' => $data['type'],
            // The free-text Arabic reference a teacher writes alongside the
            // structured range ("Ø¢Ø®Ø± Ø§ÙØ­Ø¯ÙØ¯", "Ø§ÙØªØ­ÙØ© 40"). It applies to every
            // type, including N/A and score-only records, so it sits in the
            // shared base rather than a per-type branch -- it was previously
            // validated and displayed but never written.
            'reference_label' => $data['reference_label'] ?? null,
            'homework_id' => $data['homework_id'] ?? null,
            'is_na' => $isNa,
            'result_status' => $data['result_status'] ?? null,
            'score' => $isNa ? null : ($data['score'] ?? null),
            'notes' => $data['notes'] ?? null,
            'surah_number' => null,
            'from_ayah' => null,
            'to_surah_number' => null,
            'to_ayah' => null,
            'from_global_ayah' => null,
            'to_global_ayah' => null,
            'matn_type_id' => null,
            'from_matn_section_id' => null,
            'to_matn_section_id' => null,
            'topic' => null,
        ];

        if ($isNa) {
            return $base;
        }

        if ($scoreOnly) {
            return $base;
        }

        $type = LearningRecordType::from($data['type']);

        if ($type->isQuranBased()) {
            if (! isset($data['surah_number'], $data['from_ayah'], $data['to_ayah'])) {
                throw ValidationException::withMessages([
                    'surah_number' => ['A surah/ayah range is required for this type unless marked N/A.'],
                ]);
            }

            $toSurah = (int) ($data['to_surah_number'] ?? $data['surah_number']);
            $resolved = $this->validateQuranRange(
                $this->quranRangeQuery,
                (int) $data['surah_number'],
                (int) $data['from_ayah'],
                $toSurah,
                (int) $data['to_ayah'],
            );

            return [
                ...$base,
                'surah_number' => (int) $data['surah_number'],
                'from_ayah' => (int) $data['from_ayah'],
                'to_surah_number' => $toSurah,
                'to_ayah' => (int) $data['to_ayah'],
                'from_global_ayah' => $resolved['from'],
                'to_global_ayah' => $resolved['to'],
            ];
        }

        if ($type === LearningRecordType::Matn) {
            if (! isset($data['matn_type_id'], $data['from_matn_section_id'], $data['to_matn_section_id'])) {
                throw ValidationException::withMessages([
                    'matn_type_id' => ['A matn type and section range are required for this type unless marked N/A.'],
                ]);
            }

            $this->validateMatnRange($data['matn_type_id'], $data['from_matn_section_id'], $data['to_matn_section_id']);

            return [
                ...$base,
                'matn_type_id' => $data['matn_type_id'],
                'from_matn_section_id' => $data['from_matn_section_id'],
                'to_matn_section_id' => $data['to_matn_section_id'],
            ];
        }

        if (! isset($data['topic']) || $data['topic'] === '') {
            throw ValidationException::withMessages([
                'topic' => ['A topic is required for a listening record unless marked N/A.'],
            ]);
        }

        return [...$base, 'topic' => $data['topic']];
    }
}
