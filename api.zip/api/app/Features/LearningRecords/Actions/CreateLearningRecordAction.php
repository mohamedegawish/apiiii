<?php

namespace App\Features\LearningRecords\Actions;

use App\Enums\HomeworkStatus;
use App\Features\LearningRecords\Queries\QuranRangeQuery;
use App\Features\LearningRecords\Requests\StoreLearningRecordRequest;
use App\Models\CircleSession;
use App\Models\StudentLearningRecord;
use App\Models\User;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;
use App\Support\Services\GuardianNotificationService;
use Illuminate\Validation\ValidationException;

class CreateLearningRecordAction extends BaseAction
{
    use ValidatesLearningRecord;

    public function __construct(
        protected QuranRangeQuery $quranRangeQuery,
        protected GuardianNotificationService $guardianNotificationService,
    ) {}

    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreLearningRecordRequest) {
            throw new \InvalidArgumentException('CreateLearningRecordAction expects a StoreLearningRecordRequest.');
        }

        $data = $request->validatedData();
        $user = $request->user();

        if (! $user instanceof User) {
            throw new \InvalidArgumentException('An authenticated user is required.');
        }

        $session = CircleSession::with('circle')->lockForUpdate()->find($data['circle_session_id']);

        if ($session === null) {
            throw ValidationException::withMessages(['circle_session_id' => ['The selected session is invalid.']]);
        }

        $this->validateSession($user, $session);
        $this->validateStudent($session, $data['student_id']);
        $homework = $this->validateHomeworkResult([...$data, 'circle_id' => $session->circle_id]);

        $attributes = $this->resolveTypeAttributes($data);

        // A soft-deleted row at this (session, student, type) key means the
        // teacher deleted a mistaken entry and is now re-recording it —
        // restore instead of colliding with the unique index and 500ing.
        // A non-trashed row here is a genuine duplicate request.
        $existing = StudentLearningRecord::withTrashed()
            ->where('circle_session_id', $session->id)
            ->where('student_id', $data['student_id'])
            ->where('type', $data['type'])
            ->lockForUpdate()
            ->first();

        if ($existing !== null && ! $existing->trashed()) {
            throw new ConflictException('A learning record of this type already exists for this student and session.');
        }

        // teacher_id is intentionally not mass-assignable (server-derived
        // only) — set it as a direct property, same as every other write
        // path in this feature.
        if ($existing !== null) {
            $existing->restore();
            $existing->fill([...$attributes, 'student_id' => $data['student_id']]);
            $existing->teacher_id = $session->teacher_id;
            $existing->save();
            $record = $existing;
        } else {
            $record = new StudentLearningRecord([
                ...$attributes,
                'circle_session_id' => $session->id,
                'student_id' => $data['student_id'],
            ]);
            $record->teacher_id = $session->teacher_id;
            $record->save();
        }

        if ($record->score !== null && (float) $record->score < 60) {
            $this->guardianNotificationService->notifyStudentGuardians($record->student, 'low_score', [
                'circle_session_id' => $record->circle_session_id,
                'score' => (float) $record->score,
            ]);
        }

        if ($homework !== null) {
            $homework->update([
                'status' => HomeworkStatus::Graded,
                'grade' => $record->score,
            ]);
        }

        return $record->load(['circleSession.circle', 'student', 'teacher', 'matnType', 'fromMatnSection', 'toMatnSection']);
    }
}
