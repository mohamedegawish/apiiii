<?php

namespace App\Features\LearningRecords\Policies;

use App\Enums\Role;
use App\Models\StudentLearningRecord;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class LearningRecordPolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $user instanceof User && $user->roleEnum()?->isStaff() === true;
    }

    public function view(?User $user, StudentLearningRecord $record): bool
    {
        return $this->canAccess($user, $record);
    }

    public function create(?User $user): bool
    {
        return $user instanceof User && $user->roleEnum()?->isStaff() === true;
    }

    public function update(?User $user, StudentLearningRecord $record): bool
    {
        return ! $record->circleSession->isImmutable() && $this->canAccess($user, $record);
    }

    public function delete(?User $user, StudentLearningRecord $record): bool
    {
        return ! $record->circleSession->isImmutable() && $this->canAccess($user, $record);
    }

    private function canAccess(?User $user, StudentLearningRecord $record): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        return $this->hasRole($user, Role::Teacher)
            && $user?->teacher?->id === $record->teacher_id
            && $record->circleSession?->teacher_id === $record->teacher_id;
    }
}
