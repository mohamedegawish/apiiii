<?php

namespace App\Features\StudentTracking\Controllers;

use App\Features\Students\Policies\StudentPolicy;
use App\Features\StudentTracking\Requests\StudentTrackingRequest;
use App\Features\StudentTracking\Services\StudentTrackingService;
use App\Models\Student;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;

class StudentTrackingController extends BaseController
{
    public function __construct(
        protected StudentTrackingService $trackingService,
        protected StudentPolicy $policy,
    ) {}

    public function profile(StudentTrackingRequest $request, Student $student): JsonResponse
    {
        $this->ensureCanView($request, $student);

        $filters = $request->validatedData();

        return $this->success(
            $this->trackingService->profile($student, $filters['granularity'] ?? 'monthly', $filters['date'] ?? null),
            'Student tracking profile retrieved successfully.',
        );
    }

    public function history(StudentTrackingRequest $request, Student $student): JsonResponse
    {
        $this->ensureCanView($request, $student);

        $filters = $request->validatedData();

        return $this->success(
            ['periods' => $this->trackingService->history($student, $filters['granularity'] ?? 'monthly', (int) ($filters['periods'] ?? 6))],
            'Student tracking history retrieved successfully.',
        );
    }

    private function ensureCanView(StudentTrackingRequest $request, Student $student): void
    {
        if (! $this->policy->view($request->user(), $student)) {
            throw new AuthorizationException;
        }
    }
}
