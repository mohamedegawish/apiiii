<?php

namespace App\Features\StudentTracking\Services;

use App\Models\Attendance;
use App\Models\ParentEvaluation;
use App\Models\Student;
use App\Models\StudentLearningRecord;
use App\Support\CenterClock;
use App\Support\Queries\DateColumn;
use Illuminate\Support\Carbon;

/**
 * Reads directly from attendances, student_learning_records, homework, and
 * parent_evaluations — never from a separate cached/derived table, so a
 * tracking profile is always current.
 */
class StudentTrackingService
{
    private const GRANULARITIES = ['weekly', 'monthly', 'quarterly', 'yearly'];

    private const LEARNING_TYPES = ['memorization', 'revision', 'matn', 'listening'];

    /** @return array<string, mixed> */
    public function profile(Student $student, string $granularity, ?string $referenceDate = null): array
    {
        $granularity = in_array($granularity, self::GRANULARITIES, true) ? $granularity : 'monthly';
        // Period boundaries (start/end of month, week, quarter) are the
        // center's, so "the current period" must resolve on its clock.
        $reference = $referenceDate !== null ? Carbon::parse($referenceDate, CenterClock::timezone()) : CenterClock::now();

        [$currentStart, $currentEnd] = $this->range($granularity, $reference);
        [$previousStart, $previousEnd] = $this->range($granularity, $this->shiftBack($granularity, $reference));

        $current = $this->metricsFor($student, $currentStart, $currentEnd);
        $previous = $this->metricsFor($student, $previousStart, $previousEnd);
        $memorizationTotals = $this->rangeMetrics(
            StudentLearningRecord::where('student_id', $student->id)
                ->where('type', 'memorization')
                ->with('homework')
                ->get(),
        );

        return [
            'student_id' => $student->id,
            'student_name' => $student->name,
            'period' => [
                'granularity' => $granularity,
                'start' => $currentStart->toDateString(),
                'end' => $currentEnd->toDateString(),
            ],
            'attendance' => $current['attendance'],
            'learning' => $current['learning'],
            'memorization_totals' => $memorizationTotals,
            'parent_engagement' => $current['parent_engagement'],
            'risk_flags' => $this->detectRiskFlags($current, $previous),
        ];
    }

    /**
     * A trend of consecutive periods (oldest first) for charting weekly/
     * monthly/quarterly/yearly performance over time.
     *
     * @return list<array<string, mixed>>
     */
    public function history(Student $student, string $granularity, int $periods = 6): array
    {
        $granularity = in_array($granularity, self::GRANULARITIES, true) ? $granularity : 'monthly';
        $periods = max(1, min($periods, 24));
        $reference = CenterClock::now();

        $rows = [];
        for ($i = $periods - 1; $i >= 0; $i--) {
            $point = $reference->copy();
            for ($step = 0; $step < $i; $step++) {
                $point = $this->shiftBack($granularity, $point);
            }

            [$start, $end] = $this->range($granularity, $point);
            $metrics = $this->metricsFor($student, $start, $end);

            $rows[] = [
                'period' => ['start' => $start->toDateString(), 'end' => $end->toDateString()],
                'attendance_rate' => $metrics['attendance']['rate'],
                'memorization_average_score' => $metrics['learning']['memorization']['average_score'],
                'revision_average_score' => $metrics['learning']['revision']['average_score'],
                'parent_engagement_rate' => $metrics['parent_engagement']['engagement_rate'],
            ];
        }

        return $rows;
    }

    /** @return array{0: Carbon, 1: Carbon} */
    private function range(string $granularity, Carbon $reference): array
    {
        return match ($granularity) {
            'weekly' => [$reference->copy()->startOfWeek(), $reference->copy()->endOfWeek()],
            'quarterly' => [$reference->copy()->startOfQuarter(), $reference->copy()->endOfQuarter()],
            'yearly' => [$reference->copy()->startOfYear(), $reference->copy()->endOfYear()],
            default => [$reference->copy()->startOfMonth(), $reference->copy()->endOfMonth()],
        };
    }

    private function shiftBack(string $granularity, Carbon $reference): Carbon
    {
        return match ($granularity) {
            'weekly' => $reference->copy()->subWeek(),
            'quarterly' => $reference->copy()->subQuarterNoOverflow(),
            'yearly' => $reference->copy()->subYearNoOverflow(),
            default => $reference->copy()->subMonthNoOverflow(),
        };
    }

    /** @return array<string, mixed> */
    private function metricsFor(Student $student, Carbon $start, Carbon $end): array
    {
        $attendanceRows = Attendance::where('student_id', $student->id)
            ->where('attendance_date', '>=', $start->toDateString())
            ->where('attendance_date', '<', DateColumn::dayAfter($end))
            ->get();
        $attendanceTotal = $attendanceRows->count();
        $presentCount = $attendanceRows->filter(fn (Attendance $a): bool => $a->status->wasPresent())->count();

        $recordsByType = StudentLearningRecord::where('student_id', $student->id)
            ->whereBetween('created_at', [$start->copy()->startOfDay(), $end->copy()->endOfDay()])
            ->with('homework')
            ->get()
            ->groupBy(fn (StudentLearningRecord $record): string => $record->type->value);

        $learning = [];
        foreach (self::LEARNING_TYPES as $type) {
            $records = $recordsByType->get($type, collect());
            $scored = $records->whereNotNull('score');

            $learning[$type] = [
                'records_count' => $records->count(),
                'average_score' => $scored->isNotEmpty() ? round((float) $scored->avg('score'), 2) : null,
                'na_count' => $records->where('is_na', true)->count(),
                ...$this->rangeMetrics($records),
            ];
        }

        $attendedSessionIds = $attendanceRows
            ->filter(fn (Attendance $a): bool => $a->status->wasPresent())
            ->pluck('circle_session_id')
            ->filter()
            ->unique();

        $submittedEvaluations = ParentEvaluation::where('student_id', $student->id)
            ->whereIn('circle_session_id', $attendedSessionIds)
            ->get();

        $expectedEvaluations = $attendedSessionIds->count();
        $submittedCount = $submittedEvaluations->count();

        return [
            'attendance' => [
                'total_records' => $attendanceTotal,
                'present_count' => $presentCount,
                'rate' => $attendanceTotal > 0 ? round($presentCount / $attendanceTotal * 100, 2) : null,
            ],
            'learning' => $learning,
            'parent_engagement' => [
                'expected_evaluations' => $expectedEvaluations,
                'submitted_evaluations' => $submittedCount,
                'engagement_rate' => $expectedEvaluations > 0 ? round($submittedCount / $expectedEvaluations * 100, 2) : null,
                'average_score' => $submittedEvaluations->isNotEmpty()
                    ? round($submittedEvaluations->avg(fn (ParentEvaluation $e): float => ((float) $e->behavior_score + (float) $e->prayer_score + (float) $e->homework_followup_score) / 3), 2)
                    : null,
            ],
        ];
    }

    /** @return array{ayahs_count: int, surahs_count: int} */
    private function rangeMetrics($records): array
    {
        $ayahs = 0;
        $surahs = [];

        foreach ($records->whereNotNull('score') as $record) {
            $fromGlobal = $record->from_global_ayah;
            $toGlobal = $record->to_global_ayah;
            if ($fromGlobal !== null && $toGlobal !== null && $toGlobal >= $fromGlobal) {
                $ayahs += $toGlobal - $fromGlobal + 1;
            } elseif ($record->from_ayah !== null && $record->to_ayah !== null) {
                $ayahs += max(0, $record->to_ayah - $record->from_ayah + 1);
            } elseif ($record->homework !== null && $record->homework->from_ayah !== null && $record->homework->to_ayah !== null) {
                $ayahs += max(0, $record->homework->to_ayah - $record->homework->from_ayah + 1);
            }

            if ($record->surah_number !== null) {
                $surahs[$record->surah_number] = true;
                if ($record->to_surah_number !== null) {
                    for ($surah = $record->surah_number + 1; $surah <= $record->to_surah_number; $surah++) {
                        $surahs[$surah] = true;
                    }
                }
            } elseif ($record->homework?->surah_number !== null) {
                $surahs[$record->homework->surah_number] = true;
            }
        }

        return ['ayahs_count' => $ayahs, 'surahs_count' => count($surahs)];
    }

    /**
     * @param  array<string, mixed>  $current
     * @param  array<string, mixed>  $previous
     * @return list<string>
     */
    private function detectRiskFlags(array $current, array $previous): array
    {
        $flags = [];

        $currentAttendanceRate = $current['attendance']['rate'];
        $previousAttendanceRate = $previous['attendance']['rate'];
        if ($currentAttendanceRate !== null && $previousAttendanceRate !== null && $previousAttendanceRate - $currentAttendanceRate >= 15) {
            $flags[] = 'attendance_decline';
        }

        $currentMemorization = $current['learning']['memorization']['average_score'];
        $previousMemorization = $previous['learning']['memorization']['average_score'];
        if ($currentMemorization !== null && $previousMemorization !== null && $previousMemorization - $currentMemorization >= 10) {
            $flags[] = 'memorization_decline';
        }

        $currentRevision = $current['learning']['revision']['average_score'];
        $previousRevision = $previous['learning']['revision']['average_score'];
        if ($currentRevision !== null && $previousRevision !== null && $previousRevision - $currentRevision >= 10) {
            $flags[] = 'revision_decline';
        }

        $engagementRate = $current['parent_engagement']['engagement_rate'];
        if ($current['parent_engagement']['expected_evaluations'] > 0 && $engagementRate !== null && $engagementRate < 50) {
            $flags[] = 'low_parent_engagement';
        }

        return $flags;
    }
}
