<?php

namespace App\Features\StudentTracking\Requests;

use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class StudentTrackingRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'granularity' => ['nullable', Rule::in(['weekly', 'monthly', 'quarterly', 'yearly'])],
            'date' => ['nullable', 'date'],
            'periods' => ['nullable', 'integer', 'min:1', 'max:24'],
        ];
    }
}
