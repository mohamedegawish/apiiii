<?php

namespace App\Features\Student\Controllers;

use App\Enums\CircleSessionStatus;
use App\Enums\EnrollmentStatus;
use App\Enums\Role;
use App\Features\Assessments\Resources\AssessmentResource;
use App\Features\Attendance\Resources\AttendanceResource;
use App\Features\CircleSessions\Resources\CircleSessionResource;
use App\Features\Homework\Resources\HomeworkResource;
use App\Features\LearningRecords\Resources\LearningRecordResource;
use App\Features\MemorizationSessions\Resources\MemorizationSessionResource;
use App\Features\RevisionSessions\Resources\RevisionSessionResource;
use App\Models\CircleSession;
use App\Models\Student;
use App\Models\User;
use App\Support\CenterClock;
use App\Support\Exceptions\ForbiddenException;
use App\Support\Http\Controllers\BaseController;
use App\Support\Queries\DateColumn;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\ResourceCollection;

class StudentController extends BaseController
{
    public function profile(Request $request): JsonResponse
    {
        return $this->success(
            data: $this->profileData($this->student($request)),
            message: 'Student profile retrieved successfully.',
        );
    }

    public function dashboard(Request $request): JsonResponse
    {
        $student = $this->student($request);
        $profile = $this->profileData($student);

        return $this->success(data: [
            'student' => $profile,
            'counts' => [
                'pending_homework' => $student->homework()->whereIn('status', ['pending', 'late'])->count(),
                'memorization_sessions' => $student->memorizationSessions()->count(),
                'revision_sessions' => $student->revisionSessions()->count(),
                'assessments' => $student->assessments()->count(),
            ],
            'next_session' => $student->enrollments()
                ->where('status', EnrollmentStatus::Active->value)
                ->whereNull('left_at')
                ->with(['circle.sessions' => fn (HasMany $query) => $query
                    ->where('session_date', '>=', DateColumn::day(CenterClock::today()))
                    // A cancelled session is not an upcoming lesson.
                    ->where('status', '!=', CircleSessionStatus::Cancelled->value)
                    ->orderBy('session_date')
                    ->orderBy('start_time')
                    ->limit(1)])
                ->get()
                ->flatMap(fn ($enrollment) => $enrollment->circle->sessions)
                ->sortBy('session_date')
                ->first()?->only(['id', 'circle_id', 'session_date', 'start_time', 'end_time', 'status']),
        ], message: 'Student dashboard retrieved successfully.');
    }

    public function memorizationSessions(Request $request): JsonResponse
    {
        return $this->resourcePage(
            MemorizationSessionResource::collection($this->student($request)->memorizationSessions()->latest('session_date')->latest('id')->paginate($this->perPage($request))),
            'Memorization sessions retrieved successfully.',
        );
    }

    public function revisionSessions(Request $request): JsonResponse
    {
        return $this->resourcePage(
            RevisionSessionResource::collection($this->student($request)->revisionSessions()->latest('session_date')->latest('id')->paginate($this->perPage($request))),
            'Revision sessions retrieved successfully.',
        );
    }

    public function attendance(Request $request): JsonResponse
    {
        return $this->resourcePage(
            AttendanceResource::collection($this->student($request)->attendances()->latest('attendance_date')->latest('id')->paginate($this->perPage($request))),
            'Attendance retrieved successfully.',
        );
    }

    public function homework(Request $request): JsonResponse
    {
        return $this->resourcePage(
            HomeworkResource::collection($this->student($request)->homework()->latest('due_date')->latest('id')->paginate($this->perPage($request))),
            'Homework retrieved successfully.',
        );
    }

    public function assessments(Request $request): JsonResponse
    {
        return $this->resourcePage(
            AssessmentResource::collection($this->student($request)->assessments()->latest('assessment_date')->latest('id')->paginate($this->perPage($request))),
            'Assessments retrieved successfully.',
        );
    }

    public function sessions(Request $request): JsonResponse
    {
        $student = $this->student($request);
        $circleIds = $student->enrollments()->pluck('circle_id');
        $paginator = CircleSession::query()
            ->whereIn('circle_id', $circleIds)
            ->latest('session_date')
            ->latest('id')
            ->paginate($this->perPage($request));

        return $this->resourcePage(CircleSessionResource::collection($paginator), 'Student sessions retrieved successfully.');
    }

    public function learningRecords(Request $request): JsonResponse
    {
        return $this->resourcePage(
            LearningRecordResource::collection(
                $this->student($request)
                    ->learningRecords()
                    // LearningRecordResource emits teacher_name, circle_name,
                    // session_date and the matn section names only whenLoaded();
                    // unloaded they are absent from the payload entirely, which
                    // is why matn rows rendered as a bare dash in the app.
                    ->with(['teacher.user', 'circleSession.circle', 'matnType', 'fromMatnSection', 'toMatnSection'])
                    ->latest()
                    ->latest('id')
                    ->paginate($this->perPage($request))
            ),
            'Learning records retrieved successfully.',
        );
    }

    private function student(Request $request): Student
    {
        $user = $request->user();

        if (! $user instanceof User || ! $user->hasRole(Role::Student) || $user->student === null) {
            throw new ForbiddenException('The authenticated student account is not linked to a student profile.');
        }

        return $user->student;
    }

    /** @return array<string, mixed> */
    private function profileData(Student $student): array
    {
        $student->loadMissing(['statistics', 'enrollments.circle.teacher.user']);
        $enrollment = $student->enrollments
            ->first(fn ($item) => $item->status === EnrollmentStatus::Active && $item->left_at === null)
            ?? $student->enrollments->first();
        $circle = $enrollment?->circle;
        $statistics = $student->statistics;

        return [
            'id' => $student->id,
            'student_code' => $student->student_code,
            'name' => $student->name,
            'phone' => $student->phone,
            'email' => $student->email,
            'guardian_id' => $student->guardian_id,
            'status' => $student->status?->value,
            'circle' => $circle === null ? null : [
                'id' => $circle->id,
                'name' => $circle->name,
                'level' => $circle->level,
                'teacher' => $circle->teacher === null ? null : [
                    'id' => $circle->teacher->id,
                    'name' => $circle->teacher->user?->name,
                ],
            ],
            'statistics' => [
                'memorized_pages' => $statistics?->memorized_pages ?? 0,
                'memorized_juz' => $statistics?->memorized_juz ?? 0,
                'completed_surahs' => $statistics?->completed_surahs ?? 0,
                'attendance_rate' => (float) ($statistics?->attendance_rate ?? 0),
                'average_grade' => (float) ($statistics?->average_memorization_grade ?? 0),
                'last_calculated_at' => $statistics?->last_calculated_at?->toIso8601String(),
            ],
        ];
    }

    private function perPage(Request $request): int
    {
        return min(max($request->integer('per_page', 20), 1), 100);
    }

    private function resourcePage(ResourceCollection $collection, string $message): JsonResponse
    {
        return $this->paginate($collection, $message);
    }
}
