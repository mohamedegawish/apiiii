<?php

namespace App\Features\Users\Services;

use App\Features\Users\Actions\CreateUserAction;
use App\Features\Users\Actions\DeactivateUserAction;
use App\Features\Users\Queries\UserQuery;
use App\Models\User;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class UserService extends BaseService
{
    public function __construct(
        private readonly CreateUserAction $createUserAction,
        private readonly DeactivateUserAction $deactivateUserAction,
        private readonly UserQuery $userQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->userQuery->paginate();
    }

    public function findOrFail(string $id): User
    {
        $user = $this->userQuery->getBuilder()->whereKey($id)->first();

        if (! $user instanceof User) {
            throw new NotFoundException('User not found.');
        }

        return $user;
    }

    /** @param array<string, mixed> $data */
    public function create(User $actor, array $data): User
    {
        return $this->transaction(fn (): User => $this->createUserAction->execute($actor, $data));
    }

    public function deactivate(User $actor, User $user): User
    {
        return $this->transaction(fn (): User => $this->deactivateUserAction->execute($actor, $user));
    }
}
