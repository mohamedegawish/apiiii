<?php

namespace App\Features\Users\Queries;

use App\Enums\Role;
use App\Models\User;
use App\Support\Queries\BaseQuery;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class UserQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(User::class);
    }

    /** @param EloquentBuilder<User> $builder */
    protected function applyTenantScope(EloquentBuilder $builder): void
    {
        $builder->where('role', '!=', Role::SuperAdmin->value);

        $actor = $this->currentUser();

        if ($actor?->hasRole(Role::CenterOwner)) {
            $builder->where('created_by', $actor->id)
                ->whereIn('role', [Role::Teacher->value, Role::Parent->value, Role::Student->value]);

            return;
        }

        if ($actor?->isSuperAdmin() !== true) {
            $builder->whereRaw('1 = 0');
        }
    }

    /** @return list<AllowedFilter> */
    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::partial('name'),
            AllowedFilter::partial('email'),
            AllowedFilter::exact('role'),
            AllowedFilter::exact('is_active'),
        ];
    }

    /** @return list<string> */
    protected function allowedSorts(): array
    {
        return ['name', 'email', 'role', 'is_active', 'created_at', 'updated_at'];
    }
}
