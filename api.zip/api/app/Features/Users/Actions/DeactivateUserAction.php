<?php

namespace App\Features\Users\Actions;

use App\Features\Users\Policies\UserPolicy;
use App\Models\User;
use App\Support\Actions\BaseAction;
use Illuminate\Auth\Access\AuthorizationException;

class DeactivateUserAction extends BaseAction
{
    public function __construct(private readonly UserPolicy $policy) {}

    public function execute(mixed ...$arguments): User
    {
        $actor = $arguments[0] ?? null;
        $user = $arguments[1] ?? null;

        if (! $actor instanceof User || ! $user instanceof User) {
            throw new \InvalidArgumentException('DeactivateUserAction expects an actor and target user.');
        }

        if (! $this->policy->deactivate($actor, $user)) {
            throw new AuthorizationException('You may not deactivate this user.');
        }

        $user->forceFill(['is_active' => false])->save();

        return $user->fresh();
    }
}
