<?php

namespace App\Features\Users\Actions;

use App\Enums\Role;
use App\Models\User;
use App\Support\Actions\BaseAction;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Hash;

class CreateUserAction extends BaseAction
{
    /** @param array<string, mixed> $data */
    public function execute(mixed ...$arguments): User
    {
        $actor = $arguments[0] ?? null;
        $data = $arguments[1] ?? null;

        if (! $actor instanceof User || ! is_array($data)) {
            throw new \InvalidArgumentException('CreateUserAction expects an actor and validated data.');
        }

        $role = Role::tryFrom((string) ($data['role'] ?? ''));
        $allowedRoles = $actor->isSuperAdmin()
            ? array_values(array_filter(Role::cases(), fn (Role $role): bool => $role !== Role::SuperAdmin))
            : ($actor->hasRole(Role::CenterOwner)
                ? [Role::Teacher, Role::Parent, Role::Student]
                : []);

        if (! in_array($role, $allowedRoles, true)) {
            throw new AuthorizationException('You may not create a user with this role.');
        }

        $user = new User;
        $user->fill(Arr::only($data, ['name', 'email', 'locale', 'timezone']));
        $user->forceFill([
            'password' => Hash::make((string) $data['password']),
            'role' => $role,
            'is_active' => (bool) ($data['is_active'] ?? true),
        ]);
        $user->save();

        return $user->fresh();
    }
}
