<?php

namespace App\Features\Users\Policies;

use App\Enums\Role;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class UserPolicy extends BasePolicy
{
    public function viewAny(?User $actor): bool
    {
        return $this->hasRole($actor, Role::SuperAdmin, Role::CenterOwner);
    }

    public function view(?User $actor, User $user): bool
    {
        return $this->canManage($actor, $user);
    }

    public function create(?User $actor): bool
    {
        return $this->hasRole($actor, Role::SuperAdmin, Role::CenterOwner);
    }

    public function deactivate(?User $actor, User $user): bool
    {
        return $actor?->is($user) !== true && $this->canManage($actor, $user);
    }

    private function canManage(?User $actor, User $user): bool
    {
        if (! $actor instanceof User || $user->roleEnum() === Role::SuperAdmin) {
            return false;
        }

        if ($actor->isSuperAdmin()) {
            return true;
        }

        return $actor->hasRole(Role::CenterOwner)
            && $user->created_by === $actor->id
            && in_array($user->roleEnum(), [Role::Teacher, Role::Parent, Role::Student], true);
    }
}
