<?php

namespace App\Features\Users\Requests;

use App\Features\Users\Policies\UserPolicy;
use App\Models\User;
use App\Support\Http\Requests\BaseRequest;

class DeactivateUserRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $target = User::find($this->route('user'));

        return $target instanceof User
            && (new UserPolicy)->deactivate($this->user(), $target);
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [];
    }
}
