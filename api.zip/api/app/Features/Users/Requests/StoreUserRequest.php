<?php

namespace App\Features\Users\Requests;

use App\Enums\Role;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class StoreUserRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('manage-users') ?? false;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        $roles = $this->user()?->hasRole(Role::CenterOwner)
            ? [Role::Teacher->value, Role::Parent->value, Role::Student->value]
            : array_values(array_diff(Role::values(), [Role::SuperAdmin->value]));

        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8', 'max:255', 'confirmed'],
            'role' => ['required', 'string', Rule::in($roles)],
            'locale' => ['sometimes', 'string', 'max:10'],
            'timezone' => ['sometimes', 'string', 'max:50'],
            'is_active' => ['sometimes', 'boolean'],
        ];
    }
}
