<?php

namespace App\Features\Users\Controllers;

use App\Features\Users\Policies\UserPolicy;
use App\Features\Users\Requests\DeactivateUserRequest;
use App\Features\Users\Requests\StoreUserRequest;
use App\Features\Users\Resources\UserResource;
use App\Features\Users\Services\UserService;
use App\Models\User;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class UserController extends BaseController
{
    public function __construct(
        private readonly UserService $userService,
        private readonly UserPolicy $policy,
    ) {}

    public function index(Request $request): JsonResponse
    {
        abort_unless($this->policy->viewAny($request->user()), 403);

        return $this->paginate(UserResource::collection($this->userService->paginate()), 'Users retrieved successfully.');
    }

    public function show(Request $request, string $user): JsonResponse
    {
        $target = $this->userService->findOrFail($user);
        abort_unless($this->policy->view($request->user(), $target), 403);

        return $this->success(UserResource::make($target), 'User retrieved successfully.');
    }

    public function store(StoreUserRequest $request): JsonResponse
    {
        /** @var User $actor */
        $actor = $request->user();
        $user = $this->userService->create($actor, $request->validatedData());

        return $this->created(UserResource::make($user), 'User created successfully.');
    }

    public function deactivate(DeactivateUserRequest $request, string $user): JsonResponse
    {
        /** @var User $actor */
        $actor = $request->user();
        $target = $this->userService->findOrFail($user);
        $user = $this->userService->deactivate($actor, $target);

        return $this->success(UserResource::make($user), 'User deactivated successfully.');
    }
}
