<?php

namespace App\Features\Guardians\Services;

use App\Features\Guardians\Actions\DeleteGuardianAction;
use App\Features\Guardians\Actions\UpdateGuardianAction;
use App\Features\Guardians\Queries\GuardianQuery;
use App\Features\Guardians\Requests\UpdateGuardianRequest;
use App\Models\Guardian;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class GuardianService extends BaseService
{
    public function __construct(
        protected UpdateGuardianAction $updateGuardianAction,
        protected DeleteGuardianAction $deleteGuardianAction,
        protected GuardianQuery $guardianQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->guardianQuery->paginate();
    }

    public function findOrFail(string $id): Guardian
    {
        $guardian = Guardian::find($id);

        if ($guardian === null) {
            throw new NotFoundException('Guardian not found.');
        }

        return $guardian;
    }

    public function update(Guardian $guardian, UpdateGuardianRequest $request): Guardian
    {
        return $this->transaction(fn (): Guardian => $this->updateGuardianAction->execute($guardian, $request));
    }

    public function delete(Guardian $guardian): bool
    {
        return $this->transaction(fn (): bool => $this->deleteGuardianAction->execute($guardian));
    }
}
