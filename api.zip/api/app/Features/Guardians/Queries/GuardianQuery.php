<?php

namespace App\Features\Guardians\Queries;

use App\Enums\Role;
use App\Models\Guardian;
use App\Support\Queries\BaseQuery;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class GuardianQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(Guardian::class);
    }

    /**
     * A teacher may see guardians of students currently enrolled in their
     * own circles. Every other non-staff role (guardian/student) is denied
     * entirely — `GuardianPolicy::viewAny` already blocks the endpoint for
     * them, but this scope fails closed too rather than silently returning
     * every family's contact info if that policy check is ever bypassed.
     */
    protected function applyTenantScope(EloquentBuilder $builder): void
    {
        if ($this->shouldBypassScope()) {
            return;
        }

        $user = $this->currentUser();

        if ($user?->hasRole(Role::Teacher) && $user->teacher !== null) {
            $builder->whereHas('children', fn (EloquentBuilder $query) => $query
                ->whereHas('enrollments', fn (EloquentBuilder $enrollment) => $enrollment
                    ->where('status', 'active')->whereNull('left_at')
                    ->whereHas('circle', fn (EloquentBuilder $circle) => $circle->where('teacher_id', $user->teacher->id))));

            return;
        }

        $builder->whereRaw('1 = 0');
    }

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::partial('name'),
            AllowedFilter::partial('phone'),
            AllowedFilter::partial('email'),
            AllowedFilter::exact('gender'),
            AllowedFilter::scope('search'),
        ];
    }

    protected function allowedSorts(): array
    {
        return [
            'name',
            'created_at',
            'updated_at',
        ];
    }

    protected function allowedIncludes(): array
    {
        return ['students'];
    }
}
