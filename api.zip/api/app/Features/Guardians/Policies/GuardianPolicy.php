<?php

namespace App\Features\Guardians\Policies;

use App\Enums\Role;
use App\Models\Guardian;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class GuardianPolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $user instanceof User && $user->roleEnum()?->isStaff() === true;
    }

    public function view(?User $user, Guardian $guardian): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        if ($this->hasRole($user, Role::Parent)) {
            return $guardian->user_id === $user?->id;
        }

        if ($this->hasRole($user, Role::Teacher) && $user?->teacher !== null) {
            return $guardian->children()->whereHas('enrollments', fn ($query) => $query
                ->where('status', 'active')->whereNull('left_at')
                ->whereHas('circle', fn ($circle) => $circle->where('teacher_id', $user->teacher->id)))
                ->exists();
        }

        return false;
    }

    public function create(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }

    public function update(?User $user, Guardian $guardian): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        return $this->hasRole($user, Role::CenterOwner);
    }

    public function delete(?User $user, Guardian $guardian): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        return $this->hasRole($user, Role::CenterOwner);
    }

    public function restore(?User $user, Guardian $guardian): bool
    {
        return $this->isSuperAdmin($user);
    }

    public function forceDelete(?User $user, Guardian $guardian): bool
    {
        return $this->isSuperAdmin($user);
    }
}
