<?php

namespace App\Features\Guardians\Actions;

use App\Models\Guardian;
use App\Support\Actions\BaseAction;

class DeleteGuardianAction extends BaseAction
{
    /**
     * @return bool
     */
    public function execute(mixed ...$arguments): mixed
    {
        $guardian = $arguments[0] ?? null;

        if (! $guardian instanceof Guardian) {
            throw new \InvalidArgumentException('DeleteGuardianAction expects a Guardian.');
        }

        return $guardian->delete();
    }
}
