<?php

namespace App\Features\Guardians\Actions;

use App\Features\Guardians\Requests\UpdateGuardianRequest;
use App\Models\Guardian;
use App\Support\Actions\BaseAction;

class UpdateGuardianAction extends BaseAction
{
    /**
     * @return Guardian
     */
    public function execute(mixed ...$arguments): mixed
    {
        $guardian = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $guardian instanceof Guardian) {
            throw new \InvalidArgumentException('UpdateGuardianAction expects a Guardian as the first argument.');
        }

        if (! $request instanceof UpdateGuardianRequest) {
            throw new \InvalidArgumentException('UpdateGuardianAction expects an UpdateGuardianRequest as the second argument.');
        }

        $guardian->update($request->validatedData());

        return $guardian->fresh();
    }
}
