<?php

namespace App\Features\Guardians\Requests;

use App\Enums\GuardianRelationship;
use App\Models\Guardian;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class UpdateGuardianRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $guardian = Guardian::find($this->route('guardian'));

        return $this->user()?->can('update', $guardian) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'name' => ['sometimes', 'string', 'max:255'],
            'phone' => ['nullable', 'string', 'max:30'],
            'email' => ['nullable', 'email', 'max:255'],
            'relationship' => ['nullable', Rule::enum(GuardianRelationship::class)],
            'gender' => ['nullable', 'in:male,female'],
            'occupation' => ['nullable', 'string', 'max:100'],
        ];
    }
}
