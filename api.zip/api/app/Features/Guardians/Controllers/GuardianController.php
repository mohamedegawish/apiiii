<?php

namespace App\Features\Guardians\Controllers;

use App\Features\Guardians\Requests\UpdateGuardianRequest;
use App\Features\Guardians\Resources\GuardianResource;
use App\Features\Guardians\Services\GuardianService;
use App\Models\Guardian;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class GuardianController extends BaseController
{
    public function __construct(protected GuardianService $guardianService) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Guardian::class);

        $paginator = $this->guardianService->paginate();

        return $this->paginate(GuardianResource::collection($paginator), 'Guardians retrieved successfully.');
    }

    public function show(string $guardian): JsonResponse
    {
        $model = $this->guardianService->findOrFail($guardian);

        $this->authorize('view', $model);

        return $this->success(
            data: GuardianResource::make($model),
            message: 'Guardian retrieved successfully.',
        );
    }

    public function update(UpdateGuardianRequest $request, string $guardian): JsonResponse
    {
        $model = $this->guardianService->findOrFail($guardian);
        $updated = $this->guardianService->update($model, $request);

        return $this->success(
            data: GuardianResource::make($updated),
            message: 'Guardian updated successfully.',
        );
    }

    public function destroy(string $guardian): JsonResponse
    {
        $model = $this->guardianService->findOrFail($guardian);

        $this->authorize('delete', $model);

        $this->guardianService->delete($model);

        return $this->success(
            data: null,
            message: 'Guardian deleted successfully.',
        );
    }
}
