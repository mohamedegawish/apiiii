<?php

namespace App\Features\MatnCatalog\Controllers;

use App\Features\MatnCatalog\Requests\StoreMatnTypeRequest;
use App\Features\MatnCatalog\Requests\UpdateMatnTypeRequest;
use App\Features\MatnCatalog\Resources\MatnTypeResource;
use App\Features\MatnCatalog\Services\MatnTypeService;
use App\Models\MatnType;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MatnTypeController extends BaseController
{
    public function __construct(protected MatnTypeService $matnTypeService) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', MatnType::class);

        return $this->paginate(
            MatnTypeResource::collection($this->matnTypeService->paginate()),
            'Matn types retrieved successfully.',
        );
    }

    public function show(string $matnType): JsonResponse
    {
        $model = $this->matnTypeService->findOrFail($matnType);
        $this->authorize('view', $model);

        return $this->success(MatnTypeResource::make($model), 'Matn type retrieved successfully.');
    }

    public function store(StoreMatnTypeRequest $request): JsonResponse
    {
        return $this->created(
            MatnTypeResource::make($this->matnTypeService->create($request)),
            'Matn type created successfully.',
        );
    }

    public function update(UpdateMatnTypeRequest $request, string $matnType): JsonResponse
    {
        $model = $this->matnTypeService->findOrFail($matnType);

        return $this->success(
            MatnTypeResource::make($this->matnTypeService->update($model, $request)),
            'Matn type updated successfully.',
        );
    }

    public function destroy(string $matnType): JsonResponse
    {
        $model = $this->matnTypeService->findOrFail($matnType);
        $this->authorize('delete', $model);
        $this->matnTypeService->delete($model);

        return $this->success(null, 'Matn type deleted successfully.');
    }
}
