<?php

namespace App\Features\MatnCatalog\Controllers;

use App\Features\MatnCatalog\Requests\StoreMatnSectionRequest;
use App\Features\MatnCatalog\Requests\UpdateMatnSectionRequest;
use App\Features\MatnCatalog\Resources\MatnSectionResource;
use App\Features\MatnCatalog\Services\MatnSectionService;
use App\Features\MatnCatalog\Services\MatnTypeService;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;

class MatnSectionController extends BaseController
{
    public function __construct(
        protected MatnSectionService $matnSectionService,
        protected MatnTypeService $matnTypeService,
    ) {}

    public function index(string $matnType): JsonResponse
    {
        $model = $this->matnTypeService->findOrFail($matnType);
        $this->authorize('view', $model);

        return $this->success(
            MatnSectionResource::collection($model->sections)->resolve(),
            'Matn sections retrieved successfully.',
        );
    }

    public function store(StoreMatnSectionRequest $request, string $matnType): JsonResponse
    {
        $model = $this->matnTypeService->findOrFail($matnType);

        return $this->created(
            MatnSectionResource::make($this->matnSectionService->create($model, $request)),
            'Matn section created successfully.',
        );
    }

    public function update(UpdateMatnSectionRequest $request, string $matnSection): JsonResponse
    {
        $section = $this->matnSectionService->findOrFail($matnSection);

        return $this->success(
            MatnSectionResource::make($this->matnSectionService->update($section, $request)),
            'Matn section updated successfully.',
        );
    }

    public function destroy(string $matnSection): JsonResponse
    {
        $section = $this->matnSectionService->findOrFail($matnSection);
        $this->authorize('delete', $section->matnType);
        $this->matnSectionService->delete($section);

        return $this->success(null, 'Matn section deleted successfully.');
    }
}
