<?php

namespace App\Features\MatnCatalog\Actions;

use App\Features\MatnCatalog\Requests\StoreMatnSectionRequest;
use App\Models\MatnSection;
use App\Models\MatnType;
use App\Support\Actions\BaseAction;

class CreateMatnSectionAction extends BaseAction
{
    /**
     * @return MatnSection
     */
    public function execute(mixed ...$arguments): mixed
    {
        $matnType = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $matnType instanceof MatnType) {
            throw new \InvalidArgumentException('CreateMatnSectionAction expects a MatnType as the first argument.');
        }

        if (! $request instanceof StoreMatnSectionRequest) {
            throw new \InvalidArgumentException('CreateMatnSectionAction expects a StoreMatnSectionRequest as the second argument.');
        }

        $data = $request->validatedData();
        $data['matn_type_id'] = $matnType->id;
        $data['order'] ??= ((int) $matnType->sections()->max('order')) + 1;

        return MatnSection::create($data);
    }
}
