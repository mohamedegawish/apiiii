<?php

namespace App\Features\MatnCatalog\Actions;

use App\Features\MatnCatalog\Requests\StoreMatnTypeRequest;
use App\Models\MatnType;
use App\Support\Actions\BaseAction;

class CreateMatnTypeAction extends BaseAction
{
    /**
     * @return MatnType
     */
    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreMatnTypeRequest) {
            throw new \InvalidArgumentException('CreateMatnTypeAction expects a StoreMatnTypeRequest.');
        }

        $data = $request->validatedData();
        $active = $data['is_active'] ?? true;
        unset($data['is_active']);

        $matnType = MatnType::create($data);
        $matnType->forceFill(['is_active' => $active])->save();

        return $matnType;
    }
}
