<?php

namespace App\Features\MatnCatalog\Actions;

use App\Models\MatnType;
use App\Support\Actions\BaseAction;

class DeleteMatnTypeAction extends BaseAction
{
    /**
     * @return bool
     */
    public function execute(mixed ...$arguments): mixed
    {
        $matnType = $arguments[0] ?? null;

        if (! $matnType instanceof MatnType) {
            throw new \InvalidArgumentException('DeleteMatnTypeAction expects a MatnType.');
        }

        return $matnType->delete();
    }
}
