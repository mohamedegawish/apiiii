<?php

namespace App\Features\MatnCatalog\Actions;

use App\Features\MatnCatalog\Requests\UpdateMatnSectionRequest;
use App\Models\MatnSection;
use App\Support\Actions\BaseAction;

class UpdateMatnSectionAction extends BaseAction
{
    /**
     * @return MatnSection
     */
    public function execute(mixed ...$arguments): mixed
    {
        $section = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $section instanceof MatnSection) {
            throw new \InvalidArgumentException('UpdateMatnSectionAction expects a MatnSection as the first argument.');
        }

        if (! $request instanceof UpdateMatnSectionRequest) {
            throw new \InvalidArgumentException('UpdateMatnSectionAction expects an UpdateMatnSectionRequest as the second argument.');
        }

        $section->update($request->validatedData());

        return $section->fresh();
    }
}
