<?php

namespace App\Features\MatnCatalog\Actions;

use App\Models\MatnSection;
use App\Support\Actions\BaseAction;

class DeleteMatnSectionAction extends BaseAction
{
    /**
     * @return bool
     */
    public function execute(mixed ...$arguments): mixed
    {
        $section = $arguments[0] ?? null;

        if (! $section instanceof MatnSection) {
            throw new \InvalidArgumentException('DeleteMatnSectionAction expects a MatnSection.');
        }

        return $section->delete();
    }
}
