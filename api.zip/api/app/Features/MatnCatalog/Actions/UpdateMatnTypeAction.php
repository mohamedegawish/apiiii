<?php

namespace App\Features\MatnCatalog\Actions;

use App\Features\MatnCatalog\Requests\UpdateMatnTypeRequest;
use App\Models\MatnType;
use App\Support\Actions\BaseAction;

class UpdateMatnTypeAction extends BaseAction
{
    /**
     * @return MatnType
     */
    public function execute(mixed ...$arguments): mixed
    {
        $matnType = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $matnType instanceof MatnType) {
            throw new \InvalidArgumentException('UpdateMatnTypeAction expects a MatnType as the first argument.');
        }

        if (! $request instanceof UpdateMatnTypeRequest) {
            throw new \InvalidArgumentException('UpdateMatnTypeAction expects an UpdateMatnTypeRequest as the second argument.');
        }

        $matnType->update($request->validatedData());

        return $matnType->fresh();
    }
}
