<?php

namespace App\Features\MatnCatalog\Policies;

use App\Enums\Role;
use App\Models\MatnType;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class MatnCatalogPolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $user instanceof User && $user->roleEnum()?->isStaff() === true;
    }

    public function view(?User $user, MatnType $matnType): bool
    {
        return $user instanceof User && $user->roleEnum()?->isStaff() === true;
    }

    public function create(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }

    public function update(?User $user, MatnType $matnType): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }

    public function delete(?User $user, MatnType $matnType): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }
}
