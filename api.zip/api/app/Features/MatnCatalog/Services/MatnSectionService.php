<?php

namespace App\Features\MatnCatalog\Services;

use App\Features\MatnCatalog\Actions\CreateMatnSectionAction;
use App\Features\MatnCatalog\Actions\DeleteMatnSectionAction;
use App\Features\MatnCatalog\Actions\UpdateMatnSectionAction;
use App\Features\MatnCatalog\Requests\StoreMatnSectionRequest;
use App\Features\MatnCatalog\Requests\UpdateMatnSectionRequest;
use App\Models\MatnSection;
use App\Models\MatnType;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;

class MatnSectionService extends BaseService
{
    public function __construct(
        protected CreateMatnSectionAction $createMatnSectionAction,
        protected UpdateMatnSectionAction $updateMatnSectionAction,
        protected DeleteMatnSectionAction $deleteMatnSectionAction,
    ) {}

    public function findOrFail(string $id): MatnSection
    {
        $section = MatnSection::with('matnType')->find($id);

        if ($section === null) {
            throw new NotFoundException('Matn section not found.');
        }

        return $section;
    }

    public function create(MatnType $matnType, StoreMatnSectionRequest $request): MatnSection
    {
        return $this->transaction(fn (): MatnSection => $this->createMatnSectionAction->execute($matnType, $request));
    }

    public function update(MatnSection $section, UpdateMatnSectionRequest $request): MatnSection
    {
        return $this->transaction(fn (): MatnSection => $this->updateMatnSectionAction->execute($section, $request));
    }

    public function delete(MatnSection $section): bool
    {
        return $this->transaction(fn (): bool => $this->deleteMatnSectionAction->execute($section));
    }
}
