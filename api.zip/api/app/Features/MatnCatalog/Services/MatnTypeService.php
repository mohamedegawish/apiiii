<?php

namespace App\Features\MatnCatalog\Services;

use App\Features\MatnCatalog\Actions\CreateMatnTypeAction;
use App\Features\MatnCatalog\Actions\DeleteMatnTypeAction;
use App\Features\MatnCatalog\Actions\UpdateMatnTypeAction;
use App\Features\MatnCatalog\Queries\MatnTypeQuery;
use App\Features\MatnCatalog\Requests\StoreMatnTypeRequest;
use App\Features\MatnCatalog\Requests\UpdateMatnTypeRequest;
use App\Models\MatnType;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class MatnTypeService extends BaseService
{
    public function __construct(
        protected CreateMatnTypeAction $createMatnTypeAction,
        protected UpdateMatnTypeAction $updateMatnTypeAction,
        protected DeleteMatnTypeAction $deleteMatnTypeAction,
        protected MatnTypeQuery $matnTypeQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->matnTypeQuery->paginate();
    }

    public function findOrFail(string $id): MatnType
    {
        $matnType = MatnType::with('sections')->find($id);

        if ($matnType === null) {
            throw new NotFoundException('Matn type not found.');
        }

        return $matnType;
    }

    public function create(StoreMatnTypeRequest $request): MatnType
    {
        return $this->transaction(fn (): MatnType => $this->createMatnTypeAction->execute($request));
    }

    public function update(MatnType $matnType, UpdateMatnTypeRequest $request): MatnType
    {
        return $this->transaction(fn (): MatnType => $this->updateMatnTypeAction->execute($matnType, $request));
    }

    public function delete(MatnType $matnType): bool
    {
        return $this->transaction(fn (): bool => $this->deleteMatnTypeAction->execute($matnType));
    }
}
