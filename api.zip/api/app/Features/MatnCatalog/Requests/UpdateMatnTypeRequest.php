<?php

namespace App\Features\MatnCatalog\Requests;

use App\Models\MatnType;
use App\Support\Http\Requests\BaseRequest;

class UpdateMatnTypeRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $matnType = MatnType::find($this->route('matnType'));

        return $this->user()?->can('update', $matnType) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'name' => ['sometimes', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:1000'],
            'is_active' => ['sometimes', 'boolean'],
        ];
    }
}
