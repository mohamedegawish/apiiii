<?php

namespace App\Features\MatnCatalog\Requests;

use App\Models\MatnType;
use App\Support\Http\Requests\BaseRequest;

class StoreMatnSectionRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $matnType = MatnType::find($this->route('matnType'));

        return $matnType !== null && ($this->user()?->can('update', $matnType) ?? false);
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'order' => ['nullable', 'integer', 'min:0'],
        ];
    }
}
