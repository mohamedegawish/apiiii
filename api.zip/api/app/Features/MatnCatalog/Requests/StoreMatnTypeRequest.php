<?php

namespace App\Features\MatnCatalog\Requests;

use App\Models\MatnType;
use App\Support\Http\Requests\BaseRequest;

class StoreMatnTypeRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', MatnType::class) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:1000'],
            'is_active' => ['nullable', 'boolean'],
        ];
    }
}
