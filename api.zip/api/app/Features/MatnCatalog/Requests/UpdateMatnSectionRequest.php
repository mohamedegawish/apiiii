<?php

namespace App\Features\MatnCatalog\Requests;

use App\Models\MatnSection;
use App\Support\Http\Requests\BaseRequest;

class UpdateMatnSectionRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $section = MatnSection::with('matnType')->find($this->route('matnSection'));

        return $section !== null && ($this->user()?->can('update', $section->matnType) ?? false);
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'name' => ['sometimes', 'string', 'max:255'],
            'order' => ['sometimes', 'integer', 'min:0'],
        ];
    }
}
