<?php

namespace App\Features\MatnCatalog\Queries;

use App\Models\MatnType;
use App\Support\Queries\BaseQuery;
use Spatie\QueryBuilder\AllowedFilter;

class MatnTypeQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(MatnType::class);
    }

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::partial('name'),
            AllowedFilter::exact('is_active'),
            AllowedFilter::scope('search'),
        ];
    }

    protected function allowedSorts(): array
    {
        return ['name', 'created_at', 'updated_at'];
    }

    protected function allowedIncludes(): array
    {
        return ['sections'];
    }
}
