<?php

namespace App\Features\Students\Requests;

use App\Support\Http\Requests\BaseRequest;

class BulkDeleteStudentRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    public function rules(): array
    {
        return [
            'ids' => ['required', 'array', 'min:1', 'max:100'],
            'ids.*' => ['required', 'uuid', 'exists:students,id'],
        ];
    }
}
