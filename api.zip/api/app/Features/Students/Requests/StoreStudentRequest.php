<?php

namespace App\Features\Students\Requests;

use App\Enums\GuardianRelationship;
use App\Enums\Role;
use App\Enums\StudentStatus;
use App\Models\Student;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class StoreStudentRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', Student::class) ?? false;
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'student_phone.unique' => 'رقم جوال الطالب مسجل بالفعل لحساب آخر.',
            'guardian_phone.unique' => 'رقم جوال ولي الأمر مسجل بالفعل لحساب آخر.',
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'national_id' => ['nullable', 'string', 'max:20'],
            'birth_date' => ['nullable', 'date'],
            'gender' => ['nullable', 'string', 'in:male,female'],
            'email' => ['nullable', 'email', 'max:255'],
            'status' => ['nullable', 'string', Rule::in(StudentStatus::values())],
            'enrolled_at' => ['nullable', 'date'],
            'graduated_at' => ['nullable', 'date'],
            'notes' => ['nullable', 'string', 'max:1000'],

            // Credentials for the student account (optional, only if creating an independent login)
            'student_phone' => [
                'nullable', 'string', 'max:30',
                Rule::unique('users', 'phone')->where('role', Role::Student->value),
            ],
            'password' => ['nullable', 'string', 'min:8', 'max:255'],

            // Guardian information — the guardian account is created automatically.
            'guardian_name' => ['required', 'string', 'max:255'],
            'guardian_phone' => ['required', 'string', 'max:30'],
            'guardian_relationship' => ['required', Rule::enum(GuardianRelationship::class)],
        ];
    }
}
