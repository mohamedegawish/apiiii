<?php

namespace App\Features\Students\Requests;

use App\Enums\GuardianRelationship;
use App\Enums\StudentStatus;
use App\Models\Student;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class UpdateStudentRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $student = Student::find($this->route('student'));

        return $this->user()?->can('update', $student) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            // Student profile fields (editable)
            'name' => ['sometimes', 'string', 'max:255'],
            'national_id' => ['nullable', 'string', 'max:20'],
            'birth_date' => ['nullable', 'date'],
            'gender' => ['nullable', 'string', 'in:male,female'],
            'phone' => ['nullable', 'string', 'max:30'],
            'email' => ['nullable', 'email', 'max:255'],
            'status' => ['nullable', 'string', Rule::in(StudentStatus::values())],
            'enrolled_at' => ['nullable', 'date'],
            'graduated_at' => ['nullable', 'date'],
            'notes' => ['nullable', 'string', 'max:1000'],

            // Guardian information update
            'guardian_id' => ['nullable', 'uuid', 'exists:guardians,id'],
            'guardian_name' => ['nullable', 'string', 'max:255'],
            'guardian_phone' => ['nullable', 'string', 'max:30'],
            'guardian_relationship' => ['nullable', Rule::enum(GuardianRelationship::class)],

            // Login credentials
            'password' => ['nullable', 'string', 'min:6'],
        ];
    }
}
