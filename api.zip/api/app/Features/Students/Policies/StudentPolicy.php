<?php

namespace App\Features\Students\Policies;

use App\Enums\Role;
use App\Models\Student;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class StudentPolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $user instanceof User;
    }

    public function view(?User $user, Student $student): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        if ($this->hasRole($user, Role::Teacher) && $user?->teacher !== null) {
            return $student->enrollments()
                ->where('status', 'active')
                ->whereNull('left_at')
                ->whereHas('circle', fn ($query) => $query
                    ->where('teacher_id', $user->teacher->id)
                    ->where('is_active', true))
                ->exists();
        }

        if ($this->hasRole($user, Role::Parent) && $user?->guardian !== null) {
            return $user->guardian->children()->whereKey($student->id)->exists();
        }

        // A student may read their own record. Without this branch every
        // policy-guarded self-service route -- notably
        // students/{student}/tracking/profile, which backs the progress report
        // -- answered 403 to the one person it is about.
        if ($this->hasRole($user, Role::Student)) {
            return $student->user_id !== null && $student->user_id === $user?->id;
        }

        return false;
    }

    public function create(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }

    public function update(?User $user, Student $student): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        return false;
    }

    public function delete(?User $user, Student $student): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        return false;
    }

    public function restore(?User $user, Student $student): bool
    {
        return $this->isSuperAdmin($user);
    }

    public function forceDelete(?User $user, Student $student): bool
    {
        return $this->isSuperAdmin($user);
    }
}
