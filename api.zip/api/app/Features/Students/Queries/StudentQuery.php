<?php

namespace App\Features\Students\Queries;

use App\Enums\EnrollmentStatus;
use App\Enums\Role;
use App\Models\Student;
use App\Support\Queries\BaseQuery;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\AllowedSort;

class StudentQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(Student::class);
    }

    /**
     * The students list must expose each student's current circle in the same
     * response. The circle lives on the active enrollment, so we eager-load
     * only active enrollments (status=active, left_at=null) with their circle
     * and teacher — a constant number of queries per page, never one per
     * student (no N+1).
     */
    public function paginate(): LengthAwarePaginator
    {
        $this->getBuilder()->with([
            'enrollments' => fn ($query) => $query
                ->where('status', EnrollmentStatus::Active)
                ->whereNull('left_at'),
            'enrollments.circle.teacher.user',
        ]);

        return parent::paginate();
    }

    protected function applyTenantScope(EloquentBuilder $builder): void
    {
        if ($this->shouldBypassScope()) {
            return;
        }

        $user = $this->currentUser();

        if ($user?->hasRole(Role::Teacher) && $user->teacher !== null) {
            $studentIds = $this->accessibleStudentIds();

            if ($studentIds === []) {
                $builder->whereRaw('1 = 0');

                return;
            }

            $builder->whereIn('id', $studentIds);

            return;
        }

        if ($user?->hasRole(Role::Parent) && $user->guardian !== null) {
            $studentIds = $this->accessibleStudentIds();

            if ($studentIds === []) {
                $builder->whereRaw('1 = 0');

                return;
            }

            $builder->whereIn('id', $studentIds);

            return;
        }

        // A student sees only their own record, matching StudentPolicy::view.
        if ($user?->hasRole(Role::Student)) {
            $builder->where('user_id', $user->id);

            return;
        }

        // Fail closed. This used to fall through with no constraint, so every
        // student account -- and any teacher/guardian account not yet linked to
        // a profile -- could list every student's name, student_code (a login
        // identifier and the QR attendance payload) and current circle.
        $builder->whereRaw('1 = 0');
    }

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::partial('name'),
            AllowedFilter::partial('phone'),
            AllowedFilter::partial('email'),
            AllowedFilter::partial('national_id'),
            AllowedFilter::exact('guardian_id'),
            AllowedFilter::exact('status'),
            AllowedFilter::exact('gender'),
            AllowedFilter::scope('search'),
        ];
    }

    protected function allowedSorts(): array
    {
        return [
            'name',
            'created_at',
            'updated_at',
            AllowedSort::field('birth_date', 'birth_date'),
            AllowedSort::field('enrolled_at', 'enrolled_at'),
        ];
    }

    protected function allowedIncludes(): array
    {
        return ['guardian', 'circles'];
    }
}
