<?php

namespace App\Features\Students\Actions;

use App\Enums\Role;
use App\Features\Students\Requests\StoreStudentRequest;
use App\Models\Guardian;
use App\Models\Student;
use App\Models\User;
use App\Support\Actions\BaseAction;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class CreateStudentAction extends BaseAction
{
    /**
     * Create a student account and its linked guardian account in one flow.
     *
     * Both accounts share the same mobile number and password, but remain
     * separate users with separate roles (student / parent).
     *
     * Key guarantees:
     * - Guardian user/profile is found-or-created safely under concurrency.
     * - Student user is only created when student_phone is provided (never null phone).
     * - Student code is globally unique, generated atomically.
     * - The entire flow runs inside a single DB transaction.
     *
     * @return Student
     */
    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreStudentRequest) {
            throw new \InvalidArgumentException('CreateStudentAction expects a StoreStudentRequest.');
        }

        $data = $request->validatedData();

        $studentPhone = $data['student_phone'] ?? null;
        $guardianPhone = $data['guardian_phone'];
        $password = $data['password'] ?? null;
        $guardianName = $data['guardian_name'];
        $guardianRelationship = $data['guardian_relationship'];

        unset(
            $data['student_phone'],
            $data['guardian_phone'],
            $data['password'],
            $data['guardian_name'],
            $data['guardian_relationship']
        );

        return DB::transaction(function () use ($studentPhone, $guardianPhone, $password, $guardianName, $guardianRelationship, $data) {
            // 1. Find or create the guardian user account safely.
            //    Uses try/catch on unique constraint to handle race conditions.
            $guardianUser = $this->findOrCreateUser(
                phone: $guardianPhone,
                role: Role::Parent,
                name: $guardianName,
                password: $password ?? $guardianPhone,
            );

            // 2. Find or create the guardian profile record safely.
            $guardian = $this->findOrCreateGuardian(
                userId: $guardianUser->id,
                name: $guardianName,
                phone: $guardianPhone,
                relationship: $guardianRelationship,
            );

            // 3. Create the student user account ONLY if a unique student phone is provided.
            //    NEVER set phone = null as a workaround. No phone = no user account.
            $studentUser = null;
            if (! empty($studentPhone)) {
                $studentUser = $this->findOrCreateUser(
                    phone: $studentPhone,
                    role: Role::Student,
                    name: $data['name'],
                    password: $password ?? $guardianPhone,
                );
            }

            // 4. Generate a globally unique student code atomically.
            $studentCode = $this->generateUniqueStudentCode();

            // 5. Create the student profile record linked to both accounts.
            $student = Student::create([
                ...$data,
                'student_code' => $studentCode,
                'user_id' => $studentUser?->id,
                'guardian_id' => $guardian->id,
                'phone' => $studentPhone,
            ]);

            // 6. Link student and guardian in the pivot table.
            $guardian->children()->syncWithoutDetaching([
                $student->id => [
                    'id' => (string) Str::uuid(),
                    'relationship' => $guardianRelationship,
                    'is_primary' => true,
                ],
            ]);

            return $student;
        });
    }

    /**
     * Concurrency-safe find-or-create for a user with a given phone + role.
     *
     * The (phone, role) composite unique index ensures that two concurrent
     * requests cannot both succeed in creating the same account. If the
     * insert fails with a unique constraint violation, we retry the select.
     */
    private function findOrCreateUser(string $phone, Role $role, string $name, string $password): User
    {
        // Attempt to find existing user first
        $user = User::where('phone', $phone)
            ->where('role', $role->value)
            ->first();

        if ($user !== null) {
            return $user;
        }

        // Attempt to create — catch unique constraint violation from concurrent insert
        try {
            return User::create([
                'name' => $name,
                'phone' => $phone,
                'password' => Hash::make($password),
                'role' => $role,
            ]);
        } catch (QueryException $e) {
            // MySQL: 23000 (integrity constraint), SQLite: 19 (UNIQUE constraint)
            if ($this->isUniqueConstraintViolation($e)) {
                // The other concurrent request won the race — fetch their result
                $user = User::where('phone', $phone)
                    ->where('role', $role->value)
                    ->first();

                if ($user !== null) {
                    return $user;
                }
            }

            throw $e;
        }
    }

    /**
     * Concurrency-safe find-or-create for a guardian profile.
     */
    private function findOrCreateGuardian(string $userId, string $name, string $phone, string $relationship): Guardian
    {
        $guardian = Guardian::where('user_id', $userId)->first();

        if ($guardian !== null) {
            return $guardian;
        }

        try {
            return Guardian::create([
                'user_id' => $userId,
                'name' => $name,
                'phone' => $phone,
                'relationship' => $relationship,
            ]);
        } catch (QueryException $e) {
            if ($this->isUniqueConstraintViolation($e)) {
                $guardian = Guardian::where('user_id', $userId)->first();

                if ($guardian !== null) {
                    return $guardian;
                }
            }

            throw $e;
        }
    }

    /**
     * Generate a globally unique student code with collision retry.
     */
    private function generateUniqueStudentCode(): string
    {
        $maxAttempts = 10;

        for ($i = 0; $i < $maxAttempts; $i++) {
            $code = 'STU-'.strtoupper(Str::random(8));

            if (! Student::where('student_code', $code)->exists()) {
                return $code;
            }
        }

        // Fallback: use a longer random string to virtually eliminate collision
        return 'STU-'.strtoupper(Str::random(12));
    }

    /**
     * Check if a QueryException is a unique constraint violation.
     */
    private function isUniqueConstraintViolation(QueryException $e): bool
    {
        $code = (string) $e->getCode();

        // MySQL: 23000 (integrity constraint violation)
        // SQLite: SQLSTATE[23000] or error code 19
        return $code === '23000' || str_contains($e->getMessage(), 'UNIQUE constraint failed');
    }
}
