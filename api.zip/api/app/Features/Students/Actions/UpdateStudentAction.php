<?php

namespace App\Features\Students\Actions;

use App\Features\Students\Requests\UpdateStudentRequest;
use App\Models\Guardian;
use App\Models\Student;
use App\Support\Actions\BaseAction;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Hash;

class UpdateStudentAction extends BaseAction
{
    /**
     * Update a student and optionally their guardian information.
     *
     * Protected fields (role, permissions, created_by, security fields)
     * are never mass-assigned because they are not in the request rules
     * or the model's $fillable array.
     *
     * @return Student
     */
    public function execute(mixed ...$arguments): mixed
    {
        $student = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $student instanceof Student) {
            throw new \InvalidArgumentException('UpdateStudentAction expects a Student as the first argument.');
        }

        if (! $request instanceof UpdateStudentRequest) {
            throw new \InvalidArgumentException('UpdateStudentAction expects an UpdateStudentRequest as the second argument.');
        }

        $data = $request->validatedData();

        $password = $data['password'] ?? null;

        // Separate guardian-related fields
        $guardianData = Arr::only($data, ['guardian_name', 'guardian_phone', 'guardian_relationship', 'password']);
        $studentData = Arr::except($data, ['guardian_name', 'guardian_phone', 'guardian_relationship', 'password']);

        // Track changes for audit
        $oldValues = $student->toArray();

        // Update student profile (only legitimate editable fields via $fillable)
        $student->update($studentData);

        // Update student user login data
        if ($student->user !== null) {
            $userUpdate = [];
            if (! empty($studentData['phone'])) {
                $userUpdate['phone'] = $studentData['phone'];
            }
            if (! empty($studentData['name'])) {
                $userUpdate['name'] = $studentData['name'];
            }
            if (! empty($password)) {
                $userUpdate['password'] = Hash::make($password);
            }
            if (! empty($userUpdate)) {
                $student->user->update($userUpdate);
            }
        }

        // Update guardian information if provided
        if (! empty(array_filter($guardianData))) {
            $this->updateGuardianInfo($student, $guardianData);
        }

        // Reload with relationships
        $student = $student->fresh(['guardian', 'enrollments.circle.teacher.user']);

        return $student;
    }

    /**
     * Update the guardian's information linked to this student.
     */
    private function updateGuardianInfo(Student $student, array $guardianData): void
    {
        $guardian = $student->guardian;

        if ($guardian === null) {
            return;
        }

        $updateData = [];

        if (! empty($guardianData['guardian_name'])) {
            $updateData['name'] = $guardianData['guardian_name'];
        }

        if (! empty($guardianData['guardian_phone'])) {
            $updateData['phone'] = $guardianData['guardian_phone'];
        }

        if (! empty($guardianData['guardian_relationship'])) {
            $updateData['relationship'] = $guardianData['guardian_relationship'];
        }

        if (! empty($updateData)) {
            $guardian->update($updateData);

            // Also update the guardian's user data
            if ($guardian->user !== null) {
                $guardianUserUpdate = [];
                if (isset($updateData['name'])) {
                    $guardianUserUpdate['name'] = $updateData['name'];
                }
                if (isset($updateData['phone'])) {
                    $guardianUserUpdate['phone'] = $updateData['phone'];
                }
                if (! empty($guardianData['password'])) {
                    $guardianUserUpdate['password'] = Hash::make($guardianData['password']);
                }
                if (! empty($guardianUserUpdate)) {
                    $guardian->user->update($guardianUserUpdate);
                }
            }
        } elseif (! empty($guardianData['password']) && $guardian->user !== null) {
            $guardian->user->update([
                'password' => Hash::make($guardianData['password']),
            ]);
        }
    }
}
