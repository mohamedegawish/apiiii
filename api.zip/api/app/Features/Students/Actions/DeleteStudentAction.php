<?php

namespace App\Features\Students\Actions;

use App\Models\Student;
use App\Support\Actions\BaseAction;

class DeleteStudentAction extends BaseAction
{
    /**
     * @return bool
     */
    public function execute(mixed ...$arguments): mixed
    {
        $student = $arguments[0] ?? null;

        if (! $student instanceof Student) {
            throw new \InvalidArgumentException('DeleteStudentAction expects a Student.');
        }

        return $student->delete();
    }
}
