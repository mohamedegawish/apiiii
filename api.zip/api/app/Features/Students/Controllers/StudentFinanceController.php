<?php

namespace App\Features\Students\Controllers;

use App\Enums\Role;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Student;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class StudentFinanceController extends BaseController
{
    /**
     * Get student's financial summary: payment status, balance, history.
     *
     * GET /api/v1/students/{student}/finance
     */
    public function show(Request $request, string $student): JsonResponse
    {
        $user = $request->user();

        // Only admins can see financial data
        if (! $user->hasRole(Role::SuperAdmin, Role::CenterOwner)) {
            return $this->error('You do not have permission to view financial data.', 403);
        }

        $studentModel = Student::find($student);

        if ($studentModel === null) {
            return $this->error('Student not found.', 404);
        }

        $invoices = Invoice::where('student_id', $student)
            ->latest()
            ->get();

        $payments = Payment::where('student_id', $student)
            ->latest('paid_at')
            ->get();

        $totalInvoiced = $invoices->sum('total');
        $totalPaid = $payments->sum('amount');
        $balance = $totalInvoiced - $totalPaid;

        return $this->success(
            data: [
                'student_id' => $studentModel->id,
                'student_code' => $studentModel->student_code,
                'student_name' => $studentModel->name,
                'total_invoiced' => round($totalInvoiced, 2),
                'total_paid' => round($totalPaid, 2),
                'balance' => round($balance, 2),
                'payment_status' => $balance <= 0 ? 'paid' : ($totalPaid > 0 ? 'partial' : 'unpaid'),
                'last_payment' => $payments->first() ? [
                    'id' => $payments->first()->id,
                    'amount' => $payments->first()->amount,
                    'paid_at' => $payments->first()->paid_at?->toIso8601String(),
                    'method' => $payments->first()->method,
                    'reference_number' => $payments->first()->reference_number,
                ] : null,
                'invoices' => $invoices->map(fn ($inv) => [
                    'id' => $inv->id,
                    'total' => $inv->total,
                    'status' => $inv->status,
                    'due_date' => $inv->due_date?->toIso8601String(),
                    'created_at' => $inv->created_at?->toIso8601String(),
                ])->toArray(),
                'payments' => $payments->map(fn ($pay) => [
                    'id' => $pay->id,
                    'amount' => $pay->amount,
                    'paid_at' => $pay->paid_at?->toIso8601String(),
                    'method' => $pay->method,
                    'reference_number' => $pay->reference_number,
                    'notes' => $pay->notes,
                ])->toArray(),
            ],
            message: 'Student financial data retrieved successfully.',
        );
    }
}
