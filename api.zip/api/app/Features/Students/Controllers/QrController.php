<?php

namespace App\Features\Students\Controllers;

use App\Enums\Role;
use App\Enums\StudentStatus;
use App\Features\Attendance\Services\AttendanceService;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Student;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class QrController extends BaseController
{
    public function __construct(protected AttendanceService $attendanceService) {}

    /**
     * Resolve a student by their student_code (from QR scan).
     *
     * POST /api/v1/qr/resolve
     *
     * The QR payload is only a student_code, but a code is a long-lived bearer
     * value printed on a card -- so possession of one must not be enough to
     * read a child's circle and teacher. Scanning is therefore staff-only, and
     * a teacher is limited to students enrolled in a circle they teach.
     */
    public function resolve(Request $request): JsonResponse
    {
        $request->validate([
            'student_code' => ['required', 'string', 'max:30'],
        ]);

        $student = $this->scannableStudent($request, (string) $request->input('student_code'));

        if ($student === null) {
            return $this->error('Student not found.', 404);
        }

        if ($student->status !== StudentStatus::Active) {
            return $this->error('Student is not active.', 422, 'student_inactive');
        }

        $activeEnrollment = $student->enrollments
            ->where('status', 'active')
            ->whereNull('left_at')
            ->first();

        return $this->success(
            data: [
                'student_id' => $student->id,
                'student_code' => $student->student_code,
                'name' => $student->name,
                'status' => $student->status?->value,
                'current_circle' => $activeEnrollment ? [
                    'circle_id' => $activeEnrollment->circle_id,
                    'circle_name' => $activeEnrollment->circle?->name,
                    'teacher_name' => $activeEnrollment->circle?->teacher?->user?->name,
                ] : null,
            ],
            message: 'Student resolved successfully.',
        );
    }

    /**
     * Record attendance via QR scan.
     *
     * POST /api/v1/qr/attendance
     *
     * Delegates to AttendanceService so a scan is subject to exactly the same
     * rules as the normal attendance screen: session ownership, the
     * future-date guard, session writability, enrollment covering the session
     * date, row locking, and the statistics/guardian-notification event. An
     * earlier hand-rolled copy of these checks here had drifted from all five.
     */
    public function attendance(Request $request): JsonResponse
    {
        $data = $request->validate([
            'student_code' => ['required', 'string', 'max:30'],
            'circle_session_id' => ['required', 'uuid', 'exists:circle_sessions,id'],
            'status' => ['nullable', 'string', 'in:present,absent,late,excused'],
            'arrival_time' => ['nullable', 'date_format:H:i'],
        ]);

        $student = $this->scannableStudent($request, $data['student_code']);

        if ($student === null) {
            return $this->error('Student not found.', 404);
        }

        $payload = [
            'student_id' => $student->id,
            'circle_session_id' => $data['circle_session_id'],
            'status' => $data['status'] ?? 'present',
        ];

        // Only forwarded when the scanner actually supplied one, so a re-scan
        // does not blank an arrival time recorded on the normal screen.
        if (array_key_exists('arrival_time', $data)) {
            $payload['arrival_time'] = $data['arrival_time'];
        }

        $attendance = $this->attendanceService->record($payload, $request->user());

        return $this->success(
            data: [
                'attendance_id' => $attendance->id,
                'student_id' => $student->id,
                'student_name' => $student->name,
                'student_code' => $student->student_code,
                'circle_session_id' => $attendance->circle_session_id,
                'session_date' => $attendance->attendance_date?->toDateString(),
                'status' => $attendance->status?->value,
            ],
            message: 'Attendance recorded successfully.',
        );
    }

    /**
     * Look up student finance context via QR scan.
     *
     * POST /api/v1/qr/payment-lookup
     *
     * Admin-only (super_admin, center_owner) -- teachers must not gain finance
     * access through QR. Guarded both here and by route middleware.
     */
    public function paymentLookup(Request $request): JsonResponse
    {
        $request->validate([
            'student_code' => ['required', 'string', 'max:30'],
        ]);

        $user = $request->user();

        if ($user?->isSuperAdmin() !== true && $user?->hasRole(Role::CenterOwner) !== true) {
            return $this->error('You do not have permission to access payment information.', 403);
        }

        $student = Student::where('student_code', $request->input('student_code'))->first();

        if ($student === null) {
            return $this->error('Student not found.', 404);
        }

        // Aggregated in the database rather than by hydrating every invoice and
        // payment the student has ever had -- this endpoint is scanned at a desk
        // and its cost must not grow with account age.
        $totalInvoiced = (float) Invoice::where('student_id', $student->id)->sum('total');
        $totalPaid = (float) Payment::where('student_id', $student->id)->sum('amount');
        $balance = $totalInvoiced - $totalPaid;

        $lastPayment = Payment::where('student_id', $student->id)->latest('paid_at')->first();

        return $this->success(
            data: [
                'student_id' => $student->id,
                'student_code' => $student->student_code,
                'student_name' => $student->name,
                'finance' => [
                    'total_invoiced' => round($totalInvoiced, 2),
                    'total_paid' => round($totalPaid, 2),
                    'balance' => round($balance, 2),
                    'payment_status' => $balance <= 0 ? 'paid' : ($totalPaid > 0 ? 'partial' : 'unpaid'),
                    'last_payment' => $lastPayment ? [
                        'amount' => $lastPayment->amount,
                        'paid_at' => $lastPayment->paid_at?->toIso8601String(),
                        'method' => $lastPayment->method,
                    ] : null,
                    'invoices_count' => Invoice::where('student_id', $student->id)->count(),
                    'payments_count' => Payment::where('student_id', $student->id)->count(),
                ],
            ],
            message: 'Student payment information retrieved successfully.',
        );
    }

    /**
     * The student behind a scanned code, if the current user may see them at all.
     *
     * Returns null both when no such code exists and when it belongs to a
     * student outside the scanner's scope, so a teacher cannot probe for the
     * existence of another circle's student codes.
     */
    private function scannableStudent(Request $request, string $studentCode): ?Student
    {
        $user = $request->user();

        $query = Student::where('student_code', $studentCode)
            ->with(['guardian', 'enrollments.circle.teacher.user']);

        if ($user?->isSuperAdmin() === true || $user?->hasRole(Role::CenterOwner) === true) {
            return $query->first();
        }

        $teacherId = $user?->teacher?->id;

        if ($teacherId === null) {
            return null;
        }

        // Any enrollment, not only a currently-active one: a teacher recording
        // attendance for an earlier session still needs to resolve a student
        // who has since left the circle.
        return $query
            ->whereHas('enrollments.circle', fn ($circle) => $circle->where('teacher_id', $teacherId))
            ->first();
    }
}
