<?php

namespace App\Features\Students\Controllers;

use App\Features\Students\Requests\BulkDeleteStudentRequest;
use App\Features\Students\Requests\StoreStudentRequest;
use App\Features\Students\Requests\UpdateStudentRequest;
use App\Features\Students\Resources\StudentResource;
use App\Features\Students\Services\StudentService;
use App\Models\Student;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class StudentController extends BaseController
{
    public function __construct(protected StudentService $studentService) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Student::class);

        $paginator = $this->studentService->paginate();

        return $this->paginate(StudentResource::collection($paginator), 'Students retrieved successfully.');
    }

    public function show(string $student): JsonResponse
    {
        $model = $this->studentService->findOrFail($student);

        $this->authorize('view', $model);

        return $this->success(
            data: StudentResource::make($model),
            message: 'Student retrieved successfully.',
        );
    }

    public function store(StoreStudentRequest $request): JsonResponse
    {
        $student = $this->studentService->create($request);

        return $this->created(
            data: StudentResource::make($student),
            message: 'Student created successfully.',
        );
    }

    public function update(UpdateStudentRequest $request, string $student): JsonResponse
    {
        $model = $this->studentService->findOrFail($student);
        $updated = $this->studentService->update($model, $request);

        return $this->success(
            data: StudentResource::make($updated),
            message: 'Student updated successfully.',
        );
    }

    public function destroy(string $student): JsonResponse
    {
        $model = $this->studentService->findOrFail($student);

        $this->authorize('delete', $model);

        $this->studentService->delete($model);

        return $this->success(
            data: null,
            message: 'Student deleted successfully.',
        );
    }

    public function bulkDestroy(BulkDeleteStudentRequest $request): JsonResponse
    {
        $ids = $request->validatedData()['ids'];

        $students = Student::whereIn('id', $ids)->get();

        foreach ($students as $student) {
            $this->authorize('delete', $student);
        }

        $count = $this->studentService->bulkDelete($ids);

        return $this->success(
            data: null,
            message: "{$count} students deleted successfully.",
        );
    }
}
