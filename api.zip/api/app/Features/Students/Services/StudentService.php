<?php

namespace App\Features\Students\Services;

use App\Features\Students\Actions\CreateStudentAction;
use App\Features\Students\Actions\DeleteStudentAction;
use App\Features\Students\Actions\UpdateStudentAction;
use App\Features\Students\Queries\StudentQuery;
use App\Features\Students\Requests\StoreStudentRequest;
use App\Features\Students\Requests\UpdateStudentRequest;
use App\Models\Student;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class StudentService extends BaseService
{
    public function __construct(
        protected CreateStudentAction $createStudentAction,
        protected UpdateStudentAction $updateStudentAction,
        protected DeleteStudentAction $deleteStudentAction,
        protected StudentQuery $studentQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->studentQuery->paginate();
    }

    public function findOrFail(string $id): Student
    {
        $student = Student::with([
            'guardian',
            'enrollments.circle.teacher.user',
            'enrollments.circle.schedules',
        ])->find($id);

        if ($student === null) {
            throw new NotFoundException('Student not found.');
        }

        return $student;
    }

    public function create(StoreStudentRequest $request): Student
    {
        return $this->transaction(fn (): Student => $this->createStudentAction->execute($request));
    }

    public function update(Student $student, UpdateStudentRequest $request): Student
    {
        return $this->transaction(fn (): Student => $this->updateStudentAction->execute($student, $request));
    }

    public function delete(Student $student): bool
    {
        return $this->transaction(fn (): bool => $this->deleteStudentAction->execute($student));
    }

    public function bulkDelete(array $ids): int
    {
        return $this->transaction(function () use ($ids): int {
            $count = 0;

            foreach ($ids as $id) {
                $student = Student::find($id);

                if ($student === null) {
                    continue;
                }

                $this->deleteStudentAction->execute($student);
                $count++;
            }

            return $count;
        });
    }
}
