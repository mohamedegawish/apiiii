<?php

namespace App\Features\Students\Resources;

use App\Enums\Role;
use App\Models\Enrollment;
use App\Models\Student;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * @mixin Student
 */
class StudentResource extends BaseResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = [
            'id' => $this->id,
            'student_code' => $this->student_code,
            'guardian_id' => $this->guardian_id,
            'name' => $this->name,
            'gender' => $this->gender,
            'status' => [
                'value' => $this->status?->value,
                'label' => $this->status?->name,
            ],
            'enrolled_at' => $this->enrolled_at?->toIso8601String(),
            'graduated_at' => $this->graduated_at?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];

        if ($this->shouldShowPii($request)) {
            $data['national_id'] = $this->national_id;
            $data['birth_date'] = $this->birth_date?->toIso8601String();
            $data['phone'] = $this->phone;
            $data['email'] = $this->email;
            $data['notes'] = $this->notes;
        }

        // Include guardian information when loaded
        if ($this->relationLoaded('guardian') && $this->guardian !== null) {
            $data['guardian'] = [
                'id' => $this->guardian->id,
                'name' => $this->guardian->name,
                'phone' => $this->guardian->phone,
                'relationship' => $this->guardian->relationship,
            ];
        }

        // Include current enrollment / circle information when loaded.
        // The canonical "current circle" is derived from the student's active
        // enrollment (status=active and left_at=null) — the same source the
        // write-side validators and the circle roster read from.
        if ($this->relationLoaded('enrollments')) {
            $activeEnrollment = $this->enrollments
                ->where('status', 'active')
                ->whereNull('left_at')
                ->first();

            $data['current_circle'] = $activeEnrollment && $activeEnrollment->circle !== null
                ? $this->formatCurrentCircle($activeEnrollment)
                : null;

            $data['current_enrollment'] = $activeEnrollment ? [
                'enrollment_id' => $activeEnrollment->id,
                'circle_id' => $activeEnrollment->circle_id,
                'joined_at' => $activeEnrollment->joined_at?->toIso8601String(),
                'status' => $activeEnrollment->status?->value ?? $activeEnrollment->status,
            ] : null;

            // Historical enrollments (closed/completed)
            $historicalEnrollments = $this->enrollments
                ->filter(fn ($e) => $e->left_at !== null || $e->status !== 'active')
                ->values();

            if ($historicalEnrollments->isNotEmpty()) {
                $data['enrollment_history'] = $historicalEnrollments->map(fn ($e) => [
                    'enrollment_id' => $e->id,
                    'circle_id' => $e->circle_id,
                    'circle_name' => $e->circle?->name,
                    'joined_at' => $e->joined_at?->toIso8601String(),
                    'left_at' => $e->left_at?->toIso8601String(),
                    'status' => $e->status?->value ?? $e->status,
                    'reason' => $e->reason,
                ])->toArray();
            }
        }

        // Include circles directly if loaded
        if ($this->relationLoaded('circles')) {
            $data['circles'] = $this->circles->map(fn ($c) => [
                'id' => $c->id,
                'name' => $c->name,
            ])->toArray();
        }

        return $data;
    }

    /**
     * Determine whether PII fields should be exposed to the current user.
     */
    protected function shouldShowPii(Request $request): bool
    {
        $user = $request->user();

        if ($user === null) {
            return false;
        }

        return $user->hasRole(Role::SuperAdmin, Role::CenterOwner, Role::Teacher);
    }

    /**
     * Clean `current_circle` payload derived from the student's active
     * enrollment. The optional weekly schedule is only included when the
     * relation has been eager-loaded (profile reads), so list reads stay
     * a fixed number of queries.
     *
     * @return array<string, mixed>
     */
    protected function formatCurrentCircle(Enrollment $enrollment): array
    {
        $circle = $enrollment->circle;

        $schedules = $circle->relationLoaded('schedules')
            ? $circle->schedules
                ->where('is_active', true)
                ->values()
                ->map(fn ($schedule): array => [
                    'id' => $schedule->id,
                    'day_of_week' => $schedule->day_of_week?->value,
                    'start_time' => $schedule->start_time,
                    'end_time' => $schedule->end_time,
                    'room' => $schedule->room,
                ])
                ->all()
            : null;

        return [
            'id' => $circle->id,
            'name' => $circle->name,
            'teacher_id' => $circle->teacher_id,
            'teacher_name' => $circle->teacher?->user?->name,
            'schedules' => $schedules,
        ];
    }
}
