<?php

namespace App\Features\Attendance\Actions;

use App\Models\Attendance;
use App\Support\Actions\BaseAction;

class DeleteAttendanceAction extends BaseAction
{
    /**
     * @return bool
     */
    public function execute(mixed ...$arguments): mixed
    {
        $attendance = $arguments[0] ?? null;

        if (! $attendance instanceof Attendance) {
            throw new \InvalidArgumentException('DeleteAttendanceAction expects an Attendance.');
        }

        return $attendance->delete();
    }
}
