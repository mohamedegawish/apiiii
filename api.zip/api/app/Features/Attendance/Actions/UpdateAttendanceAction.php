<?php

namespace App\Features\Attendance\Actions;

use App\Events\AttendanceRecorded;
use App\Models\Attendance;
use App\Support\Actions\BaseAction;

class UpdateAttendanceAction extends BaseAction
{
    /**
     * @return Attendance
     */
    public function execute(mixed ...$arguments): mixed
    {
        $attendance = $arguments[0] ?? null;
        $data = $arguments[1] ?? null;

        if (! $attendance instanceof Attendance) {
            throw new \InvalidArgumentException('UpdateAttendanceAction expects an Attendance as the first argument.');
        }

        if (! is_array($data)) {
            throw new \InvalidArgumentException('UpdateAttendanceAction expects attendance data as the second argument.');
        }

        $statusBefore = $attendance->status;

        $attendance->update($data);

        $attendance = $attendance->fresh();

        // Statistics and guardian alerts are derived from `status`, so a
        // correction (absent -> present, or a re-scan that changes the mark)
        // has to re-fire the same event a fresh record does — otherwise the
        // student's attendance rate silently keeps the original value.
        // Note-only or arrival-time-only edits deliberately stay quiet so
        // guardians are not notified twice for one session.
        if ($attendance->status !== $statusBefore) {
            event(new AttendanceRecorded($attendance));
        }

        return $attendance;
    }
}
