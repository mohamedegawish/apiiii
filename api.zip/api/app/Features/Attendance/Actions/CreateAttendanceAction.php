<?php

namespace App\Features\Attendance\Actions;

use App\Events\AttendanceRecorded;
use App\Models\Attendance;
use App\Support\Actions\BaseAction;

class CreateAttendanceAction extends BaseAction
{
    /**
     * @return Attendance
     */
    public function execute(mixed ...$arguments): mixed
    {
        $data = $arguments[0] ?? null;

        if (! is_array($data)) {
            throw new \InvalidArgumentException('CreateAttendanceAction expects attendance data.');
        }

        $attendance = Attendance::create($data);

        event(new AttendanceRecorded($attendance));

        return $attendance;
    }
}
