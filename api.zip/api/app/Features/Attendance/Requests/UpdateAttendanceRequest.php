<?php

namespace App\Features\Attendance\Requests;

use App\Enums\AttendanceStatus;
use App\Models\Attendance;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class UpdateAttendanceRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $attendance = Attendance::find($this->route('attendance'));

        return $this->user()?->can('update', $attendance) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'student_id' => ['prohibited'],
            'circle_session_id' => ['prohibited'],
            'teacher_id' => ['prohibited'],
            'circle_id' => ['prohibited'],
            'attendance_date' => ['prohibited'],
            'status' => ['sometimes', 'string', Rule::in(AttendanceStatus::values())],
            'arrival_time' => ['nullable', 'date_format:H:i'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
