<?php

namespace App\Features\Attendance\Requests;

use App\Enums\AttendanceStatus;
use App\Models\Attendance;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class StoreAttendanceRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', Attendance::class) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'student_id' => ['required', 'uuid', 'exists:students,id'],
            'circle_session_id' => ['required', 'uuid', 'exists:circle_sessions,id'],
            'teacher_id' => ['prohibited'],
            'circle_id' => ['prohibited'],
            'attendance_date' => ['prohibited'],
            'status' => ['required', 'string', Rule::in(AttendanceStatus::values())],
            'arrival_time' => ['nullable', 'date_format:H:i'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
