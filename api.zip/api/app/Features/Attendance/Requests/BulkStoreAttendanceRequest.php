<?php

namespace App\Features\Attendance\Requests;

use App\Enums\AttendanceStatus;
use App\Models\Attendance;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

/**
 * Bulk attendance capture — records an entire roster for a session in one
 * request. Essential at scale (marking 30+ students should not be 30 calls).
 */
class BulkStoreAttendanceRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', Attendance::class) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'circle_session_id' => ['required', 'uuid', 'exists:circle_sessions,id'],
            'teacher_id' => ['prohibited'],
            'circle_id' => ['prohibited'],
            'attendance_date' => ['prohibited'],
            'records' => ['required', 'array', 'min:1', 'max:200'],
            'records.*.student_id' => ['required', 'uuid', 'distinct:strict', 'exists:students,id'],
            'records.*.status' => ['required', 'string', Rule::in(AttendanceStatus::values())],
            'records.*.arrival_time' => ['nullable', 'date_format:H:i'],
            'records.*.notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
