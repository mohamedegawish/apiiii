<?php

namespace App\Features\Attendance\Queries;

use App\Models\Attendance;
use App\Support\Queries\BaseQuery;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class AttendanceQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(Attendance::class);
    }

    /**
     * Scope attendance to records the current user may access.
     *
     * @param  EloquentBuilder<Attendance>  $builder
     */
    protected function applyTenantScope(EloquentBuilder $builder): void
    {
        if ($this->shouldBypassScope()) {
            return;
        }

        $user = $this->currentUser();

        if ($user === null) {
            $builder->whereRaw('1 = 0');

            return;
        }

        $builder->whereHas('circleSession', function (EloquentBuilder $sessionQuery) use ($user): void {
            if ($user->teacher !== null) {
                $sessionQuery->where('teacher_id', $user->teacher->id)
                    ->whereHas('teacher', fn (EloquentBuilder $teacherQuery) => $teacherQuery->where('user_id', $user->id));

                return;
            }

            $sessionQuery->whereRaw('1 = 0');
        });
    }

    /**
     * @return list<AllowedFilter>
     */
    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::exact('student_id'),
            AllowedFilter::exact('teacher_id'),
            AllowedFilter::exact('circle_id'),
            AllowedFilter::exact('circle_session_id'),
            AllowedFilter::exact('status'),
            AllowedFilter::exact('attendance_date'),
            AllowedFilter::scope('search'),
        ];
    }

    /**
     * @return list<string>
     */
    protected function allowedSorts(): array
    {
        return [
            'attendance_date',
            'created_at',
            'updated_at',
        ];
    }

    /**
     * @return list<string>
     */
    protected function allowedIncludes(): array
    {
        return ['student', 'teacher', 'circle', 'circleSession'];
    }
}
