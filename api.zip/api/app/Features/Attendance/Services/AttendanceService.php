<?php

namespace App\Features\Attendance\Services;

use App\Enums\CircleSessionStatus;
use App\Enums\Role;
use App\Enums\StudentStatus;
use App\Features\Attendance\Actions\CreateAttendanceAction;
use App\Features\Attendance\Actions\DeleteAttendanceAction;
use App\Features\Attendance\Actions\UpdateAttendanceAction;
use App\Features\Attendance\Queries\AttendanceQuery;
use App\Features\Attendance\Requests\BulkStoreAttendanceRequest;
use App\Features\Attendance\Requests\StoreAttendanceRequest;
use App\Features\Attendance\Requests\UpdateAttendanceRequest;
use App\Models\Attendance;
use App\Models\CircleSession;
use App\Models\Enrollment;
use App\Models\Student;
use App\Models\User;
use App\Support\CenterClock;
use App\Support\Exceptions\ConflictException;
use App\Support\Exceptions\ForbiddenException;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

class AttendanceService extends BaseService
{
    public function __construct(
        protected CreateAttendanceAction $createAttendanceAction,
        protected UpdateAttendanceAction $updateAttendanceAction,
        protected DeleteAttendanceAction $deleteAttendanceAction,
        protected AttendanceQuery $attendanceQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->attendanceQuery->paginate();
    }

    public function findOrFail(string $id): Attendance
    {
        $attendance = Attendance::with(['student', 'teacher', 'circleSession.circle', 'circleSession.teacher'])->find($id);

        if ($attendance === null) {
            throw new NotFoundException('Attendance not found.');
        }

        return $attendance;
    }

    public function create(StoreAttendanceRequest $request): Attendance
    {
        $data = $request->validatedData();
        $user = $request->user();

        return $this->transaction(function () use ($data, $user): Attendance {
            $session = $this->lockWritableSession($data['circle_session_id'], $user);
            $this->assertEligibleStudent($session, $data['student_id']);

            $existing = Attendance::withTrashed()
                ->where('circle_session_id', $session->id)
                ->where('student_id', $data['student_id'])
                ->lockForUpdate()
                ->first();

            // Only a *live* row is a genuine conflict. A soft-deleted one means
            // the teacher removed a mistaken mark and is re-recording it, so it
            // is restored rather than blocking this (student, session) key
            // forever -- the rule bulkCreate() and CreateLearningRecordAction
            // already apply.
            if ($existing !== null && ! $existing->trashed()) {
                throw new ConflictException('Attendance already exists for this student and circle session.');
            }

            return $this->upsert($session, $data, $existing)
                ->load(['student', 'teacher', 'circle', 'circleSession']);
        });
    }

    /**
     * Record (or correct) one student's attendance for a session.
     *
     * Upserts by (circle_session_id, student_id): unlike create(), a repeat is
     * a correction rather than a conflict, because the callers are scan-and-mark
     * flows where re-scanning a student is normal. Shared by the QR endpoint so
     * that path cannot drift from the rules enforced here -- session writability,
     * the future-date guard, enrollment covering the session date, row locking
     * and the statistics/notification event all come for free.
     *
     * @param  array<string, mixed>  $data
     */
    public function record(array $data, ?User $user): Attendance
    {
        return $this->transaction(function () use ($data, $user): Attendance {
            $session = $this->lockWritableSession($data['circle_session_id'] ?? null, $user);
            $this->assertEligibleStudent($session, $data['student_id']);

            $existing = Attendance::withTrashed()
                ->where('circle_session_id', $session->id)
                ->where('student_id', $data['student_id'])
                ->lockForUpdate()
                ->first();

            return $this->upsert($session, $data, $existing)
                ->load(['student', 'teacher', 'circle', 'circleSession']);
        });
    }

    /**
     * Record an entire roster in one transaction.
     *
     * Upserts by (circle_session_id, student_id): a student already marked
     * for this session is updated in place (restoring a soft-deleted row if
     * needed) rather than rejecting the whole batch, so a teacher who backs
     * out of the attendance step and comes back can resubmit freely instead
     * of being permanently blocked by the first student already recorded.
     *
     * @return Collection<int, Attendance>
     */
    public function bulkCreate(BulkStoreAttendanceRequest $request): Collection
    {
        $data = $request->validatedData();

        $user = $request->user();

        return $this->transaction(function () use ($data, $user): Collection {
            $session = $this->lockWritableSession($data['circle_session_id'], $user);
            $studentIds = array_column($data['records'], 'student_id');

            $existingByStudent = Attendance::withTrashed()
                ->where('circle_session_id', $session->id)
                ->whereIn('student_id', $studentIds)
                ->lockForUpdate()
                ->get()
                ->keyBy('student_id');

            // Read the whole roster's eligibility in two queries instead of
            // two per record: one lock for every student (the same row locks
            // the per-record path takes, so nothing about concurrent semantics
            // changes) plus one covering-date check for the given circle. The
            // per-record assertions below then fail the exact same way with
            // the exact same messages.
            $students = Student::query()
                ->whereIn('id', $studentIds)
                ->lockForUpdate()
                ->get()
                ->keyBy('id');

            $coveringStudentIds = Enrollment::query()
                ->whereIn('student_id', $studentIds)
                ->where('circle_id', $session->circle_id)
                ->coveringDate($session->session_date)
                ->pluck('student_id')
                ->flip();

            $saved = collect();

            foreach ($data['records'] as $record) {
                $student = $students->get($record['student_id']);

                if ($student === null || $student->status !== StudentStatus::Active) {
                    throw new ConflictException('Attendance can only be recorded for an active student.', 'student_inactive');
                }

                if (! $coveringStudentIds->has($record['student_id'])) {
                    throw new ConflictException('The student was not enrolled in the circle for this session.', 'student_not_enrolled');
                }

                $saved->push($this->upsert($session, $record, $existingByStudent->get($record['student_id'])));
            }

            // The per-record eager loads (student, teacher, circle, session)
            // collapsed into a single whereIn so a 200-student submit finishes
            // in one read instead of 800.
            $loaded = Attendance::query()
                ->with(['student', 'teacher', 'circle', 'circleSession'])
                ->whereIn('id', $saved->pluck('id'))
                ->get()
                ->keyBy('id');

            return $saved->map(fn (Attendance $attendance): Attendance => $loaded->get($attendance->id));
        });
    }

    public function update(Attendance $attendance, UpdateAttendanceRequest $request): Attendance
    {
        $data = $request->validatedData();
        $user = $request->user();

        return $this->transaction(function () use ($attendance, $data, $user): Attendance {
            $session = $this->lockWritableSession($attendance->circle_session_id, $user);
            $lockedAttendance = Attendance::query()->lockForUpdate()->find($attendance->id);

            if ($lockedAttendance === null || $lockedAttendance->circle_session_id !== $session->id) {
                throw new NotFoundException('Attendance not found.');
            }

            $this->assertEligibleStudent($session, $lockedAttendance->student_id);

            return $this->updateAttendanceAction->execute($lockedAttendance, $data)
                ->load(['student', 'teacher', 'circle', 'circleSession']);
        });
    }

    public function delete(Attendance $attendance): bool
    {
        $user = auth()->user();

        return $this->transaction(function () use ($attendance, $user): bool {
            $session = $this->lockWritableSession($attendance->circle_session_id, $user);
            $lockedAttendance = Attendance::query()->lockForUpdate()->find($attendance->id);

            if ($lockedAttendance === null || $lockedAttendance->circle_session_id !== $session->id) {
                throw new NotFoundException('Attendance not found.');
            }

            return $this->deleteAttendanceAction->execute($lockedAttendance);
        });
    }

    private function lockWritableSession(?string $sessionId, ?User $user): CircleSession
    {
        if ($sessionId === null) {
            throw new ConflictException('Attendance is not linked to a circle session.', 'attendance_session_missing');
        }

        $session = CircleSession::with(['circle', 'teacher'])->lockForUpdate()->find($sessionId);

        if ($session === null) {
            throw new NotFoundException('Circle session not found.');
        }

        $this->assertSessionAccess($session, $user);

        if (CenterClock::isFutureDate($session->session_date)) {
            throw new ConflictException('Attendance cannot be recorded for a future session.', 'session_in_future');
        }

        if ($session->locked_at !== null || ! in_array($session->status, [CircleSessionStatus::Scheduled, CircleSessionStatus::InProgress], true)) {
            throw new ConflictException('Attendance can only be changed for an unlocked scheduled or in-progress session.', $session->locked_at !== null ? 'session_locked' : 'session_not_writable');
        }

        return $session;
    }

    private function assertSessionAccess(CircleSession $session, ?User $user): void
    {
        $allowed = $user?->isSuperAdmin()
            || $user?->hasRole(Role::CenterOwner)
            || ($user?->hasRole(Role::Teacher) && $session->teacher?->user_id === $user->id);

        if (! $allowed) {
            throw new ForbiddenException('The circle session does not belong to your tenant.');
        }
    }

    private function assertEligibleStudent(CircleSession $session, string $studentId): void
    {
        $student = Student::query()->lockForUpdate()->find($studentId);

        if ($student === null || $student->status !== StudentStatus::Active) {
            throw new ConflictException('Attendance can only be recorded for an active student.', 'student_inactive');
        }

        $enrolled = $student->enrollments()
            ->where('circle_id', $session->circle_id)
            ->coveringDate($session->session_date)
            ->exists();

        if (! $enrolled) {
            throw new ConflictException('The student was not enrolled in the circle for this session.', 'student_not_enrolled');
        }
    }

    /**
     * Create the row, or update (restoring first if soft-deleted) the one that
     * already holds this (session, student) key.
     *
     * Optional fields absent from $record keep their stored value instead of
     * being nulled: a QR re-scan carries only a status, and must not wipe a
     * note the teacher typed on the normal screen.
     *
     * @param  array<string, mixed>  $record
     */
    private function upsert(CircleSession $session, array $record, ?Attendance $existing): Attendance
    {
        $attributes = $this->attendanceData($session, $record);

        if ($existing === null) {
            return $this->createAttendanceAction->execute($attributes);
        }

        if ($existing->trashed()) {
            $existing->restore();
        }

        foreach (['arrival_time', 'notes'] as $optional) {
            if (! array_key_exists($optional, $record)) {
                unset($attributes[$optional]);
            }
        }

        return $this->updateAttendanceAction->execute($existing, $attributes);
    }

    /** @param array<string, mixed> $data */
    private function attendanceData(CircleSession $session, array $data): array
    {
        return [
            'student_id' => $data['student_id'],
            'circle_session_id' => $session->id,
            'teacher_id' => $session->teacher_id,
            'circle_id' => $session->circle_id,
            'attendance_date' => $session->session_date->toDateString(),
            'status' => $data['status'],
            'arrival_time' => $data['arrival_time'] ?? null,
            'notes' => $data['notes'] ?? null,
        ];
    }
}
