<?php

namespace App\Features\Attendance\Resources;

use App\Models\Attendance;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * @mixin Attendance
 */
class AttendanceResource extends BaseResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'student_id' => $this->student_id,
            'teacher_id' => $this->teacher_id,
            'circle_id' => $this->circle_id,
            'circle_session_id' => $this->circle_session_id,
            'status' => [
                'value' => $this->status?->value,
                'label' => $this->status?->name,
            ],
            'attendance_date' => $this->attendance_date?->toIso8601String(),
            'arrival_time' => $this->arrival_time,
            'notes' => $this->notes,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
