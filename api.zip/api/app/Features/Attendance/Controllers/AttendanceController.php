<?php

namespace App\Features\Attendance\Controllers;

use App\Features\Attendance\Requests\BulkStoreAttendanceRequest;
use App\Features\Attendance\Requests\StoreAttendanceRequest;
use App\Features\Attendance\Requests\UpdateAttendanceRequest;
use App\Features\Attendance\Resources\AttendanceResource;
use App\Features\Attendance\Services\AttendanceService;
use App\Models\Attendance;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AttendanceController extends BaseController
{
    public function __construct(protected AttendanceService $attendanceService) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Attendance::class);

        $paginator = $this->attendanceService->paginate();

        return $this->paginate(AttendanceResource::collection($paginator), 'Attendance records retrieved successfully.');
    }

    public function show(string $attendance): JsonResponse
    {
        $model = $this->attendanceService->findOrFail($attendance);

        $this->authorize('view', $model);

        return $this->success(
            data: AttendanceResource::make($model),
            message: 'Attendance record retrieved successfully.',
        );
    }

    public function store(StoreAttendanceRequest $request): JsonResponse
    {
        $attendance = $this->attendanceService->create($request);

        return $this->created(
            data: AttendanceResource::make($attendance),
            message: 'Attendance record created successfully.',
        );
    }

    public function bulkStore(BulkStoreAttendanceRequest $request): JsonResponse
    {
        $records = $this->attendanceService->bulkCreate($request);

        return $this->created(
            data: AttendanceResource::collection($records)->resolve(),
            message: 'Attendance recorded successfully.',
        );
    }

    public function update(UpdateAttendanceRequest $request, string $attendance): JsonResponse
    {
        $model = $this->attendanceService->findOrFail($attendance);
        $updated = $this->attendanceService->update($model, $request);

        return $this->success(
            data: AttendanceResource::make($updated),
            message: 'Attendance record updated successfully.',
        );
    }

    public function destroy(string $attendance): JsonResponse
    {
        $model = $this->attendanceService->findOrFail($attendance);

        $this->authorize('delete', $model);

        $this->attendanceService->delete($model);

        return $this->success(
            data: null,
            message: 'Attendance record deleted successfully.',
        );
    }
}
