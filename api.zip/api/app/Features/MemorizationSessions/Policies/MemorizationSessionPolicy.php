<?php

namespace App\Features\MemorizationSessions\Policies;

use App\Enums\Role;
use App\Models\MemorizationSession;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class MemorizationSessionPolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $user instanceof User;
    }

    public function view(?User $user, MemorizationSession $memorizationSession): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        return $this->hasRole($user, Role::Teacher)
            && $memorizationSession->teacher?->user_id === $user->id;
    }

    public function create(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner)
            || $this->hasRole($user, Role::Teacher);
    }

    public function update(?User $user, MemorizationSession $memorizationSession): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        return $this->hasRole($user, Role::Teacher)
            && $memorizationSession->teacher?->user_id === $user->id;
    }

    public function delete(?User $user, MemorizationSession $memorizationSession): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        return $this->hasRole($user, Role::CenterOwner);
    }

    public function restore(?User $user, MemorizationSession $memorizationSession): bool
    {
        return $this->isSuperAdmin($user);
    }

    public function forceDelete(?User $user, MemorizationSession $memorizationSession): bool
    {
        return $this->isSuperAdmin($user);
    }
}
