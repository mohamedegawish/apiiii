<?php

namespace App\Features\MemorizationSessions\Services;

use App\Features\MemorizationSessions\Actions\CreateMemorizationSessionAction;
use App\Features\MemorizationSessions\Actions\DeleteMemorizationSessionAction;
use App\Features\MemorizationSessions\Actions\UpdateMemorizationSessionAction;
use App\Features\MemorizationSessions\Queries\MemorizationSessionQuery;
use App\Features\MemorizationSessions\Requests\StoreMemorizationSessionRequest;
use App\Features\MemorizationSessions\Requests\UpdateMemorizationSessionRequest;
use App\Models\MemorizationSession;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class MemorizationSessionService extends BaseService
{
    public function __construct(
        protected CreateMemorizationSessionAction $createMemorizationSessionAction,
        protected UpdateMemorizationSessionAction $updateMemorizationSessionAction,
        protected DeleteMemorizationSessionAction $deleteMemorizationSessionAction,
        protected MemorizationSessionQuery $memorizationSessionQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->memorizationSessionQuery->paginate();
    }

    public function findOrFail(string $id): MemorizationSession
    {
        $memorizationSession = MemorizationSession::with(['student', 'teacher'])->find($id);

        if ($memorizationSession === null) {
            throw new NotFoundException('Memorization session not found.');
        }

        return $memorizationSession;
    }

    public function create(StoreMemorizationSessionRequest $request): MemorizationSession
    {
        return $this->transaction(fn (): MemorizationSession => $this->createMemorizationSessionAction->execute($request));
    }

    public function update(MemorizationSession $memorizationSession, UpdateMemorizationSessionRequest $request): MemorizationSession
    {
        return $this->transaction(fn (): MemorizationSession => $this->updateMemorizationSessionAction->execute($memorizationSession, $request));
    }

    public function delete(MemorizationSession $memorizationSession): bool
    {
        return $this->transaction(fn (): bool => $this->deleteMemorizationSessionAction->execute($memorizationSession));
    }
}
