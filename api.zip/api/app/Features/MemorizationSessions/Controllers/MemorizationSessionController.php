<?php

namespace App\Features\MemorizationSessions\Controllers;

use App\Features\MemorizationSessions\Requests\StoreMemorizationSessionRequest;
use App\Features\MemorizationSessions\Requests\UpdateMemorizationSessionRequest;
use App\Features\MemorizationSessions\Resources\MemorizationSessionResource;
use App\Features\MemorizationSessions\Services\MemorizationSessionService;
use App\Models\MemorizationSession;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MemorizationSessionController extends BaseController
{
    public function __construct(protected MemorizationSessionService $memorizationSessionService) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', MemorizationSession::class);

        $paginator = $this->memorizationSessionService->paginate();

        return $this->paginate(MemorizationSessionResource::collection($paginator), 'Memorization sessions retrieved successfully.');
    }

    public function show(string $memorizationSession): JsonResponse
    {
        $model = $this->memorizationSessionService->findOrFail($memorizationSession);

        $this->authorize('view', $model);

        return $this->success(
            data: MemorizationSessionResource::make($model),
            message: 'Memorization session retrieved successfully.',
        );
    }

    public function store(StoreMemorizationSessionRequest $request): JsonResponse
    {
        $memorizationSession = $this->memorizationSessionService->create($request);

        return $this->created(
            data: MemorizationSessionResource::make($memorizationSession),
            message: 'Memorization session created successfully.',
        );
    }

    public function update(UpdateMemorizationSessionRequest $request, string $memorizationSession): JsonResponse
    {
        $model = $this->memorizationSessionService->findOrFail($memorizationSession);
        $updated = $this->memorizationSessionService->update($model, $request);

        return $this->success(
            data: MemorizationSessionResource::make($updated),
            message: 'Memorization session updated successfully.',
        );
    }

    public function destroy(string $memorizationSession): JsonResponse
    {
        $model = $this->memorizationSessionService->findOrFail($memorizationSession);

        $this->authorize('delete', $model);

        $this->memorizationSessionService->delete($model);

        return $this->success(
            data: null,
            message: 'Memorization session deleted successfully.',
        );
    }
}
