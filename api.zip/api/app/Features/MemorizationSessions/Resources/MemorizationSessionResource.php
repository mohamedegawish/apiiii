<?php

namespace App\Features\MemorizationSessions\Resources;

use App\Models\MemorizationSession;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * @mixin MemorizationSession
 */
class MemorizationSessionResource extends BaseResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'student_id' => $this->student_id,
            'teacher_id' => $this->teacher_id,
            'circle_id' => $this->circle_id,
            'surah_number' => $this->surah_number,
            'from_ayah' => $this->from_ayah,
            'to_ayah' => $this->to_ayah,
            'session_type' => [
                'value' => $this->session_type?->value,
                'label' => $this->session_type?->label(),
            ],
            'memorization_grade' => $this->memorization_grade,
            'tajweed_grade' => $this->tajweed_grade,
            'fluency_grade' => $this->fluency_grade,
            'discipline_grade' => $this->discipline_grade,
            'notes' => $this->notes,
            'session_date' => $this->session_date?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
