<?php

namespace App\Features\MemorizationSessions\Actions;

use App\Models\MemorizationSession;
use App\Support\Actions\BaseAction;

class DeleteMemorizationSessionAction extends BaseAction
{
    /**
     * @return bool
     */
    public function execute(mixed ...$arguments): mixed
    {
        $memorizationSession = $arguments[0] ?? null;

        if (! $memorizationSession instanceof MemorizationSession) {
            throw new \InvalidArgumentException('DeleteMemorizationSessionAction expects a MemorizationSession.');
        }

        return $memorizationSession->delete();
    }
}
