<?php

namespace App\Features\MemorizationSessions\Actions;

use App\Features\MemorizationSessions\Requests\UpdateMemorizationSessionRequest;
use App\Models\MemorizationSession;
use App\Support\Actions\BaseAction;

class UpdateMemorizationSessionAction extends BaseAction
{
    /**
     * @return MemorizationSession
     */
    public function execute(mixed ...$arguments): mixed
    {
        $memorizationSession = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $memorizationSession instanceof MemorizationSession) {
            throw new \InvalidArgumentException('UpdateMemorizationSessionAction expects a MemorizationSession as the first argument.');
        }

        if (! $request instanceof UpdateMemorizationSessionRequest) {
            throw new \InvalidArgumentException('UpdateMemorizationSessionAction expects an UpdateMemorizationSessionRequest as the second argument.');
        }

        $memorizationSession->update($request->validatedData());

        return $memorizationSession->fresh();
    }
}
