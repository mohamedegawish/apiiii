<?php

namespace App\Features\MemorizationSessions\Actions;

use App\Events\MemorizationSessionCreated;
use App\Features\MemorizationSessions\Requests\StoreMemorizationSessionRequest;
use App\Models\Circle;
use App\Models\MemorizationSession;
use App\Models\Student;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;
use App\Support\Exceptions\ForbiddenException;

class CreateMemorizationSessionAction extends BaseAction
{
    /**
     * @return MemorizationSession
     */
    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreMemorizationSessionRequest) {
            throw new \InvalidArgumentException('CreateMemorizationSessionAction expects a StoreMemorizationSessionRequest.');
        }

        $data = $request->validatedData();
        if (! isset($data['circle_id'])) {
            throw new ConflictException('A circle is required for legacy session creation.');
        }
        $circle = Circle::findOrFail($data['circle_id']);
        $actor = $request->user();
        if ($actor?->teacher !== null && $circle->teacher_id !== $actor->teacher->id) {
            throw new ForbiddenException('The circle is not assigned to this teacher.');
        }

        // Business rule 14: suspended/graduated/withdrawn students may not receive academic records.
        $student = Student::findOrFail($data['student_id']);
        if (! $student->status->allowsAcademicActivity()) {
            throw new ConflictException('Only active students may receive memorization records.');
        }

        $data['teacher_id'] = $actor?->teacher?->id ?? $circle->teacher_id;
        $session = MemorizationSession::create($data);

        event(new MemorizationSessionCreated($session));

        return $session;
    }
}
