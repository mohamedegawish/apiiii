<?php

namespace App\Features\Statistics\Controllers;

use App\Enums\Role;
use App\Models\Circle;
use App\Models\Student;
use App\Models\Teacher;
use App\Support\Exceptions\ForbiddenException;
use App\Support\Exceptions\NotFoundException;
use App\Support\Http\Controllers\BaseController;
use App\Support\Services\StatisticsCalculatorService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class StatisticsController extends BaseController
{
    public function __construct(protected StatisticsCalculatorService $calculator) {}

    /**
     * Retrieve statistics for a single student.
     */
    public function student(Request $request, string $studentId): JsonResponse
    {
        $student = Student::find($studentId);

        if ($student === null) {
            throw new NotFoundException('Student not found.');
        }

        $this->authorize('view', $student);

        $statistics = $this->calculator->getStudentStatistics($studentId);

        return $this->success(
            data: $statistics,
            message: 'Student statistics retrieved successfully.',
        );
    }

    /**
     * Retrieve statistics for a single teacher.
     */
    public function teacher(Request $request, string $teacherId): JsonResponse
    {
        $teacher = Teacher::find($teacherId);

        if ($teacher === null) {
            throw new NotFoundException('Teacher not found.');
        }

        $this->authorize('view', $teacher);

        $statistics = $this->calculator->getTeacherStatistics($teacherId);

        return $this->success(
            data: $statistics,
            message: 'Teacher statistics retrieved successfully.',
        );
    }

    /**
     * Retrieve statistics for a single circle.
     */
    public function circle(Request $request, string $circleId): JsonResponse
    {
        $circle = Circle::find($circleId);

        if ($circle === null) {
            throw new NotFoundException('Circle not found.');
        }

        $this->authorize('view', $circle);

        $statistics = $this->calculator->getCircleStatistics($circleId);

        return $this->success(
            data: $statistics,
            message: 'Circle statistics retrieved successfully.',
        );
    }

    /**
     * Force recalculation of student statistics (synchronous).
     */
    public function recalculateStudent(Request $request, string $studentId): JsonResponse
    {
        $this->requireRecalculationPermission($request);

        $student = Student::find($studentId);

        if ($student === null) {
            throw new NotFoundException('Student not found.');
        }

        $this->authorize('view', $student);

        $statistics = $this->calculator->recalculateStudent($studentId);

        return $this->success(
            data: $statistics->toArray(),
            message: 'Student statistics recalculated successfully.',
        );
    }

    /**
     * Force recalculation of teacher statistics (synchronous).
     */
    public function recalculateTeacher(Request $request, string $teacherId): JsonResponse
    {
        $this->requireRecalculationPermission($request);

        $teacher = Teacher::find($teacherId);

        if ($teacher === null) {
            throw new NotFoundException('Teacher not found.');
        }

        $this->authorize('view', $teacher);

        $statistics = $this->calculator->recalculateTeacher($teacherId);

        return $this->success(
            data: $statistics->toArray(),
            message: 'Teacher statistics recalculated successfully.',
        );
    }

    /**
     * Force recalculation of circle statistics (synchronous).
     */
    public function recalculateCircle(Request $request, string $circleId): JsonResponse
    {
        $this->requireRecalculationPermission($request);

        $circle = Circle::find($circleId);

        if ($circle === null) {
            throw new NotFoundException('Circle not found.');
        }

        $this->authorize('view', $circle);

        $statistics = $this->calculator->recalculateCircle($circleId);

        return $this->success(
            data: $statistics->toArray(),
            message: 'Circle statistics recalculated successfully.',
        );
    }

    /**
     * Restrict synchronous recalculation to administrative roles only.
     *
     * @throws ForbiddenException
     */
    protected function requireRecalculationPermission(Request $request): void
    {
        $user = $request->user();

        if ($user === null) {
            throw new ForbiddenException('Authentication is required.');
        }

        if ($user->isSuperAdmin()) {
            return;
        }

        if ($user->hasRole(Role::SuperAdmin, Role::CenterOwner)) {
            return;
        }

        throw new ForbiddenException('You do not have permission to recalculate statistics.');
    }
}
