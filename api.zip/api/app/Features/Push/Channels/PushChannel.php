<?php

namespace App\Features\Push\Channels;

use App\Enums\DevicePlatform;
use App\Enums\PushProvider;
use App\Features\Push\Jobs\DeliverPushNotification;
use App\Models\PushDelivery;
use App\Models\User;
use App\Notifications\StudentAlertNotification;
use Throwable;

class PushChannel
{
    public function send(object $notifiable, StudentAlertNotification $notification): void
    {
        if (! $notifiable instanceof User) {
            return;
        }

        $notifiable->deviceTokens()
            ->where('provider', PushProvider::Fcm->value)
            ->whereIn('platform', [DevicePlatform::Android->value, DevicePlatform::Ios->value])
            ->each(function ($deviceToken) use ($notifiable, $notification): void {
                $delivery = PushDelivery::firstOrCreate(
                    [
                        'notification_id' => $notification->id,
                        'device_token_id' => $deviceToken->id,
                    ],
                    [
                        'user_id' => $notifiable->id,
                        'event_type' => $notification->eventType(),
                        'status' => PushDelivery::STATUS_PENDING,
                    ],
                );

                if ($delivery->wasRecentlyCreated) {
                    try {
                        DeliverPushNotification::dispatch($delivery->id, $notification->payload());
                    } catch (Throwable $exception) {
                        // A sync queue must not make the database notification fail locally.
                        (new DeliverPushNotification($delivery->id, $notification->payload()))->failed($exception);
                    }
                }
            });
    }
}
