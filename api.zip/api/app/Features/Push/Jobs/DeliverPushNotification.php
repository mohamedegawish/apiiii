<?php

namespace App\Features\Push\Jobs;

use App\Features\Push\Services\PushNotificationService;
use App\Models\DeviceToken;
use App\Models\PushDelivery;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Kreait\Firebase\Exception\Messaging\NotFound;
use Throwable;

class DeliverPushNotification implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;

    public int $timeout = 30;

    /** @var list<int> */
    public array $backoff = [10, 60, 300];

    /** @param array<string, mixed> $payload */
    public function __construct(public readonly string $deliveryId, public readonly array $payload)
    {
        $this->onQueue('push');
    }

    public function handle(PushNotificationService $pushNotificationService): void
    {
        $delivery = PushDelivery::find($this->deliveryId);

        if ($delivery === null || in_array($delivery->status, [PushDelivery::STATUS_SENT, PushDelivery::STATUS_INVALID], true)) {
            return;
        }

        $delivery->increment('attempts');
        $deviceToken = DeviceToken::find($delivery->device_token_id);

        if ($deviceToken === null) {
            $delivery->update([
                'status' => PushDelivery::STATUS_INVALID,
                'error' => 'Device token no longer exists.',
                'failed_at' => now(),
            ]);

            return;
        }

        try {
            $response = $pushNotificationService->send($deviceToken, $delivery->event_type, $this->payload);
            $delivery->update([
                'status' => PushDelivery::STATUS_SENT,
                'error' => null,
                'response_message_id' => isset($response['name']) ? (string) $response['name'] : null,
                'sent_at' => now(),
                'failed_at' => null,
            ]);
        } catch (NotFound $exception) {
            $delivery->update([
                'status' => PushDelivery::STATUS_INVALID,
                'error' => $exception->getMessage(),
                'failed_at' => now(),
            ]);
            $deviceToken->delete();
        } catch (Throwable $exception) {
            $delivery->update([
                'status' => PushDelivery::STATUS_PENDING,
                'error' => $exception->getMessage(),
            ]);

            throw $exception;
        }
    }

    public function failed(?Throwable $exception): void
    {
        PushDelivery::whereKey($this->deliveryId)->update([
            'status' => PushDelivery::STATUS_FAILED,
            'error' => $exception?->getMessage() ?? 'Push delivery failed.',
            'failed_at' => now(),
        ]);

        if ($exception !== null && function_exists('Sentry\\captureException')) {
            \Sentry\captureException($exception);
        }
    }
}
