<?php

namespace App\Features\Push\Services;

use App\Enums\DevicePlatform;
use App\Models\DeviceToken;
use Kreait\Firebase\Contract\Messaging;
use Kreait\Firebase\Messaging\CloudMessage;

class PushNotificationService
{
    public function __construct(private readonly Messaging $messaging) {}

    /**
     * @param  array<string, mixed>  $payload
     * @return array<array-key, mixed>
     */
    public function send(DeviceToken $deviceToken, string $eventType, array $payload): array
    {
        [$title, $body] = $this->notificationText($eventType, $payload);

        $message = CloudMessage::new()
            ->toToken($deviceToken->token)
            ->withNotification(['title' => $title, 'body' => $body])
            ->withData($this->stringPayload($eventType, $payload));

        $message = $deviceToken->platform === DevicePlatform::Ios
            ? $message->withApnsConfig([
                'headers' => ['apns-priority' => '10'],
                'payload' => ['aps' => ['sound' => 'default']],
            ])
            : $message->withAndroidConfig([
                'priority' => 'high',
                'notification' => ['sound' => 'default'],
            ]);

        return $this->messaging->send($message);
    }

    /** @param array<string, mixed> $payload */
    private function notificationText(string $eventType, array $payload): array
    {
        $student = isset($payload['student_name']) ? (string) $payload['student_name'] : 'the student';

        return match ($eventType) {
            'attendance' => ['Attendance update', "Attendance was updated for {$student}."],
            'absence' => ['Student absence', "{$student} was marked absent."],
            'assessment' => ['Assessment update', "A new assessment is available for {$student}."],
            'homework', 'new_homework' => ['New homework', "New homework was assigned to {$student}."],
            'payment' => ['Payment update', 'There is an update to your payment.'],
            'achievement' => ['New achievement', "{$student} earned a new achievement."],
            'low_score' => ['Learning update', "A learning update is available for {$student}."],
            'session_reminder' => ['Session reminder', 'An upcoming circle session has been scheduled.'],
            'parent_evaluation_reminder' => ['Evaluation reminder', 'Please complete the student evaluation.'],
            'system' => ['System notification', (string) ($payload['message'] ?? 'You have a new notification.')],
            default => [(string) ($payload['title'] ?? 'Student update'), (string) ($payload['body'] ?? $payload['message'] ?? 'You have a new student update.')],
        };
    }

    /**
     * @param  array<string, mixed>  $payload
     * @return array<string, string>
     */
    private function stringPayload(string $eventType, array $payload): array
    {
        $data = ['event_type' => $eventType];

        foreach ($payload as $key => $value) {
            if ($value === null) {
                continue;
            }

            $data[(string) $key] = is_scalar($value)
                ? (string) $value
                : (json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '');
        }

        return $data;
    }
}
