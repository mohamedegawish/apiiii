<?php

namespace App\Features\RevisionSessions\Services;

use App\Features\RevisionSessions\Actions\CreateRevisionSessionAction;
use App\Features\RevisionSessions\Actions\DeleteRevisionSessionAction;
use App\Features\RevisionSessions\Actions\UpdateRevisionSessionAction;
use App\Features\RevisionSessions\Queries\RevisionSessionQuery;
use App\Features\RevisionSessions\Requests\StoreRevisionSessionRequest;
use App\Features\RevisionSessions\Requests\UpdateRevisionSessionRequest;
use App\Models\RevisionSession;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class RevisionSessionService extends BaseService
{
    public function __construct(
        protected CreateRevisionSessionAction $createRevisionSessionAction,
        protected UpdateRevisionSessionAction $updateRevisionSessionAction,
        protected DeleteRevisionSessionAction $deleteRevisionSessionAction,
        protected RevisionSessionQuery $revisionSessionQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->revisionSessionQuery->paginate();
    }

    public function findOrFail(string $id): RevisionSession
    {
        $revisionSession = RevisionSession::with(['student', 'teacher'])->find($id);

        if ($revisionSession === null) {
            throw new NotFoundException('Revision session not found.');
        }

        return $revisionSession;
    }

    public function create(StoreRevisionSessionRequest $request): RevisionSession
    {
        return $this->transaction(fn (): RevisionSession => $this->createRevisionSessionAction->execute($request));
    }

    public function update(RevisionSession $revisionSession, UpdateRevisionSessionRequest $request): RevisionSession
    {
        return $this->transaction(fn (): RevisionSession => $this->updateRevisionSessionAction->execute($revisionSession, $request));
    }

    public function delete(RevisionSession $revisionSession): bool
    {
        return $this->transaction(fn (): bool => $this->deleteRevisionSessionAction->execute($revisionSession));
    }
}
