<?php

namespace App\Features\RevisionSessions\Queries;

use App\Enums\Role;
use App\Models\RevisionSession;
use App\Support\Queries\BaseQuery;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class RevisionSessionQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(RevisionSession::class);
    }

    /**
     * Scope sessions to those the current user may access.
     *
     * @param  EloquentBuilder<RevisionSession>  $builder
     */
    protected function applyTenantScope(EloquentBuilder $builder): void
    {
        if ($this->shouldBypassScope()) {
            return;
        }

        $user = $this->currentUser();

        if ($user?->hasRole(Role::Teacher) && $user->teacher !== null) {
            $builder->where('teacher_id', $user->teacher->id);

            return;
        }

        $circleIds = $this->accessibleCircleIds();

        if ($circleIds === []) {
            $builder->whereRaw('1 = 0');

            return;
        }

        if ($circleIds !== null) {
            $builder->whereIn('circle_id', $circleIds);
        }
    }

    /**
     * @return list<AllowedFilter>
     */
    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::exact('student_id'),
            AllowedFilter::exact('teacher_id'),
            AllowedFilter::exact('circle_id'),
            AllowedFilter::exact('session_type'),
            AllowedFilter::partial('notes'),
            AllowedFilter::exact('surah_number'),
            AllowedFilter::scope('search'),
        ];
    }

    /**
     * @return list<string>
     */
    protected function allowedSorts(): array
    {
        return [
            'session_date',
            'created_at',
            'updated_at',
        ];
    }

    /**
     * @return list<string>
     */
    protected function allowedIncludes(): array
    {
        return ['student', 'teacher', 'circle'];
    }
}
