<?php

namespace App\Features\RevisionSessions\Requests;

use App\Enums\SessionType;
use App\Models\RevisionSession;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class UpdateRevisionSessionRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $revisionSession = RevisionSession::find($this->route('revisionSession'));

        return $this->user()?->can('update', $revisionSession) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'student_id' => ['prohibited'],
            'teacher_id' => ['prohibited'],
            'circle_id' => ['prohibited'],
            'surah_number' => ['sometimes', 'integer', 'min:1', 'max:114'],
            'from_ayah' => ['sometimes', 'integer', 'min:1'],
            'to_ayah' => ['sometimes', 'integer', 'min:1'],
            'session_type' => ['sometimes', 'nullable', 'string', Rule::in(SessionType::values())],
            'memorization_grade' => ['sometimes', 'nullable', 'numeric', 'min:0', 'max:100'],
            'tajweed_grade' => ['sometimes', 'nullable', 'numeric', 'min:0', 'max:100'],
            'fluency_grade' => ['sometimes', 'nullable', 'numeric', 'min:0', 'max:100'],
            'discipline_grade' => ['sometimes', 'nullable', 'numeric', 'min:0', 'max:100'],
            'notes' => ['sometimes', 'nullable', 'string', 'max:2000'],
            'session_date' => ['prohibited'],
        ];
    }
}
