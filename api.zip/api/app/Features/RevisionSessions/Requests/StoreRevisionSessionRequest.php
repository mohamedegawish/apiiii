<?php

namespace App\Features\RevisionSessions\Requests;

use App\Enums\SessionType;
use App\Models\RevisionSession;
use App\Support\Http\Requests\BaseRequest;
use App\Support\Rules\OwnedCircle;
use Illuminate\Validation\Rule;

class StoreRevisionSessionRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', RevisionSession::class) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'student_id' => ['required', 'uuid', 'exists:students,id'],
            'teacher_id' => ['prohibited'],
            'circle_id' => ['nullable', 'uuid', 'exists:circles,id', new OwnedCircle],
            'surah_number' => ['required', 'integer', 'min:1', 'max:114'],
            'from_ayah' => ['required', 'integer', 'min:1'],
            'to_ayah' => ['required', 'integer', 'min:1'],
            'session_type' => ['nullable', 'string', Rule::in(SessionType::values())],
            'memorization_grade' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'tajweed_grade' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'fluency_grade' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'discipline_grade' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'notes' => ['nullable', 'string', 'max:2000'],
            'session_date' => ['required', 'date', 'before_or_equal:today'],
        ];
    }
}
