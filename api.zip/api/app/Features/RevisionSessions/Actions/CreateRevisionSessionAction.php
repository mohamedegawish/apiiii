<?php

namespace App\Features\RevisionSessions\Actions;

use App\Enums\SessionType;
use App\Events\RevisionSessionCreated;
use App\Features\RevisionSessions\Requests\StoreRevisionSessionRequest;
use App\Models\Circle;
use App\Models\RevisionSession;
use App\Models\Student;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;
use App\Support\Exceptions\ForbiddenException;

class CreateRevisionSessionAction extends BaseAction
{
    /**
     * @return RevisionSession
     */
    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreRevisionSessionRequest) {
            throw new \InvalidArgumentException('CreateRevisionSessionAction expects a StoreRevisionSessionRequest.');
        }

        $data = $request->validatedData();
        if (! isset($data['circle_id'])) {
            throw new ConflictException('A circle is required for legacy session creation.');
        }
        $circle = Circle::findOrFail($data['circle_id']);
        $actor = $request->user();
        if ($actor?->teacher !== null && $circle->teacher_id !== $actor->teacher->id) {
            throw new ForbiddenException('The circle is not assigned to this teacher.');
        }

        // Business rule 14: suspended/graduated/withdrawn students may not receive academic records.
        $student = Student::findOrFail($data['student_id']);
        if (! $student->status->allowsAcademicActivity()) {
            throw new ConflictException('Only active students may receive revision records.');
        }

        $data['teacher_id'] = $actor?->teacher?->id ?? $circle->teacher_id;
        $data['session_type'] ??= SessionType::NearRevision;

        $session = RevisionSession::create($data);

        event(new RevisionSessionCreated($session));

        return $session;
    }
}
