<?php

namespace App\Features\RevisionSessions\Actions;

use App\Models\RevisionSession;
use App\Support\Actions\BaseAction;

class DeleteRevisionSessionAction extends BaseAction
{
    /**
     * @return bool
     */
    public function execute(mixed ...$arguments): mixed
    {
        $revisionSession = $arguments[0] ?? null;

        if (! $revisionSession instanceof RevisionSession) {
            throw new \InvalidArgumentException('DeleteRevisionSessionAction expects a RevisionSession.');
        }

        return $revisionSession->delete();
    }
}
