<?php

namespace App\Features\RevisionSessions\Actions;

use App\Features\RevisionSessions\Requests\UpdateRevisionSessionRequest;
use App\Models\RevisionSession;
use App\Support\Actions\BaseAction;

class UpdateRevisionSessionAction extends BaseAction
{
    /**
     * @return RevisionSession
     */
    public function execute(mixed ...$arguments): mixed
    {
        $revisionSession = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $revisionSession instanceof RevisionSession) {
            throw new \InvalidArgumentException('UpdateRevisionSessionAction expects a RevisionSession as the first argument.');
        }

        if (! $request instanceof UpdateRevisionSessionRequest) {
            throw new \InvalidArgumentException('UpdateRevisionSessionAction expects an UpdateRevisionSessionRequest as the second argument.');
        }

        $revisionSession->update($request->validatedData());

        return $revisionSession->fresh();
    }
}
