<?php

namespace App\Features\RevisionSessions\Policies;

use App\Enums\Role;
use App\Models\RevisionSession;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class RevisionSessionPolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $user instanceof User;
    }

    public function view(?User $user, RevisionSession $revisionSession): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        return $this->hasRole($user, Role::Teacher)
            && $revisionSession->teacher?->user_id === $user->id;
    }

    public function create(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner)
            || $this->hasRole($user, Role::Teacher);
    }

    public function update(?User $user, RevisionSession $revisionSession): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        return $this->hasRole($user, Role::Teacher)
            && $revisionSession->teacher?->user_id === $user->id;
    }

    public function delete(?User $user, RevisionSession $revisionSession): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        return $this->hasRole($user, Role::CenterOwner);
    }

    public function restore(?User $user, RevisionSession $revisionSession): bool
    {
        return $this->isSuperAdmin($user);
    }

    public function forceDelete(?User $user, RevisionSession $revisionSession): bool
    {
        return $this->isSuperAdmin($user);
    }
}
