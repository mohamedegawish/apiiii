<?php

namespace App\Features\RevisionSessions\Controllers;

use App\Features\RevisionSessions\Requests\StoreRevisionSessionRequest;
use App\Features\RevisionSessions\Requests\UpdateRevisionSessionRequest;
use App\Features\RevisionSessions\Resources\RevisionSessionResource;
use App\Features\RevisionSessions\Services\RevisionSessionService;
use App\Models\RevisionSession;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class RevisionSessionController extends BaseController
{
    public function __construct(protected RevisionSessionService $revisionSessionService) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', RevisionSession::class);

        $paginator = $this->revisionSessionService->paginate();

        return $this->paginate(RevisionSessionResource::collection($paginator), 'Revision sessions retrieved successfully.');
    }

    public function show(string $revisionSession): JsonResponse
    {
        $model = $this->revisionSessionService->findOrFail($revisionSession);

        $this->authorize('view', $model);

        return $this->success(
            data: RevisionSessionResource::make($model),
            message: 'Revision session retrieved successfully.',
        );
    }

    public function store(StoreRevisionSessionRequest $request): JsonResponse
    {
        $revisionSession = $this->revisionSessionService->create($request);

        return $this->created(
            data: RevisionSessionResource::make($revisionSession),
            message: 'Revision session created successfully.',
        );
    }

    public function update(UpdateRevisionSessionRequest $request, string $revisionSession): JsonResponse
    {
        $model = $this->revisionSessionService->findOrFail($revisionSession);
        $updated = $this->revisionSessionService->update($model, $request);

        return $this->success(
            data: RevisionSessionResource::make($updated),
            message: 'Revision session updated successfully.',
        );
    }

    public function destroy(string $revisionSession): JsonResponse
    {
        $model = $this->revisionSessionService->findOrFail($revisionSession);

        $this->authorize('delete', $model);

        $this->revisionSessionService->delete($model);

        return $this->success(
            data: null,
            message: 'Revision session deleted successfully.',
        );
    }
}
