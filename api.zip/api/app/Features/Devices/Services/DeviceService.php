<?php

namespace App\Features\Devices\Services;

use App\Models\DeviceToken;
use App\Models\User;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class DeviceService extends BaseService
{
    public function paginate(User $user, int $perPage): LengthAwarePaginator
    {
        return DeviceToken::query()
            ->where('user_id', $user->id)
            ->latest('last_used_at')
            ->latest('created_at')
            ->paginate($perPage);
    }

    /** @param array<string, mixed> $data */
    public function register(User $user, array $data): DeviceToken
    {
        return $this->transaction(function () use ($user, $data): DeviceToken {
            DeviceToken::where('token', $data['token'])
                ->where(fn ($query) => $query->where('user_id', '!=', $user->id)->orWhere('device_id', '!=', $data['device_id']))
                ->delete();

            return $user->deviceTokens()->updateOrCreate(
                ['device_id' => $data['device_id']],
                [...$data, 'last_used_at' => now()],
            );
        });
    }

    public function revoke(User $user, string $deviceId): void
    {
        $this->transaction(function () use ($user, $deviceId): void {
            $query = DeviceToken::query()->where('id', $deviceId);

            if (! $user->isSuperAdmin()) {
                $query->where('user_id', $user->id);
            }

            if ($query->delete() === 0) {
                throw new NotFoundException('Device not found.');
            }
        });
    }
}
