<?php

namespace App\Features\Devices\Resources;

use App\Models\DeviceToken;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/** @mixin DeviceToken */
class DeviceResource extends BaseResource
{
    /** @return array<string, mixed> */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'device_id' => $this->device_id,
            'device_name' => $this->device_name,
            'platform' => $this->platform?->value,
            'provider' => $this->provider?->value,
            'last_used_at' => $this->last_used_at?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
