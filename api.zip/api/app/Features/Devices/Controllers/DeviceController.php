<?php

namespace App\Features\Devices\Controllers;

use App\Features\Devices\Requests\DeviceIndexRequest;
use App\Features\Devices\Requests\RegisterDeviceRequest;
use App\Features\Devices\Requests\RevokeDeviceRequest;
use App\Features\Devices\Resources\DeviceResource;
use App\Features\Devices\Services\DeviceService;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;

class DeviceController extends BaseController
{
    public function __construct(protected DeviceService $deviceService) {}

    public function index(DeviceIndexRequest $request): JsonResponse
    {
        $devices = $this->deviceService->paginate($request->user(), (int) ($request->validated('per_page') ?? 25));

        return $this->paginate(DeviceResource::collection($devices), 'Devices retrieved successfully.');
    }

    public function register(RegisterDeviceRequest $request): JsonResponse
    {
        $device = $this->deviceService->register($request->user(), $request->validatedData());

        return $this->success(DeviceResource::make($device), 'Device registered successfully.');
    }

    public function revoke(RevokeDeviceRequest $request, string $device): JsonResponse
    {
        $this->deviceService->revoke($request->user(), $device);

        return $this->success(null, 'Device revoked successfully.');
    }
}
