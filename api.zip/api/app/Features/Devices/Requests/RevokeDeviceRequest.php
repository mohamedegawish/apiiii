<?php

namespace App\Features\Devices\Requests;

use App\Support\Http\Requests\BaseRequest;

class RevokeDeviceRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [];
    }
}
