<?php

namespace App\Features\Devices\Requests;

use App\Enums\DevicePlatform;
use App\Enums\PushProvider;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class RegisterDeviceRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'device_id' => ['required', 'string', 'max:255'],
            'device_name' => ['nullable', 'string', 'max:255'],
            'platform' => ['required', Rule::in([DevicePlatform::Android->value, DevicePlatform::Ios->value])],
            'provider' => ['required', Rule::in([PushProvider::Fcm->value])],
            'token' => ['required', 'string', 'max:4096'],
        ];
    }
}
