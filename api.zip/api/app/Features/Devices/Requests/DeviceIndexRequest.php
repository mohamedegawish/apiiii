<?php

namespace App\Features\Devices\Requests;

use App\Support\Http\Requests\BaseRequest;

class DeviceIndexRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
        ];
    }
}
