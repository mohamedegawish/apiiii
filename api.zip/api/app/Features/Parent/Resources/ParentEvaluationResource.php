<?php

namespace App\Features\Parent\Resources;

use App\Models\ParentEvaluation;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * @mixin ParentEvaluation
 */
class ParentEvaluationResource extends BaseResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'circle_session_id' => $this->circle_session_id,
            'student_id' => $this->student_id,
            'guardian_id' => $this->guardian_id,
            'behavior_score' => $this->behavior_score,
            'prayer_score' => $this->prayer_score,
            'homework_followup_score' => $this->homework_followup_score,
            'notes' => $this->notes,
            'student' => $this->whenLoaded('student', fn () => [
                'id' => $this->student->id,
                'name' => $this->student->name,
            ]),
            'session' => $this->whenLoaded('circleSession', fn () => [
                'id' => $this->circleSession->id,
                'circle_id' => $this->circleSession->circle_id,
                'session_date' => $this->circleSession->session_date?->toDateString(),
                'status' => $this->circleSession->status?->value,
                'locked_at' => $this->circleSession->locked_at?->toIso8601String(),
            ]),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
