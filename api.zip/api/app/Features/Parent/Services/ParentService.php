<?php

namespace App\Features\Parent\Services;

use App\Enums\CircleSessionStatus;
use App\Enums\Role;
use App\Features\Parent\Actions\CreateParentEvaluationAction;
use App\Features\Parent\Actions\UpdateParentEvaluationAction;
use App\Features\Parent\Queries\ParentEvaluationQuery;
use App\Features\Parent\Requests\StoreParentEvaluationRequest;
use App\Features\Parent\Requests\UpdateParentEvaluationRequest;
use App\Models\CircleSession;
use App\Models\Guardian;
use App\Models\Invoice;
use App\Models\ParentEvaluation;
use App\Models\Payment;
use App\Models\Student;
use App\Models\User;
use App\Support\CenterClock;
use App\Support\Exceptions\ConflictException;
use App\Support\Exceptions\ForbiddenException;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

class ParentService extends BaseService
{
    public function __construct(
        protected CreateParentEvaluationAction $createParentEvaluationAction,
        protected UpdateParentEvaluationAction $updateParentEvaluationAction,
        protected ParentEvaluationQuery $parentEvaluationQuery,
    ) {}

    /** @return Collection<int, Student> */
    public function myChildren(User $user): Collection
    {
        $this->guardianFor($user);

        return $this->parentEvaluationQuery->children($user);
    }

    public function childSessions(User $user, string $studentId): LengthAwarePaginator
    {
        $student = $this->accessibleStudent($user, $studentId);

        return $this->parentEvaluationQuery->childSessions($user, $student);
    }

    public function childLearningRecords(User $user, string $studentId): LengthAwarePaginator
    {
        $student = $this->accessibleStudent($user, $studentId);

        return $this->parentEvaluationQuery->childLearningRecords($student);
    }

    public function childAttendance(User $user, string $studentId): LengthAwarePaginator
    {
        $student = $this->accessibleStudent($user, $studentId);

        return $this->parentEvaluationQuery->childAttendance($student);
    }

    /** @return array{invoices: Collection<int, Invoice>, payments: Collection<int, Payment>, total_invoiced: float, total_paid: float, balance_due: float} */
    public function childPayments(User $user, string $studentId): array
    {
        $student = $this->accessibleStudent($user, $studentId);
        $invoices = Invoice::query()
            ->where('student_id', $student->id)
            ->with('revenueCategory')
            ->latest('issue_date')
            ->get();
        $payments = Payment::query()
            ->where('student_id', $student->id)
            ->with('revenueCategory')
            ->latest('paid_at')
            ->get();

        $totalInvoiced = round((float) $invoices->sum('total'), 2);
        // Money actually received, which is the payments table -- not
        // invoices.amount_paid. A standalone payment (no invoice) was shown
        // in `entries` while being excluded from total_paid and balance_due,
        // so a guardian could see a payment listed and their balance unmoved.
        $totalPaid = round((float) $payments->sum('amount'), 2);

        return [
            'invoices' => $invoices,
            'payments' => $payments,
            'total_invoiced' => $totalInvoiced,
            'total_paid' => $totalPaid,
            'balance_due' => round($totalInvoiced - $totalPaid, 2),
        ];
    }

    /** @return array<string, int|float|null> */
    public function dashboard(User $user): array
    {
        return $this->parentEvaluationQuery->dashboard($user);
    }

    public function evaluations(): LengthAwarePaginator
    {
        return $this->parentEvaluationQuery->paginate();
    }

    public function storeEvaluation(User $user, StoreParentEvaluationRequest $request): ParentEvaluation
    {
        $guardian = $this->guardianFor($user);
        $data = $request->validatedData();

        return $this->transaction(function () use ($guardian, $data): ParentEvaluation {
            $session = CircleSession::query()->lockForUpdate()->find($data['circle_session_id']);

            if ($session === null) {
                throw new NotFoundException('Circle session not found.');
            }

            $this->assertWritableSession($session);
            $this->assertGuardianChild($guardian, $data['student_id']);
            $this->assertEnrolledForSession($session, $data['student_id']);

            $existing = ParentEvaluation::withTrashed()
                ->where('guardian_id', $guardian->id)
                ->where('circle_session_id', $session->id)
                ->where('student_id', $data['student_id'])
                ->lockForUpdate()
                ->first();

            if ($existing !== null) {
                throw new ConflictException('An evaluation already exists for this parent, session, and student.');
            }

            return $this->createParentEvaluationAction->create($guardian, $data)
                ->load(['student', 'circleSession.circle']);
        });
    }

    public function updateEvaluation(User $user, string $evaluationId, UpdateParentEvaluationRequest $request): ParentEvaluation
    {
        $guardian = $this->guardianFor($user);
        $data = $request->validatedData();

        return $this->transaction(function () use ($guardian, $evaluationId, $data): ParentEvaluation {
            $evaluation = ParentEvaluation::query()->find($evaluationId);

            if ($evaluation === null || $evaluation->guardian_id !== $guardian->id) {
                throw new NotFoundException('Parent evaluation not found.');
            }

            $session = CircleSession::query()->lockForUpdate()->find($evaluation->circle_session_id);

            if ($session === null) {
                throw new NotFoundException('Circle session not found.');
            }

            $evaluation = ParentEvaluation::query()->lockForUpdate()->find($evaluationId);

            if ($evaluation === null || $evaluation->guardian_id !== $guardian->id) {
                throw new NotFoundException('Parent evaluation not found.');
            }

            $this->assertWritableSession($session);
            $this->assertGuardianChild($guardian, $evaluation->student_id);
            $this->assertEnrolledForSession($session, $evaluation->student_id);

            return $this->updateParentEvaluationAction->update($evaluation, $data)
                ->load(['student', 'circleSession.circle']);
        });
    }

    private function guardianFor(User $user): Guardian
    {
        if (! $user->hasRole(Role::Parent) || $user->guardian === null) {
            throw new ForbiddenException('Only a parent with a guardian profile may submit or manage evaluations.');
        }

        return $user->guardian;
    }

    private function accessibleStudent(User $user, string $studentId): Student
    {
        $query = Student::query()->whereKey($studentId);

        if ($user->hasRole(Role::Parent)) {
            $guardian = $this->guardianFor($user);
            $query->whereHas('guardians', fn ($query) => $query->where('guardians.id', $guardian->id));
        } elseif (! $user->isSuperAdmin()) {
            throw new ForbiddenException;
        }

        $student = $query->first();

        if ($student === null) {
            throw new NotFoundException('Student not found.');
        }

        return $student;
    }

    private function assertGuardianChild(Guardian $guardian, string $studentId): void
    {
        if (! $guardian->children()->whereKey($studentId)->exists()) {
            throw new ForbiddenException('The student is not linked to this guardian.');
        }
    }

    private function assertEnrolledForSession(CircleSession $session, string $studentId): void
    {
        $enrolled = $session->circle->enrollments()
            ->where('student_id', $studentId)
            ->coveringDate($session->session_date)
            ->exists();

        if (! $enrolled) {
            throw new ForbiddenException('The student was not enrolled in the circle for this session.');
        }
    }

    private function assertWritableSession(CircleSession $session): void
    {
        if (CenterClock::isFutureDate($session->session_date)) {
            throw new ConflictException('Future sessions cannot be evaluated.');
        }

        if (! in_array($session->status, [CircleSessionStatus::Completed, CircleSessionStatus::Locked], true)) {
            throw new ConflictException('Only completed sessions can be evaluated.');
        }
    }
}
