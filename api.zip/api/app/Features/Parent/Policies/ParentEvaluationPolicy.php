<?php

namespace App\Features\Parent\Policies;

use App\Enums\Role;
use App\Models\ParentEvaluation;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class ParentEvaluationPolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $this->hasRole($user, Role::Parent, Role::CenterOwner, Role::SuperAdmin);
    }

    public function view(?User $user, ParentEvaluation $evaluation): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::Parent)) {
            return $user?->guardian?->id === $evaluation->guardian_id;
        }

        return $this->hasRole($user, Role::CenterOwner);
    }

    public function create(?User $user): bool
    {
        return $this->hasRole($user, Role::Parent) && $user?->guardian !== null;
    }

    public function update(?User $user, ParentEvaluation $evaluation): bool
    {
        return $this->create($user)
            && $user?->guardian?->id === $evaluation->guardian_id
            && $evaluation->circleSession?->locked_at === null;
    }
}
