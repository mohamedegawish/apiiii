<?php

namespace App\Features\Parent\Controllers;

use App\Features\Attendance\Resources\AttendanceResource;
use App\Features\LearningRecords\Resources\LearningRecordResource;
use App\Features\Parent\Policies\ParentEvaluationPolicy;
use App\Features\Parent\Requests\StoreParentEvaluationRequest;
use App\Features\Parent\Requests\UpdateParentEvaluationRequest;
use App\Features\Parent\Resources\ParentEvaluationResource;
use App\Features\Parent\Services\ParentService;
use App\Models\User;
use App\Support\Exceptions\ForbiddenException;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ParentController extends BaseController
{
    public function __construct(
        protected ParentService $parentService,
        protected ParentEvaluationPolicy $parentEvaluationPolicy,
    ) {}

    public function myChildren(Request $request): JsonResponse
    {
        $children = $this->parentService->myChildren($this->user($request));

        return $this->success(data: $children->map(function ($student): array {
            $enrollment = $student->enrollments->first();
            $statistic = $student->statistics;

            return [
                'id' => $student->id,
                'student_code' => $student->student_code,
                'name' => $student->name,
                'status' => $student->status?->value,
                'relationship' => $student->pivot?->relationship,
                'is_primary' => (bool) $student->pivot?->is_primary,
                // The child's real context and figures. These are null when
                // genuinely unknown (not yet enrolled, statistics never
                // calculated) -- the app renders that as "unavailable"
                // rather than as zero, which would read as a real result.
                'circle_id' => $enrollment?->circle_id,
                'circle_name' => $enrollment?->circle?->name,
                'circle_level' => $enrollment?->circle?->level,
                'teacher_name' => $enrollment?->circle?->teacher?->user?->name,
                'attendance_rate' => $statistic?->attendance_rate === null
                    ? null
                    : (float) $statistic->attendance_rate,
                'memorized_pages' => $statistic?->memorized_pages,
                'completed_surahs' => $statistic?->completed_surahs,
            ];
        })->all(), message: 'Children retrieved successfully.');
    }

    public function childSessions(Request $request, string $student): JsonResponse
    {
        $sessions = $this->parentService->childSessions($this->user($request), $student);

        $sessions->through(fn ($session) => [
            'id' => $session->id,
            'circle_id' => $session->circle_id,
            'circle_name' => $session->circle?->name,
            'teacher_id' => $session->teacher_id,
            'teacher_name' => $session->teacher?->user?->name,
            'session_date' => $session->session_date?->toDateString(),
            'start_time' => $session->start_time,
            'end_time' => $session->end_time,
            'status' => $session->status?->value,
            'completed_at' => $session->completed_at?->toIso8601String(),
            'locked_at' => $session->locked_at?->toIso8601String(),
        ]);

        return $this->paginate($sessions, 'Child sessions retrieved successfully.');
    }

    public function childLearningRecords(Request $request, string $student): JsonResponse
    {
        $records = $this->parentService->childLearningRecords($this->user($request), $student);

        return $this->paginate(
            LearningRecordResource::collection($records),
            'Child learning records retrieved successfully.',
        );
    }

    public function childAttendance(Request $request, string $student): JsonResponse
    {
        $attendance = $this->parentService->childAttendance($this->user($request), $student);

        return $this->paginate(
            AttendanceResource::collection($attendance),
            'Child attendance retrieved successfully.',
        );
    }

    public function childPayments(Request $request, string $student): JsonResponse
    {
        $finance = $this->parentService->childPayments($this->user($request), $student);
        $entries = collect();

        foreach ($finance['invoices'] as $invoice) {
            $entries->push([
                'id' => 'invoice-'.$invoice->id,
                'student_id' => $invoice->student_id,
                'title' => $invoice->revenueCategory?->name ?? 'فاتورة '.$invoice->invoice_number,
                'date' => $invoice->due_date?->toDateString() ?? $invoice->issue_date?->toDateString(),
                'amount' => (float) $invoice->total,
                'paid' => (float) $invoice->amount_paid >= (float) $invoice->total,
                'method' => null,
            ]);
        }

        foreach ($finance['payments'] as $payment) {
            $entries->push([
                'id' => 'payment-'.$payment->id,
                'student_id' => $payment->student_id,
                'title' => $payment->revenueCategory?->name ?? 'دفعة مالية',
                'date' => $payment->paid_at?->toDateString(),
                'amount' => (float) $payment->amount,
                'paid' => true,
                'method' => $payment->method,
            ]);
        }

        return $this->success([
            'total_invoiced' => $finance['total_invoiced'],
            'total_paid' => $finance['total_paid'],
            'balance_due' => $finance['balance_due'],
            'entries' => $entries->sortByDesc('date')->values()->all(),
        ], 'Child payments retrieved successfully.');
    }

    public function dashboard(Request $request): JsonResponse
    {
        $user = $this->user($request);
        $this->assertCanView($user);

        return $this->success(
            data: $this->parentService->dashboard($user),
            message: 'Parent engagement dashboard retrieved successfully.',
        );
    }

    public function evaluations(Request $request): JsonResponse
    {
        $this->assertCanView($this->user($request));
        $paginator = $this->parentService->evaluations();

        return $this->paginate(
            ParentEvaluationResource::collection($paginator),
            'Parent evaluations retrieved successfully.',
        );
    }

    public function storeEvaluation(StoreParentEvaluationRequest $request): JsonResponse
    {
        $evaluation = $this->parentService->storeEvaluation($this->user($request), $request);

        return $this->created(
            data: ParentEvaluationResource::make($evaluation),
            message: 'Parent evaluation created successfully.',
        );
    }

    public function updateEvaluation(UpdateParentEvaluationRequest $request, string $evaluation): JsonResponse
    {
        $updated = $this->parentService->updateEvaluation($this->user($request), $evaluation, $request);

        return $this->success(
            data: ParentEvaluationResource::make($updated),
            message: 'Parent evaluation updated successfully.',
        );
    }

    private function assertCanView(User $user): void
    {
        if (! $this->parentEvaluationPolicy->viewAny($user)) {
            throw new ForbiddenException;
        }
    }

    private function user(Request $request): User
    {
        $user = $request->user();

        if (! $user instanceof User) {
            throw new ForbiddenException;
        }

        return $user;
    }
}
