<?php

namespace App\Features\Parent\Requests;

use App\Features\Parent\Policies\ParentEvaluationPolicy;
use App\Support\Http\Requests\BaseRequest;

class StoreParentEvaluationRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return app(ParentEvaluationPolicy::class)->create($this->user());
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'guardian_id' => ['prohibited'],
            'circle_session_id' => ['required', 'uuid', 'exists:circle_sessions,id'],
            'student_id' => ['required', 'uuid', 'exists:students,id'],
            'behavior_score' => ['required', 'integer', 'between:1,5'],
            'prayer_score' => ['required', 'integer', 'between:1,5'],
            'homework_followup_score' => ['required', 'integer', 'between:1,5'],
            'notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
