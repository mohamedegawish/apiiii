<?php

namespace App\Features\Parent\Requests;

use App\Enums\Role;
use App\Support\Http\Requests\BaseRequest;

class UpdateParentEvaluationRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasRole(Role::Parent) === true
            && $this->user()?->guardian !== null;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'guardian_id' => ['prohibited'],
            'circle_session_id' => ['prohibited'],
            'student_id' => ['prohibited'],
            'behavior_score' => ['sometimes', 'required', 'integer', 'between:1,5'],
            'prayer_score' => ['sometimes', 'required', 'integer', 'between:1,5'],
            'homework_followup_score' => ['sometimes', 'required', 'integer', 'between:1,5'],
            'notes' => ['sometimes', 'nullable', 'string', 'max:2000'],
        ];
    }
}
