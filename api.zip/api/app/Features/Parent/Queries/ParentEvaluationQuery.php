<?php

namespace App\Features\Parent\Queries;

use App\Enums\Role;
use App\Models\Attendance;
use App\Models\CircleSession;
use App\Models\ParentEvaluation;
use App\Models\Student;
use App\Models\StudentLearningRecord;
use App\Models\User;
use App\Support\CenterClock;
use App\Support\Queries\BaseQuery;
use App\Support\Queries\DateColumn;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Illuminate\Support\Collection;
use Spatie\QueryBuilder\AllowedFilter;

class ParentEvaluationQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(ParentEvaluation::class);
    }

    /**
     * @param  EloquentBuilder<ParentEvaluation>  $builder
     */
    protected function applyTenantScope(EloquentBuilder $builder): void
    {
        $this->scopeEvaluations($builder, $this->currentUser());
    }

    /**
     * @return Collection<int, Student>
     */
    public function children(User $user): Collection
    {
        if (! $user->hasRole(Role::Parent) || $user->guardian === null) {
            return collect();
        }

        // Eager-loaded so myChildren() can answer with the child's real
        // circle, teacher and progress figures. Without them the app had
        // nothing to show and filled the guardian's cards with zeros.
        return $user->guardian->children()
            ->with([
                'statistics',
                'enrollments' => fn ($query) => $query
                    ->where('status', 'active')
                    ->whereNull('left_at')
                    ->with('circle.teacher.user'),
            ])
            ->orderBy('students.name')
            ->get();
    }

    /**
     * @return LengthAwarePaginator<int, CircleSession>
     */
    public function childSessions(User $user, Student $student): LengthAwarePaginator
    {
        $query = CircleSession::query()
            ->with(['teacher.user:id,name', 'circle'])
            // session_date is a wall-clock date at the center.
            ->where('session_date', '<', DateColumn::dayAfter(CenterClock::today()))
            ->whereExists(function ($query) use ($student): void {
                $query->selectRaw('1')
                    ->from('enrollments')
                    ->whereColumn('enrollments.circle_id', 'circle_sessions.circle_id')
                    ->where('enrollments.student_id', $student->id)
                    ->whereColumn('enrollments.joined_at', '<=', 'circle_sessions.session_date')
                    ->where(function ($query): void {
                        $query->whereNull('enrollments.left_at')
                            ->orWhereColumn('enrollments.left_at', '>=', 'circle_sessions.session_date');
                    });
            });

        return $query->latest('session_date')->latest('circle_sessions.id')->paginate($this->requestedPerPage());
    }

    /**
     * @return LengthAwarePaginator<int, StudentLearningRecord>
     */
    public function childLearningRecords(Student $student): LengthAwarePaginator
    {
        return StudentLearningRecord::query()
            ->where('student_id', $student->id)
            // Matn relations included so a guardian sees the matn type and
            // section names rather than an empty label.
            ->with(['circleSession.circle', 'teacher.user', 'matnType', 'fromMatnSection', 'toMatnSection'])
            ->latest('created_at')
            ->latest('id')
            ->paginate($this->requestedPerPage());
    }

    /**
     * @return LengthAwarePaginator<int, Attendance>
     */
    public function childAttendance(Student $student): LengthAwarePaginator
    {
        return Attendance::query()
            ->where('student_id', $student->id)
            ->with(['circleSession.circle', 'teacher.user'])
            ->latest('attendance_date')
            ->latest('id')
            ->paginate($this->requestedPerPage());
    }

    /**
     * Same per_page cap as every other list endpoint (BaseQuery::paginate) —
     * these three methods bypass BaseQuery's Spatie-backed paginate(), so the
     * cap has to be reapplied here explicitly.
     */
    private function requestedPerPage(int $default = 25): int
    {
        return max(1, min((int) request()->integer('per_page', $default), 100));
    }

    /**
     * @return array<string, int|float|null>
     */
    public function dashboard(User $user): array
    {
        $query = ParentEvaluation::query();
        $this->scopeEvaluations($query, $user);

        return [
            'children_count' => $user->hasRole(Role::Parent) && $user->guardian !== null
                ? $user->guardian->children()->count()
                : $query->clone()->distinct()->count('student_id'),
            'evaluations_count' => $query->clone()->count(),
            'behavior_score_average' => $this->roundedAverage($query->clone()->avg('behavior_score')),
            'prayer_score_average' => $this->roundedAverage($query->clone()->avg('prayer_score')),
            'homework_followup_score_average' => $this->roundedAverage($query->clone()->avg('homework_followup_score')),
        ];
    }

    /** @return list<AllowedFilter> */
    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::exact('student_id'),
            AllowedFilter::exact('circle_session_id'),
            AllowedFilter::exact('guardian_id'),
        ];
    }

    /** @return list<string> */
    protected function allowedSorts(): array
    {
        return ['created_at', 'updated_at', 'behavior_score', 'prayer_score', 'homework_followup_score'];
    }

    /** @return list<string> */
    protected function allowedIncludes(): array
    {
        return ['student', 'guardian', 'circleSession', 'circleSession.circle'];
    }

    /**
     * @param  EloquentBuilder<ParentEvaluation>  $builder
     */
    private function scopeEvaluations(EloquentBuilder $builder, ?User $user): void
    {
        if ($user?->isSuperAdmin()) {
            return;
        }

        if ($user?->hasRole(Role::Parent) && $user->guardian !== null) {
            $builder->where('guardian_id', $user->guardian->id)
                ->whereHas('student.guardians', fn (EloquentBuilder $query) => $query->where('guardians.id', $user->guardian->id));

            return;
        }

        $builder->whereRaw('1 = 0');
    }

    private function roundedAverage(mixed $average): ?float
    {
        return $average === null ? null : round((float) $average, 2);
    }
}
