<?php

namespace App\Features\Parent\Actions;

use App\Models\Guardian;
use App\Models\ParentEvaluation;
use App\Support\Actions\BaseAction;

class CreateParentEvaluationAction extends BaseAction
{
    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Guardian $guardian, array $data): ParentEvaluation
    {
        return ParentEvaluation::create([
            ...$data,
            'guardian_id' => $guardian->id,
        ]);
    }

    public function execute(mixed ...$arguments): mixed
    {
        $guardian = $arguments[0] ?? null;
        $data = $arguments[1] ?? null;

        if (! $guardian instanceof Guardian || ! is_array($data)) {
            throw new \InvalidArgumentException('CreateParentEvaluationAction expects a Guardian and validated data.');
        }

        return $this->create($guardian, $data);
    }
}
