<?php

namespace App\Features\Parent\Actions;

use App\Models\ParentEvaluation;
use App\Support\Actions\BaseAction;

class UpdateParentEvaluationAction extends BaseAction
{
    /**
     * @param  array<string, mixed>  $data
     */
    public function update(ParentEvaluation $evaluation, array $data): ParentEvaluation
    {
        $evaluation->update($data);

        return $evaluation->refresh();
    }

    public function execute(mixed ...$arguments): mixed
    {
        $evaluation = $arguments[0] ?? null;
        $data = $arguments[1] ?? null;

        if (! $evaluation instanceof ParentEvaluation || ! is_array($data)) {
            throw new \InvalidArgumentException('UpdateParentEvaluationAction expects a ParentEvaluation and validated data.');
        }

        return $this->update($evaluation, $data);
    }
}
