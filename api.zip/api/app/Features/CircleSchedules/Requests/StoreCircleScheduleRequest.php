<?php

namespace App\Features\CircleSchedules\Requests;

use App\Enums\WeekDay;
use App\Models\CircleSchedule;
use App\Support\Http\Requests\BaseRequest;
use App\Support\Rules\OwnedCircle;
use Illuminate\Validation\Rule;

class StoreCircleScheduleRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', CircleSchedule::class) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'circle_id' => ['required', 'uuid', 'exists:circles,id', new OwnedCircle],
            'day_of_week' => ['required', 'integer', Rule::in(WeekDay::values())],
            'start_time' => ['required', 'date_format:H:i'],
            'end_time' => ['required', 'date_format:H:i', 'after:start_time'],
            'room' => ['nullable', 'string', 'max:100'],
            'is_active' => ['nullable', 'boolean'],
        ];
    }
}
