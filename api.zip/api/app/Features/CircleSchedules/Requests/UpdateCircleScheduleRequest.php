<?php

namespace App\Features\CircleSchedules\Requests;

use App\Enums\WeekDay;
use App\Models\CircleSchedule;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class UpdateCircleScheduleRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $schedule = CircleSchedule::find($this->route('circleSchedule'));

        return $this->user()?->can('update', $schedule) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'circle_id' => ['sometimes', 'uuid', 'exists:circles,id'],
            'day_of_week' => ['sometimes', 'integer', Rule::in(WeekDay::values())],
            'start_time' => ['sometimes', 'date_format:H:i'],
            'end_time' => ['sometimes', 'date_format:H:i', 'after:start_time'],
            'room' => ['nullable', 'string', 'max:100'],
            'is_active' => ['sometimes', 'boolean'],
        ];
    }
}
