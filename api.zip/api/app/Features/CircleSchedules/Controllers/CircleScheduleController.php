<?php

namespace App\Features\CircleSchedules\Controllers;

use App\Features\CircleSchedules\Requests\StoreCircleScheduleRequest;
use App\Features\CircleSchedules\Requests\UpdateCircleScheduleRequest;
use App\Features\CircleSchedules\Resources\CircleScheduleResource;
use App\Features\CircleSchedules\Services\CircleScheduleService;
use App\Models\CircleSchedule;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CircleScheduleController extends BaseController
{
    public function __construct(protected CircleScheduleService $circleScheduleService) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', CircleSchedule::class);

        $paginator = $this->circleScheduleService->paginate();

        return $this->paginate(CircleScheduleResource::collection($paginator), 'Circle schedules retrieved successfully.');
    }

    public function show(string $circleSchedule): JsonResponse
    {
        $model = $this->circleScheduleService->findOrFail($circleSchedule);

        $this->authorize('view', $model);

        return $this->success(
            data: CircleScheduleResource::make($model),
            message: 'Circle schedule retrieved successfully.',
        );
    }

    public function store(StoreCircleScheduleRequest $request): JsonResponse
    {
        $schedule = $this->circleScheduleService->create($request);

        return $this->created(
            data: CircleScheduleResource::make($schedule),
            message: 'Circle schedule created successfully.',
        );
    }

    public function update(UpdateCircleScheduleRequest $request, string $circleSchedule): JsonResponse
    {
        $model = $this->circleScheduleService->findOrFail($circleSchedule);
        $updated = $this->circleScheduleService->update($model, $request);

        return $this->success(
            data: CircleScheduleResource::make($updated),
            message: 'Circle schedule updated successfully.',
        );
    }

    public function destroy(string $circleSchedule): JsonResponse
    {
        $model = $this->circleScheduleService->findOrFail($circleSchedule);

        $this->authorize('delete', $model);

        $this->circleScheduleService->delete($model);

        return $this->success(
            data: null,
            message: 'Circle schedule deleted successfully.',
        );
    }
}
