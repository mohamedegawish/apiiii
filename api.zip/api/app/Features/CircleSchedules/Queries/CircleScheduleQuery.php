<?php

namespace App\Features\CircleSchedules\Queries;

use App\Models\CircleSchedule;
use App\Support\Queries\BaseQuery;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class CircleScheduleQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(CircleSchedule::class);
    }

    /**
     * Scope schedules to circles the current user may access.
     *
     * @param  EloquentBuilder<CircleSchedule>  $builder
     */
    protected function applyTenantScope(EloquentBuilder $builder): void
    {
        if ($this->shouldBypassScope()) {
            return;
        }

        $circleIds = $this->accessibleCircleIds();

        if ($circleIds === []) {
            $builder->whereRaw('1 = 0');

            return;
        }

        if ($circleIds !== null) {
            $builder->whereIn('circle_id', $circleIds);
        }
    }

    /**
     * @return list<AllowedFilter>
     */
    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::exact('circle_id'),
            AllowedFilter::exact('day_of_week'),
            AllowedFilter::exact('is_active'),
            AllowedFilter::scope('search'),
        ];
    }

    /**
     * @return list<string>
     */
    protected function allowedSorts(): array
    {
        return [
            'day_of_week',
            'start_time',
            'created_at',
            'updated_at',
        ];
    }

    /**
     * @return list<string>
     */
    protected function allowedIncludes(): array
    {
        return ['circle'];
    }
}
