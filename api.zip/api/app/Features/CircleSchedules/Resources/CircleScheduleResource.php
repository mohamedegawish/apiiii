<?php

namespace App\Features\CircleSchedules\Resources;

use App\Models\CircleSchedule;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * @mixin CircleSchedule
 */
class CircleScheduleResource extends BaseResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'circle_id' => $this->circle_id,
            'day_of_week' => [
                'value' => $this->day_of_week?->value,
                'label' => $this->day_of_week?->name,
            ],
            'start_time' => $this->start_time,
            'end_time' => $this->end_time,
            'room' => $this->room,
            'is_active' => $this->is_active,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
