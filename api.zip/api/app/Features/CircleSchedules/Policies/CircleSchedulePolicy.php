<?php

namespace App\Features\CircleSchedules\Policies;

use App\Enums\Role;
use App\Models\CircleSchedule;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class CircleSchedulePolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $user instanceof User;
    }

    public function view(?User $user, CircleSchedule $schedule): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        return $this->hasRole($user, Role::Teacher)
            && $schedule->circle?->teacher?->user_id === $user?->id;
    }

    public function create(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }

    public function update(?User $user, CircleSchedule $schedule): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        return false;
    }

    public function delete(?User $user, CircleSchedule $schedule): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        return $this->hasRole($user, Role::CenterOwner);
    }

    public function restore(?User $user, CircleSchedule $schedule): bool
    {
        return $this->isSuperAdmin($user);
    }

    public function forceDelete(?User $user, CircleSchedule $schedule): bool
    {
        return $this->isSuperAdmin($user);
    }
}
