<?php

namespace App\Features\CircleSchedules\Actions;

use App\Features\CircleSchedules\Requests\StoreCircleScheduleRequest;
use App\Models\CircleSchedule;
use App\Support\Actions\BaseAction;

class CreateCircleScheduleAction extends BaseAction
{
    /**
     * @return CircleSchedule
     */
    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreCircleScheduleRequest) {
            throw new \InvalidArgumentException('CreateCircleScheduleAction expects a StoreCircleScheduleRequest.');
        }

        $data = $request->validatedData();
        $active = $data['is_active'] ?? true;
        unset($data['is_active']);

        $schedule = CircleSchedule::create($data);
        $schedule->forceFill(['is_active' => $active])->save();

        return $schedule;
    }
}
