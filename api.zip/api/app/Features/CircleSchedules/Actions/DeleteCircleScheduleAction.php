<?php

namespace App\Features\CircleSchedules\Actions;

use App\Models\CircleSchedule;
use App\Support\Actions\BaseAction;

class DeleteCircleScheduleAction extends BaseAction
{
    /**
     * @return bool
     */
    public function execute(mixed ...$arguments): mixed
    {
        $schedule = $arguments[0] ?? null;

        if (! $schedule instanceof CircleSchedule) {
            throw new \InvalidArgumentException('DeleteCircleScheduleAction expects a CircleSchedule.');
        }

        return $schedule->delete();
    }
}
