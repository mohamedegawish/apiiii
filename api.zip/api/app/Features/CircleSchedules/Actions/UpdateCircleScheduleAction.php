<?php

namespace App\Features\CircleSchedules\Actions;

use App\Features\CircleSchedules\Requests\UpdateCircleScheduleRequest;
use App\Models\CircleSchedule;
use App\Support\Actions\BaseAction;

class UpdateCircleScheduleAction extends BaseAction
{
    /**
     * @return CircleSchedule
     */
    public function execute(mixed ...$arguments): mixed
    {
        $schedule = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $schedule instanceof CircleSchedule) {
            throw new \InvalidArgumentException('UpdateCircleScheduleAction expects a CircleSchedule as the first argument.');
        }

        if (! $request instanceof UpdateCircleScheduleRequest) {
            throw new \InvalidArgumentException('UpdateCircleScheduleAction expects an UpdateCircleScheduleRequest as the second argument.');
        }

        $schedule->update($request->validatedData());

        return $schedule->fresh();
    }
}
