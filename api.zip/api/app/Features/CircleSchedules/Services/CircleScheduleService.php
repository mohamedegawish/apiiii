<?php

namespace App\Features\CircleSchedules\Services;

use App\Features\CircleSchedules\Actions\CreateCircleScheduleAction;
use App\Features\CircleSchedules\Actions\DeleteCircleScheduleAction;
use App\Features\CircleSchedules\Actions\UpdateCircleScheduleAction;
use App\Features\CircleSchedules\Queries\CircleScheduleQuery;
use App\Features\CircleSchedules\Requests\StoreCircleScheduleRequest;
use App\Features\CircleSchedules\Requests\UpdateCircleScheduleRequest;
use App\Models\CircleSchedule;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class CircleScheduleService extends BaseService
{
    public function __construct(
        protected CreateCircleScheduleAction $createCircleScheduleAction,
        protected UpdateCircleScheduleAction $updateCircleScheduleAction,
        protected DeleteCircleScheduleAction $deleteCircleScheduleAction,
        protected CircleScheduleQuery $circleScheduleQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->circleScheduleQuery->paginate();
    }

    public function findOrFail(string $id): CircleSchedule
    {
        $schedule = CircleSchedule::with('circle')->find($id);

        if ($schedule === null) {
            throw new NotFoundException('Circle schedule not found.');
        }

        return $schedule;
    }

    public function create(StoreCircleScheduleRequest $request): CircleSchedule
    {
        return $this->transaction(fn (): CircleSchedule => $this->createCircleScheduleAction->execute($request));
    }

    public function update(CircleSchedule $schedule, UpdateCircleScheduleRequest $request): CircleSchedule
    {
        return $this->transaction(fn (): CircleSchedule => $this->updateCircleScheduleAction->execute($schedule, $request));
    }

    public function delete(CircleSchedule $schedule): bool
    {
        return $this->transaction(fn (): bool => $this->deleteCircleScheduleAction->execute($schedule));
    }
}
