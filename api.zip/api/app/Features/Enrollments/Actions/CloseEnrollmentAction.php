<?php

namespace App\Features\Enrollments\Actions;

use App\Enums\EnrollmentStatus;
use App\Features\Enrollments\DTO\EnrollmentData;
use App\Models\Enrollment;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;
use App\Support\Exceptions\NotFoundException;

class CloseEnrollmentAction extends BaseAction
{
    /**
     * @return Enrollment
     */
    public function execute(mixed ...$arguments): mixed
    {
        [$enrollmentId, $data] = $arguments;

        if (! $data instanceof EnrollmentData || $data->status === null) {
            throw new \InvalidArgumentException('CloseEnrollmentAction expects EnrollmentData with a status.');
        }

        if (! in_array($data->status, [EnrollmentStatus::Completed, EnrollmentStatus::Transferred, EnrollmentStatus::Withdrawn], true)) {
            throw new \InvalidArgumentException('The enrollment close status is invalid.');
        }

        $enrollment = Enrollment::query()->lockForUpdate()->find($enrollmentId);

        if ($enrollment === null) {
            throw new NotFoundException('Enrollment not found.');
        }

        if ($enrollment->status !== EnrollmentStatus::Active) {
            throw new ConflictException('Only an active enrollment can be closed.');
        }

        $enrollment->update([
            'status' => $data->status,
            'left_at' => $data->leftAt ?? now()->toDateString(),
            'reason' => $data->reason,
        ]);

        // Remove the student from the legacy circle_student pivot so the
        // circle roster and statistics no longer count them as enrolled.
        $enrollment->circle?->students()->detach($enrollment->student_id);

        return $enrollment->fresh();
    }
}
