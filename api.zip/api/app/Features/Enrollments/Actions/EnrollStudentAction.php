<?php

namespace App\Features\Enrollments\Actions;

use App\Enums\EnrollmentStatus;
use App\Enums\StudentStatus;
use App\Features\Enrollments\DTO\EnrollmentData;
use App\Models\Circle;
use App\Models\Enrollment;
use App\Models\Student;
use App\Support\Actions\BaseAction;
use App\Support\Exceptions\ConflictException;
use App\Support\Exceptions\NotFoundException;
use Illuminate\Support\Str;

class EnrollStudentAction extends BaseAction
{
    /**
     * @return Enrollment
     */
    public function execute(mixed ...$arguments): mixed
    {
        [$circleId, $studentId, $data] = $arguments;

        if (! $data instanceof EnrollmentData) {
            throw new \InvalidArgumentException('EnrollStudentAction expects EnrollmentData as the third argument.');
        }

        $student = Student::query()->lockForUpdate()->find($studentId);

        if ($student === null) {
            throw new NotFoundException('Student not found.');
        }

        $circle = Circle::query()->lockForUpdate()->find($circleId);

        if ($circle === null) {
            throw new NotFoundException('Circle not found.');
        }

        $activeEnrollments = Enrollment::query()
            ->where('student_id', $student->id)
            ->where('status', EnrollmentStatus::Active)
            ->lockForUpdate()
            ->get();

        if ($student->status !== StudentStatus::Active) {
            throw new ConflictException('Only active students can be enrolled.');
        }

        if (! $circle->is_active) {
            throw new ConflictException('The circle is not active.');
        }

        if ($activeEnrollments->isNotEmpty()) {
            throw new ConflictException('The student already has an active enrollment.');
        }

        $activeEnrollmentCount = Enrollment::query()
            ->where('circle_id', $circle->id)
            ->where('status', EnrollmentStatus::Active)
            ->count();

        if ($activeEnrollmentCount >= $circle->capacity) {
            throw new ConflictException('The circle has reached its capacity.');
        }

        $enrollment = Enrollment::query()->create([
            'student_id' => $student->id,
            'circle_id' => $circle->id,
            'joined_at' => $data->joinedAt ?? now()->toDateString(),
            'status' => EnrollmentStatus::Active,
            'reason' => $data->reason,
        ]);

        // Keep the legacy circle_student pivot in sync with the canonical
        // enrollments table so pivot readers (circle roster, statistics)
        // reflect the enrollment immediately.
        $circle->students()->syncWithoutDetaching([
            $student->id => [
                'id' => (string) Str::uuid(),
                'enrolled_at' => $enrollment->joined_at,
                'status' => 'active',
            ],
        ]);

        return $enrollment;
    }
}
