<?php

namespace App\Features\Enrollments\Resources;

use App\Models\Enrollment;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * @mixin Enrollment
 */
class EnrollmentResource extends BaseResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'student_id' => $this->student_id,
            'circle_id' => $this->circle_id,
            'joined_at' => $this->joined_at?->toDateString(),
            'left_at' => $this->left_at?->toDateString(),
            'status' => [
                'value' => $this->status?->value,
                'label' => $this->status?->name,
            ],
            'reason' => $this->reason,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
