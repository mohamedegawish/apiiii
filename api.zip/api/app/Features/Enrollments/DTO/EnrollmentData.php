<?php

namespace App\Features\Enrollments\DTO;

use App\Enums\EnrollmentStatus;

final readonly class EnrollmentData
{
    public function __construct(
        public ?string $joinedAt = null,
        public ?string $leftAt = null,
        public ?EnrollmentStatus $status = null,
        public ?string $reason = null,
    ) {}
}
