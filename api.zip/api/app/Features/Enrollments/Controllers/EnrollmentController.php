<?php

namespace App\Features\Enrollments\Controllers;

use App\Enums\EnrollmentStatus;
use App\Features\Enrollments\Requests\CloseEnrollmentRequest;
use App\Features\Enrollments\Requests\EnrollStudentRequest;
use App\Features\Enrollments\Resources\EnrollmentResource;
use App\Features\Enrollments\Services\EnrollmentService;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;

class EnrollmentController extends BaseController
{
    public function __construct(protected EnrollmentService $enrollmentService) {}

    public function enroll(EnrollStudentRequest $request, string $circle): JsonResponse
    {
        $data = $request->validatedData();
        $enrollment = $this->enrollmentService->enroll(
            $circle,
            $data['student_id'],
            $data['joined_at'] ?? null,
            $data['reason'] ?? null,
        );

        return $this->created(
            data: EnrollmentResource::make($enrollment),
            message: 'Student enrolled successfully.',
        );
    }

    public function close(CloseEnrollmentRequest $request, string $enrollment): JsonResponse
    {
        $data = $request->validatedData();
        $closedEnrollment = $this->enrollmentService->close(
            $enrollment,
            EnrollmentStatus::from($data['status']),
            $data['reason'],
            $data['left_at'] ?? null,
        );

        return $this->success(
            data: EnrollmentResource::make($closedEnrollment),
            message: 'Enrollment closed successfully.',
        );
    }
}
