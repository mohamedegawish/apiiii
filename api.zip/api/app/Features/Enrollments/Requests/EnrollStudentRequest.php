<?php

namespace App\Features\Enrollments\Requests;

use App\Models\Circle;
use App\Support\Http\Requests\BaseRequest;

class EnrollStudentRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $circle = $this->route('circle');
        $circle = $circle instanceof Circle ? $circle : Circle::find($circle);

        return $circle !== null && ($this->user()?->can('update', $circle) ?? false);
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'student_id' => ['required', 'uuid', 'exists:students,id'],
            'joined_at' => ['nullable', 'date'],
            'reason' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
