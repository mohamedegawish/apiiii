<?php

namespace App\Features\Enrollments\Requests;

use App\Enums\EnrollmentStatus;
use App\Models\Enrollment;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class CloseEnrollmentRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $enrollment = $this->route('enrollment');
        $enrollment = $enrollment instanceof Enrollment ? $enrollment : Enrollment::find($enrollment);

        return $enrollment !== null && ($this->user()?->can('update', $enrollment->circle) ?? false);
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'status' => ['required', Rule::enum(EnrollmentStatus::class)->only([
                EnrollmentStatus::Completed,
                EnrollmentStatus::Transferred,
                EnrollmentStatus::Withdrawn,
            ])],
            'reason' => ['required', 'string', 'max:2000'],
            'left_at' => ['nullable', 'date'],
        ];
    }
}
