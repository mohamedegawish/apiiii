<?php

namespace App\Features\Enrollments\Services;

use App\Enums\EnrollmentStatus;
use App\Features\Enrollments\Actions\CloseEnrollmentAction;
use App\Features\Enrollments\Actions\EnrollStudentAction;
use App\Features\Enrollments\DTO\EnrollmentData;
use App\Models\Enrollment;
use App\Support\Services\BaseService;

class EnrollmentService extends BaseService
{
    public function __construct(
        protected EnrollStudentAction $enrollStudentAction,
        protected CloseEnrollmentAction $closeEnrollmentAction,
    ) {}

    public function enroll(string $circleId, string $studentId, ?string $joinedAt = null, ?string $reason = null): Enrollment
    {
        return $this->transaction(fn (): Enrollment => $this->enrollStudentAction->execute(
            $circleId,
            $studentId,
            new EnrollmentData(joinedAt: $joinedAt, reason: $reason),
        ));
    }

    public function close(
        string $enrollmentId,
        EnrollmentStatus $status,
        string $reason,
        ?string $leftAt = null,
    ): Enrollment {
        return $this->transaction(fn (): Enrollment => $this->closeEnrollmentAction->execute(
            $enrollmentId,
            new EnrollmentData(leftAt: $leftAt, status: $status, reason: $reason),
        ));
    }
}
