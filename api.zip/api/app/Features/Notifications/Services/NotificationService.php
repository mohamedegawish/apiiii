<?php

namespace App\Features\Notifications\Services;

use App\Models\User;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Notifications\DatabaseNotification;

class NotificationService extends BaseService
{
    /** @param array<string, mixed> $filters */
    public function paginate(User $user, array $filters): LengthAwarePaginator
    {
        return $user->notifications()
            ->when($filters['updated_since'] ?? null, fn ($query, string $date) => $query->where('updated_at', '>=', $date))
            ->latest('updated_at')
            ->latest('id')
            ->paginate((int) ($filters['per_page'] ?? 25));
    }

    public function markRead(User $user, string $notificationId): DatabaseNotification
    {
        return $this->transaction(function () use ($user, $notificationId): DatabaseNotification {
            /** @var DatabaseNotification|null $notification */
            $notification = $user->notifications()->lockForUpdate()->find($notificationId);

            if ($notification === null) {
                throw new NotFoundException('Notification not found.');
            }

            if ($notification->read_at === null) {
                $notification->markAsRead();
                $notification->refresh();
            }

            return $notification;
        });
    }

    public function markAllRead(User $user): int
    {
        return $this->transaction(fn (): int => $user->unreadNotifications()->update([
            'read_at' => now(),
            'updated_at' => now(),
        ]));
    }
}
