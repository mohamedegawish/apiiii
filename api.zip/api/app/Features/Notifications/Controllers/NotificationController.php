<?php

namespace App\Features\Notifications\Controllers;

use App\Features\Notifications\Requests\NotificationIndexRequest;
use App\Features\Notifications\Resources\NotificationResource;
use App\Features\Notifications\Services\NotificationService;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class NotificationController extends BaseController
{
    public function __construct(protected NotificationService $notificationService) {}

    public function index(NotificationIndexRequest $request): JsonResponse
    {
        $notifications = $this->notificationService->paginate($request->user(), $request->validatedData());

        return $this->paginate(NotificationResource::collection($notifications), 'Notifications retrieved successfully.');
    }

    public function markRead(Request $request, string $notification): JsonResponse
    {
        $model = $this->notificationService->markRead($request->user(), $notification);

        return $this->success(NotificationResource::make($model), 'Notification marked as read.');
    }

    public function markAllRead(Request $request): JsonResponse
    {
        $count = $this->notificationService->markAllRead($request->user());

        return $this->success(['updated' => $count], 'Notifications marked as read.');
    }
}
