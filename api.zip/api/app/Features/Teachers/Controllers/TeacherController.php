<?php

namespace App\Features\Teachers\Controllers;

use App\Features\Teachers\Requests\BulkDeleteTeacherRequest;
use App\Features\Teachers\Requests\StoreTeacherRequest;
use App\Features\Teachers\Requests\UpdateTeacherRequest;
use App\Features\Teachers\Requests\UpdateTeacherSalaryRequest;
use App\Features\Teachers\Resources\TeacherResource;
use App\Features\Teachers\Services\TeacherService;
use App\Models\Teacher;
use App\Support\Http\Controllers\BaseController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TeacherController extends BaseController
{
    public function __construct(protected TeacherService $teacherService) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Teacher::class);

        $paginator = $this->teacherService->paginate();

        return $this->paginate(TeacherResource::collection($paginator), 'Teachers retrieved successfully.');
    }

    public function show(string $teacher): JsonResponse
    {
        $model = $this->teacherService->findOrFail($teacher);

        $this->authorize('view', $model);

        return $this->success(
            data: TeacherResource::make($model),
            message: 'Teacher retrieved successfully.',
        );
    }

    public function store(StoreTeacherRequest $request): JsonResponse
    {
        $teacher = $this->teacherService->create($request);

        return $this->created(
            data: TeacherResource::make($teacher),
            message: 'Teacher created successfully.',
        );
    }

    public function update(UpdateTeacherRequest $request, string $teacher): JsonResponse
    {
        $model = $this->teacherService->findOrFail($teacher);
        $updated = $this->teacherService->update($model, $request);

        return $this->success(
            data: TeacherResource::make($updated),
            message: 'Teacher updated successfully.',
        );
    }

    public function destroy(string $teacher): JsonResponse
    {
        $model = $this->teacherService->findOrFail($teacher);

        $this->authorize('delete', $model);

        $this->teacherService->delete($model);

        return $this->success(
            data: null,
            message: 'Teacher deleted successfully.',
        );
    }

    public function updateSalary(UpdateTeacherSalaryRequest $request, string $teacher): JsonResponse
    {
        $model = $this->teacherService->findOrFail($teacher);

        return $this->success(
            TeacherResource::make($this->teacherService->updateSalary($model, $request)),
            'Teacher salary updated successfully.',
        );
    }

    public function bulkDestroy(BulkDeleteTeacherRequest $request): JsonResponse
    {
        $ids = $request->validatedData()['ids'];

        $teachers = Teacher::whereIn('id', $ids)->get();

        foreach ($teachers as $teacher) {
            $this->authorize('delete', $teacher);
        }

        $count = $this->teacherService->bulkDelete($ids);

        return $this->success(
            data: null,
            message: "{$count} teachers deleted successfully.",
        );
    }
}
