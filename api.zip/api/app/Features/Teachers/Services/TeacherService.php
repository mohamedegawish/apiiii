<?php

namespace App\Features\Teachers\Services;

use App\Features\Teachers\Actions\CreateTeacherAction;
use App\Features\Teachers\Actions\DeleteTeacherAction;
use App\Features\Teachers\Actions\UpdateTeacherAction;
use App\Features\Teachers\Queries\TeacherQuery;
use App\Features\Teachers\Requests\StoreTeacherRequest;
use App\Features\Teachers\Requests\UpdateTeacherRequest;
use App\Features\Teachers\Requests\UpdateTeacherSalaryRequest;
use App\Models\Teacher;
use App\Support\Exceptions\NotFoundException;
use App\Support\Services\BaseService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class TeacherService extends BaseService
{
    public function __construct(
        protected CreateTeacherAction $createTeacherAction,
        protected UpdateTeacherAction $updateTeacherAction,
        protected DeleteTeacherAction $deleteTeacherAction,
        protected TeacherQuery $teacherQuery,
    ) {}

    public function paginate(): LengthAwarePaginator
    {
        return $this->teacherQuery->paginate();
    }

    public function findOrFail(string $id): Teacher
    {
        $teacher = Teacher::with(['user'])->find($id);

        if ($teacher === null) {
            throw new NotFoundException('Teacher not found.');
        }

        return $teacher;
    }

    public function create(StoreTeacherRequest $request): Teacher
    {
        return $this->transaction(fn (): Teacher => $this->createTeacherAction->execute($request));
    }

    public function update(Teacher $teacher, UpdateTeacherRequest $request): Teacher
    {
        return $this->transaction(fn (): Teacher => $this->updateTeacherAction->execute($teacher, $request));
    }

    public function delete(Teacher $teacher): bool
    {
        return $this->transaction(fn (): bool => $this->deleteTeacherAction->execute($teacher));
    }

    public function updateSalary(Teacher $teacher, UpdateTeacherSalaryRequest $request): Teacher
    {
        return $this->transaction(function () use ($teacher, $request): Teacher {
            $teacher->update($request->validatedData());

            return $teacher->refresh();
        });
    }

    public function bulkDelete(array $ids): int
    {
        return $this->transaction(function () use ($ids): int {
            $count = 0;

            foreach ($ids as $id) {
                $teacher = Teacher::find($id);

                if ($teacher === null) {
                    continue;
                }

                $this->deleteTeacherAction->execute($teacher);
                $count++;
            }

            return $count;
        });
    }
}
