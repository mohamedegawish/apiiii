<?php

namespace App\Features\Teachers\Actions;

use App\Enums\Role;
use App\Enums\SalaryType;
use App\Features\Teachers\Requests\StoreTeacherRequest;
use App\Features\Users\Actions\CreateUserAction;
use App\Models\Teacher;
use App\Models\User;
use App\Support\Actions\BaseAction;

class CreateTeacherAction extends BaseAction
{
    public function __construct(private readonly CreateUserAction $createUserAction) {}

    /**
     * @return Teacher
     */
    public function execute(mixed ...$arguments): mixed
    {
        $request = $arguments[0] ?? null;

        if (! $request instanceof StoreTeacherRequest) {
            throw new \InvalidArgumentException('CreateTeacherAction expects a StoreTeacherRequest.');
        }

        $data = $request->validatedData();
        $actor = $request->user();

        if (! $actor instanceof User) {
            throw new \InvalidArgumentException('CreateTeacherAction expects an authenticated user.');
        }

        $user = $this->createUserAction->execute($actor, [
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => $data['password'],
            'role' => Role::Teacher->value,
        ]);

        $teacher = Teacher::create([
            'user_id' => $user->id,
            'title' => $data['name'],
            'salary_type' => SalaryType::Fixed->value,
            'salary_amount' => $data['salary_amount'],
            'hourly_rate' => 0,
            'per_session_rate' => 0,
            'per_student_rate' => 0,
        ]);

        return $teacher->load('user');
    }
}
