<?php

namespace App\Features\Teachers\Actions;

use App\Models\Teacher;
use App\Support\Actions\BaseAction;

class DeleteTeacherAction extends BaseAction
{
    /**
     * @return bool
     */
    public function execute(mixed ...$arguments): mixed
    {
        $teacher = $arguments[0] ?? null;

        if (! $teacher instanceof Teacher) {
            throw new \InvalidArgumentException('DeleteTeacherAction expects a Teacher.');
        }

        return $teacher->delete();
    }
}
