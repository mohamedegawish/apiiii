<?php

namespace App\Features\Teachers\Actions;

use App\Features\Teachers\Requests\UpdateTeacherRequest;
use App\Models\Teacher;
use App\Models\User;
use App\Support\Actions\BaseAction;
use Illuminate\Support\Arr;

class UpdateTeacherAction extends BaseAction
{
    /**
     * @return Teacher
     */
    public function execute(mixed ...$arguments): mixed
    {
        $teacher = $arguments[0] ?? null;
        $request = $arguments[1] ?? null;

        if (! $teacher instanceof Teacher) {
            throw new \InvalidArgumentException('UpdateTeacherAction expects a Teacher as the first argument.');
        }

        if (! $request instanceof UpdateTeacherRequest) {
            throw new \InvalidArgumentException('UpdateTeacherAction expects an UpdateTeacherRequest as the second argument.');
        }

        $data = $request->validatedData();
        $userData = Arr::only($data, ['name', 'email']);

        if (! empty($data['password'])) {
            $userData['password'] = $data['password'];
        }

        $user = $teacher->user;

        if (! $user instanceof User) {
            throw new \RuntimeException('Teacher user account not found.');
        }

        $user->update($userData);
        $teacher->update(['title' => $data['name']]);

        return $teacher->fresh()->load('user');
    }
}
