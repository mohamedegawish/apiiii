<?php

namespace App\Features\Teachers\Queries;

use App\Enums\Role;
use App\Models\Teacher;
use App\Support\Queries\BaseQuery;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Spatie\QueryBuilder\AllowedFilter;

class TeacherQuery extends BaseQuery
{
    public function __construct()
    {
        parent::__construct(Teacher::class);
        $this->builder->with('user');
    }

    protected function applyTenantScope(EloquentBuilder $builder): void
    {
        if ($this->shouldBypassScope()) {
            return;
        }

        $user = $this->currentUser();

        if ($user?->hasRole(Role::Teacher) && $user->teacher !== null) {
            $builder->where('id', $user->teacher->id);

            return;
        }

        // Fail closed for every other role (guardian/student) rather than
        // silently falling through unscoped.
        $teacherIds = $this->accessibleTeacherIds();

        if ($teacherIds === []) {
            $builder->whereRaw('1 = 0');

            return;
        }

        if ($teacherIds !== null) {
            $builder->whereIn('id', $teacherIds);
        }
    }

    protected function allowedFilters(): array
    {
        return [
            AllowedFilter::partial('title'),
            AllowedFilter::partial('qualification'),
            AllowedFilter::partial('specialization'),
            AllowedFilter::exact('is_active'),
            AllowedFilter::exact('user_id'),
            AllowedFilter::exact('salary_type'),
            AllowedFilter::scope('search'),
        ];
    }

    protected function allowedSorts(): array
    {
        return [
            'title',
            'years_of_experience',
            'hired_at',
            'created_at',
            'updated_at',
        ];
    }

    protected function allowedIncludes(): array
    {
        return ['user', 'circles'];
    }
}
