<?php

namespace App\Features\Teachers\Requests;

use App\Enums\SalaryType;
use App\Models\Teacher;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class UpdateTeacherSalaryRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $teacher = Teacher::find($this->route('teacher'));

        return $teacher !== null && ($this->user()?->can('updateSalary', $teacher) ?? false);
    }

    public function rules(): array
    {
        return [
            'salary_type' => ['required', Rule::enum(SalaryType::class)],
            'salary_amount' => ['required', 'numeric', 'min:0'],
            'hourly_rate' => ['nullable', 'numeric', 'min:0'],
            'per_session_rate' => ['nullable', 'numeric', 'min:0'],
            'per_student_rate' => ['nullable', 'numeric', 'min:0'],
        ];
    }
}
