<?php

namespace App\Features\Teachers\Requests;

use App\Models\Teacher;
use App\Support\Http\Requests\BaseRequest;
use Illuminate\Validation\Rule;

class UpdateTeacherRequest extends BaseRequest
{
    public function authorize(): bool
    {
        $teacher = Teacher::find($this->route('teacher'));

        return $this->user()?->can('update', $teacher) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $teacher = Teacher::find($this->route('teacher'));

        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => [
                'required',
                'string',
                'email',
                'max:255',
                Rule::unique('users', 'email')->ignore($teacher?->user_id),
            ],
            'password' => ['nullable', 'string', 'min:8', 'max:255', 'confirmed'],
            'user_id' => ['prohibited'],
            'title' => ['prohibited'],
            'qualification' => ['prohibited'],
            'specialization' => ['prohibited'],
            'years_of_experience' => ['prohibited'],
            'salary_type' => ['prohibited'],
            'salary_amount' => ['prohibited'],
            'hourly_rate' => ['prohibited'],
            'per_session_rate' => ['prohibited'],
            'per_student_rate' => ['prohibited'],
            'hired_at' => ['prohibited'],
            'is_active' => ['prohibited'],
        ];
    }
}
