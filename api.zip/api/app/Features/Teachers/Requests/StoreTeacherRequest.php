<?php

namespace App\Features\Teachers\Requests;

use App\Models\Teacher;
use App\Support\Http\Requests\BaseRequest;

class StoreTeacherRequest extends BaseRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('create', Teacher::class) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8', 'max:255', 'confirmed'],
            'salary_amount' => ['required', 'numeric', 'min:0'],
            'user_id' => ['prohibited'],
            'salary_type' => ['prohibited'],
            'hourly_rate' => ['prohibited'],
            'per_session_rate' => ['prohibited'],
            'per_student_rate' => ['prohibited'],
        ];
    }
}
