<?php

namespace App\Features\Teachers\Policies;

use App\Enums\Role;
use App\Models\Teacher;
use App\Models\User;
use App\Support\Policies\BasePolicy;

class TeacherPolicy extends BasePolicy
{
    public function viewAny(?User $user): bool
    {
        return $user instanceof User;
    }

    public function view(?User $user, Teacher $teacher): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        if ($this->hasRole($user, Role::Teacher) && $teacher->user_id === $user->id) {
            return true;
        }

        return false;
    }

    public function create(?User $user): bool
    {
        return $this->isAtLeast($user, Role::CenterOwner);
    }

    public function update(?User $user, Teacher $teacher): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        if ($this->hasRole($user, Role::CenterOwner)) {
            return true;
        }

        return $teacher->user_id === $user->id;
    }

    public function delete(?User $user, Teacher $teacher): bool
    {
        if ($this->isSuperAdmin($user)) {
            return true;
        }

        return $this->hasRole($user, Role::CenterOwner);
    }

    public function updateSalary(?User $user, Teacher $teacher): bool
    {
        return $this->isSuperAdmin($user)
            || $this->hasRole($user, Role::CenterOwner);
    }

    public function restore(?User $user, Teacher $teacher): bool
    {
        return $this->isSuperAdmin($user);
    }

    public function forceDelete(?User $user, Teacher $teacher): bool
    {
        return $this->isSuperAdmin($user);
    }
}
