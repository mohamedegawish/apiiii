<?php

namespace App\Features\Teachers\Resources;

use App\Enums\Role;
use App\Models\Teacher;
use App\Support\Http\Resources\BaseResource;
use Illuminate\Http\Request;

/**
 * @mixin Teacher
 */
class TeacherResource extends BaseResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'name' => $this->user?->name ?? $this->title,
            'email' => $this->user?->email,
            'title' => $this->title,
            'qualification' => $this->qualification,
            'specialization' => $this->specialization,
            'years_of_experience' => $this->years_of_experience,
            'hired_at' => $this->hired_at?->toIso8601String(),
            'is_active' => $this->is_active,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];

        if ($this->shouldShowSalary($request)) {
            $data['salary_type'] = [
                'value' => $this->salary_type?->value,
                'label' => $this->salary_type?->name,
            ];
            $data['salary_amount'] = $this->salary_amount;
            $data['hourly_rate'] = $this->hourly_rate;
            $data['per_session_rate'] = $this->per_session_rate;
            $data['per_student_rate'] = $this->per_student_rate;
        }

        return $data;
    }

    /**
     * Determine whether salary fields should be exposed to the current user.
     */
    protected function shouldShowSalary(Request $request): bool
    {
        $user = $request->user();

        if ($user === null) {
            return false;
        }

        if ($user->isSuperAdmin() || $user->hasRole(Role::CenterOwner)) {
            return true;
        }

        return false;
    }
}
