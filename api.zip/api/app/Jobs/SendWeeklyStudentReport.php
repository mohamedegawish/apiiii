<?php

namespace App\Jobs;

class SendWeeklyStudentReport extends SendStudentReports
{
    protected function reportKind(): string
    {
        return 'weekly_student_report';
    }
}
