<?php

namespace App\Jobs\Concerns;

use Illuminate\Support\Facades\Log;
use Throwable;

trait LogsAutomationJobFailures
{
    public int $tries = 3;

    public int $timeout = 120;

    /** @return list<int> */
    public function backoff(): array
    {
        return [10, 30, 60];
    }

    public function failed(?Throwable $exception): void
    {
        Log::error('Scheduler automation job failed.', [
            'job' => static::class,
            'exception' => $exception,
        ]);
    }
}
