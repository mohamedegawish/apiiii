<?php

namespace App\Jobs;

use App\Jobs\Concerns\LogsAutomationJobFailures;
use App\Models\IdempotencyKey;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

/**
 * Drop idempotency claims past their expiry.
 *
 * `expires_at` was always written (24h) and the column indexed, but nothing
 * ever read or deleted it -- and each row stores a full JSON response body, so
 * the table grew without bound for the life of the deployment.
 */
class CleanupExpiredIdempotencyKeys implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, LogsAutomationJobFailures, Queueable, SerializesModels;

    public function handle(): int
    {
        return IdempotencyKey::where('expires_at', '<=', now())->delete();
    }
}
