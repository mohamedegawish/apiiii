<?php

namespace App\Jobs;

use App\Jobs\Concerns\LogsAutomationJobFailures;
use App\Models\Invoice;
use App\Notifications\StudentAlertNotification;
use App\Support\CenterClock;
use App\Support\Queries\DateColumn;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

class SendPaymentReminders implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, LogsAutomationJobFailures, Queueable, SerializesModels;

    public function handle(): void
    {
        if (! Schema::hasTable('invoices')) {
            Log::info('Payment reminders skipped because the invoices table does not exist.');

            return;
        }

        // Due-date comparisons follow the center's calendar day.
        $today = CenterClock::today();

        // فواتير مستحقة خلال ٣ أيام أو متأخرة السداد بالفعل.
        Invoice::query()
            ->whereIn('status', ['sent', 'partial'])
            ->where('due_date', '<', DateColumn::dayAfter($today->copy()->addDays(3)))
            ->whereHas('student.guardians.user')
            ->with(['student.guardians.user'])
            ->chunkById(100, function ($invoices) use ($today): void {
                foreach ($invoices as $invoice) {
                    if ($invoice->due_date->lt($today) && $invoice->status !== 'overdue') {
                        $invoice->update(['status' => 'overdue']);
                    }

                    $student = $invoice->student;

                    if ($student === null) {
                        continue;
                    }

                    foreach ($student->guardians->unique('user_id') as $guardian) {
                        $user = $guardian->user;
                        $key = "automation:payment-reminder:{$invoice->id}:{$user?->id}:{$today->toDateString()}";

                        if ($user !== null && Cache::add($key, true, now()->addDay())) {
                            $user->notify(new StudentAlertNotification('payment_due_reminder', [
                                'invoice_id' => $invoice->id,
                                'invoice_number' => $invoice->invoice_number,
                                'student_id' => $student->id,
                                'student_name' => $student->name,
                                'balance_due' => $invoice->balanceDue(),
                                'due_date' => $invoice->due_date->toDateString(),
                                'is_overdue' => $invoice->due_date->lt($today),
                            ]));
                        }
                    }
                }
            });
    }
}
