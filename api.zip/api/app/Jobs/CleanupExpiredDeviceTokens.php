<?php

namespace App\Jobs;

use App\Jobs\Concerns\LogsAutomationJobFailures;
use App\Models\DeviceToken;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class CleanupExpiredDeviceTokens implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, LogsAutomationJobFailures, Queueable, SerializesModels;

    public function __construct(public readonly int $days) {}

    public function handle(): int
    {
        $cutoff = now()->subDays($this->days);

        return DeviceToken::query()
            ->where(fn ($query) => $query
                ->where('last_used_at', '<', $cutoff)
                ->orWhere(fn ($query) => $query->whereNull('last_used_at')->where('created_at', '<', $cutoff)))
            ->delete();
    }
}
