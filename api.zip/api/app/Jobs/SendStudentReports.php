<?php

namespace App\Jobs;

use App\Enums\StudentStatus;
use App\Jobs\Concerns\LogsAutomationJobFailures;
use App\Models\Student;
use App\Notifications\StudentAlertNotification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;

abstract class SendStudentReports implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, LogsAutomationJobFailures, Queueable, SerializesModels;

    public function __construct(
        public readonly string $startsAt,
        public readonly string $endsAt,
    ) {}

    abstract protected function reportKind(): string;

    public function handle(): void
    {
        Student::query()
            ->where('status', StudentStatus::Active->value)
            ->whereHas('guardians.user')
            ->with(['guardians.user'])
            ->withCount([
                'attendances as attendance_count' => fn ($query) => $query->whereBetween('attendance_date', [$this->startsAt, $this->endsAt]),
                'learningRecords as learning_record_count' => fn ($query) => $query->whereBetween('created_at', [Carbon::parse($this->startsAt)->startOfDay(), Carbon::parse($this->endsAt)->endOfDay()]),
            ])
            ->withAvg([
                'learningRecords as average_score' => fn ($query) => $query->whereBetween('created_at', [Carbon::parse($this->startsAt)->startOfDay(), Carbon::parse($this->endsAt)->endOfDay()]),
            ], 'score')
            ->chunkById(100, function ($students): void {
                foreach ($students as $student) {
                    foreach ($student->guardians->unique('user_id') as $guardian) {
                        $user = $guardian->user;
                        $kind = $this->reportKind();
                        $key = "automation:{$kind}:{$this->endsAt}:{$student->id}:{$user?->id}";

                        if ($user !== null && Cache::add($key, true, now()->addMonths(2))) {
                            $user->notify(new StudentAlertNotification($kind, [
                                'student_id' => $student->id,
                                'student_name' => $student->name,
                                'starts_at' => $this->startsAt,
                                'ends_at' => $this->endsAt,
                                'attendance_count' => $student->attendance_count,
                                'learning_record_count' => $student->learning_record_count,
                                'average_score' => $student->average_score === null ? null : round((float) $student->average_score, 2),
                            ]));
                        }
                    }
                }
            });
    }
}
