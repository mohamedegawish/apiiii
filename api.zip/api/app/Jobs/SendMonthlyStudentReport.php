<?php

namespace App\Jobs;

class SendMonthlyStudentReport extends SendStudentReports
{
    protected function reportKind(): string
    {
        return 'monthly_student_report';
    }
}
