<?php

namespace App\Jobs;

use App\Enums\AttendanceStatus;
use App\Enums\StudentStatus;
use App\Jobs\Concerns\LogsAutomationJobFailures;
use App\Models\Student;
use App\Notifications\StudentAlertNotification;
use App\Support\Queries\DateColumn;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;

class SendDailyAttendanceSummary implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, LogsAutomationJobFailures, Queueable, SerializesModels;

    public function __construct(public readonly string $date) {}

    public function handle(): void
    {
        Student::query()
            ->where('status', StudentStatus::Active->value)
            ->whereHas('attendances', fn ($query) => $query->where('attendance_date', '>=', DateColumn::day($this->date))->where('attendance_date', '<', DateColumn::dayAfter($this->date)))
            ->with(['guardians.user'])
            ->withCount([
                'attendances as present_count' => fn ($query) => $query->where('attendance_date', '>=', DateColumn::day($this->date))->where('attendance_date', '<', DateColumn::dayAfter($this->date))->where('status', AttendanceStatus::Present->value),
                'attendances as absent_count' => fn ($query) => $query->where('attendance_date', '>=', DateColumn::day($this->date))->where('attendance_date', '<', DateColumn::dayAfter($this->date))->where('status', AttendanceStatus::Absent->value),
                'attendances as excused_count' => fn ($query) => $query->where('attendance_date', '>=', DateColumn::day($this->date))->where('attendance_date', '<', DateColumn::dayAfter($this->date))->where('status', AttendanceStatus::Excused->value),
                'attendances as late_count' => fn ($query) => $query->where('attendance_date', '>=', DateColumn::day($this->date))->where('attendance_date', '<', DateColumn::dayAfter($this->date))->where('status', AttendanceStatus::Late->value),
            ])
            ->chunkById(100, function ($students): void {
                foreach ($students as $student) {
                    foreach ($student->guardians->unique('user_id') as $guardian) {
                        $user = $guardian->user;
                        $key = "automation:attendance:{$this->date}:{$student->id}:{$user?->id}";

                        if ($user !== null && Cache::add($key, true, now()->addDays(7))) {
                            $user->notify(new StudentAlertNotification('daily_attendance_summary', [
                                'student_id' => $student->id,
                                'student_name' => $student->name,
                                'date' => $this->date,
                                'present' => $student->present_count,
                                'absent' => $student->absent_count,
                                'excused' => $student->excused_count,
                                'late' => $student->late_count,
                            ]));
                        }
                    }
                }
            });
    }
}
