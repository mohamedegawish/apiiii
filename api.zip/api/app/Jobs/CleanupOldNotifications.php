<?php

namespace App\Jobs;

use App\Jobs\Concerns\LogsAutomationJobFailures;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class CleanupOldNotifications implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, LogsAutomationJobFailures, Queueable, SerializesModels;

    public function __construct(public readonly int $days) {}

    public function handle(): int
    {
        return DB::table('notifications')->where('created_at', '<', now()->subDays($this->days))->delete();
    }
}
