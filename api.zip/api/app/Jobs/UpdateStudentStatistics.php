<?php

namespace App\Jobs;

use App\Support\Services\StatisticsCalculatorService;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\Middleware\WithoutOverlapping;
use Illuminate\Queue\SerializesModels;

class UpdateStudentStatistics implements ShouldBeUnique, ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;

    public int $timeout = 120;

    public function __construct(
        public string $studentId,
    ) {
        $this->onQueue('statistics');
    }

    public function handle(StatisticsCalculatorService $calculator): void
    {
        $calculator->recalculateStudent($this->studentId);
    }

    public function backoff(): array
    {
        return [10, 30, 60];
    }

    public function middleware(): array
    {
        return [new WithoutOverlapping($this->studentId)];
    }

    /**
     * One recalculation in flight per student: a burst of attendance writes
     * (a whole roster being marked) otherwise enqueues one recalculation per
     * record, and a single recalculation covers every write that came before
     * it. Dropped duplicates are safe — the calculation is an idempotent
     * full recompute of the student's own numbers.
     */
    public function uniqueId(): string
    {
        return $this->studentId;
    }

    public function uniqueFor(): int
    {
        return 30;
    }
}
