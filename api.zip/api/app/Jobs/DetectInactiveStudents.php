<?php

namespace App\Jobs;

use App\Enums\Role;
use App\Enums\StudentStatus;
use App\Jobs\Concerns\LogsAutomationJobFailures;
use App\Models\Student;
use App\Models\User;
use App\Notifications\StudentAlertNotification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;

class DetectInactiveStudents implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, LogsAutomationJobFailures, Queueable, SerializesModels;

    public function __construct(public readonly int $days) {}

    public function handle(): void
    {
        $cutoff = now()->subDays($this->days);

        Student::query()
            ->where('status', StudentStatus::Active->value)
            ->whereDoesntHave('attendances', fn ($query) => $query->where('attendance_date', '>=', $cutoff->toDateString()))
            ->whereDoesntHave('learningRecords', fn ($query) => $query->where('created_at', '>=', $cutoff))
            ->with('guardian')
            ->chunkById(100, function ($students) use ($cutoff): void {
                $fallbackAdmins = null;

                foreach ($students as $student) {
                    $recipients = $fallbackAdmins ??= User::query()
                        ->where('role', Role::SuperAdmin->value)
                        ->where('is_active', true)
                        ->get();

                    foreach ($recipients as $recipient) {
                        $key = "automation:inactive:{$this->days}:{$student->id}:{$recipient->id}";

                        if (Cache::add($key, true, Carbon::now()->addDays($this->days))) {
                            $recipient->notify(new StudentAlertNotification('inactive_student_detected', [
                                'student_id' => $student->id,
                                'student_name' => $student->name,
                                'inactive_days' => $this->days,
                                'activity_cutoff' => $cutoff->toDateString(),
                            ]));
                        }
                    }
                }
            });
    }
}
