<?php

namespace App\Jobs;

use App\Enums\CircleSessionStatus;
use App\Jobs\Concerns\LogsAutomationJobFailures;
use App\Models\CircleSession;
use App\Models\Student;
use App\Notifications\StudentAlertNotification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;

class SendUpcomingSessionReminders implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, LogsAutomationJobFailures, Queueable, SerializesModels;

    public function __construct(
        public readonly string $startsAt,
        public readonly string $endsAt,
    ) {}

    public function handle(): void
    {
        $startsAt = Carbon::parse($this->startsAt);
        $endsAt = Carbon::parse($this->endsAt);

        CircleSession::query()
            ->where('status', CircleSessionStatus::Scheduled->value)
            ->whereBetween('session_date', [$startsAt->toDateString(), $endsAt->toDateString()])
            ->chunkById(50, function ($sessions) use ($startsAt, $endsAt): void {
                foreach ($sessions as $session) {
                    $sessionAt = Carbon::parse($session->session_date->toDateString().' '.($session->start_time ?? '00:00:00'));

                    if (! $sessionAt->betweenIncluded($startsAt, $endsAt)) {
                        continue;
                    }

                    Student::query()
                        ->whereHas('enrollments', fn ($query) => $query
                            ->where('circle_id', $session->circle_id)
                            ->where('status', 'active')
                            ->whereNull('left_at'))
                        ->with(['guardians.user'])
                        ->chunkById(100, function ($students) use ($session, $sessionAt): void {
                            foreach ($students as $student) {
                                foreach ($student->guardians->unique('user_id') as $guardian) {
                                    $user = $guardian->user;
                                    $key = "automation:session-reminder:{$session->id}:{$student->id}:{$user?->id}";

                                    if ($user !== null && Cache::add($key, true, $sessionAt->copy()->addDay())) {
                                        $user->notify(new StudentAlertNotification('upcoming_session_reminder', [
                                            'student_id' => $student->id,
                                            'student_name' => $student->name,
                                            'circle_session_id' => $session->id,
                                            'session_at' => $sessionAt->toIso8601String(),
                                        ]));
                                    }
                                }
                            }
                        });
                }
            });
    }
}
