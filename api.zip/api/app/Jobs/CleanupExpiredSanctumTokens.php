<?php

namespace App\Jobs;

use App\Jobs\Concerns\LogsAutomationJobFailures;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Laravel\Sanctum\PersonalAccessToken;

class CleanupExpiredSanctumTokens implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, LogsAutomationJobFailures, Queueable, SerializesModels;

    public function handle(): int
    {
        return PersonalAccessToken::query()
            ->whereNotNull('expires_at')
            ->where('expires_at', '<=', now())
            ->delete();
    }
}
