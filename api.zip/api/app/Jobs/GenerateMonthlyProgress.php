<?php

namespace App\Jobs;

use App\Features\Reports\Actions\GenerateMonthlyProgressAction;
use App\Jobs\Concerns\LogsAutomationJobFailures;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

/**
 * Builds the monthly progress snapshot that `reports/monthly-progress` reads.
 *
 * Without this the report queried a table nothing ever wrote to, so it could
 * only ever return an empty page.
 */
class GenerateMonthlyProgress implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, LogsAutomationJobFailures, Queueable, SerializesModels;

    public function __construct(
        public readonly int $year,
        public readonly int $month,
        public readonly ?string $circleId = null,
    ) {}

    public function handle(GenerateMonthlyProgressAction $action): int
    {
        return $action->execute($this->year, $this->month, $this->circleId);
    }
}
