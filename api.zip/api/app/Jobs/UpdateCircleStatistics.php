<?php

namespace App\Jobs;

use App\Support\Services\StatisticsCalculatorService;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\Middleware\WithoutOverlapping;
use Illuminate\Queue\SerializesModels;

class UpdateCircleStatistics implements ShouldBeUnique, ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;

    public int $timeout = 120;

    public function __construct(
        public string $circleId,
    ) {
        $this->onQueue('statistics');
    }

    public function handle(StatisticsCalculatorService $calculator): void
    {
        $calculator->recalculateCircle($this->circleId);
    }

    public function backoff(): array
    {
        return [10, 30, 60];
    }

    public function middleware(): array
    {
        return [new WithoutOverlapping($this->circleId)];
    }

    public function uniqueId(): string
    {
        return $this->circleId;
    }

    public function uniqueFor(): int
    {
        return 30;
    }
}
