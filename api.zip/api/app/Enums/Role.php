<?php

namespace App\Enums;

/**
 * The platform roles, ordered from highest to lowest privilege.
 */
enum Role: string
{
    case SuperAdmin = 'super_admin';
    case CenterOwner = 'center_owner';
    case Teacher = 'teacher';
    case Parent = 'guardian';
    case Student = 'student';

    /**
     * All role values keyed by name, useful for validation rules.
     *
     * @return array<string, string>
     */
    public static function options(): array
    {
        return array_column(self::cases(), 'value', 'name');
    }

    /**
     * The list of role values accepted by validation rules.
     *
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(fn (self $role) => $role->value, self::cases());
    }

    /**
     * Roles with equal or higher privilege than the current role, inclusive.
     *
     * @return list<self>
     */
    public function andAbove(): array
    {
        return array_filter(self::cases(), fn (self $role) => $role->rank() <= $this->rank());
    }

    /**
     * Roles with equal or lower privilege than the current role, inclusive.
     *
     * @return list<self>
     */
    public function andBelow(): array
    {
        return array_filter(self::cases(), fn (self $role) => $role->rank() >= $this->rank());
    }

    /**
     * The privilege rank of the role, where a lower number means higher privilege.
     */
    public function rank(): int
    {
        return match ($this) {
            self::SuperAdmin => 1,
            self::CenterOwner => 2,
            self::Teacher => 3,
            self::Parent => 4,
            self::Student => 5,
        };
    }

    /**
     * The capabilities this role carries, as stable slugs.
     *
     * The API previously answered `permissions: ['*']` for every user
     * regardless of role, so any client trusting that field was handed a full
     * grant. This is the real list. It intentionally mirrors the vocabulary
     * admin_app derives locally in state/permissions.dart, so that client can
     * stop guessing and read it from here -- the server stays authoritative
     * either way, since every endpoint is still gated by middleware and
     * policies. This list drives presentation, never enforcement.
     *
     * @return list<string>
     */
    public function permissions(): array
    {
        $adminLike = in_array($this, [self::SuperAdmin, self::CenterOwner], true);

        return match (true) {
            $adminLike => array_values(array_filter([
                $this === self::SuperAdmin ? 'manage_centers' : null,
                'manage_guardians',
                'manage_teachers',
                'manage_circles',
                'manage_schedules',
                'manage_catalog',
                'create_students',
                'edit_students',
                'delete_students',
                'view_student_pii',
                'record_attendance',
                'record_sessions',
                'record_assessments',
                'manage_homework',
                'delete_field_records',
                'view_finance',
                'view_reports',
                'view_salaries',
                'recalculate_statistics',
                'view_admin_sessions',
                'view_audit_logs',
                'manage_users',
                'access_settings',
            ])),
            $this === self::Teacher => [
                'record_attendance',
                'record_sessions',
                'record_assessments',
                'manage_homework',
                'view_reports',
                'access_settings',
            ],
            $this === self::Parent => [
                'view_children_data',
                'submit_parent_evaluation',
                'access_settings',
            ],
            default => [
                'view_own_data',
                'access_settings',
            ],
        };
    }

    /**
     * Roles that may sign themselves in from the student app, and the only
     * roles reachable through role selection on a shared mobile number.
     *
     * Defined once here because SelectRoleRequest previously carried the
     * literal `in:student,guardian` as the sole guard -- if that string ever
     * drifted from the enum, staff accounts became reachable through an
     * endpoint that never re-checked the role itself.
     *
     *  list<self>
     */
    public static function selfService(): array
    {
        return [self::Student, self::Parent];
    }

    /**  list<string> */
    public static function selfServiceValues(): array
    {
        return array_map(fn (self $role): string => $role->value, self::selfService());
    }

    public function isStaff(): bool
    {
        return in_array($this, [self::SuperAdmin, self::CenterOwner, self::Teacher], true);
    }

    /**
     * Whether the current role outranks the given role.
     */
    public function outranks(self $other): bool
    {
        return $this->rank() < $other->rank();
    }

    /**
     * Whether the current role is the super admin.
     */
    public function isSuperAdmin(): bool
    {
        return $this === self::SuperAdmin;
    }
}
