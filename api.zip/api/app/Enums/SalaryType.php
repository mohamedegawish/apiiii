<?php

namespace App\Enums;

/**
 * The salary calculation method for a teacher.
 */
enum SalaryType: string
{
    case Fixed = 'fixed';
    case PerSession = 'per_session';
    case PerStudent = 'per_student';
    case Hourly = 'hourly';

    /**
     * All salary type values, useful for validation rules.
     *
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(fn (self $type) => $type->value, self::cases());
    }

    /**
     * All salary type values keyed by label for select inputs.
     *
     * @return array<string, string>
     */
    public static function options(): array
    {
        return array_column(self::cases(), 'value', 'name');
    }
}
