<?php

namespace App\Enums;

/**
 * The type of assessment given to a student.
 */
enum AssessmentType: string
{
    case Placement = 'placement';
    case Midterm = 'midterm';
    case Final = 'final';
    case Progress = 'progress';
    case Oral = 'oral';

    /**
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(fn (self $type) => $type->value, self::cases());
    }

    /**
     * @return array<string, string>
     */
    public static function options(): array
    {
        return array_column(self::cases(), 'value', 'name');
    }
}
