<?php

namespace App\Enums;

enum GuardianRelationship: string
{
    case Father = 'أب';
    case Mother = 'أم';
    case Brother = 'أخ';
    case Sister = 'أخت';
    case Grandfather = 'جد';
    case Grandmother = 'جدة';

    /** @return list<string> */
    public static function values(): array
    {
        return array_column(self::cases(), 'value');
    }

    /**
     * All relationship values keyed by label for select inputs.
     *
     * @return array<string, string>
     */
    public static function options(): array
    {
        return array_column(self::cases(), 'value', 'name');
    }

    /**
     * Arabic label for display.
     */
    public function label(): string
    {
        return match ($this) {
            self::Father => 'أب',
            self::Mother => 'أم',
            self::Brother => 'أخ',
            self::Sister => 'أخت',
            self::Grandfather => 'جد',
            self::Grandmother => 'جدة',
        };
    }
}
