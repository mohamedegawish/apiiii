<?php

namespace App\Enums;

/**
 * The attendance status of a student for a given session.
 */
enum AttendanceStatus: string
{
    case Present = 'present';
    case Absent = 'absent';
    case Excused = 'excused';
    case Late = 'late';

    /**
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(fn (self $status) => $status->value, self::cases());
    }

    /**
     * @return array<string, string>
     */
    public static function options(): array
    {
        return array_column(self::cases(), 'value', 'name');
    }

    /**
     * Whether the student was physically present (present or late).
     */
    public function wasPresent(): bool
    {
        return $this === self::Present || $this === self::Late;
    }
}
