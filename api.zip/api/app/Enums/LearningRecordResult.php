<?php

namespace App\Enums;

enum LearningRecordResult: string
{
    case NotMemorized = 'not_memorized';

    /**
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(fn (self $result): string => $result->value, self::cases());
    }
}
