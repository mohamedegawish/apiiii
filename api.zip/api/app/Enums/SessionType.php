<?php

namespace App\Enums;

/**
 * The type of a Quran session, covering both memorization and revision.
 */
enum SessionType: string
{
    case NewMemorization = 'new_memorization';
    case NearRevision = 'near_revision';
    case FarRevision = 'far_revision';
    case WeeklyRevision = 'weekly_revision';
    case MonthlyRevision = 'monthly_revision';
    case Test = 'test';

    /**
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(fn (self $type) => $type->value, self::cases());
    }

    /**
     * @return array<string, string>
     */
    public static function options(): array
    {
        return array_column(self::cases(), 'value', 'name');
    }

    /**
     * Session types that represent memorization (not revision).
     *
     * @return list<self>
     */
    public static function memorizationTypes(): array
    {
        return [self::NewMemorization, self::Test];
    }

    /**
     * Session types that represent revision.
     *
     * @return list<self>
     */
    public static function revisionTypes(): array
    {
        return [self::NearRevision, self::FarRevision, self::WeeklyRevision, self::MonthlyRevision];
    }

    /**
     * Values of memorization-only session types.
     *
     * @return list<string>
     */
    public static function memorizationValues(): array
    {
        return array_map(fn (self $type) => $type->value, self::memorizationTypes());
    }

    /**
     * Values of revision-only session types.
     *
     * @return list<string>
     */
    public static function revisionValues(): array
    {
        return array_map(fn (self $type) => $type->value, self::revisionTypes());
    }

    public function isMemorization(): bool
    {
        return in_array($this, self::memorizationTypes(), true);
    }

    public function isRevision(): bool
    {
        return in_array($this, self::revisionTypes(), true);
    }

    public function label(): string
    {
        return match ($this) {
            self::NewMemorization => 'New Memorization',
            self::NearRevision => 'Near Revision',
            self::FarRevision => 'Far Revision',
            self::WeeklyRevision => 'Weekly Revision',
            self::MonthlyRevision => 'Monthly Revision',
            self::Test => 'Test',
        };
    }
}
