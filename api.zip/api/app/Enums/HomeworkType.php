<?php

namespace App\Enums;

enum HomeworkType: string
{
    case Memorization = 'memorization';
    case Revision = 'revision';

    /**
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(fn (self $type): string => $type->value, self::cases());
    }

    public function label(): string
    {
        return match ($this) {
            self::Memorization => 'تسميع',
            self::Revision => 'مراجعة',
        };
    }
}
