<?php

namespace App\Enums;

enum PushProvider: string
{
    case Fcm = 'fcm';
    case Apns = 'apns';

    /** @return list<string> */
    public static function values(): array
    {
        return array_column(self::cases(), 'value');
    }
}
