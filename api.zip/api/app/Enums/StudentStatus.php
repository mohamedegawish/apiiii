<?php

namespace App\Enums;

/**
 * The lifecycle status of a student within the platform.
 */
enum StudentStatus: string
{
    case Active = 'active';
    case Suspended = 'suspended';
    case Graduated = 'graduated';
    case Withdrawn = 'withdrawn';
    case Transferred = 'transferred';

    /**
     * All status values, useful for validation rules.
     *
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(fn (self $status) => $status->value, self::cases());
    }

    /**
     * All status values keyed by label for select inputs.
     *
     * @return array<string, string>
     */
    public static function options(): array
    {
        return array_column(self::cases(), 'value', 'name');
    }

    /**
     * Whether the student is currently participating.
     */
    public function isActive(): bool
    {
        return $this === self::Active;
    }

    public function allowsAcademicActivity(): bool
    {
        return $this === self::Active;
    }

    /**
     * @return list<self>
     */
    public function allowedTransitions(): array
    {
        return match ($this) {
            self::Active => [self::Suspended, self::Graduated, self::Withdrawn, self::Transferred],
            self::Suspended => [self::Active, self::Withdrawn],
            self::Transferred => [self::Active, self::Withdrawn],
            self::Withdrawn => [self::Active],
            self::Graduated => [],
        };
    }

    public function canTransitionTo(self $target): bool
    {
        return in_array($target, $this->allowedTransitions(), true);
    }
}
