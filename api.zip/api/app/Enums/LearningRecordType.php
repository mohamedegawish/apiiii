<?php

namespace App\Enums;

/**
 * The kind of evaluation a teacher records for a student during a circle
 * session. Distinct from the legacy `SessionType` (used only by the
 * pre-existing memorization_sessions/revision_sessions tables) — this is the
 * canonical type for everything written via the session workspace.
 */
enum LearningRecordType: string
{
    case Memorization = 'memorization';
    case Revision = 'revision';
    case Matn = 'matn';
    case Listening = 'listening';

    /**
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(fn (self $type) => $type->value, self::cases());
    }

    /**
     * @return array<string, string>
     */
    public static function options(): array
    {
        return array_column(self::cases(), 'value', 'name');
    }

    /**
     * Types that carry a Quran surah/ayah range.
     *
     * @return list<self>
     */
    public static function quranBasedTypes(): array
    {
        return [self::Memorization, self::Revision];
    }

    public function isQuranBased(): bool
    {
        return in_array($this, self::quranBasedTypes(), true);
    }

    public function label(): string
    {
        return match ($this) {
            self::Memorization => 'Memorization',
            self::Revision => 'Revision',
            self::Matn => 'Matn',
            self::Listening => 'Listening',
        };
    }
}
