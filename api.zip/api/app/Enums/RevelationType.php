<?php

namespace App\Enums;

/**
 * The revelation type of a surah — Meccan or Medinan.
 */
enum RevelationType: string
{
    case Meccan = 'meccan';
    case Medinan = 'medinan';

    /**
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(fn (self $type) => $type->value, self::cases());
    }

    /**
     * @return array<string, string>
     */
    public static function options(): array
    {
        return array_column(self::cases(), 'value', 'name');
    }
}
