<?php

namespace App\Enums;

/**
 * The days of the week, following ISO-8601 where Monday is day 1.
 */
enum WeekDay: int
{
    case Monday = 1;
    case Tuesday = 2;
    case Wednesday = 3;
    case Thursday = 4;
    case Friday = 5;
    case Saturday = 6;
    case Sunday = 7;

    /**
     * All day values, useful for validation rules.
     *
     * @return list<int>
     */
    public static function values(): array
    {
        return array_map(fn (self $day) => $day->value, self::cases());
    }

    /**
     * All day values keyed by label for select inputs.
     *
     * @return array<int, string>
     */
    public static function options(): array
    {
        return array_column(self::cases(), 'name', 'value');
    }

    /**
     * The short English label for the day.
     */
    public function label(): string
    {
        return match ($this) {
            self::Monday => 'Mon',
            self::Tuesday => 'Tue',
            self::Wednesday => 'Wed',
            self::Thursday => 'Thu',
            self::Friday => 'Fri',
            self::Saturday => 'Sat',
            self::Sunday => 'Sun',
        };
    }
}
