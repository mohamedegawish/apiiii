<?php

namespace App\Models;

use App\Enums\SessionType;
use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Database\Factories\MemorizationSessionFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property string $id
 * @property string $student_id
 * @property string $teacher_id
 * @property string|null $circle_id
 * @property int $surah_number
 * @property int $from_ayah
 * @property int $to_ayah
 * @property SessionType $session_type
 * @property string|null $memorization_grade
 * @property string|null $tajweed_grade
 * @property string|null $fluency_grade
 * @property string|null $discipline_grade
 * @property string|null $notes
 * @property string $session_date
 * @property string|null $created_by
 * @property string|null $updated_by
 */
class MemorizationSession extends Model
{
    /** @use HasFactory<MemorizationSessionFactory> */
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'student_id',
        'teacher_id',
        'circle_id',
        'surah_number',
        'from_ayah',
        'to_ayah',
        'session_type',
        'memorization_grade',
        'tajweed_grade',
        'fluency_grade',
        'discipline_grade',
        'notes',
        'session_date',
    ];

    protected function casts(): array
    {
        return [
            'session_type' => SessionType::class,
            'session_date' => 'date',
            'memorization_grade' => 'decimal:2',
            'tajweed_grade' => 'decimal:2',
            'fluency_grade' => 'decimal:2',
            'discipline_grade' => 'decimal:2',
        ];
    }

    /**
     * @return BelongsTo<Student, covariant $this>
     */
    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }

    /**
     * @return BelongsTo<Teacher, covariant $this>
     */
    public function teacher(): BelongsTo
    {
        return $this->belongsTo(Teacher::class);
    }

    /**
     * @return BelongsTo<Circle, covariant $this>
     */
    public function circle(): BelongsTo
    {
        return $this->belongsTo(Circle::class);
    }

    /**
     * Search scope for filtering memorization sessions by notes.
     *
     * @param  Builder  $query
     * @param  string  $value
     * @return Builder
     */
    public function scopeSearch($query, $value)
    {
        return $query->where('notes', 'like', "%{$value}%");
    }
}
