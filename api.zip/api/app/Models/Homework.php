<?php

namespace App\Models;

use App\Enums\HomeworkStatus;
use App\Enums\HomeworkType;
use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Database\Factories\HomeworkFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property string $id
 * @property string $student_id
 * @property string $teacher_id
 * @property string|null $circle_id
 * @property string|null $circle_session_id
 * @property HomeworkType $homework_type
 * @property string $title
 * @property string|null $description
 * @property int|null $surah_number
 * @property int|null $from_ayah
 * @property int|null $to_ayah
 * @property string $due_date
 * @property string|null $submitted_at
 * @property HomeworkStatus $status
 * @property string|null $grade
 * @property string|null $feedback
 * @property string|null $created_by
 * @property string|null $updated_by
 */
class Homework extends Model
{
    /** @use HasFactory<HomeworkFactory> */
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'student_id',
        'teacher_id',
        'circle_id',
        'circle_session_id',
        'homework_type',
        'title',
        'description',
        'surah_number',
        'from_ayah',
        'to_ayah',
        'due_date',
        'submitted_at',
        'status',
        'grade',
        'feedback',
    ];

    protected function casts(): array
    {
        return [
            'status' => HomeworkStatus::class,
            'homework_type' => HomeworkType::class,
            'due_date' => 'date',
            'submitted_at' => 'datetime',
            'grade' => 'decimal:2',
        ];
    }

    /**
     * @return BelongsTo<Student, covariant $this>
     */
    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }

    /**
     * @return BelongsTo<Teacher, covariant $this>
     */
    public function teacher(): BelongsTo
    {
        return $this->belongsTo(Teacher::class);
    }

    /**
     * @return BelongsTo<Circle, covariant $this>
     */
    public function circle(): BelongsTo
    {
        return $this->belongsTo(Circle::class);
    }

    public function circleSession(): BelongsTo
    {
        return $this->belongsTo(CircleSession::class);
    }

    /**
     * Search scope for filtering homework by title or description.
     *
     * @param  Builder  $query
     * @param  string  $value
     * @return Builder
     */
    public function scopeSearch($query, $value)
    {
        return $query->where(function ($q) use ($value): void {
            $q->where('title', 'like', "%{$value}%")
                ->orWhere('description', 'like', "%{$value}%");
        });
    }
}
