<?php

namespace App\Models;

use App\Support\Traits\HasUuid;
use Database\Factories\StudentStatisticFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property string $id
 * @property string $student_id
 * @property int $memorized_pages
 * @property int $memorized_juz
 * @property int $completed_surahs
 * @property int $total_memorization_sessions
 * @property int $total_revision_sessions
 * @property int $total_assessments
 * @property string $average_memorization_grade
 * @property string $average_tajweed_grade
 * @property string $average_fluency_grade
 * @property string $average_discipline_grade
 * @property string $attendance_rate
 * @property string $revision_ratio
 * @property array|null $monthly_progress
 * @property array|null $surah_progress
 * @property string|null $last_calculated_at
 */
class StudentStatistic extends Model
{
    /** @use HasFactory<StudentStatisticFactory> */
    use HasFactory, HasUuid;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'student_id',
        'memorized_pages',
        'memorized_juz',
        'completed_surahs',
        'total_memorization_sessions',
        'total_revision_sessions',
        'total_assessments',
        'average_memorization_grade',
        'average_tajweed_grade',
        'average_fluency_grade',
        'average_discipline_grade',
        'attendance_rate',
        'revision_ratio',
        'monthly_progress',
        'surah_progress',
        'last_calculated_at',
    ];

    protected function casts(): array
    {
        return [
            'average_memorization_grade' => 'decimal:2',
            'average_tajweed_grade' => 'decimal:2',
            'average_fluency_grade' => 'decimal:2',
            'average_discipline_grade' => 'decimal:2',
            'attendance_rate' => 'decimal:2',
            'revision_ratio' => 'decimal:2',
            'monthly_progress' => 'array',
            'surah_progress' => 'array',
            'last_calculated_at' => 'datetime',
        ];
    }

    /**
     * @return BelongsTo<Student, covariant $this>
     */
    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }
}
