<?php

namespace App\Models;

use App\Support\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A single, immutable ledger entry recording money actually moving —
 * created automatically alongside a {@see Payment} (income) or an approved
 * {@see Expense} (expense). This is the sole source of truth for Cash Flow
 * and Profit & Loss reporting; invoices/expenses being merely *recorded*
 * (draft/pending) do not create a transaction until money actually moves.
 */
class Transaction extends Model
{
    use HasFactory, HasUuid;

    public $incrementing = false;

    protected $keyType = 'string';

    public const TYPE_INCOME = 'income';

    public const TYPE_EXPENSE = 'expense';

    protected $fillable = [
        'type', 'amount', 'occurred_on', 'financial_account_id', 'financial_period_id',
        'revenue_category_id', 'expense_category_id', 'source_type', 'source_id', 'description',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:2',
            'occurred_on' => 'date',
        ];
    }

    public function financialAccount(): BelongsTo
    {
        return $this->belongsTo(FinancialAccount::class);
    }

    public function financialPeriod(): BelongsTo
    {
        return $this->belongsTo(FinancialPeriod::class);
    }

    public function revenueCategory(): BelongsTo
    {
        return $this->belongsTo(RevenueCategory::class);
    }

    public function expenseCategory(): BelongsTo
    {
        return $this->belongsTo(ExpenseCategory::class);
    }
}
