<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $page_number
 * @property int $juz_number
 * @property int $hizb_number
 * @property int $starting_surah
 * @property int $starting_ayah
 */
class QuranPage extends Model
{
    protected $table = 'quran_pages';

    protected $fillable = [
        'page_number',
        'juz_number',
        'hizb_number',
        'starting_surah',
        'starting_ayah',
    ];

    protected function casts(): array
    {
        return [
            'page_number' => 'integer',
            'juz_number' => 'integer',
            'hizb_number' => 'integer',
            'starting_surah' => 'integer',
            'starting_ayah' => 'integer',
        ];
    }
}
