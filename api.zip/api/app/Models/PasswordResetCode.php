<?php

namespace App\Models;

use App\Support\Traits\HasUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

/**
 * A one-time password (OTP) used for the password-reset flow.
 *
 * @property string $id
 * @property string $email
 * @property string $code_hash
 * @property string|null $reset_token_hash
 * @property int $attempts
 * @property Carbon $expires_at
 */
class PasswordResetCode extends Model
{
    use HasUuid;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'email',
        'code_hash',
        'reset_token_hash',
        'attempts',
        'expires_at',
    ];

    protected function casts(): array
    {
        return [
            'expires_at' => 'datetime',
            'attempts' => 'integer',
        ];
    }

    public function isExpired(): bool
    {
        return $this->expires_at->isPast();
    }
}
