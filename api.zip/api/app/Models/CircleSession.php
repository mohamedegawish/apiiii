<?php

namespace App\Models;

use App\Enums\CircleSessionStatus;
use App\Enums\EnrollmentStatus;
use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Closure;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class CircleSession extends Model
{
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'circle_id', 'schedule_id', 'teacher_id', 'session_date', 'start_time',
        'end_time', 'status', 'notes', 'completed_at', 'locked_at', 'version',
    ];

    protected function casts(): array
    {
        return [
            'status' => CircleSessionStatus::class,
            'session_date' => 'date',
            'completed_at' => 'datetime',
            'locked_at' => 'datetime',
            'version' => 'integer',
        ];
    }

    public function circle(): BelongsTo
    {
        return $this->belongsTo(Circle::class);
    }

    public function schedule(): BelongsTo
    {
        return $this->belongsTo(CircleSchedule::class);
    }

    public function teacher(): BelongsTo
    {
        return $this->belongsTo(Teacher::class);
    }

    public function attendances(): HasMany
    {
        return $this->hasMany(Attendance::class);
    }

    public function learningRecords(): HasMany
    {
        return $this->hasMany(StudentLearningRecord::class);
    }

    public function parentEvaluations(): HasMany
    {
        return $this->hasMany(ParentEvaluation::class);
    }

    public function isImmutable(): bool
    {
        return $this->status->isImmutable();
    }

    /**
     * Eager-load spec for the `circle` relation with its active student
     * count — shared by the sessions index, show, and lifecycle-transition
     * responses so the dashboard card's circle name and student count are
     * always present regardless of which endpoint served the session.
     */
    public static function circleWithStudentCount(): Closure
    {
        return fn ($query) => $query->withCount([
            'enrollments' => fn ($query) => $query->where('status', EnrollmentStatus::Active),
        ]);
    }
}
