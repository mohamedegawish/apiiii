<?php

namespace App\Models;

use App\Support\Traits\HasUuid;
use Database\Factories\CircleStatisticFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property string $id
 * @property string $circle_id
 * @property int $total_students
 * @property int $total_memorization_sessions
 * @property int $total_revision_sessions
 * @property int $total_assessments
 * @property string $average_memorization_grade
 * @property string $average_tajweed_grade
 * @property string $average_fluency_grade
 * @property string $average_discipline_grade
 * @property string $average_attendance_rate
 * @property int $memorized_pages_total
 * @property int $completed_surahs_total
 * @property array|null $monthly_progress
 * @property string|null $last_calculated_at
 */
class CircleStatistic extends Model
{
    /** @use HasFactory<CircleStatisticFactory> */
    use HasFactory, HasUuid;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'circle_id',
        'total_students',
        'total_memorization_sessions',
        'total_revision_sessions',
        'total_assessments',
        'average_memorization_grade',
        'average_tajweed_grade',
        'average_fluency_grade',
        'average_discipline_grade',
        'average_attendance_rate',
        'memorized_pages_total',
        'completed_surahs_total',
        'monthly_progress',
        'last_calculated_at',
    ];

    protected function casts(): array
    {
        return [
            'average_memorization_grade' => 'decimal:2',
            'average_tajweed_grade' => 'decimal:2',
            'average_fluency_grade' => 'decimal:2',
            'average_discipline_grade' => 'decimal:2',
            'average_attendance_rate' => 'decimal:2',
            'monthly_progress' => 'array',
            'last_calculated_at' => 'datetime',
        ];
    }

    /**
     * @return BelongsTo<Circle, covariant $this>
     */
    public function circle(): BelongsTo
    {
        return $this->belongsTo(Circle::class);
    }
}
