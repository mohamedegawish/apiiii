<?php

namespace App\Models;

use App\Enums\StudentStatus;
use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Database\Factories\StudentFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property string $id
 * @property string|null $user_id
 * @property string|null $guardian_id
 * @property string $name
 * @property string|null $national_id
 * @property string|null $birth_date
 * @property string|null $gender
 * @property string|null $phone
 * @property string|null $email
 * @property StudentStatus $status
 * @property string|null $enrolled_at
 * @property string|null $graduated_at
 * @property string|null $notes
 * @property string|null $created_by
 * @property string|null $updated_by
 */
class Student extends Model
{
    /** @use HasFactory<StudentFactory> */
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'student_code',
        'user_id',
        'guardian_id',
        'name',
        'national_id',
        'birth_date',
        'gender',
        'phone',
        'email',
        'status',
        'enrolled_at',
        'graduated_at',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'status' => StudentStatus::class,
            'birth_date' => 'date',
            'enrolled_at' => 'date',
            'graduated_at' => 'date',
        ];
    }

    /**
     * @return BelongsTo<User, covariant $this>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * @return BelongsTo<Guardian, covariant $this>
     */
    public function guardian(): BelongsTo
    {
        return $this->belongsTo(Guardian::class);
    }

    /**
     * @return BelongsToMany<Circle, covariant $this>
     */
    public function circles(): BelongsToMany
    {
        return $this->belongsToMany(Circle::class, 'circle_student')
            ->withPivot(['id', 'enrolled_at', 'status'])
            ->withTimestamps();
    }

    public function guardians(): BelongsToMany
    {
        return $this->belongsToMany(Guardian::class, 'guardian_student')
            ->withPivot(['id', 'relationship', 'is_primary'])
            ->withTimestamps();
    }

    public function enrollments(): HasMany
    {
        return $this->hasMany(Enrollment::class);
    }

    public function statusHistory(): HasMany
    {
        return $this->hasMany(StudentStatusHistory::class);
    }

    public function learningRecords(): HasMany
    {
        return $this->hasMany(StudentLearningRecord::class);
    }

    /**
     * @return HasMany<MemorizationSession, covariant $this>
     */
    public function memorizationSessions(): HasMany
    {
        return $this->hasMany(MemorizationSession::class);
    }

    /**
     * @return HasMany<RevisionSession, covariant $this>
     */
    public function revisionSessions(): HasMany
    {
        return $this->hasMany(RevisionSession::class);
    }

    /**
     * @return HasMany<Attendance, covariant $this>
     */
    public function attendances(): HasMany
    {
        return $this->hasMany(Attendance::class);
    }

    /**
     * @return HasMany<Assessment, covariant $this>
     */
    public function assessments(): HasMany
    {
        return $this->hasMany(Assessment::class);
    }

    /**
     * @return HasMany<Homework, covariant $this>
     */
    public function homework(): HasMany
    {
        return $this->hasMany(Homework::class);
    }

    /**
     * @return HasOne<StudentStatistic, covariant $this>
     */
    public function statistics(): HasOne
    {
        return $this->hasOne(StudentStatistic::class);
    }

    /**
     * Search scope for filtering students by name, national_id, phone, or email.
     *
     * @param  Builder  $query
     * @param  string  $value
     * @return Builder
     */
    public function scopeSearch($query, $value)
    {
        return $query->where(function ($q) use ($value): void {
            $q->where('name', 'like', "%{$value}%")
                ->orWhere('national_id', 'like', "%{$value}%")
                ->orWhere('phone', 'like', "%{$value}%")
                ->orWhere('email', 'like', "%{$value}%")
                ->orWhere('student_code', 'like', "%{$value}%");
        });
    }

    /**
     * Find a student by their student_code (used for QR resolution).
     */
    public static function findByCode(string $code): ?self
    {
        return static::where('student_code', $code)->first();
    }

    /**
     * Invoices for this student.
     */
    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    /**
     * Payments made for this student.
     */
    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }
}
