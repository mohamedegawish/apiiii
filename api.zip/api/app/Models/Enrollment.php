<?php

namespace App\Models;

use App\Enums\EnrollmentStatus;
use App\Support\Queries\DateColumn;
use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Carbon\CarbonInterface;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Enrollment extends Model
{
    use Auditable, Blameable, HasFactory, HasUuid;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = ['student_id', 'circle_id', 'joined_at', 'left_at', 'status', 'reason'];

    protected function casts(): array
    {
        return ['joined_at' => 'date', 'left_at' => 'date', 'status' => EnrollmentStatus::class];
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }

    public function circle(): BelongsTo
    {
        return $this->belongsTo(Circle::class);
    }

    /**
     * Enrollments whose membership window covers the given date — the single
     * definition of "enrolled as of this date" shared by attendance eligibility
     * (AttendanceService, ValidatesLearningRecord, AcademicSessionGuard,
     * ParentService) and roster reads (CircleController, CircleSessionService),
     * so a roster can never disagree with the validator that gates writes
     * against it.
     *
     * @param  Builder<Enrollment>  $query
     * @return Builder<Enrollment>
     */
    public function scopeCoveringDate(Builder $query, CarbonInterface|string $date): Builder
    {
        return $query
            ->where('joined_at', '<', DateColumn::dayAfter($date))
            ->where(function (Builder $query) use ($date): void {
                $query->whereNull('left_at')->orWhere('left_at', '>=', DateColumn::day($date));
            });
    }
}
