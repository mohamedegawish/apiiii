<?php

namespace App\Models;

use App\Enums\AssessmentType;
use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Database\Factories\AssessmentFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property string $id
 * @property string $student_id
 * @property string $teacher_id
 * @property string|null $circle_id
 * @property string $title
 * @property string|null $description
 * @property AssessmentType $assessment_type
 * @property int|null $surah_number
 * @property int|null $from_ayah
 * @property int|null $to_ayah
 * @property string|null $grade
 * @property string $max_grade
 * @property string $assessment_date
 * @property string|null $notes
 * @property string|null $created_by
 * @property string|null $updated_by
 */
class Assessment extends Model
{
    /** @use HasFactory<AssessmentFactory> */
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'student_id',
        'teacher_id',
        'circle_id',
        'circle_session_id',
        'title',
        'description',
        'assessment_type',
        'surah_number',
        'from_ayah',
        'to_ayah',
        'grade',
        'max_grade',
        'assessment_date',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'assessment_type' => AssessmentType::class,
            'assessment_date' => 'date',
            'grade' => 'decimal:2',
            'max_grade' => 'decimal:2',
        ];
    }

    /**
     * @return BelongsTo<Student, covariant $this>
     */
    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }

    /**
     * @return BelongsTo<Teacher, covariant $this>
     */
    public function teacher(): BelongsTo
    {
        return $this->belongsTo(Teacher::class);
    }

    /**
     * @return BelongsTo<Circle, covariant $this>
     */
    public function circle(): BelongsTo
    {
        return $this->belongsTo(Circle::class);
    }

    public function circleSession(): BelongsTo
    {
        return $this->belongsTo(CircleSession::class);
    }

    /**
     * Search scope for filtering assessments by title or description.
     *
     * @param  Builder  $query
     * @param  string  $value
     * @return Builder
     */
    public function scopeSearch($query, $value)
    {
        return $query->where(function ($q) use ($value): void {
            $q->where('title', 'like', "%{$value}%")
                ->orWhere('description', 'like', "%{$value}%");
        });
    }
}
