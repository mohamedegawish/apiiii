<?php

namespace App\Models;

use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Database\Factories\CircleFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property string $id
 * @property string|null $teacher_id
 * @property string $name
 * @property string|null $description
 * @property int $capacity
 * @property bool $is_active
 * @property string|null $starts_at
 * @property string|null $created_by
 * @property string|null $updated_by
 */
class Circle extends Model
{
    /** @use HasFactory<CircleFactory> */
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'teacher_id',
        'name',
        'description',
        'capacity',
        'starts_at',
    ];

    protected function casts(): array
    {
        return [
            'capacity' => 'integer',
            'is_active' => 'boolean',
            'starts_at' => 'date',
        ];
    }

    /**
     * @return BelongsTo<Teacher, covariant $this>
     */
    public function teacher(): BelongsTo
    {
        return $this->belongsTo(Teacher::class);
    }

    /**
     * @return BelongsToMany<Student, covariant $this>
     */
    public function students(): BelongsToMany
    {
        return $this->belongsToMany(Student::class, 'circle_student')
            ->withPivot(['id', 'enrolled_at', 'status'])
            ->withTimestamps();
    }

    /**
     * @return HasMany<CircleSchedule, covariant $this>
     */
    public function schedules(): HasMany
    {
        return $this->hasMany(CircleSchedule::class);
    }

    public function sessions(): HasMany
    {
        return $this->hasMany(CircleSession::class);
    }

    public function enrollments(): HasMany
    {
        return $this->hasMany(Enrollment::class);
    }

    /**
     * @return HasMany<MemorizationSession, covariant $this>
     */
    public function memorizationSessions(): HasMany
    {
        return $this->hasMany(MemorizationSession::class);
    }

    /**
     * @return HasMany<RevisionSession, covariant $this>
     */
    public function revisionSessions(): HasMany
    {
        return $this->hasMany(RevisionSession::class);
    }

    /**
     * @return HasMany<Attendance, covariant $this>
     */
    public function attendances(): HasMany
    {
        return $this->hasMany(Attendance::class);
    }

    /**
     * @return HasMany<Assessment, covariant $this>
     */
    public function assessments(): HasMany
    {
        return $this->hasMany(Assessment::class);
    }

    /**
     * @return HasMany<Homework, covariant $this>
     */
    public function homework(): HasMany
    {
        return $this->hasMany(Homework::class);
    }

    /**
     * @return HasOne<CircleStatistic, covariant $this>
     */
    public function statistics(): HasOne
    {
        return $this->hasOne(CircleStatistic::class);
    }

    /**
     * Search scope for filtering circles by name or description.
     *
     * @param  Builder  $query
     * @param  string  $value
     * @return Builder
     */
    public function scopeSearch($query, $value)
    {
        return $query->where(function ($q) use ($value): void {
            $q->where('name', 'like', "%{$value}%")
                ->orWhere('description', 'like', "%{$value}%");
        });
    }
}
