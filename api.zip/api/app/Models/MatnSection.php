<?php

namespace App\Models;

use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * A single named, ordered section within a `MatnType` (e.g. "الحديث الأول"
 * for الأربعين النووية). `order` drives from/to range validation — a valid
 * range requires `to.order >= from.order` within the same matn type.
 *
 * @property string $id
 * @property string $matn_type_id
 * @property string $name
 * @property int $order
 */
class MatnSection extends Model
{
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = ['matn_type_id', 'name', 'order'];

    protected function casts(): array
    {
        return [
            'order' => 'integer',
        ];
    }

    /**
     * @return BelongsTo<MatnType, covariant $this>
     */
    public function matnType(): BelongsTo
    {
        return $this->belongsTo(MatnType::class);
    }
}
