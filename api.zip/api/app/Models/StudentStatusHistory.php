<?php

namespace App\Models;

use App\Enums\StudentStatus;
use App\Support\Traits\HasUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StudentStatusHistory extends Model
{
    use HasUuid;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $table = 'student_status_history';

    protected $fillable = ['student_id', 'old_status', 'new_status', 'reason', 'changed_by', 'changed_at'];

    protected function casts(): array
    {
        return ['old_status' => StudentStatus::class, 'new_status' => StudentStatus::class, 'changed_at' => 'datetime'];
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }

    public function changer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'changed_by');
    }
}
