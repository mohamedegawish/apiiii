<?php

namespace App\Models;

use Database\Factories\AyahFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property int $id
 * @property int $surah_number
 * @property int $ayah_number
 * @property int $global_ayah_number
 * @property int $juz_number
 * @property int $hizb_number
 * @property int $page_number
 * @property bool $has_sajda
 */
class Ayah extends Model
{
    /** @use HasFactory<AyahFactory> */
    use HasFactory;

    protected $fillable = [
        'surah_number',
        'ayah_number',
        'global_ayah_number',
        'juz_number',
        'hizb_number',
        'page_number',
        'has_sajda',
    ];

    protected function casts(): array
    {
        return [
            'surah_number' => 'integer',
            'ayah_number' => 'integer',
            'global_ayah_number' => 'integer',
            'juz_number' => 'integer',
            'hizb_number' => 'integer',
            'page_number' => 'integer',
            'has_sajda' => 'boolean',
        ];
    }

    /**
     * @return BelongsTo<Surah, covariant $this>
     */
    public function surah(): BelongsTo
    {
        return $this->belongsTo(Surah::class, 'surah_number', 'surah_number');
    }
}
