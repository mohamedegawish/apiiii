<?php

namespace App\Models;

use App\Support\Traits\HasUuid;
use Database\Factories\TeacherStatisticFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property string $id
 * @property string $teacher_id
 * @property int $total_memorization_sessions
 * @property int $total_revision_sessions
 * @property int $total_assessments
 * @property int $total_students
 * @property int $total_attendance_records
 * @property string $average_memorization_grade
 * @property string $average_tajweed_grade
 * @property string $average_fluency_grade
 * @property string $average_discipline_grade
 * @property string $student_attendance_rate
 * @property array|null $monthly_sessions
 * @property string|null $last_calculated_at
 */
class TeacherStatistic extends Model
{
    /** @use HasFactory<TeacherStatisticFactory> */
    use HasFactory, HasUuid;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'teacher_id',
        'total_memorization_sessions',
        'total_revision_sessions',
        'total_assessments',
        'total_students',
        'total_attendance_records',
        'average_memorization_grade',
        'average_tajweed_grade',
        'average_fluency_grade',
        'average_discipline_grade',
        'student_attendance_rate',
        'monthly_sessions',
        'last_calculated_at',
    ];

    protected function casts(): array
    {
        return [
            'average_memorization_grade' => 'decimal:2',
            'average_tajweed_grade' => 'decimal:2',
            'average_fluency_grade' => 'decimal:2',
            'average_discipline_grade' => 'decimal:2',
            'student_attendance_rate' => 'decimal:2',
            'monthly_sessions' => 'array',
            'last_calculated_at' => 'datetime',
        ];
    }

    /**
     * @return BelongsTo<Teacher, covariant $this>
     */
    public function teacher(): BelongsTo
    {
        return $this->belongsTo(Teacher::class);
    }
}
