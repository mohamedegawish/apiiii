<?php

namespace App\Models;

use App\Enums\AttendanceStatus;
use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Database\Factories\AttendanceFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property string $id
 * @property string $student_id
 * @property string $teacher_id
 * @property string|null $circle_id
 * @property string|null $circle_session_id
 * @property AttendanceStatus $status
 * @property string $attendance_date
 * @property string|null $arrival_time
 * @property string|null $notes
 * @property string|null $created_by
 * @property string|null $updated_by
 */
class Attendance extends Model
{
    /** @use HasFactory<AttendanceFactory> */
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'student_id',
        'circle_session_id',
        'teacher_id',
        'circle_id',
        'status',
        'attendance_date',
        'arrival_time',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'status' => AttendanceStatus::class,
            'attendance_date' => 'date',
        ];
    }

    /**
     * @return BelongsTo<Student, covariant $this>
     */
    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }

    /**
     * @return BelongsTo<Teacher, covariant $this>
     */
    public function teacher(): BelongsTo
    {
        return $this->belongsTo(Teacher::class);
    }

    /**
     * @return BelongsTo<Circle, covariant $this>
     */
    public function circle(): BelongsTo
    {
        return $this->belongsTo(Circle::class);
    }

    /**
     * @return BelongsTo<CircleSession, covariant $this>
     */
    public function circleSession(): BelongsTo
    {
        return $this->belongsTo(CircleSession::class);
    }

    /**
     * Search scope for filtering attendances by notes.
     *
     * @param  Builder  $query
     * @param  string  $value
     * @return Builder
     */
    public function scopeSearch($query, $value)
    {
        return $query->where('notes', 'like', "%{$value}%");
    }
}
