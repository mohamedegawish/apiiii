<?php

namespace App\Models;

use App\Enums\LearningRecordResult;
use App\Enums\LearningRecordType;
use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class StudentLearningRecord extends Model
{
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'circle_session_id', 'student_id', 'type', 'reference_label', 'surah_number', 'from_ayah',
        'to_surah_number', 'to_ayah', 'from_global_ayah', 'to_global_ayah', 'score', 'notes',
        'matn_type_id', 'from_matn_section_id', 'to_matn_section_id', 'topic', 'is_na',
        'homework_id', 'result_status',
    ];

    protected function casts(): array
    {
        return [
            'type' => LearningRecordType::class,
            'score' => 'decimal:2',
            'to_surah_number' => 'integer',
            'from_global_ayah' => 'integer',
            'to_global_ayah' => 'integer',
            'is_na' => 'boolean',
            'result_status' => LearningRecordResult::class,
        ];
    }

    public function circleSession(): BelongsTo
    {
        return $this->belongsTo(CircleSession::class);
    }

    public function homework(): BelongsTo
    {
        return $this->belongsTo(Homework::class);
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }

    public function teacher(): BelongsTo
    {
        return $this->belongsTo(Teacher::class);
    }

    public function matnType(): BelongsTo
    {
        return $this->belongsTo(MatnType::class);
    }

    public function fromMatnSection(): BelongsTo
    {
        return $this->belongsTo(MatnSection::class, 'from_matn_section_id');
    }

    public function toMatnSection(): BelongsTo
    {
        return $this->belongsTo(MatnSection::class, 'to_matn_section_id');
    }
}
