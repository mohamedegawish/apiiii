<?php

namespace App\Models;

use Database\Factories\SurahFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @property int $id
 * @property int $surah_number
 * @property string $name_arabic
 * @property string $name_english
 * @property string $name_transliteration
 * @property string $revelation_type
 * @property int $ayah_count
 * @property int|null $juz_start
 * @property int|null $page_start
 */
class Surah extends Model
{
    /** @use HasFactory<SurahFactory> */
    use HasFactory;

    protected $fillable = [
        'surah_number',
        'name_arabic',
        'name_english',
        'name_transliteration',
        'revelation_type',
        'ayah_count',
        'juz_start',
        'page_start',
    ];

    protected function casts(): array
    {
        return [
            'surah_number' => 'integer',
            'ayah_count' => 'integer',
            'juz_start' => 'integer',
            'page_start' => 'integer',
        ];
    }

    /**
     * @return HasMany<Ayah, covariant $this>
     */
    public function ayahs(): HasMany
    {
        return $this->hasMany(Ayah::class, 'surah_number', 'surah_number');
    }
}
