<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $hizb_number
 * @property string $name_arabic
 * @property string $name_english
 * @property int $starting_surah
 * @property int $starting_ayah
 * @property int $page_start
 */
class Hizb extends Model
{
    protected $fillable = [
        'hizb_number',
        'name_arabic',
        'name_english',
        'starting_surah',
        'starting_ayah',
        'page_start',
    ];

    protected function casts(): array
    {
        return [
            'hizb_number' => 'integer',
            'starting_surah' => 'integer',
            'starting_ayah' => 'integer',
            'page_start' => 'integer',
        ];
    }
}
