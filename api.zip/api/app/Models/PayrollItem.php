<?php

namespace App\Models;

use App\Support\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * One teacher's computed pay for a single {@see PayrollRun} — the
 * performance metrics are a snapshot taken at generation time, not a live
 * query, so a payroll_run's numbers stay stable even as new sessions are
 * recorded after generation.
 */
class PayrollItem extends Model
{
    use HasFactory, HasUuid;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'payroll_run_id', 'teacher_id', 'salary_type',
        'sessions_count', 'completed_sessions_count', 'students_count',
        'attendance_rate', 'evaluation_completion_rate', 'homework_reviews_count',
        'base_amount', 'bonus_amount', 'deduction_amount', 'penalty_amount', 'overtime_amount',
        'total_amount', 'status', 'notes', 'expense_id',
    ];

    protected function casts(): array
    {
        return [
            'attendance_rate' => 'decimal:2',
            'evaluation_completion_rate' => 'decimal:2',
            'base_amount' => 'decimal:2',
            'bonus_amount' => 'decimal:2',
            'deduction_amount' => 'decimal:2',
            'penalty_amount' => 'decimal:2',
            'overtime_amount' => 'decimal:2',
            'total_amount' => 'decimal:2',
        ];
    }

    public function payrollRun(): BelongsTo
    {
        return $this->belongsTo(PayrollRun::class);
    }

    public function teacher(): BelongsTo
    {
        return $this->belongsTo(Teacher::class);
    }

    public function expense(): BelongsTo
    {
        return $this->belongsTo(Expense::class);
    }
}
