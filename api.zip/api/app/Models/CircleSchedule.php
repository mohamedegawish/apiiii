<?php

namespace App\Models;

use App\Enums\WeekDay;
use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Database\Factories\CircleScheduleFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property string $id
 * @property string $circle_id
 * @property WeekDay $day_of_week
 * @property string $start_time
 * @property string $end_time
 * @property string|null $room
 * @property bool $is_active
 * @property string|null $created_by
 * @property string|null $updated_by
 */
class CircleSchedule extends Model
{
    /** @use HasFactory<CircleScheduleFactory> */
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'circle_id',
        'day_of_week',
        'start_time',
        'end_time',
        'room',
    ];

    protected function casts(): array
    {
        return [
            'day_of_week' => WeekDay::class,
            'is_active' => 'boolean',
        ];
    }

    /**
     * @return BelongsTo<Circle, covariant $this>
     */
    public function circle(): BelongsTo
    {
        return $this->belongsTo(Circle::class);
    }

    /**
     * Search scope for filtering schedules by room.
     *
     * @param  Builder  $query
     * @param  string  $value
     * @return Builder
     */
    public function scopeSearch($query, $value)
    {
        return $query->where('room', 'like', "%{$value}%");
    }
}
