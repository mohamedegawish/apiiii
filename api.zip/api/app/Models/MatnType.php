<?php

namespace App\Models;

use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Admin-managed catalog of memorized texts other than the Quran (e.g.
 * الأربعين النووية، تحفة الأطفال، الجزرية). Each type owns an ordered list
 * of named sections (`MatnSection`) that a teacher picks a from/to range
 * from when recording a Matn evaluation.
 *
 * @property string $id
 * @property string $name
 * @property string|null $description
 * @property bool $is_active
 */
class MatnType extends Model
{
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = ['name', 'description', 'is_active'];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
        ];
    }

    /**
     * @return HasMany<MatnSection, covariant $this>
     */
    public function sections(): HasMany
    {
        return $this->hasMany(MatnSection::class)->orderBy('order');
    }

    public function scopeSearch(Builder $query, string $value): Builder
    {
        return $query->where('name', 'like', "%{$value}%");
    }
}
