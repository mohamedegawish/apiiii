<?php

namespace App\Models;

use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MonthlyProgressRecord extends Model
{
    use Auditable, Blameable, HasFactory, HasUuid;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'student_id',
        'circle_id',
        'year',
        'month',
        'memorization_start_ref',
        'memorization_end_ref',
        'revision_start_ref',
        'revision_end_ref',
        'matn_start_ref',
        'matn_end_ref',
        'listening_score',
        'attendance_percentage',
        'absence_percentage',
        'sessions_count',
        'attended_sessions',
        'missed_sessions',
        'notes',
        'manually_edited_at',
    ];

    protected function casts(): array
    {
        return [
            'year' => 'integer',
            'month' => 'integer',
            'listening_score' => 'decimal:2',
            'attendance_percentage' => 'decimal:2',
            'absence_percentage' => 'decimal:2',
            'sessions_count' => 'integer',
            'attended_sessions' => 'integer',
            'missed_sessions' => 'integer',
            'manually_edited_at' => 'datetime',
        ];
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }

    public function circle(): BelongsTo
    {
        return $this->belongsTo(Circle::class);
    }
}
