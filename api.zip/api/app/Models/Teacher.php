<?php

namespace App\Models;

use App\Enums\SalaryType;
use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Database\Factories\TeacherFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property string $id
 * @property string $user_id
 * @property string|null $title
 * @property string|null $qualification
 * @property string|null $specialization
 * @property int $years_of_experience
 * @property SalaryType $salary_type
 * @property string $salary_amount
 * @property string $hourly_rate
 * @property string $per_session_rate
 * @property string $per_student_rate
 * @property string|null $hired_at
 * @property bool $is_active
 * @property string|null $created_by
 * @property string|null $updated_by
 */
class Teacher extends Model
{
    /** @use HasFactory<TeacherFactory> */
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = [
        'user_id',
        'title',
        'qualification',
        'specialization',
        'years_of_experience',
        'salary_type',
        'salary_amount',
        'hourly_rate',
        'per_session_rate',
        'per_student_rate',
        'hired_at',
    ];

    protected function casts(): array
    {
        return [
            'salary_type' => SalaryType::class,
            'is_active' => 'boolean',
            'hired_at' => 'date',
        ];
    }

    /**
     * @return BelongsTo<User, covariant $this>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * @return HasMany<Circle, covariant $this>
     */
    public function circles(): HasMany
    {
        return $this->hasMany(Circle::class);
    }

    public function circleSessions(): HasMany
    {
        return $this->hasMany(CircleSession::class);
    }

    /**
     * @return HasMany<MemorizationSession, covariant $this>
     */
    public function memorizationSessions(): HasMany
    {
        return $this->hasMany(MemorizationSession::class);
    }

    /**
     * @return HasMany<RevisionSession, covariant $this>
     */
    public function revisionSessions(): HasMany
    {
        return $this->hasMany(RevisionSession::class);
    }

    /**
     * @return HasMany<Attendance, covariant $this>
     */
    public function attendances(): HasMany
    {
        return $this->hasMany(Attendance::class);
    }

    /**
     * @return HasMany<Assessment, covariant $this>
     */
    public function assessments(): HasMany
    {
        return $this->hasMany(Assessment::class);
    }

    /**
     * @return HasMany<Homework, covariant $this>
     */
    public function homework(): HasMany
    {
        return $this->hasMany(Homework::class);
    }

    /**
     * @return HasOne<TeacherStatistic, covariant $this>
     */
    public function statistics(): HasOne
    {
        return $this->hasOne(TeacherStatistic::class);
    }

    /**
     * Search scope for filtering teachers by title, qualification, or specialization.
     *
     * @param  Builder  $query
     * @param  string  $value
     * @return Builder
     */
    public function scopeSearch($query, $value)
    {
        return $query->where(function ($q) use ($value): void {
            $q->where('title', 'like', "%{$value}%")
                ->orWhere('qualification', 'like', "%{$value}%")
                ->orWhere('specialization', 'like', "%{$value}%");
        });
    }
}
