<?php

namespace App\Models;

use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class ParentEvaluation extends Model
{
    use Auditable, Blameable, HasFactory, HasUuid, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    protected $fillable = ['circle_session_id', 'student_id', 'guardian_id', 'behavior_score', 'prayer_score', 'homework_followup_score', 'notes'];

    protected function casts(): array
    {
        return ['behavior_score' => 'integer', 'prayer_score' => 'integer', 'homework_followup_score' => 'integer'];
    }

    public function circleSession(): BelongsTo
    {
        return $this->belongsTo(CircleSession::class);
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }

    public function guardian(): BelongsTo
    {
        return $this->belongsTo(Guardian::class);
    }
}
