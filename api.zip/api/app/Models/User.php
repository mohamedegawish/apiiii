<?php

namespace App\Models;

use App\Enums\Role;
use App\Support\Traits\Auditable;
use App\Support\Traits\Blameable;
use App\Support\Traits\HasUuid;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Carbon;
use Laravel\Sanctum\HasApiTokens;

/**
 * @property string $id
 * @property string $name
 * @property string|null $email
 * @property string|null $phone
 * @property Carbon|null $email_verified_at
 * @property string $password
 * @property Role $role
 * @property string $locale
 * @property string $timezone
 * @property bool $is_active
 * @property string|null $created_by
 * @property string|null $updated_by
 * @property Carbon|null $deleted_at
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 */
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use Auditable, Blameable, HasApiTokens, HasFactory, HasUuid, Notifiable, SoftDeletes;

    public $incrementing = false;

    protected $keyType = 'string';

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'phone',
        'password',
        'role',
        'locale',
        'timezone',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'role' => Role::class,
            'is_active' => 'boolean',
        ];
    }

    /**
     * Resolve the user's role as a typed enum, or null when unset.
     */
    public function roleEnum(): ?Role
    {
        return $this->role instanceof Role ? $this->role : null;
    }

    /**
     * Whether the user is a super admin.
     */
    public function isSuperAdmin(): bool
    {
        return $this->roleEnum()?->isSuperAdmin() === true;
    }

    /**
     * Whether the user holds one of the given roles.
     */
    public function hasRole(Role ...$roles): bool
    {
        $current = $this->roleEnum();

        if ($current === null) {
            return false;
        }

        foreach ($roles as $role) {
            if ($current === $role) {
                return true;
            }
        }

        return false;
    }

    /**
     * The teacher profile associated with this user, if any.
     *
     * @return HasOne<Teacher, covariant $this>
     */
    public function teacher(): HasOne
    {
        return $this->hasOne(Teacher::class, 'user_id');
    }

    public function guardian(): HasOne
    {
        return $this->hasOne(Guardian::class, 'user_id');
    }

    public function student(): HasOne
    {
        return $this->hasOne(Student::class, 'user_id');
    }

    public function deviceTokens(): HasMany
    {
        return $this->hasMany(DeviceToken::class);
    }

    protected static function booted(): void
    {
        static::updated(function (self $user): void {
            if ($user->wasChanged('is_active') && ! $user->is_active) {
                $user->tokens()->delete();
                $user->deviceTokens()->delete();
            }
        });
    }
}
