<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $juz_number
 * @property string $name_arabic
 * @property string $name_english
 * @property int $starting_surah
 * @property int $starting_ayah
 * @property int $page_start
 * @property int $page_end
 */
class Juz extends Model
{
    protected $fillable = [
        'juz_number',
        'name_arabic',
        'name_english',
        'starting_surah',
        'starting_ayah',
        'page_start',
        'page_end',
    ];

    protected function casts(): array
    {
        return [
            'juz_number' => 'integer',
            'starting_surah' => 'integer',
            'starting_ayah' => 'integer',
            'page_start' => 'integer',
            'page_end' => 'integer',
        ];
    }
}
