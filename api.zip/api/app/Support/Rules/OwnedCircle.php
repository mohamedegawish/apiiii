<?php

namespace App\Support\Rules;

use App\Enums\Role;
use App\Models\Circle;
use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Translation\PotentiallyTranslatedString;

/**
 * Validates that the given circle_id belongs to a circle the authenticated
 * user is permitted to operate on, preventing cross-tenant data injection.
 */
class OwnedCircle implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  Closure(string): PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if ($value === null) {
            return;
        }

        $user = auth()->user();

        if ($user === null || $user->isSuperAdmin() || $user->hasRole(Role::CenterOwner)) {
            return;
        }

        $circle = Circle::find($value);

        if ($circle === null) {
            return;
        }

        if ($user->hasRole(Role::Teacher) && $user->teacher !== null && $circle->teacher_id === $user->teacher->id) {
            return;
        }

        $fail('The selected circle does not belong to your tenant.');
    }
}
