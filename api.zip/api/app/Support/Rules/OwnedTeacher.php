<?php

namespace App\Support\Rules;

use App\Enums\Role;
use App\Models\Teacher;
use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Translation\PotentiallyTranslatedString;

/**
 * Prevents assigning a teacher from another tenant to a circle.
 */
class OwnedTeacher implements ValidationRule
{
    /**
     * @param  Closure(string): PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if ($value === null) {
            return;
        }

        $user = auth()->user();

        if ($user === null || $user->isSuperAdmin() || $user->hasRole(Role::CenterOwner)) {
            return;
        }

        $teacher = Teacher::find($value);

        if ($teacher === null) {
            return;
        }

        if ($user->hasRole(Role::Teacher) && $user->teacher?->id === $teacher->id) {
            return;
        }

        $fail('The selected teacher does not belong to your tenant.');
    }
}
