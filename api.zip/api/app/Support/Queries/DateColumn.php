<?php

namespace App\Support\Queries;

use DateTimeInterface;
use Illuminate\Support\Carbon;

/**
 * Bounds for filtering a date-cast column by calendar day.
 *
 * Two constraints meet here, and only the half-open form `col >= start AND
 * col < dayAfter(end)` satisfies both:
 *
 * 1. `whereDate($column, ...)` wraps the column in SQL's `DATE()`, which makes
 *    it unusable as an index key — MySQL degrades a composite index such as
 *    `(teacher_id, attendance_date)` from a `range` seek to a `ref` scan of
 *    every row for that teacher, so a one-month report reads the teacher's
 *    entire history. Comparing the bare column keeps the index.
 *
 * 2. A date-cast column is not stored identically everywhere: MySQL's `DATE`
 *    holds `2026-02-28`, while SQLite (used by the test suite) holds the
 *    serialized datetime `2026-02-28 00:00:00`. An inclusive upper bound of
 *    `<= '2026-02-28'` therefore silently drops that whole day on SQLite,
 *    because the stored string sorts after the bound. `< '2026-03-01'` selects
 *    the same rows under either storage shape.
 *
 * So: pass the lower bound through untouched, and express every upper bound as
 * "strictly before the next day".
 */
final class DateColumn
{
    /**
     * The exclusive upper bound for a range that should include all of $date:
     * the following calendar day, as a bare `Y-m-d` string.
     */
    public static function dayAfter(DateTimeInterface|string $date): string
    {
        return Carbon::parse($date instanceof DateTimeInterface ? $date->format('Y-m-d') : $date)
            ->addDay()
            ->toDateString();
    }

    /** The bare `Y-m-d` string for a date, for use as an inclusive lower bound. */
    public static function day(DateTimeInterface|string $date): string
    {
        return $date instanceof DateTimeInterface
            ? $date->format('Y-m-d')
            : Carbon::parse($date)->toDateString();
    }
}
