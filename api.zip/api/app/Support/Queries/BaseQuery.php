<?php

namespace App\Support\Queries;

use App\Enums\Role;
use App\Models\Circle;
use App\Models\Student;
use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\QueryBuilder\QueryBuilder as SpatieQueryBuilder;

/**
 * Base query object backed by spatie/laravel-query-builder.
 *
 * Each feature defines a query object that declares its allowed filters,
 * sorts, includes, and default sort. The Spatie package handles the
 * request parsing, filtering, sorting, and eager loading — keeping
 * controllers and services free of query logic and preventing N+1
 * queries through declared includes.
 *
 * Subclasses MAY override {@see applyTenantScope()} to restrict results
 * to the authenticated user's accessible records. Super admins bypass all scoping.
 */
abstract class BaseQuery
{
    protected int $defaultPerPage = 15;

    protected string $defaultSort = '-created_at';

    protected SpatieQueryBuilder $builder;

    private bool $configured = false;

    public function __construct(string $model)
    {
        $query = $model::query();

        $this->applyTenantScope($query);

        if ($updatedSince = request()->date('updated_since')) {
            $query->where('updated_at', '>=', $updatedSince);
        }

        $this->builder = SpatieQueryBuilder::for($query);

        // configure() is deliberately NOT called here — see ensureConfigured().
    }

    /**
     * Registers allowedFilters/allowedSorts/allowedIncludes on $builder —
     * deferred until the query is actually used (paginate()/getBuilder()),
     * not run eagerly in the constructor. Spatie validates the *current*
     * request's sort/filter params the instant allowedSorts()/allowedFilters()
     * is called (see SortsQuery::ensureAllSortsExist()) — eagerly, not when
     * the query actually runs. A service that constructor-injects more than
     * one BaseQuery subclass (e.g. FinanceCatalogService, which needs one
     * per reference-data entity) would otherwise validate the request's
     * params against *every* injected query's allowed list, not just the
     * one the current action actually uses — an unrelated sibling query
     * threw a 400 for a perfectly valid request. $builder itself stays
     * eager (unlike this validation step) because several subclasses chain
     * .with() on it immediately in their own constructors, or use it
     * directly outside paginate() (e.g. LearningRecordQuery::findOrFail()).
     */
    private function ensureConfigured(): void
    {
        if ($this->configured) {
            return;
        }

        $this->configured = true;
        $this->configure();
    }

    protected function configure(): void
    {
        if ($this->allowedFilters() !== []) {
            $this->builder->allowedFilters($this->allowedFilters());
        }

        if ($this->allowedSorts() !== []) {
            $this->builder->allowedSorts($this->allowedSorts());
        }

        if ($this->allowedIncludes() !== []) {
            $this->builder->allowedIncludes($this->allowedIncludes());
        }

        $this->builder->defaultSort($this->defaultSort);
    }

    /**
     * Restrict the query to records the authenticated user may access.
     *
     * Super admins and center owners see everything. Teachers see only
     * their own data. Parents see only their children.
     */
    protected function applyTenantScope(EloquentBuilder $builder): void
    {
        // Default: no scoping. Subclasses override as needed.
    }

    protected function currentUser(): ?User
    {
        return Auth::user();
    }

    protected function shouldBypassScope(): bool
    {
        $user = $this->currentUser();

        return $user?->isSuperAdmin() === true || $user?->hasRole(Role::CenterOwner) === true;
    }

    /**
     * Teacher IDs the current user may access.
     *
     * @return list<string>|null Null when unrestricted (super admin / center owner).
     */
    protected function accessibleTeacherIds(): ?array
    {
        $user = $this->currentUser();

        if ($user === null || $this->shouldBypassScope()) {
            return null;
        }

        if ($user->hasRole(Role::Teacher) && $user->teacher !== null) {
            return [$user->teacher->id];
        }

        return [];
    }

    /**
     * Circle IDs the current user may access.
     *
     * @return list<string>|null Null when unrestricted (super admin / center owner).
     */
    protected function accessibleCircleIds(): ?array
    {
        $user = $this->currentUser();

        if ($user === null || $this->shouldBypassScope()) {
            return null;
        }

        if ($user->hasRole(Role::Teacher) && $user->teacher !== null) {
            return Circle::where('teacher_id', $user->teacher->id)
                ->where('is_active', true)
                ->pluck('id')->all();
        }

        return [];
    }

    /**
     * Student IDs the current user may access.
     *
     * @return list<string>|null Null when unrestricted (super admin / center owner).
     */
    protected function accessibleStudentIds(): ?array
    {
        $user = $this->currentUser();

        if ($user === null || $this->shouldBypassScope()) {
            return null;
        }

        if ($user->hasRole(Role::Teacher) && $user->teacher !== null) {
            return DB::table('enrollments')
                ->join('circles', 'enrollments.circle_id', '=', 'circles.id')
                ->where('circles.teacher_id', $user->teacher->id)
                ->whereNull('circles.deleted_at')
                ->where('circles.is_active', true)
                ->where('enrollments.status', 'active')
                ->whereNull('enrollments.left_at')
                ->pluck('enrollments.student_id')
                ->unique()
                ->values()
                ->all();
        }

        if ($user->hasRole(Role::Parent) && $user->guardian !== null) {
            return $user->guardian->children()->pluck('students.id')->all();
        }

        return [];
    }

    protected function allowedFilters(): array
    {
        return [];
    }

    protected function allowedSorts(): array
    {
        return ['created_at', 'updated_at'];
    }

    protected function allowedIncludes(): array
    {
        return [];
    }

    public function paginate(): LengthAwarePaginator
    {
        $this->ensureConfigured();

        $perPage = (int) request()->integer('per_page', $this->defaultPerPage);

        // Clients walk every page to read a full list. Sorts such as
        // -created_at are not unique (bulk inserts share a timestamp), and an
        // ambiguous ORDER BY lets the database return tied rows in a different
        // order per page, so a row could be skipped or repeated across pages.
        // The primary key makes the order total.
        $this->builder->orderBy($this->builder->getModel()->getQualifiedKeyName());

        return $this->builder->paginate(max(1, min($perPage, 100)));
    }

    public function getBuilder(): SpatieQueryBuilder
    {
        $this->ensureConfigured();

        return $this->builder;
    }
}
