<?php

namespace App\Support\Policies;

use App\Enums\Role;
use App\Models\User;

/**
 * Base policy providing shared role-based authorization helpers.
 *
 * Feature policies extend this class and define their own viewAny,
 * view, create, update, and delete methods using the helpers below.
 */
abstract class BasePolicy
{
    /**
     * Whether the user holds any of the given roles.
     */
    protected function hasRole(?User $user, Role ...$roles): bool
    {
        if (! $user instanceof User) {
            return false;
        }

        $userRole = $user->roleEnum();

        if ($userRole === null) {
            return false;
        }

        foreach ($roles as $role) {
            if ($userRole === $role) {
                return true;
            }
        }

        return false;
    }

    /**
     * Whether the user is a super admin (bypasses all checks).
     */
    protected function isSuperAdmin(?User $user): bool
    {
        return $user instanceof User && $user->roleEnum()?->isSuperAdmin() === true;
    }

    /**
     * Whether the user's role outranks or matches the given role.
     */
    protected function isAtLeast(?User $user, Role $role): bool
    {
        $userRole = $user?->roleEnum();

        if ($userRole === null) {
            return false;
        }

        return $userRole->rank() <= $role->rank();
    }
}
