<?php

namespace App\Support\Exceptions;

use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\QueryException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\ThrottleRequestsException;
use Throwable;

/**
 * Centralized renderer that converts exceptions into the API's
 * standardized JSON response envelope.
 */
class ApiExceptionRenderer
{
    /**
     * Render the given exception into a JSON response, or null when the
     * exception should fall through to Laravel's default handler.
     */
    public function render(Throwable $e, Request $request): ?JsonResponse
    {
        if (! $this->isApiRequest($request)) {
            return null;
        }

        return match (true) {
            $e instanceof ApiException => $this->renderApiException($e),
            $e instanceof ValidationException => $this->renderValidationException($e),
            $e instanceof AuthenticationException => $this->build(false, $e->getMessage() ?: 'Unauthenticated.', 401, 'unauthenticated'),
            $e instanceof AuthorizationException => $this->build(false, $e->getMessage() ?: 'Forbidden.', 403, 'forbidden'),
            $e instanceof AccessDeniedHttpException => $this->build(false, $e->getMessage() ?: 'Forbidden.', 403, 'forbidden'),
            $e instanceof ModelNotFoundException => $this->build(false, 'The requested resource was not found.', 404, 'not_found'),
            $e instanceof QueryException && $this->isUniqueConstraintViolation($e) => $this->build(false, 'The resource conflicts with an existing record.', 409, 'conflict'),
            $e instanceof NotFoundHttpException => $this->build(false, 'The requested route was not found.', 404, 'route_not_found'),
            $e instanceof MethodNotAllowedHttpException => $this->build(false, 'The HTTP method is not allowed for this route.', 405, 'method_not_allowed'),
            $e instanceof ThrottleRequestsException => $this->build(false, 'Too many requests. Please try again later.', 429, 'too_many_requests'),
            $e instanceof HttpException => $this->build(false, $e->getMessage() ?: 'HTTP error.', $e->getStatusCode(), 'http_error'),
            default => $this->renderFallback($e),
        };
    }

    /**
     * Render a custom {@see ApiException}.
     */
    protected function renderApiException(ApiException $e): JsonResponse
    {
        $payload = [
            'success' => false,
            'message' => $e->getMessage(),
            'error_code' => $e->errorCode(),
        ];

        if ($e->errors() !== null) {
            $payload['errors'] = $e->errors();
        }

        return response()->json($payload, $e->statusCode());
    }

    /**
     * Render a Laravel {@see ValidationException}.
     */
    protected function renderValidationException(ValidationException $e): JsonResponse
    {
        return response()->json([
            'success' => false,
            'message' => 'The given data was invalid.',
            'error_code' => 'validation_failed',
            'errors' => $e->errors(),
        ], $e->status);
    }

    /**
     * Render a fallback for unhandled exceptions.
     */
    protected function renderFallback(Throwable $e): JsonResponse
    {
        $isDebug = config('app.debug', false);

        $payload = [
            'success' => false,
            'message' => $isDebug ? $e->getMessage() : 'An unexpected error occurred.',
            'error_code' => 'internal_error',
        ];

        if ($isDebug) {
            $payload['exception'] = [
                'type' => $e::class,
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ];
        }

        return response()->json($payload, 500);
    }

    /**
     * Build a minimal error response.
     *
     * @param  array<string, mixed>  ...$parts
     */
    protected function build(bool $success, string $message, int $status, string $errorCode): JsonResponse
    {
        return response()->json([
            'success' => $success,
            'message' => $message,
            'error_code' => $errorCode,
        ], $status);
    }

    /**
     * Determine whether the request targets the API.
     */
    protected function isApiRequest(Request $request): bool
    {
        return $request->is('api/*') || $request->expectsJson();
    }

    protected function isUniqueConstraintViolation(QueryException $exception): bool
    {
        return in_array((string) ($exception->errorInfo[0] ?? $exception->getCode()), ['23000', '23505', '19'], true);
    }
}
