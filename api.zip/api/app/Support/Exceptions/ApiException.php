<?php

namespace App\Support\Exceptions;

use RuntimeException;
use Throwable;

/**
 * Base exception for all API errors that should be rendered as a
 * structured JSON response by the global exception handler.
 */
class ApiException extends RuntimeException
{
    /**
     * The HTTP status code to return.
     */
    protected int $statusCode = 500;

    /**
     * The error code identifier for the API consumer.
     */
    protected string $errorCode = 'internal_error';

    /**
     * Optional contextual error details to include in the response.
     *
     * @var array<string, mixed>|null
     */
    protected ?array $errors = null;

    public function __construct(string $message = '', ?Throwable $previous = null)
    {
        parent::__construct($message, 0, $previous);
    }

    public function statusCode(): int
    {
        return $this->statusCode;
    }

    public function errorCode(): string
    {
        return $this->errorCode;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function errors(): ?array
    {
        return $this->errors;
    }

    /**
     * Attach contextual error details and return the exception for chaining.
     *
     * @param  array<string, mixed>  $errors
     */
    public function withErrors(array $errors): static
    {
        $this->errors = $errors;

        return $this;
    }
}
