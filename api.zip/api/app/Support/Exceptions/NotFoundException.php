<?php

namespace App\Support\Exceptions;

class NotFoundException extends ApiException
{
    protected int $statusCode = 404;

    protected string $errorCode = 'not_found';

    public function __construct(string $message = 'The requested resource was not found.')
    {
        parent::__construct($message);
    }
}
