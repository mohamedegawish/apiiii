<?php

namespace App\Support\Exceptions;

class ConflictException extends ApiException
{
    protected int $statusCode = 409;

    protected string $errorCode = 'conflict';

    /**
     * @param  string|null  $errorCode  A specific machine-readable code for the
     *                                  caller, e.g. 'student_inactive'. Clients
     *                                  (notably the QR scanner) branch on this
     *                                  to show the operator a precise message
     *                                  instead of a generic conflict.
     */
    public function __construct(string $message = 'The request conflicts with the current state of the resource.', ?string $errorCode = null)
    {
        parent::__construct($message);

        if ($errorCode !== null) {
            $this->errorCode = $errorCode;
        }
    }
}
