<?php

namespace App\Support\Exceptions;

class ForbiddenException extends ApiException
{
    protected int $statusCode = 403;

    protected string $errorCode = 'forbidden';

    public function __construct(string $message = 'You do not have permission to perform this action.')
    {
        parent::__construct($message);
    }
}
