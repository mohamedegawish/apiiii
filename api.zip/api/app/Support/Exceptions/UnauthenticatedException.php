<?php

namespace App\Support\Exceptions;

class UnauthenticatedException extends ApiException
{
    protected int $statusCode = 401;

    protected string $errorCode = 'unauthenticated';

    public function __construct(string $message = 'Authentication is required to access this resource.')
    {
        parent::__construct($message);
    }
}
