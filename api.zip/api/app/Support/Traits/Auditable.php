<?php

namespace App\Support\Traits;

use App\Models\AuditLog;
use App\Observers\AuditableObserver;
use Illuminate\Database\Eloquent\Relations\MorphMany;

/**
 * Marks an Eloquent model as auditable.
 *
 * Models using this trait are observed by the {@see AuditableObserver},
 * which records created, updated, deleted, and restored events as
 * entries in the {@see AuditLog} table.
 */
trait Auditable
{
    /**
     * Boot the trait and register the observer.
     */
    public static function bootAuditable(): void
    {
        static::observe(AuditableObserver::class);
    }

    /**
     * The audit logs recorded for this model.
     *
     * @return MorphMany<AuditLog, covariant $this>
     */
    public function audits(): MorphMany
    {
        return $this->morphMany(AuditLog::class, 'auditable');
    }
}
