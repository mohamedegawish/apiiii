<?php

namespace App\Support\Traits;

use Illuminate\Support\Str;

/**
 * Provides UUID primary key generation for Eloquent models.
 *
 * Models using this trait have their UUID primary key automatically
 * populated on creation, replacing Laravel's default auto-incrementing
 * integer. Models MUST also declare the following to remain compatible
 * with Eloquent's expectations for non-incrementing keys:
 *
 *     public $incrementing = false;
 *     protected string $keyType = 'string';
 */
trait HasUuid
{
    /**
     * Boot the trait and register the UUID generation hook.
     */
    public static function bootHasUuid(): void
    {
        static::creating(function (self $model): void {
            if (! $model->getKey()) {
                $model->setAttribute($model->getKeyName(), (string) Str::uuid());
            }
        });
    }
}
