<?php

namespace App\Support\Traits;

use App\Models\User;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Auth;

/**
 * Tracks which user created and updated each record.
 *
 * Models using this trait automatically populate the `created_by` and
 * `updated_by` columns with the UUID of the authenticated user.
 */
trait Blameable
{
    /**
     * Boot the trait and register the blameable hooks.
     */
    public static function bootBlameable(): void
    {
        static::creating(function (self $model): void {
            if (! $model->getAttribute('created_by')) {
                $model->setAttribute('created_by', self::authenticatedId());
            }
        });

        static::updating(function (self $model): void {
            $model->setAttribute('updated_by', self::authenticatedId());
        });
    }

    /**
     * The user who created this record.
     *
     * @return BelongsTo<User, covariant $this>
     */
    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    /**
     * The user who last updated this record.
     *
     * @return BelongsTo<User, covariant $this>
     */
    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    /**
     * Resolve the UUID of the currently authenticated user, if any.
     */
    protected static function authenticatedId(): ?string
    {
        try {
            $id = Auth::id();

            if ($id !== null) {
                return (string) $id;
            }

            $id = Auth::guard('web')->id();

            return $id !== null ? (string) $id : null;
        } catch (\Throwable) {
            return null;
        }
    }
}
