<?php

namespace App\Support\Services;

class AuditSanitizer
{
    /**
     * Sensitive key concepts after punctuation and casing are removed.
     *
     * @var list<string>
     */
    private const SENSITIVE_CONCEPTS = [
        'password',
        'currentpassword',
        'newpassword',
        'passwordconfirmation',
        'remembertoken',
        'apitoken',
        'accesstoken',
        'refreshtoken',
        'token',
        'sanctumtoken',
        'twofactorsecret',
        'twofactorrecoverycodes',
        'otp',
        'verificationcode',
    ];

    /**
     * Recursively remove sensitive keys from an audit payload.
     *
     * @param  array<array-key, mixed>|null  $values
     * @return array<array-key, mixed>|null
     */
    public function sanitize(?array $values): ?array
    {
        if ($values === null) {
            return null;
        }

        $sanitized = [];

        foreach ($values as $key => $value) {
            if (is_string($key) && $this->isSensitiveKey($key)) {
                continue;
            }

            $sanitized[$key] = is_array($value) ? $this->sanitize($value) : $value;
        }

        return $sanitized;
    }

    private function isSensitiveKey(string $key): bool
    {
        $normalized = strtolower((string) preg_replace('/[^a-z0-9]+/i', '', $key));

        foreach (self::SENSITIVE_CONCEPTS as $concept) {
            if (str_contains($normalized, $concept)) {
                return true;
            }
        }

        return false;
    }
}
