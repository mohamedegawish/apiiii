<?php

namespace App\Support\Services;

use App\Enums\LearningRecordType;
use App\Models\Assessment;
use App\Models\Attendance;
use App\Models\Ayah;
use App\Models\CircleStatistic;
use App\Models\Student;
use App\Models\StudentLearningRecord;
use App\Models\StudentStatistic;
use App\Models\Surah;
use App\Models\Teacher;
use App\Models\TeacherStatistic;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

/**
 * Computes and persists aggregate statistics for students, teachers, and circles.
 *
 * This service performs expensive aggregate queries against the tracking tables
 * and upserts the results into the denormalized statistics tables. It is
 * designed to be invoked asynchronously via queue jobs, never on the request
 * path, and to cache its output via the Laravel Cache facade.
 */
class StatisticsCalculatorService extends BaseService
{
    private const CACHE_TTL = 3600;

    /**
     * Recalculate and persist statistics for a single student.
     */
    public function recalculateStudent(string $studentId): StudentStatistic
    {
        $student = Student::findOrFail($studentId);

        $memoSessions = $this->learningRecordsOfType(LearningRecordType::Memorization, 'student_id', $studentId);
        $revSessions = $this->learningRecordsOfType(LearningRecordType::Revision, 'student_id', $studentId);
        $assessments = Assessment::where('student_id', $studentId)->get();
        $attendances = Attendance::where('student_id', $studentId)->get();
        $matnListening = $this->matnListeningStats('student_id', $studentId);

        $memorizedPages = $this->computeMemorizedPages($memoSessions);
        $memorizedJuz = $this->computeMemorizedJuz($memoSessions);
        $completedSurahs = $this->computeCompletedSurahs($memoSessions);
        $monthlyProgress = $this->computeMonthlyProgress($memoSessions, $revSessions);
        $surahProgress = $this->computeSurahProgress($memoSessions);
        $attendanceRate = $this->computeAttendanceRate($attendances);
        $revisionRatio = $this->computeRevisionRatio($memoSessions->count(), $revSessions->count());

        $statistic = StudentStatistic::updateOrCreate(
            ['student_id' => $studentId],
            [
                'memorized_pages' => $memorizedPages,
                'memorized_juz' => $memorizedJuz,
                'completed_surahs' => $completedSurahs,
                'total_memorization_sessions' => $memoSessions->count(),
                'total_revision_sessions' => $revSessions->count(),
                'total_assessments' => $assessments->count(),
                'average_memorization_grade' => $this->averageGrade($memoSessions, 'memorization_grade'),
                'average_tajweed_grade' => $this->averageGrade($memoSessions, 'tajweed_grade'),
                'average_fluency_grade' => $this->averageGrade($memoSessions, 'fluency_grade'),
                'average_discipline_grade' => $this->averageGrade($memoSessions, 'discipline_grade'),
                'attendance_rate' => $attendanceRate,
                'revision_ratio' => $revisionRatio,
                'monthly_progress' => $monthlyProgress,
                'surah_progress' => $surahProgress,
                ...$matnListening,
                'last_calculated_at' => now(),
            ],
        );

        $this->put($this->studentCacheKey($studentId), $statistic->toArray(), self::CACHE_TTL);

        return $statistic;
    }

    /**
     * Recalculate and persist statistics for a single teacher.
     */
    public function recalculateTeacher(string $teacherId): TeacherStatistic
    {
        $teacher = Teacher::findOrFail($teacherId);

        $memoSessions = $this->learningRecordsOfType(LearningRecordType::Memorization, 'teacher_id', $teacherId);
        $revSessions = $this->learningRecordsOfType(LearningRecordType::Revision, 'teacher_id', $teacherId);
        $assessments = Assessment::where('teacher_id', $teacherId)->get();
        $attendances = Attendance::where('teacher_id', $teacherId)->get();
        $matnListening = $this->matnListeningStats('teacher_id', $teacherId);
        $totalStudents = DB::table('circle_student')
            ->join('circles', 'circle_student.circle_id', '=', 'circles.id')
            ->where('circles.teacher_id', $teacherId)
            ->distinct('circle_student.student_id')
            ->count('circle_student.student_id');

        $statistic = TeacherStatistic::updateOrCreate(
            ['teacher_id' => $teacherId],
            [
                'total_memorization_sessions' => $memoSessions->count(),
                'total_revision_sessions' => $revSessions->count(),
                'total_assessments' => $assessments->count(),
                'total_students' => $totalStudents,
                'total_attendance_records' => $attendances->count(),
                'average_memorization_grade' => $this->averageGrade($memoSessions, 'memorization_grade'),
                'average_tajweed_grade' => $this->averageGrade($memoSessions, 'tajweed_grade'),
                'average_fluency_grade' => $this->averageGrade($memoSessions, 'fluency_grade'),
                'average_discipline_grade' => $this->averageGrade($memoSessions, 'discipline_grade'),
                'student_attendance_rate' => $this->computeAttendanceRate($attendances),
                'monthly_sessions' => $this->computeMonthlySessions($memoSessions, $revSessions),
                ...$matnListening,
                'last_calculated_at' => now(),
            ],
        );

        $this->put($this->teacherCacheKey($teacherId), $statistic->toArray(), self::CACHE_TTL);

        return $statistic;
    }

    /**
     * Recalculate and persist statistics for a single circle.
     */
    public function recalculateCircle(string $circleId): CircleStatistic
    {
        $totalStudents = DB::table('circle_student')
            ->where('circle_id', $circleId)
            ->where('status', 'active')
            ->count();

        $memoSessions = $this->learningRecordsOfType(LearningRecordType::Memorization, 'circle_id', $circleId);
        $revSessions = $this->learningRecordsOfType(LearningRecordType::Revision, 'circle_id', $circleId);
        $assessments = Assessment::where('circle_id', $circleId)->get();
        $attendances = Attendance::where('circle_id', $circleId)->get();
        $matnListening = $this->matnListeningStats('circle_id', $circleId);

        $memorizedPagesTotal = $this->computeMemorizedPages($memoSessions);
        $completedSurahsTotal = $this->computeCompletedSurahs($memoSessions);

        $statistic = CircleStatistic::updateOrCreate(
            ['circle_id' => $circleId],
            [
                'total_students' => $totalStudents,
                'total_memorization_sessions' => $memoSessions->count(),
                'total_revision_sessions' => $revSessions->count(),
                'total_assessments' => $assessments->count(),
                'average_memorization_grade' => $this->averageGrade($memoSessions, 'memorization_grade'),
                'average_tajweed_grade' => $this->averageGrade($memoSessions, 'tajweed_grade'),
                'average_fluency_grade' => $this->averageGrade($memoSessions, 'fluency_grade'),
                'average_discipline_grade' => $this->averageGrade($memoSessions, 'discipline_grade'),
                'average_attendance_rate' => $this->computeAttendanceRate($attendances),
                'memorized_pages_total' => $memorizedPagesTotal,
                'completed_surahs_total' => $completedSurahsTotal,
                'monthly_progress' => $this->computeMonthlyProgress($memoSessions, $revSessions),
                ...$matnListening,
                'last_calculated_at' => now(),
            ],
        );

        $this->put($this->circleCacheKey($circleId), $statistic->toArray(), self::CACHE_TTL);

        return $statistic;
    }

    /**
     * Retrieve cached student statistics, computing on miss.
     */
    public function getStudentStatistics(string $studentId): array
    {
        return $this->remember(
            $this->studentCacheKey($studentId),
            fn (): array => $this->recalculateStudent($studentId)->toArray(),
            self::CACHE_TTL,
        );
    }

    /**
     * Retrieve cached teacher statistics, computing on miss.
     */
    public function getTeacherStatistics(string $teacherId): array
    {
        return $this->remember(
            $this->teacherCacheKey($teacherId),
            fn (): array => $this->recalculateTeacher($teacherId)->toArray(),
            self::CACHE_TTL,
        );
    }

    /**
     * Retrieve cached circle statistics, computing on miss.
     */
    public function getCircleStatistics(string $circleId): array
    {
        return $this->remember(
            $this->circleCacheKey($circleId),
            fn (): array => $this->recalculateCircle($circleId)->toArray(),
            self::CACHE_TTL,
        );
    }

    /**
     * Merges the legacy memorization_sessions/revision_sessions rows with
     * the new `student_learning_records` rows the session workspace writes,
     * so statistics no longer silently go stale once grading moves to the
     * new table. Records are mapped to a duck-typed object exposing exactly
     * the properties the compute*() methods below already read
     * (`surah_number`, `from_ayah`, `to_ayah`, `session_date`, and
     * `memorization_grade` aliased from `score` — tajweed/fluency/discipline
     * grades don't exist at this granularity in the new schema and are left
     * absent, which `averageGrade()` already treats as "no grade"). N/A
     * entries (no range) are excluded — they carry no Quran position to
     * contribute.
     *
     * @param@param  Collection<int, object>  $sessions  Learning records shaped by learningRecordsOfType()$legacySessions
     */
    /**
     * The learning records of one type for a student or teacher, shaped for
     * the computation helpers below.
     *
     * This used to concat the legacy memorization_sessions/revision_sessions
     * rows onto these, which double-counted every lesson a teacher had
     * entered through both surfaces -- inflating session totals, memorized
     * pages, juz, and every average derived from them. `student_learning_records`
     * is the single canonical academic source; those legacy tables are no
     * longer written to and no longer read here.
     */
    protected function learningRecordsOfType(LearningRecordType $type, string $scopeColumn, string $scopeValue): Collection
    {
        $newRows = $this->recordsForScope($type, $scopeColumn, $scopeValue, requireSurahNumber: true)
            ->map(fn (StudentLearningRecord $record): object => (object) [
                'surah_number' => $record->surah_number,
                'from_ayah' => $record->from_ayah,
                'to_ayah' => $record->to_ayah,
                'session_date' => $record->circleSession?->session_date,
                'memorization_grade' => $record->score !== null ? (float) $record->score : null,
            ]);

        return $newRows;
    }

    /**
     * Load the learning records of one type for a student, teacher or circle.
     *
     * A learning record carries no circle of its own — it belongs to one only
     * through its session — so circle-scoped reads go through
     * `circleSession`, exactly like {@see learningRecordsOfType()}.
     *
     * @return \Illuminate\Database\Eloquent\Collection<int, StudentLearningRecord>
     */
    protected function recordsForScope(LearningRecordType $type, string $scopeColumn, string $scopeValue, bool $requireSurahNumber = false): \Illuminate\Database\Eloquent\Collection
    {
        return StudentLearningRecord::with('circleSession')
            ->when(
                $scopeColumn === 'circle_id',
                fn ($query) => $query->whereHas('circleSession', fn ($session) => $session->where('circle_id', $scopeValue)),
                fn ($query) => $query->where($scopeColumn, $scopeValue),
            )
            ->where('type', $type)
            ->when($requireSurahNumber, fn ($query) => $query->whereNotNull('surah_number'))
            ->get();
    }

    /**
     * Matn/Listening have no Quran position, so they contribute only counts
     * and an average grade — the two new statistic columns added alongside
     * memorization/revision.
     *
     * @return array{total_matn_evaluations: int, average_matn_grade: float, total_listening_evaluations: int, average_listening_grade: float}
     */
    protected function matnListeningStats(string $scopeColumn, string $scopeValue): array
    {
        $matn = $this->recordsForScope(LearningRecordType::Matn, $scopeColumn, $scopeValue);
        $listening = $this->recordsForScope(LearningRecordType::Listening, $scopeColumn, $scopeValue);

        return [
            'total_matn_evaluations' => $matn->count(),
            'average_matn_grade' => $this->averageGrade($matn, 'score'),
            'total_listening_evaluations' => $listening->count(),
            'average_listening_grade' => $this->averageGrade($listening, 'score'),
        ];
    }

    /**
     * Compute the total number of distinct pages memorized.
     *
     * @param@param  Collection<int, object>  $sessions  Learning records shaped by learningRecordsOfType()$sessions
     */
    protected function computeMemorizedPages($sessions): int
    {
        $pages = [];
        $ayahMap = $this->buildAyahMap($sessions);

        foreach ($sessions as $session) {
            $startPage = $ayahMap[$session->surah_number.'-'.$session->from_ayah]['page'] ?? 1;
            $endPage = $ayahMap[$session->surah_number.'-'.$session->to_ayah]['page'] ?? 1;

            for ($p = $startPage; $p <= $endPage; $p++) {
                $pages[$p] = true;
            }
        }

        return count($pages);
    }

    /**
     * Compute the total number of distinct juz memorized (fully).
     *
     * @param@param  Collection<int, object>  $sessions  Learning records shaped by learningRecordsOfType()$sessions
     */
    protected function computeMemorizedJuz($sessions): int
    {
        $juzCoverage = [];
        $ayahMap = $this->buildAyahMap($sessions);

        foreach ($sessions as $session) {
            $startJuz = $ayahMap[$session->surah_number.'-'.$session->from_ayah]['juz'] ?? 1;
            $endJuz = $ayahMap[$session->surah_number.'-'.$session->to_ayah]['juz'] ?? 1;

            for ($j = $startJuz; $j <= $endJuz; $j++) {
                $juzCoverage[$j] = ($juzCoverage[$j] ?? 0) + 1;
            }
        }

        return count($juzCoverage);
    }

    /**
     * Compute the number of fully completed surahs.
     *
     * @param@param  Collection<int, object>  $sessions  Learning records shaped by learningRecordsOfType()$sessions
     */
    protected function computeCompletedSurahs($sessions): int
    {
        $surahMaxAyah = [];
        $surahNumbers = $sessions->pluck('surah_number')->unique()->all();
        $surahs = Surah::whereIn('surah_number', $surahNumbers)->get()->keyBy('surah_number');

        foreach ($sessions as $session) {
            $surahNumber = $session->surah_number;

            if (! isset($surahMaxAyah[$surahNumber])) {
                $surah = $surahs->get($surahNumber);

                if ($surah === null) {
                    continue;
                }

                $surahMaxAyah[$surahNumber] = $surah->ayah_count;
            }

            if ($session->from_ayah <= 1 && $session->to_ayah >= $surahMaxAyah[$surahNumber]) {
                $surahMaxAyah[$surahNumber] = -1;
            }
        }

        return count(array_filter($surahMaxAyah, fn ($v) => $v === -1));
    }

    /**
     * Compute monthly progress as an array of month => session counts.
     *
     * @param  Collection  $memoSessions
     * @param  Collection  $revSessions
     * @return array<string, array<string, int>>
     */
    protected function computeMonthlyProgress($memoSessions, $revSessions): array
    {
        $progress = [];

        foreach ($memoSessions as $session) {
            $month = $session->session_date->format('Y-m');
            $progress[$month]['memorization'] = ($progress[$month]['memorization'] ?? 0) + 1;
        }

        foreach ($revSessions as $session) {
            $month = $session->session_date->format('Y-m');
            $progress[$month]['revision'] = ($progress[$month]['revision'] ?? 0) + 1;
        }

        return $progress;
    }

    /**
     * Compute surah-level progress as an array of surah_number => max_ayah_memorized.
     *
     * @param  Collection  $sessions
     * @return array<int, int>
     */
    protected function computeSurahProgress($sessions): array
    {
        $surahProgress = [];

        foreach ($sessions as $session) {
            $surahNumber = $session->surah_number;
            $surahProgress[$surahNumber] = max($surahProgress[$surahNumber] ?? 0, $session->to_ayah);
        }

        return $surahProgress;
    }

    /**
     * Compute the attendance rate as a percentage.
     *
     * @param  Collection<int, Attendance>  $attendances
     */
    protected function computeAttendanceRate($attendances): float
    {
        if ($attendances->isEmpty()) {
            return 0.0;
        }

        $present = $attendances->filter(fn ($a) => $a->status->wasPresent())->count();

        return round(($present / $attendances->count()) * 100, 2);
    }

    /**
     * Compute the revision ratio (revisions per memorization session).
     */
    protected function computeRevisionRatio(int $memoCount, int $revCount): float
    {
        if ($memoCount === 0) {
            return 0.0;
        }

        return round($revCount / $memoCount, 2);
    }

    /**
     * Compute monthly sessions as an array of month => counts.
     *
     * @param  Collection  $memoSessions
     * @param  Collection  $revSessions
     * @return array<string, array<string, int>>
     */
    protected function computeMonthlySessions($memoSessions, $revSessions): array
    {
        return $this->computeMonthlyProgress($memoSessions, $revSessions);
    }

    /**
     * Compute the average of a specific grade column across sessions.
     *
     * @param  Collection  $sessions
     */
    protected function averageGrade($sessions, string $column): float
    {
        $grades = $sessions->pluck($column)->filter(fn ($g) => $g !== null);

        if ($grades->isEmpty()) {
            return 0.0;
        }

        return round($grades->avg(), 2);
    }

    /**
     * Build a lookup map of ayah data keyed by "surahNumber-ayahNumber" from a
     * single batch query, eliminating per-session N+1 queries.
     *
     * @param  Collection  $sessions
     * @return array<string, array{page: int, juz: int}>
     */
    protected function buildAyahMap($sessions): array
    {
        $pairs = [];

        foreach ($sessions as $session) {
            $pairs[$session->surah_number.'-'.$session->from_ayah] = true;
            $pairs[$session->surah_number.'-'.$session->to_ayah] = true;
        }

        if ($pairs === []) {
            return [];
        }

        $conditions = collect(array_keys($pairs))->map(function (string $key): array {
            [$surah, $ayah] = explode('-', $key);

            return [(int) $surah, (int) $ayah];
        });

        $query = Ayah::query();

        $conditions->each(function (array $pair, int $index) use ($query): void {
            if ($index === 0) {
                $query->where(function ($q) use ($pair): void {
                    $q->where('surah_number', $pair[0])->where('ayah_number', $pair[1]);
                });
            } else {
                $query->orWhere(function ($q) use ($pair): void {
                    $q->where('surah_number', $pair[0])->where('ayah_number', $pair[1]);
                });
            }
        });

        return $query->get()->mapWithKeys(function (Ayah $ayah): array {
            return [$ayah->surah_number.'-'.$ayah->ayah_number => [
                'page' => $ayah->page_number ?? 1,
                'juz' => $ayah->juz_number ?? 1,
            ]];
        })->all();
    }

    /**
     * Resolve the page number for a surah/ayah from the ayahs table.
     */
    protected function ayahPage(int $surahNumber, int $ayahNumber): int
    {
        $ayah = Ayah::where('surah_number', $surahNumber)
            ->where('ayah_number', $ayahNumber)
            ->first();

        return $ayah?->page_number ?? 1;
    }

    /**
     * Resolve the juz number for a surah/ayah from the ayahs table.
     */
    protected function ayahJuz(int $surahNumber, int $ayahNumber): int
    {
        $ayah = Ayah::where('surah_number', $surahNumber)
            ->where('ayah_number', $ayahNumber)
            ->first();

        return $ayah?->juz_number ?? 1;
    }

    protected function studentCacheKey(string $studentId): string
    {
        return "itqan:stats:student:{$studentId}";
    }

    protected function teacherCacheKey(string $teacherId): string
    {
        return "itqan:stats:teacher:{$teacherId}";
    }

    protected function circleCacheKey(string $circleId): string
    {
        return "itqan:stats:circle:{$circleId}";
    }
}
