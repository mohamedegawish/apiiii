<?php

namespace App\Support\Services;

use App\Models\AuditLog;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Records audit log entries for model lifecycle events.
 */
class AuditService extends BaseService
{
    protected AuditSanitizer $sanitizer;

    public function __construct(
        protected ?Request $request = null,
        ?AuditSanitizer $sanitizer = null,
    ) {
        $this->request = $request ?? request();
        $this->sanitizer = $sanitizer ?? app(AuditSanitizer::class);
    }

    /**
     * Record an audit entry for the given model event.
     *
     * @param  array<string, mixed>|null  $old
     * @param  array<string, mixed>|null  $new
     */
    public function record(Model $model, string $action, ?array $old = null, ?array $new = null): AuditLog
    {
        $actorId = $this->authenticatedId();
        $auditLog = new AuditLog;
        $auditLog->fill([
            'action' => $action,
            'auditable_type' => $model->getMorphClass(),
            'auditable_id' => (string) $model->getKey(),
            'old_values' => $this->sanitizer->sanitize($old),
            'new_values' => $this->sanitizer->sanitize($new),
            'ip_address' => $this->ipAddress(),
            'user_agent' => $this->userAgent(),
            'route' => $this->route(),
        ]);

        $auditLog->user_id = $actorId;
        $auditLog->created_by = $actorId;
        $auditLog->save();

        return $auditLog;
    }

    /**
     * Compute the diff between the original and current attributes of a model.
     *
     * @return array{old: array<string, mixed>, new: array<string, mixed>}
     */
    public function attributeDiff(Model $model): array
    {
        $changes = $model->getChanges();

        if ($changes === []) {
            return ['old' => [], 'new' => []];
        }

        $original = $model->getOriginal();

        $oldValues = [];
        $newValues = [];

        foreach ($changes as $key => $new) {
            $oldValues[$key] = $original[$key] ?? null;
            $newValues[$key] = $new;
        }

        return [
            'old' => $this->sanitizer->sanitize($oldValues) ?? [],
            'new' => $this->sanitizer->sanitize($newValues) ?? [],
        ];
    }

    protected function authenticatedId(): ?string
    {
        $id = $this->request?->user()?->getAuthIdentifier() ?? Auth::id();

        return $id !== null ? (string) $id : null;
    }

    protected function ipAddress(): ?string
    {
        return $this->request?->ip();
    }

    protected function userAgent(): ?string
    {
        $agent = $this->request?->userAgent();

        return $agent !== null ? mb_substr($agent, 0, 500) : null;
    }

    protected function route(): ?string
    {
        return $this->request?->route()?->getName()
            ?? $this->request?->path();
    }
}
