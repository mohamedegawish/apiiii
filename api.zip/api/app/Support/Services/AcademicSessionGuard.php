<?php

namespace App\Support\Services;

use App\Enums\Role;
use App\Models\CircleSession;
use App\Models\Student;
use App\Models\User;
use App\Support\CenterClock;
use App\Support\Exceptions\ConflictException;
use App\Support\Exceptions\ForbiddenException;

class AcademicSessionGuard
{
    public function assertWritable(User $user, CircleSession $session, string $studentId): Student
    {
        if ($session->isImmutable() || CenterClock::isFutureDate($session->session_date) || $session->locked_at !== null) {
            throw new ConflictException('The selected session is not writable.');
        }

        $allowed = $user->isSuperAdmin()
            || $user->hasRole(Role::CenterOwner)
            || ($user->hasRole(Role::Teacher) && $session->teacher?->user_id === $user->id);

        if (! $allowed) {
            throw new ForbiddenException('The selected session does not belong to your tenant.');
        }

        $student = Student::find($studentId);
        if ($student === null || ! $student->status->allowsAcademicActivity()) {
            throw new ConflictException('Only active students may receive academic records.');
        }

        $enrolled = $student->enrollments()
            ->where('circle_id', $session->circle_id)
            ->coveringDate($session->session_date)
            ->exists();

        if (! $enrolled) {
            throw new ForbiddenException('The student was not enrolled in the session circle.');
        }

        return $student;
    }
}
