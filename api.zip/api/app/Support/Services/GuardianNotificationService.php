<?php

namespace App\Support\Services;

use App\Models\CircleSession;
use App\Models\Student;
use App\Notifications\StudentAlertNotification;

class GuardianNotificationService
{
    /** @param array<string, mixed> $data */
    public function notifyStudentGuardians(Student $student, string $kind, array $data): void
    {
        $student->loadMissing('guardians.user');
        foreach ($student->guardians as $guardian) {
            $guardian->user?->notify(new StudentAlertNotification($kind, [
                'student_id' => $student->id,
                'student_name' => $student->name,
                ...$data,
            ]));
        }
    }

    /** @param array<string, mixed> $data */
    public function notifyCircleGuardians(CircleSession $session, string $kind, array $data = []): void
    {
        Student::whereHas('enrollments', fn ($query) => $query
            ->where('circle_id', $session->circle_id)
            ->where('status', 'active')
            ->whereNull('left_at'))
            ->chunkById(100, fn ($students) => $students->each(fn (Student $student) => $this->notifyStudentGuardians($student, $kind, [
                'circle_session_id' => $session->id,
                'session_date' => $session->session_date->toDateString(),
                ...$data,
            ])));
    }
}
