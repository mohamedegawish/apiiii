<?php

namespace App\Support\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

/**
 * Base service providing shared helpers for caching and transactions.
 *
 * All feature services extend this class to inherit a consistent
 * interface for cache-backed reads and database transactions. The
 * cache driver is resolved from the application configuration, so the
 * underlying store (file, redis) can be swapped without touching
 * business logic.
 */
abstract class BaseService
{
    /**
     * Execute a transactional unit of work and return its result.
     *
     * @template T
     *
     * @param  callable(): T  $callback
     * @return T
     */
    protected function transaction(callable $callback): mixed
    {
        return DB::transaction($callback);
    }

    /**
     * Retrieve a value from the cache, computing and storing it on miss.
     *
     * @template T
     *
     * @param  callable(): T  $callback
     * @return T
     */
    protected function remember(string $key, callable $callback, \DateTimeInterface|\DateInterval|int|null $ttl = null): mixed
    {
        return Cache::remember($key, $ttl ?? 300, $callback);
    }

    /**
     * Forget a cached value by key.
     */
    protected function forget(string $key): void
    {
        Cache::forget($key);
    }

    /**
     * Write a value into the cache for the given TTL.
     */
    protected function put(string $key, mixed $value, \DateTimeInterface|\DateInterval|int|null $ttl = null): void
    {
        Cache::put($key, $value, $ttl ?? 300);
    }

    /**
     * Forget every cached value matching the given tags, if supported.
     *
     * @param  list<string>  $tags
     */
    protected function flushTags(array $tags): void
    {
        $store = Cache::getStore();

        if (method_exists($store, 'flush')) {
            foreach ($tags as $tag) {
                Cache::forget($tag);
            }
        }
    }
}
