<?php

namespace App\Support\Response;

use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Resources\Json\ResourceCollection;
use Illuminate\Http\Response;

/**
 * Provides a consistent JSON response envelope for API controllers.
 *
 * Success envelope:
 * {
 *   "success": true,
 *   "message": "...",
 *   "data": {...},
 *   "meta": {...}
 * }
 *
 * Error envelope:
 * {
 *   "success": false,
 *   "message": "...",
 *   "error_code": "...",
 *   "errors": {...}
 * }
 */
trait ApiResponseTrait
{
    /**
     * Build a success response.
     *
     * @param  JsonResource|array<string, mixed>|null  $data
     * @param  array<string, mixed>  $meta
     */
    protected function success(
        JsonResource|array|null $data = null,
        string $message = 'OK',
        int $status = Response::HTTP_OK,
        array $meta = [],
    ): JsonResponse {
        $payload = [
            'success' => true,
            'message' => $message,
            'data' => $this->resolveData($data),
        ];

        if ($meta !== []) {
            $payload['meta'] = $meta;
        }

        return response()->json($payload, $status);
    }

    /**
     * Build a 201 Created response.
     *
     * @param  JsonResource|array<string, mixed>|null  $data
     */
    protected function created(
        JsonResource|array|null $data = null,
        string $message = 'Resource created successfully.',
    ): JsonResponse {
        return $this->success($data, $message, Response::HTTP_CREATED);
    }

    /**
     * Build a success response for a paginated collection.
     */
    protected function paginate(LengthAwarePaginator|ResourceCollection $paginator, string $message = 'OK'): JsonResponse
    {
        if ($paginator instanceof ResourceCollection) {
            $resolved = $paginator->response()->getData(true);

            $pagination = $this->extractPagination($resolved['meta'] ?? []);

            return $this->success(
                data: $resolved['data'] ?? [],
                message: $message,
                meta: ['pagination' => $pagination],
            );
        }

        $data = $paginator->toArray();

        $pagination = $this->extractPagination($data);

        return $this->success(
            data: $data['data'] ?? $data,
            message: $message,
            meta: ['pagination' => $pagination],
        );
    }

    /**
     * Build an error response.
     *
     * @param  array<string, mixed>|null  $errors
     */
    protected function error(
        string $message = 'An error occurred.',
        int $status = Response::HTTP_BAD_REQUEST,
        string $errorCode = 'error',
        ?array $errors = null,
    ): JsonResponse {
        $payload = [
            'success' => false,
            'message' => $message,
            'error_code' => $errorCode,
        ];

        if ($errors !== null) {
            $payload['errors'] = $errors;
        }

        return response()->json($payload, $status);
    }

    /**
     * Normalize the data payload into an array.
     *
     * @param  JsonResource|array<string, mixed>|null  $data
     * @return array<string, mixed>|null
     */
    protected function resolveData(JsonResource|array|null $data): ?array
    {
        if ($data instanceof JsonResource) {
            $resolved = $data->resolve();

            return is_array($resolved) ? $resolved : (array) $resolved;
        }

        return $data;
    }

    /**
     * Extract the pagination metadata from a paginated payload.
     *
     * @param  array<string, mixed>  $data
     * @return array<string, mixed>
     */
    protected function extractPagination(array $data): array
    {
        return [
            'total' => $data['total'] ?? null,
            'per_page' => $data['per_page'] ?? null,
            'current_page' => $data['current_page'] ?? null,
            'last_page' => $data['last_page'] ?? null,
            'from' => $data['from'] ?? null,
            'to' => $data['to'] ?? null,
            'has_more_pages' => ($data['current_page'] ?? 0) < ($data['last_page'] ?? 1),
        ];
    }
}
