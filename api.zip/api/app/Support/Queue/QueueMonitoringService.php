<?php

namespace App\Support\Queue;

use App\Enums\Role;
use App\Models\User;
use App\Notifications\StudentAlertNotification;
use Illuminate\Contracts\Queue\Job;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;
use Sentry\State\HubInterface;
use Throwable;

class QueueMonitoringService
{
    /** @var array<string, int> */
    private static array $startedAt = [];

    /** @var array<string, int> */
    private static array $lastAlertAt = [];

    public function recordJobStarted(string $connection, Job $job): void
    {
        self::$startedAt[$this->jobKey($connection, $job)] = hrtime(true);
    }

    public function recordJobProcessed(string $connection, Job $job): void
    {
        $key = $this->jobKey($connection, $job);
        $startedAt = self::$startedAt[$key] ?? null;
        unset(self::$startedAt[$key]);

        if ($startedAt === null) {
            return;
        }

        $durationMilliseconds = (hrtime(true) - $startedAt) / 1_000_000;
        $thresholdSeconds = max(0, (int) config('operations.queue.long_running_seconds', 60));

        if ($durationMilliseconds < $thresholdSeconds * 1000) {
            return;
        }

        $this->reportCritical('queue_job_long_running', [
            ...$this->jobContext($connection, $job),
            'duration_ms' => round($durationMilliseconds, 2),
            'threshold_seconds' => $thresholdSeconds,
        ]);
    }

    public function recordJobFailed(string $connection, Job $job, Throwable $exception): void
    {
        unset(self::$startedAt[$this->jobKey($connection, $job)]);

        $this->reportCritical('queue_job_failed', [
            ...$this->jobContext($connection, $job),
            'exception' => $exception::class,
            'exception_message' => $exception->getMessage(),
        ], $exception);
    }

    public function recordQueueBusy(string $connection, string $queue, int $size): void
    {
        $threshold = max(1, (int) config('operations.queue.busy_size', 100));

        if ($size < $threshold) {
            return;
        }

        $this->reportCritical('queue_busy', [
            'connection' => $connection,
            'queue' => $queue,
            'size' => $size,
            'threshold' => $threshold,
        ]);
    }

    /** @param array<string, mixed> $context */
    public function recordQueueStalled(array $context): void
    {
        $this->reportCritical('queue_stalled', $context);
    }

    /** @param array<string, mixed> $context */
    private function reportCritical(string $event, array $context, ?Throwable $exception = null): void
    {
        $context = ['event' => $event, ...$context];

        Log::critical('Queue operation incident', $context);
        $this->captureInSentry($event, $exception);
        $this->alertSuperAdmins($event, $context);
    }

    private function captureInSentry(string $event, ?Throwable $exception): void
    {
        if (blank(config('sentry.dsn')) || ! app()->bound(HubInterface::class)) {
            return;
        }

        try {
            $hub = app(HubInterface::class);

            if ($exception !== null) {
                $hub->captureException($exception);

                return;
            }

            $hub->captureMessage("Queue monitoring: {$event}");
        } catch (Throwable $sentryException) {
            Log::warning('Queue monitoring could not report to Sentry', [
                'event' => $event,
                'exception' => $sentryException::class,
            ]);
        }
    }

    /** @param array<string, mixed> $context */
    private function alertSuperAdmins(string $event, array $context): void
    {
        $now = time();
        $cooldown = max(0, (int) config('operations.queue.alert_cooldown_seconds', 300));

        if ($cooldown > 0 && $now - (self::$lastAlertAt[$event] ?? 0) < $cooldown) {
            return;
        }

        self::$lastAlertAt[$event] = $now;

        try {
            $recipients = User::query()
                ->where('role', Role::SuperAdmin->value)
                ->where('is_active', true)
                ->get();

            if ($recipients->isEmpty()) {
                return;
            }

            Notification::sendNow($recipients, new StudentAlertNotification('system', [
                'event' => $event,
                'message' => $this->alertMessage($event),
                'context' => $context,
            ]), ['database']);
        } catch (Throwable $notificationException) {
            Log::error('Queue monitoring could not alert super admins', [
                'event' => $event,
                'exception' => $notificationException::class,
            ]);
        }
    }

    private function alertMessage(string $event): string
    {
        return match ($event) {
            'queue_job_failed' => 'A queued job failed.',
            'queue_job_long_running' => 'A queued job exceeded the runtime threshold.',
            'queue_busy' => 'A queue exceeded the configured size threshold.',
            'queue_stalled' => 'A database queue appears to be stalled.',
            default => 'A queue operation requires attention.',
        };
    }

    /** @return array<string, mixed> */
    private function jobContext(string $connection, Job $job): array
    {
        return [
            'connection' => $connection,
            'queue' => $this->safely(fn (): ?string => $job->getQueue()),
            'job_id' => $this->safely(fn (): ?string => $job->getJobId()),
            'job_uuid' => $this->safely(fn (): ?string => $job->uuid()),
            'job_name' => $this->safely(fn (): ?string => $job->resolveName()),
            'attempts' => $this->safely(fn (): ?int => $job->attempts()),
        ];
    }

    private function jobKey(string $connection, Job $job): string
    {
        $identifier = $this->safely(fn (): ?string => $job->uuid())
            ?? $this->safely(fn (): ?string => $job->getJobId())
            ?? (string) spl_object_id($job);

        return $connection.':'.$identifier;
    }

    /**
     * @template TValue
     *
     * @param  callable(): TValue  $callback
     * @return TValue|null
     */
    private function safely(callable $callback): mixed
    {
        try {
            return $callback();
        } catch (Throwable) {
            return null;
        }
    }
}
