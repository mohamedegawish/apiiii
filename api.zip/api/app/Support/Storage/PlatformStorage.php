<?php

namespace App\Support\Storage;

use DateTimeInterface;

interface PlatformStorage
{
    public function put(string $path, string $contents, array $options = []): bool;

    public function get(string $path): string;

    public function delete(string $path): bool;

    public function exists(string $path): bool;

    public function url(string $path): string;

    public function temporaryUrl(string $path, DateTimeInterface $expiration, array $options = []): string;
}
