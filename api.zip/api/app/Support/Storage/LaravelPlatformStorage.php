<?php

namespace App\Support\Storage;

use DateTimeInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Storage;

class LaravelPlatformStorage implements PlatformStorage
{
    public function __construct(private readonly ?string $disk = null) {}

    public function put(string $path, string $contents, array $options = []): bool
    {
        return $this->filesystem()->put($path, $contents, $options);
    }

    public function get(string $path): string
    {
        return $this->filesystem()->get($path);
    }

    public function delete(string $path): bool
    {
        return $this->filesystem()->delete($path);
    }

    public function exists(string $path): bool
    {
        return $this->filesystem()->exists($path);
    }

    public function url(string $path): string
    {
        return $this->filesystem()->url($path);
    }

    public function temporaryUrl(string $path, DateTimeInterface $expiration, array $options = []): string
    {
        return $this->filesystem()->temporaryUrl($path, $expiration, $options);
    }

    private function filesystem(): Filesystem
    {
        return Storage::disk($this->disk ?? config('platform.storage.disk'));
    }
}
