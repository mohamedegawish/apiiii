<?php

namespace App\Support\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Base API resource that appends the standardized response envelope
 * to every transformed resource.
 */
abstract class BaseResource extends JsonResource
{
    /**
     * The additional data appended to every resource response.
     *
     * @return array<string, mixed>
     */
    public function with($request): array
    {
        return [
            'success' => true,
            'message' => 'OK',
        ];
    }
}
