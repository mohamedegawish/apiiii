<?php

namespace App\Support\Http\Controllers\Concerns;

use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * Shared by every report controller (operational and financial): renders a
 * paginated report either as the standard JSON envelope or, when
 * `format=csv` is requested, as a streamed CSV download — so every report
 * in the system is filterable, paginated, and exportable the same way.
 */
trait RespondsWithReport
{
    /**
     * @param  array<string, mixed>  $filters
     * @param  callable(array<string, mixed>): LengthAwarePaginator  $report
     */
    protected function respondWithReport(array $filters, string $name, callable $report): JsonResponse|StreamedResponse
    {
        $paginator = $report($filters);

        if (($filters['format'] ?? 'json') === 'csv') {
            return response()->streamDownload(function () use ($paginator): void {
                $stream = fopen('php://output', 'wb');
                $rows = $paginator->items();

                if ($stream === false || $rows === []) {
                    return;
                }

                $first = (array) $rows[0];
                fputcsv($stream, array_keys($first));

                foreach ($rows as $row) {
                    fputcsv($stream, (array) $row);
                }

                fclose($stream);
            }, $name.'-'.now()->format('Y-m-d-His').'.csv', ['Content-Type' => 'text/csv; charset=UTF-8']);
        }

        return $this->paginate($paginator, 'Report retrieved successfully.');
    }
}
