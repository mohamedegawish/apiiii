<?php

namespace App\Support\Http\Controllers;

use App\Http\Controllers\Controller as LaravelController;
use App\Support\Response\ApiResponseTrait;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

/**
 * Base controller for all API controllers.
 *
 * Provides the standardized JSON response helpers via the
 * {@see ApiResponseTrait} and a shared contract for dependency injection.
 */
abstract class BaseController extends LaravelController
{
    use ApiResponseTrait;
    use AuthorizesRequests;
}
