<?php

namespace App\Support\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Response;

/**
 * Base form request for all API requests.
 *
 * Ensures that validation and authorization failures are rendered as
 * structured JSON responses matching the API response envelope.
 */
abstract class BaseRequest extends FormRequest
{
    /**
     * Authorization is denied by default; each request must explicitly opt in.
     */
    public function authorize(): bool
    {
        return false;
    }

    /**
     * Throw a structured JSON response when validation fails.
     *
     * @throws HttpResponseException
     */
    protected function failedValidation(Validator $validator): void
    {
        throw new HttpResponseException(
            response()->json([
                'success' => false,
                'message' => 'The given data was invalid.',
                'error_code' => 'validation_failed',
                'errors' => $validator->errors()->toArray(),
            ], Response::HTTP_UNPROCESSABLE_ENTITY)
        );
    }

    /**
     * Throw a structured JSON response when authorization fails.
     *
     * @throws HttpResponseException
     */
    protected function failedAuthorization(): void
    {
        throw new HttpResponseException(
            response()->json([
                'success' => false,
                'message' => 'You do not have permission to perform this action.',
                'error_code' => 'forbidden',
            ], Response::HTTP_FORBIDDEN)
        );
    }

    /**
     * Resolve the validated data as a plain array.
     *
     * @return array<string, mixed>
     */
    public function validatedData(): array
    {
        return $this->validated();
    }
}
