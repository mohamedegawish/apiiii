<?php

namespace App\Support;

use Illuminate\Support\Carbon;

/**
 * Resolves "now" and wall-clock session times against the center's
 * configured timezone (config('itqan.timezone')), independent of
 * `app.timezone` (UTC, used for storage/logging).
 *
 * `session_date` is a date-only column and round-trips through
 * `toDateString()` unaffected by timezone, so date-only comparisons
 * ("is this date in the future?") are done as string comparisons rather
 * than via Carbon::isFuture(), which would otherwise compare against a
 * UTC midnight and misclassify the center's early morning hours as
 * belonging to the wrong calendar day.
 */
final class CenterClock
{
    public static function timezone(): string
    {
        return config('itqan.timezone', 'UTC');
    }

    public static function now(): Carbon
    {
        return Carbon::now(self::timezone());
    }

    public static function today(): Carbon
    {
        return self::now()->startOfDay();
    }

    /** The instant a date + wall-clock time represents in the center's timezone. */
    public static function moment(string $date, ?string $time = null): Carbon
    {
        return Carbon::parse($time === null ? $date : "{$date} {$time}", self::timezone());
    }

    /** Is the given date after today in the center's calendar? */
    public static function isFutureDate(Carbon|string $date): bool
    {
        $value = $date instanceof Carbon ? $date->toDateString() : Carbon::parse($date)->toDateString();

        return $value > self::today()->toDateString();
    }
}
