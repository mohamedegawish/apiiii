<?php

namespace App\Support\Actions;

/**
 * Base class for action classes.
 *
 * Actions encapsulate a single, atomic unit of business behavior. They are
 * invokable, may be injected as dependencies, and should remain focused on
 * one responsibility. Controllers orchestrate actions rather than holding
 * business logic themselves.
 */
abstract class BaseAction
{
    /**
     * Execute the action with the given arguments.
     */
    abstract public function execute(mixed ...$arguments): mixed;

    /**
     * Allow the action to be invoked as a closure.
     */
    public function __invoke(mixed ...$arguments): mixed
    {
        return $this->execute(...$arguments);
    }
}
