<?php

namespace App\Http\Middleware;

use App\Models\IdempotencyKey;
use App\Support\Exceptions\ConflictException;
use Closure;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Replay protection for unsafe requests carrying an `Idempotency-Key`.
 *
 * Two properties matter here:
 *
 * 1. The claim on a key is an INSERT, not a read-then-write. The previous
 *    implementation did SELECT ... FOR UPDATE and then INSERT, so two truly
 *    simultaneous requests both saw no row, both inserted, and the loser hit
 *    the unique index as an uncaught QueryException -- a 500. The documented
 *    409 "already being processed" branch was unreachable in exactly the race
 *    it existed to handle. The insert is now the claim, and losing it is the
 *    409.
 *
 * 2. The wrapped handler runs OUTSIDE the transaction. It used to execute
 *    inside DB::transaction(..., 3), which meant every row lock the controller
 *    took was held for the whole request, and -- worse -- a deadlock re-ran the
 *    entire controller up to three times. Anything the handler did that a
 *    rollback cannot undo (events, guardian notifications, push sends) could
 *    therefore fire three times for one logical request. Only the bookkeeping
 *    writes are transactional now; the handler manages its own transactions,
 *    as every service here already does.
 */
class EnsureIdempotency
{
    public function handle(Request $request, Closure $next): Response
    {
        $key = $request->header('Idempotency-Key');

        if (! $key || ! in_array($request->method(), ['POST', 'PUT', 'PATCH'], true)) {
            return $next($request);
        }

        $user = $request->user();

        if ($user === null) {
            return $next($request);
        }

        // The query string is part of the request's identity: two calls to the
        // same path with different filters are different operations and must
        // not replay each other's stored response.
        $hash = hash('sha256', implode('|', [
            $request->method(),
            $request->path(),
            $request->getQueryString() ?? '',
            $request->getContent(),
        ]));

        try {
            $record = IdempotencyKey::create([
                'user_id' => $user->id,
                'key' => $key,
                'request_hash' => $hash,
                'expires_at' => now()->addDay(),
            ]);
        } catch (UniqueConstraintViolationException) {
            return $this->resolveExisting($user->id, $key, $hash);
        }

        try {
            $response = $next($request);
        } catch (\Throwable $e) {
            // Leave no half-claimed key behind: a failed request must be
            // retryable under the same key.
            $record->delete();

            throw $e;
        }

        if ($response instanceof JsonResponse && $response->isSuccessful()) {
            $record->update([
                'response_status' => $response->getStatusCode(),
                'response_body' => $response->getData(true),
            ]);
        } else {
            $record->delete();
        }

        return $response;
    }

    /**
     * Someone else already holds this key: replay their answer, or explain the
     * conflict.
     */
    private function resolveExisting(string $userId, string $key, string $hash): JsonResponse
    {
        $record = IdempotencyKey::where('user_id', $userId)->where('key', $key)->first();

        // Raced with the loser's own cleanup (a failed request deletes its
        // claim). Treat as still in flight rather than silently proceeding.
        if ($record === null) {
            throw new ConflictException('The request is already being processed.', 'idempotency_in_flight');
        }

        if ($record->request_hash !== $hash) {
            throw new ConflictException(
                'The idempotency key was used with a different request.',
                'idempotency_key_reused',
            );
        }

        if ($record->response_status === null) {
            throw new ConflictException('The request is already being processed.', 'idempotency_in_flight');
        }

        return new JsonResponse($record->response_body, $record->response_status);
    }
}
