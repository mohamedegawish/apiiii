<?php

namespace App\Http\Middleware;

use App\Support\Exceptions\ForbiddenException;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Prevent deactivated users from accessing the API even when they
 * hold a valid authentication token.
 */
class EnsureUserIsActive
{
    /**
     * Handle an incoming request.
     *
     * @param  Closure(Request): (Response)  $next
     *
     * @throws ForbiddenException
     */
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user !== null && ! $user->is_active) {
            throw new ForbiddenException('Your account has been deactivated.');
        }

        return $next($request);
    }
}
