<?php

namespace App\Http\Middleware;

use App\Enums\Role;
use App\Support\Exceptions\ForbiddenException;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Restrict a route to users holding one of the allowed roles.
 *
 * Usage in routes:
 *   ->middleware('role:super_admin,center_owner')
 */
class RequireRole
{
    /**
     * Handle an incoming request.
     *
     * @param  Closure(Request): (Response)  $next
     * @param  list<string>  ...$roles
     *
     * @throws ForbiddenException
     */
    public function handle(Request $request, Closure $next, ...$roles): Response
    {
        $user = $request->user();

        if ($user === null) {
            throw new ForbiddenException('Authentication is required to access this resource.');
        }

        $allowed = [];
        foreach ($roles as $role) {
            $resolved = Role::tryFrom($role);
            if ($resolved === null) {
                throw new \LogicException("Unknown route role [{$role}].");
            }
            $allowed[] = $resolved;
        }

        $userRole = $user->roleEnum();

        if ($userRole === null || ! in_array($userRole, $allowed, true)) {
            throw new ForbiddenException('You do not have the required role to access this resource.');
        }

        return $next($request);
    }
}
