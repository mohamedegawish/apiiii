<?php

namespace App\Events;

use App\Models\MemorizationSession;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class MemorizationSessionCreated
{
    use Dispatchable, SerializesModels;

    public function __construct(
        public MemorizationSession $session,
    ) {}
}
