<?php

namespace App\Events;

use App\Models\RevisionSession;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class RevisionSessionCreated
{
    use Dispatchable, SerializesModels;

    public function __construct(
        public RevisionSession $session,
    ) {}
}
