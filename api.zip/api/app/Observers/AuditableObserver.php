<?php

namespace App\Observers;

use App\Support\Services\AuditService;
use Illuminate\Database\Eloquent\Model;

/**
 * Observes auditable models and records their lifecycle events.
 */
class AuditableObserver
{
    public function __construct(protected AuditService $auditService) {}

    /**
     * Record a "created" event for the model.
     */
    public function created(Model $model): void
    {
        if ($this->shouldAudit()) {
            $this->auditService->record(
                model: $model,
                action: 'created',
                new: $this->cleanAttributes($model),
            );
        }
    }

    /**
     * Record an "updated" event for the model.
     */
    public function updated(Model $model): void
    {
        if (! $this->shouldAudit()) {
            return;
        }

        $diff = $this->auditService->attributeDiff($model);

        if ($diff['old'] === [] && $diff['new'] === []) {
            return;
        }

        $this->auditService->record(
            model: $model,
            action: 'updated',
            old: $diff['old'],
            new: $diff['new'],
        );
    }

    /**
     * Record a "deleted" event for the model.
     */
    public function deleted(Model $model): void
    {
        if ($this->shouldAudit()) {
            $this->auditService->record(
                model: $model,
                action: 'deleted',
                old: $this->cleanAttributes($model),
            );
        }
    }

    /**
     * Record a "restored" event for the model.
     */
    public function restored(Model $model): void
    {
        if ($this->shouldAudit()) {
            $this->auditService->record(
                model: $model,
                action: 'restored',
                new: $this->cleanAttributes($model),
            );
        }
    }

    /**
     * Determine whether audit logging should occur for the current request.
     */
    protected function shouldAudit(): bool
    {
        return ! app()->runningInConsole() || app()->environment('production');
    }

    /**
     * Remove sensitive or internal attributes before logging.
     *
     * @return array<string, mixed>
     */
    protected function cleanAttributes(Model $model): array
    {
        return $model->getAttributes();
    }
}
