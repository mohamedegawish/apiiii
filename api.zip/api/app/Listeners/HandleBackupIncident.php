<?php

namespace App\Listeners;

use App\Enums\Role;
use App\Models\User;
use App\Notifications\StudentAlertNotification;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;
use Sentry\State\HubInterface;
use Spatie\Backup\Events\BackupHasFailed;
use Spatie\Backup\Events\CleanupHasFailed;
use Spatie\Backup\Events\UnhealthyBackupWasFound;
use Throwable;

class HandleBackupIncident
{
    public function handle(BackupHasFailed|CleanupHasFailed|UnhealthyBackupWasFound $event): void
    {
        $type = match (true) {
            $event instanceof BackupHasFailed => 'backup_failed',
            $event instanceof CleanupHasFailed => 'backup_cleanup_failed',
            default => 'backup_unhealthy',
        };

        $exception = property_exists($event, 'exception') ? $event->exception : null;
        Log::critical('Backup operation incident', [
            'event' => $type,
            'exception' => $exception?->getMessage(),
        ]);

        if ($exception instanceof Throwable && filled(config('sentry.dsn')) && app()->bound(HubInterface::class)) {
            app(HubInterface::class)->captureException($exception);
        }

        $admins = User::query()
            ->where('role', Role::SuperAdmin->value)
            ->where('is_active', true)
            ->get();

        if ($admins->isNotEmpty()) {
            Notification::sendNow($admins, new StudentAlertNotification('system', [
                'event' => $type,
                'message' => 'A backup operation requires immediate attention.',
            ]), ['database']);
        }
    }
}
