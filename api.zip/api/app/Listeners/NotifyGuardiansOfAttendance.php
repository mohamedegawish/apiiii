<?php

namespace App\Listeners;

use App\Enums\AttendanceStatus;
use App\Events\AttendanceRecorded;
use App\Notifications\StudentAlertNotification;
use Illuminate\Contracts\Queue\ShouldQueue;

class NotifyGuardiansOfAttendance implements ShouldQueue
{
    public int $tries = 3;

    public int $timeout = 30;

    /** @var list<int> */
    public array $backoff = [10, 60, 300];

    public function handle(AttendanceRecorded $event): void
    {
        $attendance = $event->attendance->loadMissing('student.guardians.user', 'circleSession');
        $eventType = $attendance->status === AttendanceStatus::Absent ? 'absence' : 'attendance';

        foreach ($attendance->student->guardians as $guardian) {
            $guardian->user?->notify(new StudentAlertNotification($eventType, [
                'student_id' => $attendance->student_id,
                'student_name' => $attendance->student->name,
                'circle_session_id' => $attendance->circle_session_id,
                'session_date' => $attendance->attendance_date?->toDateString(),
                'status' => $attendance->status->value,
            ]));
        }
    }
}
