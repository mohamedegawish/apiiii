<?php

namespace App\Listeners;

use App\Events\AssessmentCreated;
use App\Events\AttendanceRecorded;
use App\Events\HomeworkGraded;
use App\Events\MemorizationSessionCreated;
use App\Events\RevisionSessionCreated;
use App\Jobs\UpdateCircleStatistics;
use Illuminate\Contracts\Queue\ShouldQueue;

class DispatchCircleStatisticsUpdate implements ShouldQueue
{
    public function handle(MemorizationSessionCreated|RevisionSessionCreated|AttendanceRecorded|AssessmentCreated|HomeworkGraded $event): void
    {
        $circleId = $this->extractCircleId($event);

        if ($circleId !== null) {
            UpdateCircleStatistics::dispatch($circleId);
        }
    }

    protected function extractCircleId(object $event): ?string
    {
        return match (true) {
            $event instanceof MemorizationSessionCreated,
            $event instanceof RevisionSessionCreated => $event->session->circle_id,
            $event instanceof AttendanceRecorded => $event->attendance->circle_id,
            $event instanceof AssessmentCreated => $event->assessment->circle_id,
            $event instanceof HomeworkGraded => $event->homework->circle_id,
            default => null,
        };
    }
}
