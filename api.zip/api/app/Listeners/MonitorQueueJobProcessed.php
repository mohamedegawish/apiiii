<?php

namespace App\Listeners;

use App\Support\Queue\QueueMonitoringService;
use Illuminate\Queue\Events\JobProcessed;

class MonitorQueueJobProcessed
{
    public function __construct(private readonly QueueMonitoringService $monitor) {}

    public function handle(JobProcessed $event): void
    {
        $this->monitor->recordJobProcessed($event->connectionName, $event->job);
    }
}
