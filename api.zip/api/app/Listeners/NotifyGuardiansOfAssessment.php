<?php

namespace App\Listeners;

use App\Events\AssessmentCreated;
use App\Support\Services\GuardianNotificationService;
use Illuminate\Contracts\Queue\ShouldQueue;

class NotifyGuardiansOfAssessment implements ShouldQueue
{
    public int $tries = 3;

    public int $timeout = 30;

    /** @var list<int> */
    public array $backoff = [10, 60, 300];

    public function __construct(private readonly GuardianNotificationService $notifications) {}

    public function handle(AssessmentCreated $event): void
    {
        $assessment = $event->assessment->loadMissing('student');
        $this->notifications->notifyStudentGuardians($assessment->student, 'assessment', [
            'assessment_id' => $assessment->id,
            'grade' => $assessment->grade,
            'max_grade' => $assessment->max_grade,
        ]);
    }
}
