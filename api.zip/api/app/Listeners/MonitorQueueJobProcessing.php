<?php

namespace App\Listeners;

use App\Support\Queue\QueueMonitoringService;
use Illuminate\Queue\Events\JobProcessing;

class MonitorQueueJobProcessing
{
    public function __construct(private readonly QueueMonitoringService $monitor) {}

    public function handle(JobProcessing $event): void
    {
        $this->monitor->recordJobStarted($event->connectionName, $event->job);
    }
}
