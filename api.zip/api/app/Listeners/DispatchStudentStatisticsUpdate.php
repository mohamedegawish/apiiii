<?php

namespace App\Listeners;

use App\Events\AssessmentCreated;
use App\Events\AttendanceRecorded;
use App\Events\HomeworkGraded;
use App\Events\MemorizationSessionCreated;
use App\Events\RevisionSessionCreated;
use App\Jobs\UpdateStudentStatistics;
use Illuminate\Contracts\Queue\ShouldQueue;

class DispatchStudentStatisticsUpdate implements ShouldQueue
{
    public function handle(MemorizationSessionCreated|RevisionSessionCreated|AttendanceRecorded|AssessmentCreated|HomeworkGraded $event): void
    {
        $studentId = $this->extractStudentId($event);

        if ($studentId !== null) {
            UpdateStudentStatistics::dispatch($studentId);
        }
    }

    protected function extractStudentId(object $event): ?string
    {
        return match (true) {
            $event instanceof MemorizationSessionCreated,
            $event instanceof RevisionSessionCreated => $event->session->student_id,
            $event instanceof AttendanceRecorded => $event->attendance->student_id,
            $event instanceof AssessmentCreated => $event->assessment->student_id,
            $event instanceof HomeworkGraded => $event->homework->student_id,
            default => null,
        };
    }
}
