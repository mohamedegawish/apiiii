<?php

namespace App\Listeners;

use App\Events\AssessmentCreated;
use App\Events\AttendanceRecorded;
use App\Events\HomeworkGraded;
use App\Events\MemorizationSessionCreated;
use App\Events\RevisionSessionCreated;
use App\Jobs\UpdateTeacherStatistics;
use Illuminate\Contracts\Queue\ShouldQueue;

class DispatchTeacherStatisticsUpdate implements ShouldQueue
{
    public function handle(MemorizationSessionCreated|RevisionSessionCreated|AttendanceRecorded|AssessmentCreated|HomeworkGraded $event): void
    {
        $teacherId = $this->extractTeacherId($event);

        if ($teacherId !== null) {
            UpdateTeacherStatistics::dispatch($teacherId);
        }
    }

    protected function extractTeacherId(object $event): ?string
    {
        return match (true) {
            $event instanceof MemorizationSessionCreated,
            $event instanceof RevisionSessionCreated => $event->session->teacher_id,
            $event instanceof AttendanceRecorded => $event->attendance->teacher_id,
            $event instanceof AssessmentCreated => $event->assessment->teacher_id,
            $event instanceof HomeworkGraded => $event->homework->teacher_id,
            default => null,
        };
    }
}
