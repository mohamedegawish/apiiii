<?php

namespace App\Listeners;

use App\Support\Queue\QueueMonitoringService;
use Illuminate\Queue\Events\QueueBusy;

class MonitorQueueBusy
{
    public function __construct(private readonly QueueMonitoringService $monitor) {}

    public function handle(QueueBusy $event): void
    {
        $this->monitor->recordQueueBusy($event->connection, $event->queue, $event->size);
    }
}
