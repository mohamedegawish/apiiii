<?php

namespace App\Listeners;

use App\Support\Queue\QueueMonitoringService;
use Illuminate\Queue\Events\JobFailed;

class MonitorQueueJobFailed
{
    public function __construct(private readonly QueueMonitoringService $monitor) {}

    public function handle(JobFailed $event): void
    {
        $this->monitor->recordJobFailed($event->connectionName, $event->job, $event->exception);
    }
}
