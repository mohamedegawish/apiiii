<?php

namespace App\Providers;

use App\Events\AssessmentCreated;
use App\Events\AttendanceRecorded;
use App\Events\HomeworkGraded;
use App\Events\MemorizationSessionCreated;
use App\Events\RevisionSessionCreated;
use App\Listeners\DispatchCircleStatisticsUpdate;
use App\Listeners\DispatchStudentStatisticsUpdate;
use App\Listeners\DispatchTeacherStatisticsUpdate;
use App\Listeners\HandleBackupIncident;
use App\Listeners\MonitorQueueBusy;
use App\Listeners\MonitorQueueJobFailed;
use App\Listeners\MonitorQueueJobProcessed;
use App\Listeners\MonitorQueueJobProcessing;
use App\Listeners\NotifyGuardiansOfAssessment;
use App\Listeners\NotifyGuardiansOfAttendance;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Queue\Events\JobFailed;
use Illuminate\Queue\Events\JobProcessed;
use Illuminate\Queue\Events\JobProcessing;
use Illuminate\Queue\Events\QueueBusy;
use Spatie\Backup\Events\BackupHasFailed;
use Spatie\Backup\Events\CleanupHasFailed;
use Spatie\Backup\Events\UnhealthyBackupWasFound;

class EventServiceProvider extends ServiceProvider
{
    /**
     * @var array<class-string, list<class-string>>
     */
    protected $listen = [
        BackupHasFailed::class => [HandleBackupIncident::class],
        CleanupHasFailed::class => [HandleBackupIncident::class],
        UnhealthyBackupWasFound::class => [HandleBackupIncident::class],
        JobFailed::class => [MonitorQueueJobFailed::class],
        QueueBusy::class => [MonitorQueueBusy::class],
        JobProcessing::class => [MonitorQueueJobProcessing::class],
        JobProcessed::class => [MonitorQueueJobProcessed::class],
        MemorizationSessionCreated::class => [
            DispatchStudentStatisticsUpdate::class,
            DispatchTeacherStatisticsUpdate::class,
            DispatchCircleStatisticsUpdate::class,
        ],
        RevisionSessionCreated::class => [
            DispatchStudentStatisticsUpdate::class,
            DispatchTeacherStatisticsUpdate::class,
            DispatchCircleStatisticsUpdate::class,
        ],
        AttendanceRecorded::class => [
            DispatchStudentStatisticsUpdate::class,
            DispatchTeacherStatisticsUpdate::class,
            DispatchCircleStatisticsUpdate::class,
            NotifyGuardiansOfAttendance::class,
        ],
        AssessmentCreated::class => [
            DispatchStudentStatisticsUpdate::class,
            DispatchTeacherStatisticsUpdate::class,
            DispatchCircleStatisticsUpdate::class,
            NotifyGuardiansOfAssessment::class,
        ],
        HomeworkGraded::class => [
            DispatchStudentStatisticsUpdate::class,
            DispatchTeacherStatisticsUpdate::class,
            DispatchCircleStatisticsUpdate::class,
        ],
    ];
}
