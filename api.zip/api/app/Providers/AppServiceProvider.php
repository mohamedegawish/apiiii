<?php

namespace App\Providers;

use App\Support\Exceptions\ConflictException;
use App\Support\Services\AuditService;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;
use Illuminate\Validation\ValidationException;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->scoped(AuditService::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Keyed on whichever identifier was actually submitted. Keying on
        // `email` alone put every mobile and student_code login into one shared
        // empty-string bucket per IP, while an attacker who varied `email`
        // sidestepped the limit entirely. The second, IP-independent limit stops
        // a distributed attack from grinding one account.
        RateLimiter::for('login', function (Request $request): array {
            $identifier = mb_strtolower(trim((string) (
                $request->input('email')
                ?? $request->input('mobile')
                ?? $request->input('student_code')
                ?? ''
            )));

            $tooMany = function (): JsonResponse {
                return response()->json([
                    'success' => false,
                    'message' => 'Too many login attempts. Please try again later.',
                    'error_code' => 'too_many_requests',
                ], 429);
            };

            return [
                Limit::perMinute(5)->by('login-ip:'.$request->ip().'|'.$identifier)->response($tooMany),
                Limit::perMinute(10)->by('login-id:'.$identifier)->response($tooMany),
            ];
        });

        RateLimiter::for('api', function (Request $request): Limit {
            return Limit::perMinute(60)->by($request->user()?->id ?: $request->ip());
        });

        RateLimiter::for('otp', fn (Request $request): array => [
            Limit::perMinute(5)->by('otp:'.$request->ip()),
            Limit::perHour(20)->by('otp-email:'.mb_strtolower((string) $request->input('email'))),
        ]);

        RateLimiter::for('password-reset', fn (Request $request): array => [
            Limit::perMinute(3)->by('reset:'.$request->ip()),
            Limit::perHour(10)->by('reset-email:'.mb_strtolower((string) $request->input('email'))),
        ]);

        RateLimiter::for('notifications', fn (Request $request): Limit => Limit::perMinute(60)->by('notifications:'.$request->user()?->id));
        RateLimiter::for('device-registration', fn (Request $request): Limit => Limit::perMinute(10)->by('devices:'.$request->user()?->id));
        // Password-confirmed and irreversible: few attempts, so a stolen token
        // cannot be used to grind the password through this endpoint.
        RateLimiter::for('account-deletion', fn (Request $request): Limit => Limit::perMinute(5)->by('account-deletion:'.$request->user()?->id));
        RateLimiter::for('sensitive-write', fn (Request $request): Limit => Limit::perMinute(30)->by('write:'.$request->user()?->id));
        RateLimiter::for('audit-read', fn (Request $request): Limit => Limit::perMinute(30)->by('audit:'.$request->user()?->id));
        RateLimiter::for('health', fn (Request $request): Limit => Limit::perMinute(12)->by('health:'.$request->user()?->id));

        // Client-cooperative optimistic locking: a caller that sends
        // `last_updated_at` is told 409 rather than silently overwriting an
        // edit made since it read the record. Six admin_app screens send it.
        //
        // Registered as a wildcard event listener, NOT as Model::updating().
        // Calling that on the abstract base class registers a listener for
        // "eloquent.updating: Illuminate\Database\Eloquent\Model", while
        // Eloquent dispatches "eloquent.updating: App\Models\Homework" -- so
        // the previous hook here never fired for any model, and this whole
        // feature was silently inert.
        //
        // Scoped to the record the route is actually about, so a write made as
        // a side effect (a learning-record update also grades its linked
        // Homework) is not compared against the subject's timestamp.
        Event::listen('eloquent.updating: *', function (string $eventName, array $payload): void {
            $model = $payload[0] ?? null;

            if (! $model instanceof Model) {
                return;
            }

            $request = request();

            if (! $request?->has('last_updated_at')) {
                return;
            }

            $route = $request->route();

            if ($route === null || ! $this->isRouteSubject($route->parameters(), $model)) {
                return;
            }

            try {
                $clientTime = Carbon::parse((string) $request->input('last_updated_at'));
            } catch (\Throwable) {
                // A malformed timestamp is a client error, not a 500.
                throw new ValidationException(validator([], []), response()->json([
                    'success' => false,
                    'message' => 'The given data was invalid.',
                    'error_code' => 'validation_failed',
                    'errors' => ['last_updated_at' => ['The last updated at field must be a valid date.']],
                ], 422));
            }

            $serverTime = $model->getOriginal('updated_at');

            if ($serverTime && $serverTime->gt($clientTime)) {
                throw new ConflictException('Stale resource: the server has a newer version.', 'stale_resource');
            }
        });
    }

    /**
     * Whether $model is the very record this route resolved, rather than one
     * written as a side effect of handling it.
     *
     * @param  array<string, mixed>  $parameters
     */
    private function isRouteSubject(array $parameters, Model $model): bool
    {
        $key = (string) $model->getKey();

        foreach ($parameters as $parameter) {
            // Controllers here are split between route-model binding and taking
            // a raw string id, so both shapes have to be recognised -- matching
            // only bound models would silently disable the lock on every
            // controller that resolves the record itself.
            if ($parameter instanceof Model) {
                if ($parameter::class === $model::class && (string) $parameter->getKey() === $key) {
                    return true;
                }

                continue;
            }

            if ((is_string($parameter) || is_int($parameter)) && (string) $parameter === $key) {
                return true;
            }
        }

        return false;
    }
}
