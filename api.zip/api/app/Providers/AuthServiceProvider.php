<?php

namespace App\Providers;

use App\Enums\Role;
use App\Features\Assessments\Policies\AssessmentPolicy;
use App\Features\Attendance\Policies\AttendancePolicy;
use App\Features\AuditLogs\Policies\AuditLogPolicy;
use App\Features\Circles\Policies\CirclePolicy;
use App\Features\CircleSchedules\Policies\CircleSchedulePolicy;
use App\Features\CircleSessions\Policies\CircleSessionPolicy;
use App\Features\Guardians\Policies\GuardianPolicy;
use App\Features\Homework\Policies\HomeworkPolicy;
use App\Features\LearningRecords\Policies\LearningRecordPolicy;
use App\Features\MatnCatalog\Policies\MatnCatalogPolicy;
use App\Features\MemorizationSessions\Policies\MemorizationSessionPolicy;
use App\Features\Parent\Policies\ParentEvaluationPolicy;
use App\Features\Reports\Policies\MonthlyProgressPolicy;
use App\Features\RevisionSessions\Policies\RevisionSessionPolicy;
use App\Features\Students\Policies\StudentPolicy;
use App\Features\Teachers\Policies\TeacherPolicy;
use App\Features\Users\Policies\UserPolicy;
use App\Models\Assessment;
use App\Models\Attendance;
use App\Models\AuditLog;
use App\Models\Circle;
use App\Models\CircleSchedule;
use App\Models\CircleSession;
use App\Models\Guardian;
use App\Models\Homework;
use App\Models\MatnType;
use App\Models\MemorizationSession;
use App\Models\MonthlyProgressRecord;
use App\Models\ParentEvaluation;
use App\Models\RevisionSession;
use App\Models\Student;
use App\Models\StudentLearningRecord;
use App\Models\Teacher;
use App\Models\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * Register any application authorization policies, gates, and the
     * super-admin bypass.
     */
    public function boot(): void
    {
        /**
         * Super admins bypass every authorization check. This callback
         * runs before any gate or policy evaluation.
         */
        Gate::before(function ($user, string $ability): ?bool {
            if ($user?->isSuperAdmin()) {
                return true;
            }

            return null;
        });

        $this->registerPolicies();

        /**
         * Foundation gates.
         */
        Gate::define('manage-users', fn ($user): bool => $user->hasRole(Role::SuperAdmin, Role::CenterOwner));

        Gate::define('view-audit-logs', fn ($user): bool => $user->hasRole(Role::SuperAdmin, Role::CenterOwner));
    }

    /**
     * Register the model-to-policy mappings for all feature modules.
     */
    protected function registerPolicies(): void
    {
        Gate::policy(Guardian::class, GuardianPolicy::class);
        Gate::policy(Teacher::class, TeacherPolicy::class);
        Gate::policy(Student::class, StudentPolicy::class);
        Gate::policy(MonthlyProgressRecord::class, MonthlyProgressPolicy::class);
        Gate::policy(Circle::class, CirclePolicy::class);
        Gate::policy(CircleSchedule::class, CircleSchedulePolicy::class);
        Gate::policy(MemorizationSession::class, MemorizationSessionPolicy::class);
        Gate::policy(RevisionSession::class, RevisionSessionPolicy::class);
        Gate::policy(Attendance::class, AttendancePolicy::class);
        Gate::policy(Assessment::class, AssessmentPolicy::class);
        Gate::policy(Homework::class, HomeworkPolicy::class);
        Gate::policy(CircleSession::class, CircleSessionPolicy::class);
        Gate::policy(StudentLearningRecord::class, LearningRecordPolicy::class);
        Gate::policy(MatnType::class, MatnCatalogPolicy::class);
        Gate::policy(ParentEvaluation::class, ParentEvaluationPolicy::class);
        Gate::policy(User::class, UserPolicy::class);
        Gate::policy(AuditLog::class, AuditLogPolicy::class);
    }
}
