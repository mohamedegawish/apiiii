<?php

namespace App\Providers;

use App\Support\Storage\LaravelPlatformStorage;
use App\Support\Storage\PlatformStorage;
use Illuminate\Support\ServiceProvider;

class PlatformStorageServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(config_path('platform.php'), 'platform');

        if (config('filesystems.disks.r2') === null) {
            config()->set('filesystems.disks.r2', config('platform.storage.r2'));
        }

        $this->app->singleton(
            PlatformStorage::class,
            fn (): LaravelPlatformStorage => new LaravelPlatformStorage(config('platform.storage.disk')),
        );
    }
}
