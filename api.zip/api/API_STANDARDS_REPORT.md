# API Standards Report

**Audit Date:** 2026-07-13  

---

## Executive Summary

The API follows consistent standards with all routes versioned under `/api/v1/`, a standardized JSON response envelope, API Resources for transformation, and Form Requests for validation. Two issues were found and fixed.

| Check | Status | Notes |
|-------|--------|-------|
| API Versioning | ✓ | All routes under `/api/v1/` |
| API Resources | ✓ | 14 resources, all list endpoints now use Resource Collections (fixed) |
| Form Requests | ✓ | 25 form requests with structured validation responses |
| Consistent JSON Responses | ✓ | Standardized envelope via `ApiResponseTrait` |
| Proper HTTP Status Codes | ✓ | 200, 201, 401, 403, 404, 405, 422, 429, 500 |
| Error Codes | ✓ | `unauthenticated`, `forbidden`, `not_found`, `validation_failed`, `too_many_requests`, etc. |
| No routes outside versioned structure | ✓ | All API routes in `routes/api/v1/` |

---

## API Versioning

**Status: COMPLIANT**

```
routes/
├── api.php              → Route::prefix('v1')->group(...)
├── api/
│   ├── v1.php           → Aggregates 15 feature route files
│   └── v1/              → Per-feature route files
```

All 71 routes are prefixed with `/api/v1/`. No routes exist outside the versioned structure. The `api.php` entry point automatically prefixes with `/api` (Laravel's API routing), and the `v1.php` file adds the `v1` prefix.

---

## Response Envelope

**Status: COMPLIANT**

### Success Response
```json
{
  "success": true,
  "message": "Resource retrieved successfully.",
  "data": { ... },
  "meta": {
    "pagination": {
      "total": 100,
      "per_page": 15,
      "current_page": 1,
      "last_page": 7,
      "from": 1,
      "to": 15,
      "has_more_pages": true
    }
  }
}
```

### Error Response
```json
{
  "success": false,
  "message": "The given data was invalid.",
  "error_code": "validation_failed",
  "errors": { ... }
}
```

### Standard Error Codes
| Error Code | HTTP Status | Scenario |
|------------|-------------|----------|
| `unauthenticated` | 401 | No valid token |
| `forbidden` | 403 | Policy denied (fixed) |
| `not_found` | 404 | Resource not found |
| `route_not_found` | 404 | Route doesn't exist |
| `method_not_allowed` | 405 | Wrong HTTP method |
| `validation_failed` | 422 | Invalid input data |
| `too_many_requests` | 429 | Rate limit exceeded (fixed) |
| `http_error` | various | Other HTTP errors |
| `internal_error` | 500 | Unexpected error |

---

## Issues Found & Fixed

### S1: List Endpoints Not Using Resource Collections (FIXED)
**Before:** Controllers passed `LengthAwarePaginator` directly to `paginate()`, which called `$paginator->toArray()` exposing ALL model attributes without resource transformation.

**After:** All 12 controllers now wrap paginators in `Resource::collection()`. The `ApiResponseTrait::paginate()` was updated to correctly extract pagination metadata from `ResourceCollection` responses (which nest it under `meta`).

### S2: AuthorizationException Rendered as http_error (FIXED)
**Before:** Laravel converts `AuthorizationException` to `AccessDeniedHttpException` before custom renderers run. Controller-level `$this->authorize()` failures were rendered as `http_error` instead of `forbidden`.

**After:** Added `AccessDeniedHttpException` case to `ApiExceptionRenderer` before the `HttpException` fallback.

---

## API Resource Usage

**Status: COMPLIANT**

All 14 resources extend `BaseResource` which provides the `success`/`message` envelope via `with()`.

| Resource | Fields Exposed | Role-Based Visibility |
|----------|---------------|----------------------|
| UserResource | 8 fields | No restrictions |
| TokenResource | 4 fields | Intentional plaintext token at login only |
| CenterResource | 12 fields | No restrictions |
| BranchResource | 9 fields | No restrictions |
| GuardianResource | 9 fields | No restrictions |
| TeacherResource | 11 base + 5 salary | Salary fields hidden from non-admins (fixed) |
| StudentResource | 9 base + 5 PII | PII hidden from teachers (fixed) |
| CircleResource | 13 fields | No restrictions |
| CircleScheduleResource | 9 fields | No restrictions |
| MemorizationSessionResource | 15 fields | No restrictions |
| RevisionSessionResource | 15 fields | No restrictions |
| AttendanceResource | 10 fields | No restrictions |
| AssessmentResource | 16 fields | No restrictions |
| HomeworkResource | 17 fields | No restrictions |

---

## Form Request Usage

**Status: COMPLIANT**

All 25 form requests extend `BaseRequest` which provides:
- Deny-by-default authorization (`authorize()` returns `false`)
- Structured 422 JSON on validation failure
- Structured 403 JSON on authorization failure
- `validatedData()` helper for clean access to validated input

All store/update endpoints inject their form request type. The `authorize()` method in each form request checks the appropriate policy (`create` or `update`).

---

## HTTP Status Code Usage

| Status | Usage | Compliant |
|--------|-------|-----------|
| 200 OK | GET, PUT, DELETE success | ✓ |
| 201 Created | POST success | ✓ |
| 401 Unauthorized | No/invalid token | ✓ |
| 403 Forbidden | Policy denied | ✓ (fixed) |
| 404 Not Found | Resource not found | ✓ |
| 405 Method Not Allowed | Wrong HTTP method | ✓ |
| 422 Unprocessable Entity | Validation error | ✓ |
| 429 Too Many Requests | Rate limit exceeded | ✓ (fixed) |
| 500 Internal Server Error | Unexpected error | ✓ |

---

## Recommendations

1. **Quran endpoints should use a controller** — The 2 Quran routes use inline closures instead of a proper controller with resource transformation. This is inconsistent with the feature-based architecture.

2. **Update form requests cause double model loading** — `Update*Request::authorize()` loads the model, then the controller calls `findOrFail()` again. Consider route-model binding or passing the model from the form request.

3. **Consider API documentation generation** — Add Scribe or OpenAPI/Swagger documentation generation for the 71 endpoints.
