<?php

require 'vendor/autoload.php';
$app = require_once 'bootstrap/app.php';
$app->loadEnvironmentFrom('.env.concurrency_test');
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;
use App\Models\Guardian;
use App\Models\Student;
use App\Models\Circle;
use App\Models\CircleSession;
use Illuminate\Support\Str;

$guardianUser = User::factory()->create(['role' => 'guardian']);
$guardian = Guardian::factory()->create(['user_id' => $guardianUser->id]);

$studentUser = User::factory()->create(['role' => 'student']);
$student = Student::factory()->create(['user_id' => $studentUser->id]);

$guardian->children()->attach($student->id, ['id' => (string) Str::uuid(), 'relationship' => 'father', 'is_primary' => true]);

$circle = Circle::factory()->create();
$circle->students()->attach($student->id, ['id' => (string) Str::uuid(), 'status' => 'active']);

$session = CircleSession::factory()->create([
    'circle_id' => $circle->id,
    'status' => 'completed'
]);

$plainTextToken = 'guardian_token_123';
$guardianUser->tokens()->delete();
$token = $guardianUser->createToken('test-token')->plainTextToken;

$baseUrl = 'http://127.0.0.1:8001/api/v1';

function runConcurrentRequests($requests, $token) {
    $multiHandle = curl_multi_init();
    $curlHandles = [];

    foreach ($requests as $i => $req) {
        $ch = curl_init($req['url']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Accept: application/json',
            'Content-Type: application/json'
        ];
        if (isset($req['headers'])) {
            $headers = array_merge($headers, $req['headers']);
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        
        if ($req['method'] === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($req['payload']));
        } elseif ($req['method'] === 'PUT') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($req['payload']));
        }
        curl_multi_add_handle($multiHandle, $ch);
        $curlHandles[$i] = $ch;
    }

    $running = null;
    do {
        curl_multi_exec($multiHandle, $running);
        curl_multi_select($multiHandle);
    } while ($running > 0);

    $results = [];
    foreach ($curlHandles as $i => $ch) {
        $results[$i] = [
            'status' => curl_getinfo($ch, CURLINFO_HTTP_CODE),
            'body' => curl_multi_getcontent($ch)
        ];
        curl_multi_remove_handle($multiHandle, $ch);
    }
    curl_multi_close($multiHandle);
    return $results;
}


// Test 1: Idempotency with exact same key (10 concurrent requests)
echo "\n--- TEST 1: Idempotency (Same Key, Concurrent) ---\n";
$idempotencyKey = uniqid('idem_', true);
$payload = [
    'circle_session_id' => $session->id,
    'student_id' => $student->id,
    'behavior_score' => 5,
    'prayer_score' => 4,
    'homework_followup_score' => 3,
    'notes' => 'Test concurrency'
];
$requests = [];
for ($i=0; $i<10; $i++) {
    $requests[] = [
        'url' => $baseUrl . '/parent/evaluations',
        'method' => 'POST',
        'headers' => ['Idempotency-Key: ' . $idempotencyKey],
        'payload' => $payload
    ];
}

$results = runConcurrentRequests($requests, $token);
$successes = 0;
$conflicts = 0;

foreach ($results as $i => $res) {
    if ($res['status'] == 201 || $res['status'] == 200) {
        $successes++;
    } elseif ($res['status'] == 409) {
        $conflicts++;
    } else {
        echo "Unexpected status {$res['status']} on request $i: {$res['body']}\n";
    }
}
echo "Successes: $successes, Conflicts: $conflicts\n";
if ($successes == 1 && $conflicts == 9) {
    echo "PASS_DYNAMIC: Idempotency prevented duplicate execution perfectly.\n";
} else {
    echo "FAIL_DYNAMIC: Idempotency failed. Successes=$successes, Conflicts=$conflicts\n";
}

$count = \App\Models\ParentEvaluation::where('circle_session_id', $session->id)
    ->where('student_id', $student->id)->count();
echo "DB Records for this session/student: $count\n";

