<?php

return [
    'version' => env('APP_VERSION', '1.0.0'),

    'storage' => [
        'disk' => env('PLATFORM_STORAGE_DISK', env('FILESYSTEM_DISK', 'local')),

        'r2' => [
            'driver' => 's3',
            'key' => env('R2_ACCESS_KEY_ID'),
            'secret' => env('R2_SECRET_ACCESS_KEY'),
            'region' => env('R2_REGION', 'auto'),
            'bucket' => env('R2_BUCKET'),
            'url' => env('R2_URL'),
            'endpoint' => env('R2_ENDPOINT'),
            'use_path_style_endpoint' => env('R2_USE_PATH_STYLE_ENDPOINT', false),
            'throw' => true,
            'report' => true,
        ],
    ],
];
