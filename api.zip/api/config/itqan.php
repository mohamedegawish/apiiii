<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Center Timezone
    |--------------------------------------------------------------------------
    |
    | circle_sessions.session_date / start_time / end_time are wall-clock
    | values entered by staff for a physical Quran circle — they mean
    | "4pm at the center", not "4pm UTC". `app.timezone` stays UTC for
    | storage/logging; this value is used wherever a session's date or
    | time needs to be compared against "now" from the center's point of
    | view (starting a session, attendance/record writability windows,
    | daily session generation).
    |
    */

    'timezone' => env('ITQAN_TIMEZONE', 'Africa/Cairo'),

];
