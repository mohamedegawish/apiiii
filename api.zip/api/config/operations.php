<?php

return [
    'queue' => [
        'long_running_seconds' => (int) env('QUEUE_LONG_RUNNING_SECONDS', 60),
        'busy_size' => (int) env('QUEUE_BUSY_SIZE', 100),
        'stall_size' => (int) env('QUEUE_STALL_SIZE', 1),
        'stall_age_seconds' => (int) env('QUEUE_STALL_AGE_SECONDS', 300),
        'alert_cooldown_seconds' => (int) env('QUEUE_ALERT_COOLDOWN_SECONDS', 300),
    ],
];
