<?php
require 'vendor/autoload.php';
$app = require_once 'bootstrap/app.php';
$app->loadEnvironmentFrom('.env');
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$studentId = \App\Models\Student::first()->id;

$stats = \DB::table('student_statistics')->where('student_id', $studentId)->get();
echo "Student Statistics Records: " . $stats->count() . "\n";
foreach ($stats as $stat) {
    echo "Total Parent Evals: {$stat->total_parent_evaluations}\n";
    echo "Avg Behavior: {$stat->avg_behavior}\n";
}

$failed = \DB::table('failed_jobs')->count();
echo "Failed Jobs: $failed\n";

$pending = \DB::table('jobs')->count();
echo "Pending Jobs: $pending\n";
